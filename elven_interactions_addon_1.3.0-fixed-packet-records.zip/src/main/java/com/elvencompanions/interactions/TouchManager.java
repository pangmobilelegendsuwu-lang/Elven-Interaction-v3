package com.elvencompanions.interactions;

import com.elvencompanions.data.ElfManager;
import com.elvencompanions.entity.ElfEntity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Touch mode, fully server-authoritative. The server raycasts from the player's eye to find the targeted body zone and
 * reads the player's own look deltas to tell a calm hold from a head-pat motion from rough yanking; the client only
 * reports "right-click held / released". A comfort meter (0..100, starts at 50) drives the elf's reactions:
 *  - it drifts back toward a baseline that rises with the bond level,
 *  - below {@link #lockLow()} the elf pulls away and touching is refused until it recovers to {@link #lockHigh()},
 *  - pressing anyway while she is refusing costs more comfort (so the meter CAN reach 0),
 *  - at 0 she lashes out once: bond loss, a single light hit on the owner, session ends, short sulk (touch lockout).
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME)
public final class TouchManager {
    /** Defaults (config overrides at runtime through the accessors below). */
    public static final float DEFAULT_START = 50f;

    public static float start() {
        return Cfg.COMMON.comfortStart.get();
    }

    public static float lockLow() {
        return Cfg.COMMON.lockBelow.get();
    }

    public static float lockHigh() {
        return Math.max(lockLow() + 1f, Cfg.COMMON.unlockAt.get());
    }

    private static final float REACH = 3.2f;
    private static final int MAX_TICKS = 20 * 60 * 5;
    private static final double MAX_DRIFT_SQ = 1.5 * 1.5;

    private static final class Session {
        final UUID player;
        final UUID elfId;
        final int elfEntityId;
        final Vec3 anchor;
        final int startTick;
        float comfort = start();
        boolean locked;
        boolean holding;
        TouchZone zone;
        boolean left;
        TouchGesture gesture = TouchGesture.NONE;
        float lastYaw;
        float lastPitch;
        float speed;
        int lastDir;
        int revCount;
        int lastRev = -1000;
        int lastLine = -1000;
        TouchZone spokenZone;
        TouchGesture spokenGesture = TouchGesture.NONE;
        int goodTicks;
        int affectionGained;

        Session(UUID player, UUID elfId, int elfEntityId, Vec3 anchor, int startTick) {
            this.player = player;
            this.elfId = elfId;
            this.elfEntityId = elfEntityId;
            this.anchor = anchor;
            this.startTick = startTick;
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    private TouchManager() {}

    public static boolean isActive(UUID player) {
        return SESSIONS.containsKey(player);
    }

    // ------------------------------------------------------------------ start / input

    public static void start(ServerPlayer p, ElfEntity elf) {
        if (elf == null || elf.getCompanionId() == null || !Cfg.COMMON.touchEnabled.get()) return;
        UUID id = p.getUUID();
        if (SESSIONS.containsKey(id) || InteractionManager.isActive(id)) return;
        UUID elfId = elf.getCompanionId();
        MinecraftServer server = p.server;
        if (elf.level() != p.level() || elf.distanceToSqr(p) > 3.5 * 3.5) {
            fail(p, "interact.fail.too_far");
            return;
        }
        if (!p.onGround() || p.isPassenger() || p.isSleeping() || p.isSwimming() || p.isFallFlying() || p.isUsingItem()) {
            fail(p, "interact.fail.player_busy");
            return;
        }
        if (!InteractionManager.elfAvailable(elf)) {
            fail(p, "interact.fail.elf_busy");
            return;
        }
        BondData bond = BondData.get(server);
        if (bond.touchLockEnd(elfId) > server.overworld().getGameTime()) {
            fail(p, "touch.sulking");
            return;
        }
        InteractionManager.placeElfInFront(p, elf, 1.5f);
        Session s = new Session(id, elfId, elf.getId(), p.position(), server.getTickCount());
        s.lastYaw = p.getYRot();
        s.lastPitch = p.getXRot();
        SESSIONS.put(id, s);
        ModeGuard.Holder.get().enter(p);
        InteractionManager.hold(elf, p);
        TouchDialogue.line(elf, "touch_start_" + TouchDialogue.tier(bond.level(elfId)));
        s.lastLine = server.getTickCount();
        sendState(p, s, true);
    }

    /** Client reports right-click held/released. A fresh press while she is refusing is penalised. */
    public static void setHolding(ServerPlayer p, boolean holding) {
        Session s = SESSIONS.get(p.getUUID());
        if (s == null) return;
        boolean press = holding && !s.holding;
        s.holding = holding;
        if (press && s.locked && s.zone != null) {
            s.comfort = Math.max(0f, s.comfort - Cfg.COMMON.pressWhileRefusedPenalty.get());
            ElfEntity elf = ElfManager.LOADED.get(s.elfId);
            int tick = p.server.getTickCount();
            if (elf != null && tick - s.lastLine >= 15) {
                TouchDialogue.line(elf, "touch_protest");
                s.lastLine = tick;
            }
        }
    }

    public static void cancel(ServerPlayer p) {
        Session s = SESSIONS.get(p.getUUID());
        if (s != null) end(p.server, s, p, true);
    }

    private static void fail(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable("message.elven_companions." + key), true);
    }

    // ------------------------------------------------------------------ end

    private static void end(MinecraftServer server, Session s, ServerPlayer known, boolean online) {
        if (!SESSIONS.remove(s.player, s)) return;
        ServerPlayer p = known != null ? known : server.getPlayerList().getPlayer(s.player);
        if (p != null) {
            ModeGuard.Holder.get().exit(p, online);
            if (online) sendState(p, s, false);
        }
    }

    private static void rebel(MinecraftServer server, Session s, ServerPlayer p, ElfEntity elf) {
        BondData bond = BondData.get(server);
        UUID id = s.elfId;
        int loss = Math.max(Cfg.COMMON.rebelBondLossMin.get(),
                Math.round(bond.affection(id) * Cfg.COMMON.rebelBondLossPercent.get() / 100f));
        bond.add(id, -loss);
        bond.setTouchLock(id, server.overworld().getGameTime() + 20L * Cfg.COMMON.rebelLockoutSeconds.get());
        TouchDialogue.single(elf, "touch_rebel_a");
        end(server, s, p, true); // end FIRST so the hit below cannot re-enter this session
        elf.swing(InteractionHand.MAIN_HAND);
        float dmg = Math.min(Cfg.COMMON.rebelDamage.get().floatValue(), Math.max(0f, p.getHealth() - 1.0F));
        if (dmg > 0f) p.hurt(elf.damageSources().mobAttack(elf), dmg);
        p.knockback(0.5, elf.getX() - p.getX(), elf.getZ() - p.getZ());
        p.hurtMarked = true;
        if (Cfg.COMMON.sounds.get()) {
            elf.level().playSound(null, elf.getX(), elf.getY(), elf.getZ(), SoundEvents.PLAYER_ATTACK_STRONG,
                    SoundSource.NEUTRAL, 0.8F, 1.0F);
        }
        p.sendSystemMessage(Component.translatable("message.elven_companions.touch.rebel", elf.getDisplayName()));
        InteractionManager.sendBond(p, elf);
    }

    // ------------------------------------------------------------------ per-tick

    private static TouchZone.Hit hover(ServerPlayer p, ElfEntity elf) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        if (ElfMesh.available()) {
            // real geometry from the elf's own OBJ (rest pose)
            return ElfMesh.raycast(elf.getX(), elf.getY(), elf.getZ(), elf.yBodyRot,
                    eye.x, eye.y, eye.z, look.x, look.y, look.z, REACH);
        }
        // fallback: height-fraction bands on the bounding box
        Vec3 end = eye.add(look.scale(REACH));
        AABB box = elf.getBoundingBox().inflate(0.12, 0.0, 0.12);
        Optional<Vec3> hit = box.clip(eye, end);
        return hit.isPresent() ? TouchZone.classify(elf, hit.get()) : null;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        if (SESSIONS.isEmpty()) return;
        MinecraftServer server = e.getServer();
        BondData bond = BondData.get(server);
        int tick = server.getTickCount();
        for (Session s : new ArrayList<>(SESSIONS.values())) {
            ServerPlayer p = server.getPlayerList().getPlayer(s.player);
            ElfEntity elf = ElfManager.LOADED.get(s.elfId);
            if (p == null || !p.isAlive() || p.isRemoved() || elf == null || !elf.isAlive() || elf.isRemoved()
                    || elf.level() != p.level()) {
                end(server, s, p, p != null);
                continue;
            }
            if (p.position().distanceToSqr(s.anchor) > MAX_DRIFT_SQ || elf.distanceToSqr(p) > 3.5 * 3.5
                    || p.isPassenger() || p.isSleeping() || elf.isBusyForMovement() || elf.getTarget() != null
                    || tick - s.startTick > MAX_TICKS) {
                end(server, s, p, true);
                continue;
            }
            InteractionManager.hold(elf, p);
            int level = bond.level(s.elfId);

            // what is the player pointing at?
            TouchZone.Hit hit = hover(p, elf);
            s.zone = hit == null ? null : hit.zone();
            s.left = hit != null && hit.left();

            // how are they moving? (the player's own look deltas, not client-reported)
            float dy = Mth.wrapDegrees(p.getYRot() - s.lastYaw);
            float dp = p.getXRot() - s.lastPitch;
            s.lastYaw = p.getYRot();
            s.lastPitch = p.getXRot();
            s.speed = s.speed * 0.8f + (float) Math.sqrt(dy * dy + dp * dp) * 0.2f;
            int dir = Math.abs(dy) > 0.35f ? (dy > 0 ? 1 : -1) : 0;
            if (dir != 0) {
                if (s.lastDir != 0 && dir != s.lastDir) {
                    s.revCount = (tick - s.lastRev > 30) ? 1 : s.revCount + 1;
                    s.lastRev = tick;
                }
                s.lastDir = dir;
            }

            boolean touching = s.holding && !s.locked && s.zone != null;
            TouchGesture g = TouchGesture.NONE;
            if (touching) {
                g = TouchGesture.HOLD;
                if (s.zone == TouchZone.HEAD && s.revCount >= 2 && tick - s.lastRev <= 25 && s.speed < 5.5f) {
                    g = TouchGesture.PAT;
                }
                if (s.speed > 10f || (s.revCount >= 3 && tick - s.lastRev <= 20 && s.speed > 7f)) {
                    g = TouchGesture.ROUGH;
                }
            }
            s.gesture = g;

            // comfort
            float rate = 0f;
            float c = s.comfort;
            if (touching) {
                rate = g == TouchGesture.ROUGH ? TouchZone.scaled(-7f) : g == TouchGesture.PAT ? TouchZone.patRate(level) : s.zone.rate(level);
                c += rate / 20f;
            } else {
                float base = start() + 10f * level;
                float up = s.locked ? 2.0f : 1.2f;
                if (c < base) c = Math.min(base, c + up / 20f);
                else if (c > base) c = Math.max(base, c - 0.4f / 20f);
            }
            s.comfort = Mth.clamp(c, 0f, 100f);

            if (!s.locked && s.comfort < lockLow()) {
                s.locked = true;
                TouchDialogue.line(elf, "touch_pullaway");
                s.lastLine = tick;
            } else if (s.locked && s.comfort >= lockHigh()) {
                s.locked = false;
                TouchDialogue.single(elf, "touch_recover_a");
                s.lastLine = tick;
            }
            if (s.comfort <= 0f) {
                if (Cfg.COMMON.rebelEnabled.get()) {
                    rebel(server, s, p, elf);
                    continue;
                }
                s.comfort = 0.5f; // rebelling disabled: she just keeps refusing
            }

            // dialogue while touching: on a change of zone/gesture, otherwise now and then
            if (touching && tick - s.lastLine >= 60) {
                boolean changed = s.zone != s.spokenZone || g != s.spokenGesture;
                if (changed || tick - s.lastLine >= 120) {
                    String tier = TouchDialogue.tier(level);
                    if (g == TouchGesture.ROUGH) TouchDialogue.line(elf, "touch_rough");
                    else if (g == TouchGesture.PAT) TouchDialogue.line(elf, "touch_pat_" + tier);
                    else TouchDialogue.line(elf, "touch_" + s.zone.id + "_" + tier);
                    s.lastLine = tick;
                    s.spokenZone = s.zone;
                    s.spokenGesture = g;
                }
            }

            // gentle, welcome touch slowly earns affection (capped per session)
            if (touching && rate > 0f && !s.zone.guarded() && s.zone != TouchZone.LEG) {
                if (++s.goodTicks >= 60 && s.affectionGained < Cfg.COMMON.touchAffectionCap.get()) {
                    s.goodTicks = 0;
                    s.affectionGained++;
                    bond.add(s.elfId, 1);
                    InteractionManager.sendBond(p, elf);
                }
            }

            if ((tick & 1) == 0) sendState(p, s, true);
        }
    }

    private static void sendState(ServerPlayer p, Session s, boolean active) {
        boolean eff = s.holding && !s.locked && s.zone != null;
        int flags = (s.zone == null ? 0 : s.zone.ordinal() + 1)
                | (s.left ? 1 << 4 : 0)
                | (s.gesture.ordinal() << 5)
                | (s.locked ? 1 << 7 : 0)
                | (eff ? 1 << 8 : 0)
                | (active ? 1 << 9 : 0);
        PacketDistributor.sendToPlayer(p, new InteractNet.TouchStateS2C(s.elfEntityId, flags, Math.round(s.comfort * 10f)),
                new net.minecraft.network.protocol.common.custom.CustomPacketPayload[0]);
    }

    // ------------------------------------------------------------------ interruptions

    @SubscribeEvent
    public static void onDamaged(LivingDamageEvent.Post e) {
        if (SESSIONS.isEmpty()) return;
        if (e.getEntity() instanceof ServerPlayer sp) {
            cancel(sp);
        } else if (e.getEntity() instanceof ElfEntity elf && elf.getCompanionId() != null) {
            for (Session s : new ArrayList<>(SESSIONS.values())) {
                if (s.elfId.equals(elf.getCompanionId()) && elf.getServer() != null) {
                    ServerPlayer p = elf.getServer().getPlayerList().getPlayer(s.player);
                    if (p != null) cancel(p);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!SESSIONS.isEmpty() && e.getEntity() instanceof ServerPlayer sp) cancel(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Session s = SESSIONS.get(sp.getUUID());
            if (s != null) end(sp.server, s, sp, false);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) cancel(sp);
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        for (Session s : new ArrayList<>(SESSIONS.values())) end(e.getServer(), s, null, false);
        SESSIONS.clear();
    }
}
