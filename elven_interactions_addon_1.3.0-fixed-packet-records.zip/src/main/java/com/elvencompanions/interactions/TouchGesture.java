package com.elvencompanions.interactions;

/** What the player's motion looks like while holding on the elf (decided by the server from the player's own look deltas). */
public enum TouchGesture {
    NONE, HOLD, PAT, ROUGH;

    public static TouchGesture byId(int i) {
        TouchGesture[] v = values();
        return i >= 0 && i < v.length ? v[i] : NONE;
    }
}
