package com.elvencompanions.interactions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Real-geometry hit testing for touch mode. Reads the elf's own OBJ (the same file the renderer uses), builds one
 * axis-aligned box per named mesh part (in the OBJ frame), and ray-tests them, mapping the hit part to a {@link TouchZone}
 * by the same bone naming rules the renderer uses. Pure geometry - no Minecraft types - so it is unit-testable.
 *
 * Frame (derived from ElfModel/ElfRenderer): world_offset = RotY(180deg - bodyYaw) * 0.95 * obj, with +Y up, feet at y=0,
 * and the elf's front at -Z in the OBJ frame. Parts are the REST pose; the elf's current animation is not applied.
 * If the OBJ cannot be read, {@link #available()} is false and TouchManager falls back to the height-fraction classifier.
 */
public final class ElfMesh {
    public static final double MODEL_SCALE = 0.95; // ElfRenderer#scale
    public static final String RESOURCE = "assets/elven_companions/models/entity/elf.obj";

    enum Bone { HEAD, BODY, L_ARM, R_ARM, L_LEG, R_LEG }

    private record Part(String name, Bone bone, double[] min, double[] max) {}

    private static final Object LOCK = new Object();
    private static List<Part> parts;
    private static double[] headMin, headMax;
    private static final double[][] ARM_Y = new double[2][2]; // [0]=L,[1]=R : {minY,maxY}

    private ElfMesh() {}

    public static boolean available() {
        ensureLoaded();
        return !parts.isEmpty();
    }

    private static void ensureLoaded() {
        synchronized (LOCK) {
            if (parts != null) return;
            try (InputStream in = Locator.open()) {
                if (in == null) throw new IOException("elf.obj not found in the Elven Companions mod file");
                load(in);
            } catch (Throwable t) {
                ElvenInteractions.LOGGER.warn("Elf mesh zones unavailable ({}); using the height-based fallback", t.toString());
                parts = List.of();
            }
        }
    }

    /** Parses an OBJ stream into per-part boxes. Exposed for tests. */
    static void load(InputStream in) throws IOException {
        List<double[]> verts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<List<Integer>> faces = new ArrayList<>();
        List<Integer> cur = null;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\\s+");
                switch (p[0]) {
                    case "v" -> verts.add(new double[]{Double.parseDouble(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3])});
                    case "o", "g" -> {
                        names.add(line.substring(p[0].length()).trim());
                        cur = new ArrayList<>();
                        faces.add(cur);
                    }
                    case "f" -> {
                        if (cur == null) break;
                        for (int i = 1; i < p.length; i++) {
                            int idx = Integer.parseInt(p[i].split("/", -1)[0]);
                            cur.add(idx > 0 ? idx - 1 : verts.size() + idx);
                        }
                    }
                    default -> { }
                }
            }
        }
        List<Part> out = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            List<Integer> idx = faces.get(i);
            if (idx.isEmpty()) continue;
            double[] mn = {1e9, 1e9, 1e9};
            double[] mx = {-1e9, -1e9, -1e9};
            for (int vi : idx) {
                double[] v = verts.get(vi);
                for (int k = 0; k < 3; k++) {
                    mn[k] = Math.min(mn[k], v[k]);
                    mx[k] = Math.max(mx[k], v[k]);
                }
            }
            out.add(new Part(names.get(i), boneFor(names.get(i)), mn, mx));
        }
        // reference extents per bone group
        double[] hMin = {1e9, 1e9, 1e9};
        double[] hMax = {-1e9, -1e9, -1e9};
        double[][] am = {{1e9, -1e9}, {1e9, -1e9}};
        for (Part p : out) {
            if (p.bone == Bone.HEAD) {
                for (int k = 0; k < 3; k++) {
                    hMin[k] = Math.min(hMin[k], p.min[k]);
                    hMax[k] = Math.max(hMax[k], p.max[k]);
                }
            } else if (p.bone == Bone.L_ARM || p.bone == Bone.R_ARM) {
                int a = p.bone == Bone.L_ARM ? 0 : 1;
                am[a][0] = Math.min(am[a][0], p.min[1]);
                am[a][1] = Math.max(am[a][1], p.max[1]);
            }
        }
        headMin = hMin;
        headMax = hMax;
        ARM_Y[0] = am[0];
        ARM_Y[1] = am[1];
        parts = out;
    }

    /** Same naming rules as the renderer's ElfObjModel#boneFor. */
    static Bone boneFor(String raw) {
        String n = raw.toLowerCase(Locale.ROOT);
        if (n.equals("head") || n.equals("hat")) return Bone.HEAD;
        if (n.contains("left arm")) return Bone.L_ARM;
        if (n.contains("right arm")) return Bone.R_ARM;
        if (n.contains("left leg") || n.equals("leggings_left")) return Bone.L_LEG;
        if (n.contains("right leg") || n.equals("leggings_right")) return Bone.R_LEG;
        return Bone.BODY;
    }

    /**
     * Casts a world-space ray at the elf.
     *
     * @param ex,ey,ez  elf feet position
     * @param bodyYawDeg the elf's body yaw (what the renderer uses)
     * @param rx,ry,rz  ray origin (player eye)
     * @param dx,dy,dz  ray direction (need not be normalised)
     * @param reach     max distance along the normalised direction, in blocks
     * @return the zone hit, or null if the ray misses every part
     */
    public static TouchZone.Hit raycast(double ex, double ey, double ez, float bodyYawDeg,
                                        double rx, double ry, double rz, double dx, double dy, double dz, double reach) {
        ensureLoaded();
        if (parts.isEmpty()) return null;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-9) return null;
        dx /= len;
        dy /= len;
        dz /= len;

        double theta = Math.PI - Math.toRadians(bodyYawDeg);
        double c = Math.cos(theta);
        double s = Math.sin(theta);
        // world -> OBJ frame: inverse of RotY(theta), then undo the 0.95 model scale
        double relX = rx - ex, relY = ry - ey, relZ = rz - ez;
        double ox = (relX * c - relZ * s) / MODEL_SCALE;
        double oy = relY / MODEL_SCALE;
        double oz = (relX * s + relZ * c) / MODEL_SCALE;
        double ddx = (dx * c - dz * s) / MODEL_SCALE;
        double ddy = dy / MODEL_SCALE;
        double ddz = (dx * s + dz * c) / MODEL_SCALE;

        Part best = null;
        double bestT = Double.MAX_VALUE;
        for (Part p : parts) {
            double t = slab(ox, oy, oz, ddx, ddy, ddz, p.min, p.max);
            if (t >= 0 && t <= reach && t < bestT) {
                bestT = t;
                best = p;
            }
        }
        if (best == null) return null;

        double hx = ox + ddx * bestT, hy = oy + ddy * bestT, hz = oz + ddz * bestT;
        // elf forward (world) -> OBJ frame; with yaw 0 this is -Z
        double fwx = -Math.sin(Math.toRadians(bodyYawDeg));
        double fwz = Math.cos(Math.toRadians(bodyYawDeg));
        double fx = fwx * c - fwz * s;
        double fz = fwx * s + fwz * c;

        switch (best.bone) {
            case HEAD: {
                double cx = (headMin[0] + headMax[0]) / 2, cz = (headMin[2] + headMax[2]) / 2;
                double front = (hx - cx) * fx + (hz - cz) * fz;
                double lateral = Math.abs(-(hx - cx) * fz + (hz - cz) * fx);
                double headH = headMax[1] - headMin[1];
                boolean faceBand = hy < headMin[1] + 0.46 * headH; // chin..eyes
                boolean central = lateral < 0.28 * (headMax[0] - headMin[0]);
                if (front > 0.30 * (headMax[2] - headMin[2]) && faceBand && central) return new TouchZone.Hit(TouchZone.FACE, false);
                return new TouchZone.Hit(TouchZone.HEAD, false);
            }
            case L_ARM:
            case R_ARM: {
                int a = best.bone == Bone.L_ARM ? 0 : 1;
                double h = ARM_Y[a][1] - ARM_Y[a][0];
                boolean hand = hy < ARM_Y[a][0] + 0.28 * h;
                return new TouchZone.Hit(hand ? TouchZone.HAND : TouchZone.ARM, best.bone == Bone.L_ARM);
            }
            case L_LEG:
                return new TouchZone.Hit(TouchZone.LEG, true);
            case R_LEG:
                return new TouchZone.Hit(TouchZone.LEG, false);
            default:
                return new TouchZone.Hit(TouchZone.TORSO, false);
        }
    }

    /** Ray/AABB slab test. Returns the entry distance (param along the given direction) or -1. */
    private static double slab(double ox, double oy, double oz, double dx, double dy, double dz, double[] mn, double[] mx) {
        double tMin = 0, tMax = Double.MAX_VALUE;
        double[] o = {ox, oy, oz};
        double[] d = {dx, dy, dz};
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1.0E-12) {
                if (o[i] < mn[i] || o[i] > mx[i]) return -1;
            } else {
                double t1 = (mn[i] - o[i]) / d[i];
                double t2 = (mx[i] - o[i]) / d[i];
                if (t1 > t2) { double tmp = t1; t1 = t2; t2 = tmp; }
                tMin = Math.max(tMin, t1);
                tMax = Math.min(tMax, t2);
                if (tMin > tMax) return -1;
            }
        }
        return tMin;
    }

    /** Finds the OBJ inside the Elven Companions mod file. Separate class so tests never load the FML types. */
    static final class Locator {
        private Locator() {}

        static InputStream open() throws IOException {
            try {
                var container = net.neoforged.fml.ModList.get().getModContainerById("elven_companions");
                if (container.isPresent()) {
                    var path = container.get().getModInfo().getOwningFile().getFile().findResource(RESOURCE.split("/"));
                    if (path != null && java.nio.file.Files.exists(path)) return java.nio.file.Files.newInputStream(path);
                }
            } catch (Throwable ignored) {
                // fall through to the classloader
            }
            ClassLoader cl = Locator.class.getClassLoader();
            InputStream in = cl == null ? null : cl.getResourceAsStream(RESOURCE);
            if (in == null) in = ClassLoader.getSystemResourceAsStream(RESOURCE);
            return in;
        }
    }
}
