package com.elvencompanions.interactions;

import com.elvencompanions.entity.ElfEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Body zones the player can point at in touch mode, with how each one affects the elf's comfort (per second, indexed by
 * bond level 0..4). Zones are derived from the hit point on the elf's bounding box (height fraction + sideways offset
 * relative to the way the elf faces); the thresholds in {@link #classify} are the tuning knobs for your model's proportions.
 * Torso and legs are uncomfortable at every bond level - a higher bond only makes her tolerate it longer.
 */
public enum TouchZone {
    HEAD("head", new float[]{-1.5f, 0.0f, 1.0f, 1.8f, 2.5f}),
    FACE("face", new float[]{-3.0f, -1.5f, 0.0f, 0.8f, 1.5f}),
    ARM("arm", new float[]{-2.0f, -0.8f, 0.5f, 1.2f, 1.8f}),
    HAND("hand", new float[]{-1.0f, 0.4f, 1.4f, 2.0f, 2.6f}),
    TORSO("torso", new float[]{-6.0f, -4.5f, -3.0f, -2.2f, -1.6f}),
    LEG("leg", new float[]{-7.0f, -5.5f, -4.0f, -3.0f, -2.2f});

    private static final float[] PAT_RATE = {-0.3f, 2.5f, 4.0f, 5.0f, 6.0f};

    public final String id;
    private final float[] rates;

    TouchZone(String id, float[] rates) {
        this.id = id;
        this.rates = rates;
    }

    /** Comfort change per second for a calm hold. */
    public float rate(int bondLevel) {
        return scaled(rates[Math.max(0, Math.min(rates.length - 1, bondLevel))]);
    }

    /** Applies the configured drain/gain multipliers. */
    public static float scaled(float perSecond) {
        float k = (perSecond < 0f ? Cfg.COMMON.drainScale : Cfg.COMMON.gainScale).get().floatValue();
        return perSecond * k;
    }

    /** Comfort change per second for a head-pat gesture (head only). */
    public static float patRate(int bondLevel) {
        return scaled(PAT_RATE[Math.max(0, Math.min(PAT_RATE.length - 1, bondLevel))]);
    }

    public String langKey() {
        return "gui.elven_companions.touch.zone." + id;
    }

    /** True for zones where the elf is uncomfortable by default. */
    public boolean guarded() {
        return this == TORSO || this == LEG;
    }

    public static TouchZone byId(int i) {
        TouchZone[] v = values();
        return i >= 0 && i < v.length ? v[i] : null;
    }

    public record Hit(TouchZone zone, boolean left) {}

    /** Classifies a point on the elf. {@code left} is the elf's own left side. */
    public static Hit classify(ElfEntity elf, Vec3 hit) {
        double h = (hit.y - elf.getY()) / Math.max(0.1, elf.getBbHeight());
        double yaw = Math.toRadians(elf.yBodyRot);
        double leftX = Math.cos(yaw);
        double leftZ = Math.sin(yaw);
        double fwdX = -Math.sin(yaw);
        double fwdZ = Math.cos(yaw);
        double dx = hit.x - elf.getX();
        double dz = hit.z - elf.getZ();
        double lat = dx * leftX + dz * leftZ;
        double fwd = dx * fwdX + dz * fwdZ;
        double half = Math.max(0.15, elf.getBbWidth() / 2.0);
        double al = Math.abs(lat) / half;
        boolean left = lat > 0;
        if (h >= 0.78) {
            if (fwd > 0 && al < 0.7 && h < 0.90) return new Hit(FACE, left);
            return new Hit(HEAD, left);
        }
        if (h >= 0.52) return new Hit(al <= 0.55 ? TORSO : ARM, left);
        if (h >= 0.40 && al > 0.55) return new Hit(HAND, left);
        return new Hit(LEG, left);
    }
}
