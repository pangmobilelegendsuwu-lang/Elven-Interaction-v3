package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.InteractNet;
import com.elvencompanions.interactions.TouchGesture;
import com.elvencompanions.interactions.TouchManager;
import com.elvencompanions.interactions.TouchZone;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Client side of touch mode: mirrors the server's state (hovered zone, gesture, comfort, refusing), reports the right-click
 * held/released edge, blocks vanilla attack/use while touching (so right-click cannot open the elf's menu), tracks the
 * drag (how far the view moved since the grab, used for the elf's pose and the first-person hand) and draws the HUD.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class TouchClient {
    private static boolean active;
    private static int elfEntityId = -1;
    private static TouchZone zone;
    private static boolean left;
    private static TouchGesture gesture = TouchGesture.NONE;
    private static float comfort = TouchManager.DEFAULT_START;
    private static boolean locked;
    private static boolean touching;
    private static long lastStateMs;

    private static boolean keyHeld;
    private static boolean sentHeld;
    private static float grabYaw;
    private static float grabPitch;
    /** Smoothed drag, radians: how far the view has moved since the grab (0 when not touching). */
    private static float dragYaw;
    private static float dragPitch;

    private TouchClient() {}

    public static boolean active() {
        return active;
    }

    public static int elfEntityId() {
        return elfEntityId;
    }

    public static TouchZone zone() {
        return zone;
    }

    public static boolean left() {
        return left;
    }

    public static TouchGesture gesture() {
        return gesture;
    }

    public static float comfort() {
        return comfort;
    }

    public static boolean locked() {
        return locked;
    }

    public static boolean touching() {
        return touching;
    }

    public static boolean keyHeld() {
        return keyHeld;
    }

    public static float dragYaw() {
        return dragYaw;
    }

    public static float dragPitch() {
        return dragPitch;
    }

    // ------------------------------------------------------------------ server -> client

    public static void onState(InteractNet.TouchStateS2C p) {
        Minecraft mc = Minecraft.getInstance();
        if (!p.active()) {
            stop(mc);
            return;
        }
        if (!active) {
            active = true;
            keyHeld = false;
            sentHeld = false;
            dragYaw = dragPitch = 0f;
            ClientInteractions.resetCancel();
            if (mc.player instanceof AbstractClientPlayer acp) PlayerAnimBridge.startTouch(acp);
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.translatable("gui.elven_companions.touch.hint"), true);
            }
        }
        elfEntityId = p.elfEntityId();
        zone = p.zone();
        left = p.left();
        gesture = p.gesture();
        comfort = p.comfort();
        locked = p.locked();
        touching = p.touching();
        lastStateMs = System.currentTimeMillis();
    }

    private static void stop(Minecraft mc) {
        if (active && mc.player instanceof AbstractClientPlayer acp) PlayerAnimBridge.stopTouch(acp);
        active = false;
        zone = null;
        gesture = TouchGesture.NONE;
        touching = false;
        locked = false;
        keyHeld = false;
        sentHeld = false;
    }

    // ------------------------------------------------------------------ events

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (!active) {
            dragYaw *= 0.7f;
            dragPitch *= 0.7f;
            return;
        }
        if (mc.player == null || mc.level == null || System.currentTimeMillis() - lastStateMs > 4000L) {
            stop(mc);
            return;
        }
        // right-click held? (a screen open counts as released)
        keyHeld = mc.screen == null && mc.options.keyUse.isDown();
        if (keyHeld != sentHeld) {
            sentHeld = keyHeld;
            if (keyHeld) {
                grabYaw = mc.player.getYRot();
                grabPitch = mc.player.getXRot();
            }
            PacketDistributor.sendToServer(new InteractNet.TouchHoldC2S(keyHeld), new CustomPacketPayload[0]);
        }
        // drag = view movement since the grab, only while the server says we are really touching
        float ty = 0f;
        float tp = 0f;
        if (touching && keyHeld) {
            ty = Mth.clamp(Mth.wrapDegrees(mc.player.getYRot() - grabYaw) * Mth.DEG_TO_RAD, -1.2f, 1.2f);
            tp = Mth.clamp((mc.player.getXRot() - grabPitch) * Mth.DEG_TO_RAD, -1.0f, 1.0f);
        }
        dragYaw += (ty - dragYaw) * 0.35f;
        dragPitch += (tp - dragPitch) * 0.35f;
        PlayerAnimBridge.setTouchHolding(keyHeld && !locked);
    }

    /** No vanilla attack/use/pick while touching: right-click would otherwise open the elf menu, left-click would hit her. */
    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered e) {
        if (!active) return;
        e.setCanceled(true);
        e.setSwingHand(false);
    }

    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        if (!active || !Cfg.CLIENT.touchHud.get()) return;
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g = e.getGuiGraphics();
        int w = g.guiWidth();
        int h = g.guiHeight();
        var font = mc.font;

        // comfort meter
        int bw = 120;
        int bx = w / 2 - bw / 2;
        int by = 20;
        g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.comfort"), w / 2, by - 11, 0xFFE9D9A0);
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 9, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 8, 0xFF1F2E22);
        int col = comfort < TouchManager.lockLow() ? 0xFFD9534F : comfort < TouchManager.lockHigh() ? 0xFFE8923C
                : comfort < 60f ? 0xFFE8D44F : 0xFF4FA860;
        if (locked && (System.currentTimeMillis() / 250L) % 2L == 0L) col = 0xFFFF8080;
        g.fill(bx, by, bx + Math.round(bw * comfort / 100f), by + 8, col);
        g.fill(bx + Math.round(bw * TouchManager.lockLow() / 100f), by - 2, bx + Math.round(bw * TouchManager.lockLow() / 100f) + 1, by + 10, 0xFFFFFFFF);

        // what am I pointing at
        if (zone != null) {
            boolean bad = zone.guarded() || locked || gesture == TouchGesture.ROUGH;
            Component zl = Component.translatable(zone.langKey());
            g.drawCenteredString(font, zl, w / 2, h / 2 + 14, bad ? 0xFFFF9A8A : 0xFFB8F0C0);
            if (gesture == TouchGesture.PAT) {
                g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.pat"), w / 2, h / 2 + 25, 0xFFB8F0C0);
            } else if (gesture == TouchGesture.ROUGH) {
                g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.rough"), w / 2, h / 2 + 25, 0xFFFF9A8A);
            }
        }
        Component hint = locked ? Component.translatable("gui.elven_companions.touch.refusing")
                : Component.translatable("gui.elven_companions.touch.hint");
        g.drawCenteredString(font, hint, w / 2, h - 52, locked ? 0xFFFF9A8A : 0xFFB0B0B0);
    }
}
