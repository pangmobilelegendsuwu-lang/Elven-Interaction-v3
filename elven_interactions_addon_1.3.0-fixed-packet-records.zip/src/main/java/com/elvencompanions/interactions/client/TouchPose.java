package com.elvencompanions.interactions.client;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.Clip.Ch;
import com.elvencompanions.interactions.TouchGesture;
import com.elvencompanions.interactions.TouchZone;
import net.minecraft.util.Mth;

/**
 * The elf's reaction pose in touch mode, as ADDITIVE offsets on top of her normal pose (so her idle animation keeps
 * running). Targets are authored in vanilla angle convention and converted with {@link Clip#toElfSign}; the result is
 * smoothed every frame. Reactions:
 *  - head held + slow left/right motion (server says PAT): bows her head into the pat,
 *  - head/face held otherwise: the head follows where you drag,
 *  - arm/hand held: that arm follows your drag (the hand is offered a little forward),
 *  - torso/legs, rough handling, or refusing: recoil - leans back, turns her head away, guards with her arms.
 * Only the local player's own session is visualised (state is not broadcast to other clients).
 */
public final class TouchPose {
    private static final int N = Ch.values().length;
    private static final float[] cur = new float[N];
    private static float weight;
    private static int lastElf = -1;

    private TouchPose() {}

    private static void set(float[] t, Ch ch, float v) {
        t[ch.ordinal()] = v;
    }

    private static float time() {
        return (System.currentTimeMillis() % 100000L) / 1000f;
    }

    /** @return additive offsets in InteractionPose slot layout (slot 0 = weight), or null when untouched. */
    public static float[] sample(ElfEntity elf) {
        boolean mine = TouchClient.active() && TouchClient.elfEntityId() == elf.getId();
        if (mine) lastElf = elf.getId();
        else if (elf.getId() != lastElf) return null;

        weight = Mth.clamp(weight + (mine ? 0.12f : -0.08f), 0f, 1f);
        if (weight <= 0.001f && !mine) {
            lastElf = -1;
            for (int i = 0; i < N; i++) cur[i] = 0f;
            return null;
        }

        float[] t = new float[N];
        if (mine) {
            TouchZone zone = TouchClient.zone();
            TouchGesture gesture = TouchClient.gesture();
            boolean touching = TouchClient.touching();
            boolean recoil = TouchClient.locked()
                    || (touching && zone != null && (gesture == TouchGesture.ROUGH || zone.guarded()
                    || (zone == TouchZone.FACE && TouchClient.comfort() < 45f)));
            float dY = TouchClient.dragYaw() * (Cfg.CLIENT.flipTouchDragYaw.get() ? -1f : 1f);
            float dP = TouchClient.dragPitch() * (Cfg.CLIENT.flipTouchDragPitch.get() ? -1f : 1f);
            if (recoil) {
                set(t, Ch.TORSO_PITCH, -0.14f);
                set(t, Ch.HEAD_YAW, 0.35f);
                set(t, Ch.HEAD_PITCH, 0.12f);
                set(t, Ch.R_ARM_PITCH, -0.95f);
                set(t, Ch.L_ARM_PITCH, -0.95f);
                set(t, Ch.R_ARM_YAW, -0.65f);
                set(t, Ch.L_ARM_YAW, 0.65f);
            } else if (touching && zone != null) {
                switch (zone) {
                    case HEAD -> {
                        if (gesture == TouchGesture.PAT) {
                            set(t, Ch.HEAD_PITCH, 0.5f + 0.05f * (float) Math.sin(time() * 6f));
                            set(t, Ch.TORSO_PITCH, 0.06f);
                            set(t, Ch.R_ARM_PITCH, -0.2f);
                            set(t, Ch.L_ARM_PITCH, -0.2f);
                        } else {
                            set(t, Ch.HEAD_PITCH, Mth.clamp(dP * 0.9f, -0.5f, 0.55f));
                            set(t, Ch.HEAD_YAW, Mth.clamp(-dY * 0.9f, -0.6f, 0.6f));
                        }
                    }
                    case FACE -> {
                        set(t, Ch.HEAD_PITCH, Mth.clamp(dP * 0.6f, -0.4f, 0.4f));
                        set(t, Ch.HEAD_YAW, Mth.clamp(-dY * 0.7f, -0.5f, 0.5f));
                    }
                    case ARM, HAND -> {
                        boolean l = TouchClient.left();
                        float base = zone == TouchZone.HAND ? -0.45f : 0f;
                        float pitch = base + Mth.clamp(dP * 1.0f, -1.4f, 1.4f);
                        float yaw = Mth.clamp(-dY * 0.8f, -0.9f, 0.9f) * (l ? -1f : 1f);
                        set(t, l ? Ch.L_ARM_PITCH : Ch.R_ARM_PITCH, pitch);
                        set(t, l ? Ch.L_ARM_YAW : Ch.R_ARM_YAW, yaw);
                        set(t, Ch.TORSO_ROLL, Mth.clamp(-dY * 0.15f, -0.12f, 0.12f));
                    }
                    default -> { }
                }
            }
        }

        for (int i = 0; i < N; i++) cur[i] += (t[i] - cur[i]) * 0.2f;

        float[] out = new float[InteractionPose.SIZE];
        out[InteractionPose.W] = weight;
        out[InteractionPose.HEAD_X] = cur[Ch.HEAD_PITCH.ordinal()] * InteractionPose.sign(Ch.HEAD_PITCH);
        out[InteractionPose.HEAD_Y] = cur[Ch.HEAD_YAW.ordinal()] * InteractionPose.sign(Ch.HEAD_YAW);
        out[InteractionPose.TORSO_X] = cur[Ch.TORSO_PITCH.ordinal()] * InteractionPose.sign(Ch.TORSO_PITCH);
        out[InteractionPose.TORSO_Z] = cur[Ch.TORSO_ROLL.ordinal()] * InteractionPose.sign(Ch.TORSO_ROLL);
        InteractionPose.fillArms(out,
                cur[Ch.R_ARM_PITCH.ordinal()] * InteractionPose.sign(Ch.R_ARM_PITCH),
                cur[Ch.R_ARM_YAW.ordinal()] * InteractionPose.sign(Ch.R_ARM_YAW),
                cur[Ch.R_ARM_ROLL.ordinal()] * InteractionPose.sign(Ch.R_ARM_ROLL),
                cur[Ch.L_ARM_PITCH.ordinal()] * InteractionPose.sign(Ch.L_ARM_PITCH),
                cur[Ch.L_ARM_YAW.ordinal()] * InteractionPose.sign(Ch.L_ARM_YAW),
                cur[Ch.L_ARM_ROLL.ordinal()] * InteractionPose.sign(Ch.L_ARM_ROLL));
        out[InteractionPose.R_LEG_X] = cur[Ch.R_LEG_PITCH.ordinal()] * InteractionPose.sign(Ch.R_LEG_PITCH);
        out[InteractionPose.L_LEG_X] = cur[Ch.L_LEG_PITCH.ordinal()] * InteractionPose.sign(Ch.L_LEG_PITCH);
        return out;
    }
}
