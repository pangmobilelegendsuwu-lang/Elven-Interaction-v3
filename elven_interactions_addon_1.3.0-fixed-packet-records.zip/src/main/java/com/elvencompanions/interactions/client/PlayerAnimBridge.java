package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.Clip;
import com.elvencompanions.interactions.Clip.Ch;
import com.elvencompanions.interactions.InteractionType;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.api.layered.modifier.AbstractFadeModifier;
import dev.kosmx.playerAnim.core.data.AnimationFormat;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.core.util.Ease;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationFactory;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;

/**
 * The only class that touches Player Animator. Builds the player's side of each interaction from the shared
 * {@link Clip}s (no JSON assets needed) and plays it on a dedicated, high-priority layer.
 * NOT RUN IN-GAME: pitch/yaw/roll sign conventions follow vanilla's humanoid model; tune in {@link InteractionType}.
 */
public final class PlayerAnimBridge {
    public static final ResourceLocation LAYER_ID = ElvenInteractions.rl("interaction");
    private static final Map<InteractionType, KeyframeAnimation> CACHE = new EnumMap<>(InteractionType.class);

    private PlayerAnimBridge() {}

    /** Call once from client setup (inside enqueueWork). */
    public static void register() {
        PlayerAnimationFactory.ANIMATION_DATA_FACTORY.registerFactory(LAYER_ID, 100, player -> new ModifierLayer<>());
    }

    @SuppressWarnings("unchecked")
    private static ModifierLayer<IAnimation> layer(AbstractClientPlayer p) {
        try {
            IAnimation a = PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER_ID);
            return a instanceof ModifierLayer<?> ml ? (ModifierLayer<IAnimation>) ml : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    public static void play(AbstractClientPlayer p, InteractionType t) {
        ModifierLayer<IAnimation> layer = layer(p);
        if (layer == null) return;
        KeyframeAnimation anim = CACHE.computeIfAbsent(t, PlayerAnimBridge::build);
        // First person: render the animated third-person arms (Player Animator's first-person mode) instead of the
        // static vanilla hand, show only the arms this clip actually moves, and hide held items while interacting.
        Clip pc = t.player;
        boolean right = pc.has(Ch.R_ARM_PITCH) || pc.has(Ch.R_ARM_YAW) || pc.has(Ch.R_ARM_ROLL);
        boolean left = pc.has(Ch.L_ARM_PITCH) || pc.has(Ch.L_ARM_YAW) || pc.has(Ch.L_ARM_ROLL);
        KeyframeAnimationPlayer ap = new KeyframeAnimationPlayer(anim);
        if (Cfg.CLIENT.firstPersonArms.get()) {
            ap.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL)
                    .setFirstPersonConfiguration(new FirstPersonConfiguration()
                            .setShowRightArm(right).setShowLeftArm(left)
                            .setShowRightItem(false).setShowLeftItem(false));
        }
        layer.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(4, Ease.INOUTSINE), ap);
    }

    // ---------------------------------------------------------------- touch mode (live right-arm animation)
    private static TouchArmAnimation touchAnim;

    public static void startTouch(AbstractClientPlayer p) {
        ModifierLayer<IAnimation> layer = layer(p);
        if (layer == null) return;
        touchAnim = new TouchArmAnimation();
        layer.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(3, Ease.INOUTSINE), touchAnim);
    }

    public static void setTouchHolding(boolean holding) {
        if (touchAnim != null) touchAnim.holding = holding;
    }

    public static void stopTouch(AbstractClientPlayer p) {
        if (touchAnim != null) {
            touchAnim.stopping = true; // fades out by itself, then reports inactive
            touchAnim = null;
        }
    }

    public static void stop(AbstractClientPlayer p) {
        ModifierLayer<IAnimation> layer = layer(p);
        if (layer == null || !layer.isActive()) return;
        layer.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(6, Ease.INOUTSINE), (IAnimation) null);
    }

    // ---------------------------------------------------------------- build

    private static KeyframeAnimation build(InteractionType t) {
        Clip c = t.player;
        KeyframeAnimation.AnimationBuilder b = new KeyframeAnimation.AnimationBuilder(AnimationFormat.JSON_EMOTECRAFT);
        b.setName("elven_companions:" + t.id);
        b.beginTick = 0;
        b.endTick = c.duration;
        b.stopTick = c.duration + 2;
        b.isLooped = false;
        for (Ch ch : Ch.values()) {
            if (!c.has(ch)) continue;
            KeyframeAnimation.StateCollection.State st = state(b, ch);
            if (st == null) continue;
            st.setEnabled(true);
            for (int i = 0; i < c.keyCount(ch); i++) {
                st.addKeyFrame(Math.round(c.keyTime(ch, i)), c.keyValue(ch, i), Ease.INOUTSINE);
            }
        }
        return b.build();
    }

    private static KeyframeAnimation.StateCollection.State state(KeyframeAnimation.AnimationBuilder b, Ch ch) {
        return switch (ch) {
            case HEAD_PITCH -> b.head.pitch;
            case HEAD_YAW -> b.head.yaw;
            case TORSO_PITCH -> b.body.pitch;
            case TORSO_ROLL -> b.body.roll;
            case R_ARM_PITCH -> b.rightArm.pitch;
            case R_ARM_YAW -> b.rightArm.yaw;
            case R_ARM_ROLL -> b.rightArm.roll;
            case L_ARM_PITCH -> b.leftArm.pitch;
            case L_ARM_YAW -> b.leftArm.yaw;
            case L_ARM_ROLL -> b.leftArm.roll;
            case R_LEG_PITCH -> b.rightLeg.pitch;
            case L_LEG_PITCH -> b.leftLeg.pitch;
        };
    }
}
