package com.elvencompanions.interactions.mixin;

import com.elvencompanions.client.ElfModel;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.client.InteractionPose;
import com.elvencompanions.interactions.client.TouchPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The single mixin of the addon: the elf's pose fields are private and ElfModel#setupAnim is the only place they are
 * computed, so the interaction clip is mixed in at its TAIL. Does nothing unless an interaction is active.
 */
@Mixin(value = ElfModel.class, remap = false)
public abstract class ElfModelMixin {
    @Shadow private float headX;
    @Shadow private float headY;
    @Shadow private float torsoX;
    @Shadow private float torsoZ;
    @Shadow private float rArmX;
    @Shadow private float rArmY;
    @Shadow private float rArmZ;
    @Shadow private float lArmX;
    @Shadow private float lArmY;
    @Shadow private float lArmZ;
    @Shadow private float rLegX;
    @Shadow private float lLegX;

    @Inject(method = "setupAnim(Lcom/elvencompanions/entity/ElfEntity;FFFFF)V", at = @At("TAIL"), remap = false)
    private void elven_interactions$applyPose(ElfEntity e, float a, float b, float c, float d, float f, CallbackInfo ci) {
        float[] p = InteractionPose.sample(e);
        if (p != null) {
            float w = p[InteractionPose.W];
            headX = mix(headX, p[InteractionPose.HEAD_X], w);
            headY = mix(headY, p[InteractionPose.HEAD_Y], w);
            torsoX = mix(torsoX, p[InteractionPose.TORSO_X], w);
            torsoZ = mix(torsoZ, p[InteractionPose.TORSO_Z], w);
            rArmX = mix(rArmX, p[InteractionPose.R_ARM_X], w);
            rArmY = mix(rArmY, p[InteractionPose.R_ARM_Y], w);
            rArmZ = mix(rArmZ, p[InteractionPose.R_ARM_Z], w);
            lArmX = mix(lArmX, p[InteractionPose.L_ARM_X], w);
            lArmY = mix(lArmY, p[InteractionPose.L_ARM_Y], w);
            lArmZ = mix(lArmZ, p[InteractionPose.L_ARM_Z], w);
            rLegX = mix(rLegX, p[InteractionPose.R_LEG_X], w);
            lLegX = mix(lLegX, p[InteractionPose.L_LEG_X], w);
        }

        // touch-mode reaction: additive offsets on top of whatever pose she has
        float[] t = TouchPose.sample(e);
        if (t != null) {
            float w = t[InteractionPose.W];
            headX += t[InteractionPose.HEAD_X] * w;
            headY += t[InteractionPose.HEAD_Y] * w;
            torsoX += t[InteractionPose.TORSO_X] * w;
            torsoZ += t[InteractionPose.TORSO_Z] * w;
            rArmX += t[InteractionPose.R_ARM_X] * w;
            rArmY += t[InteractionPose.R_ARM_Y] * w;
            rArmZ += t[InteractionPose.R_ARM_Z] * w;
            lArmX += t[InteractionPose.L_ARM_X] * w;
            lArmY += t[InteractionPose.L_ARM_Y] * w;
            lArmZ += t[InteractionPose.L_ARM_Z] * w;
            rLegX += t[InteractionPose.R_LEG_X] * w;
            lLegX += t[InteractionPose.L_LEG_X] * w;
        }
    }

    private static float mix(float cur, float v, float w) {
        return Float.isNaN(v) ? cur : cur + (v - cur) * w;
    }
}
