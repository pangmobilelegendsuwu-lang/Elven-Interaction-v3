Offline test for the touch-zone raycaster (ElfMesh) against the real elf OBJ. No Minecraft needed, only a JDK 21.
From this folder:
  mkdir out && javac -d out -sourcepath stubs ../../src/main/java/com/elvencompanions/interactions/ElfMesh.java \
      ../../src/main/java/com/elvencompanions/interactions/TouchZone.java Test.java && java -cp out Test
Prints one line per case (face / head / torso / arms / hands / legs / misses / rotated elf) and ALL PASSED or the failures.
