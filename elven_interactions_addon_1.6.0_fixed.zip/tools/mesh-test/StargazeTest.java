import com.elvencompanions.interactions.StargazeMath;
public class StargazeTest {
    static int fails = 0;
    static void ok(String n, boolean c) { System.out.printf("%-66s %s%n", n, c ? "ok" : "FAIL"); if (!c) fails++; }
    public static void main(String[] a) {
        // default window 12000..23000 (sunset .. just before sunrise)
        ok("11999 is day (blocked)", !StargazeMath.inWindow(11999, 12000, 23000));
        ok("12000 sunset allowed", StargazeMath.inWindow(12000, 12000, 23000));
        ok("18000 midnight allowed", StargazeMath.inWindow(18000, 12000, 23000));
        ok("23000 allowed", StargazeMath.inWindow(23000, 12000, 23000));
        ok("23001 blocked", !StargazeMath.inWindow(23001, 12000, 23000));
        ok("0 (sunrise) blocked", !StargazeMath.inWindow(0, 12000, 23000));
        ok("day time beyond 24000 wraps (36000 = 12000)", StargazeMath.inWindow(36000, 12000, 23000));
        ok("dayTime 24000*5+13000 allowed", StargazeMath.inWindow(24000L * 5 + 13000, 12000, 23000));
        ok("negative time handled", !StargazeMath.inWindow(-1000, 12000, 23000) == !StargazeMath.inWindow(23000, 12000, 23000));
        // wrapping window 22000..2000
        ok("wrap: 23000 in", StargazeMath.inWindow(23000, 22000, 2000));
        ok("wrap: 1000 in", StargazeMath.inWindow(1000, 22000, 2000));
        ok("wrap: 3000 out", !StargazeMath.inWindow(3000, 22000, 2000));
        ok("wrap: 12000 out", !StargazeMath.inWindow(12000, 22000, 2000));
        // sides (Minecraft: yaw 0 faces +Z, 90 faces -X, 180 faces -Z, 270 faces +X)
        ok("yaw 0 (facing +Z): point at -X is on the RIGHT", StargazeMath.sideOf(-1, 0, 0) == 1);
        ok("yaw 0: point at +X is on the LEFT", StargazeMath.sideOf(1, 0, 0) == -1);
        ok("yaw 0: straight ahead is 0", StargazeMath.sideOf(0, 1, 0) == 0);
        ok("yaw 90 (facing -X): -Z is on the right (north)", StargazeMath.sideOf(0, -1, 90) == 1);
        ok("yaw 180 (facing -Z): +X is on the right (east)", StargazeMath.sideOf(1, 0, 180) == 1);
        ok("yaw 270 (facing +X): +Z is on the right (south)", StargazeMath.sideOf(0, 1, 270) == 1);
        // player seated 0.8 to the elf's RIGHT: elf is then on the player's LEFT; mirrored for the other side
        for (float yaw : new float[]{0, 90, 180, 270, 37, 211}) {
            double rx = StargazeMath.rightX(yaw), rz = StargazeMath.rightZ(yaw);
            double px = rx * 0.8, pz = rz * 0.8;                 // player seat on the elf's right (elf at origin)
            boolean e1 = StargazeMath.sideOf(0 - px, 0 - pz, yaw) == -1;
            double qx = -rx * 0.8, qz = -rz * 0.8;               // player seat on the elf's left
            boolean e2 = StargazeMath.sideOf(0 - qx, 0 - qz, yaw) == 1;
            ok("yaw " + yaw + ": elf is on the opposite side of the player's seat side", e1 && e2);
            // and the player, seen from the elf, is on the matching side (used for her head turn = -side)
            ok("yaw " + yaw + ": head-turn sides are mirror images", StargazeMath.sideOf(px, pz, yaw) == -StargazeMath.sideOf(-px, -pz, yaw));
        }
        // seat entity height: rider hips on the surface
        ok("seat stand Y = surface - standHeight + offset", Math.abs(StargazeMath.seatStandY(1.0, 0.9875, 0.0) - 0.0125) < 1e-9
                && Math.abs(StargazeMath.seatStandY(65.5, 0.9875, 0.1) - 64.6125) < 1e-9);
        ok("script length 60 -> 105 ticks (settle 15 + gaze 60 + sky turn 30)", StargazeMath.scriptLength(60) == 105);
        ok("gaze 0 allowed, negative clamps", StargazeMath.scriptLength(0) == 45 && StargazeMath.scriptLength(-5) == 45);
        ok("smooth clamps and is monotonic", StargazeMath.smooth(-1) == 0f && StargazeMath.smooth(2) == 1f && Math.abs(StargazeMath.smooth(0.5f) - 0.5f) < 1e-6
                && StargazeMath.smooth(0.25f) < StargazeMath.smooth(0.75f));
        System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
}
