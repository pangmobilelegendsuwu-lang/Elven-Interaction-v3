# Elven Interactions (addon for Elven Companions)

## 1.6.0 - Stargaze and Kiss on the Cheek
**Kiss on the Cheek** (bond 3 / Close Friend, 60 s cooldown): a normal paired interaction at 0.55 blocks. You lean in with a hand on her shoulder
and turn your face to her cheek; she turns her face to offer it and holds her hands together, a little shy; hearts appear at the moment of contact.

**Stargaze** (bond 2 / Friend, 120 s cooldown) - only in the evening and at night by default. It is a session, not one clip:
1. **Search.** When you ask, the server looks within `searchRadius` (20) blocks of her for somewhere to sit and checks she can actually path there.
   She then looks around for ~2 seconds.
2. **Walk.** She walks slowly (`walkSpeed` 0.55) to the seat and sits down (her own sit stance). If she cannot get there within `walkTimeoutSeconds`
   she gives up.
3. **Wait.** She waits (`waitTimeoutSeconds` 90). Walk within `joinDistance` (3 blocks) of her to join.
4. **Script.** You are seated beside her (on an invisible seat, so you get a real sitting pose); you look at her for `gazeAtElfTicks` (60 = 3 s), then
   both of you look up at the sky - your head in third person, your view in first person (it eases up, then releases so you can look around).
5. **Hold.** The scripted part ends but you stay seated and she keeps gazing at the sky **until you sneak** (vanilla dismount) or something
   interrupts it (damage to either of you, death, logout, dimension change, she is attacked/needs to rest). Asking for stargazing again cancels it.
Seats: stairs, slabs, logs and beds by default (`seatBlocks`, comma separated, `#tag` or block id; e.g. add `minecraft:hay_block`). Heights come from the
blocks' real collision shapes (bottom slab 0.5, log 1.0, bed 0.5625); stairs are sat on the LOW step, found by probing the shape, not assumed. A spot
needs headroom and open sky (`requireOpenSky`); a spot where you can also sit on a platform (e.g. a row of logs/stairs) is preferred, otherwise you sit
on the ground beside her. Time window: `onlyAtNight`, `startTick` (12000), `endTick` (23000); an end before the start wraps past midnight. Tuning: `seatYOffset`.
Her bow is stowed for the whole session (same stow system as interactions).
New mixin #4 (`ElfEntityMixin`, common): appends one goal (`StargazeWalkGoal`, priority -1, MOVE+LOOK flags) to her goal list in `registerGoals`; it only
runs while she has a stargaze job in the WALK phase. Seat entities are tagged and any leftover one after a crash is refused on world load.
Tests added: `tools/mesh-test` suite 4 (time window incl. wrap, left/right for all yaws, seat height, script timeline) and clip checks for the new types.
Unverified (needs the game): seat height on the invisible entity (fix with `seatYOffset`), how the rider is placed on dismount, and the walk onto 1-block-high seats.

## 1.5.0
* **Face caress (Touch).** Hold on the FACE and slide your view slowly left/right: the server detects a CARESS exactly like a head pat.
  She leans into your hand (head tips down and follows the stroke, body sways a little). Comfort per second by bond level:
  {-1.5, +0.8, +2.8, +4.2, +5.2} (unwelcome from a stranger, lovely from a bonded friend); `touch_caress_*` dialogue by bond tier. Fast
  yanking is still "too rough". (`TouchGesture.CARESS`, `TouchZone.caressRate`; the state packet now carries the gesture in 3 bits.)
* **Closer.** Everyone stands closer: wave 1.25, high five 0.9, head pat 0.7, hold hands 0.8, dance 0.9, hug 0.5 (was 1.6 / 0.95 / 0.8 /
  0.85 / 1.0 / 0.6) and Touch 1.05 (was 1.5). Config: `distanceScale` (multiplies the interaction distances) and `touchDistance`.
* **Bow is now elf-only.** She bows to you from 1.9 blocks away; the player has no animation, is not frozen, no camera effect and no Epic Fight
  switch (`InteractionType.playerActs()`). Sneak or walking more than ~1.5 blocks away still ends it.
* **Head pat (Interaction menu) fixed.** Her clip had her look UP at the player; she now bows her head DOWN into the pat, and the player's
  hand reaches up to the top of her head (arm pitch -2.0).
* **Bow stowing.** While any interaction or touch session runs on her, her held items (bow and off-hand) are not drawn, and she takes
  them out again `stowGraceTicks` (12) ticks after it ends. Purely visual: a render skip in `ElfHeldItemLayer.render` (the addon's third
  mixin, `ElfHeldItemLayerMixin`); her inventory is never touched. Config: `stowWeapon`, `stowGraceTicks`.
* **Hug redesigned.** It read as "holding hands" because the arms hung at waist height (pitch -1.0) and only angled slightly in at 0.6 blocks.
  Now both stand chest to chest (0.5), arms go almost level (-1.4 player / -1.3 elf) and angle strongly inward (0.75 / 0.85) so the hands
  meet behind the partner's back, torsos lean in and both heads turn to their own right (cheek to cheek).
* Tests: `tools/mesh-test` now has a third suite (`ClipTest`) asserting the above numerically.

## 1.4.0 - grab-lock and real joints
* **Grab lock.** When you PRESS right-click the server latches whatever is under the crosshair (part + side) and keeps it until you
  RELEASE, wherever the crosshair goes. So pressing on the face and then moving your view drags the face; it cannot slide onto another
  part mid-drag. Pressing on nothing grabs nothing. (`TouchManager`: latchZone/latchLeft.)
* **New zone: Knee.** Zones are now Head, Face, Torso, **Arm > Hand**, **Leg > Knee** (left/right are the elf's own sides). The split is at
  the elbow and knee planes measured from the elf's own mesh (arm y=1.125, leg y=0.375 in the OBJ frame): above = Arm / Leg (thigh),
  below = Hand (forearm + hand) / Knee (lower leg). The HUD shows "Holding: Left Hand" etc. Knee is milder than the thigh (not "guarded").
* **Real elbow and knee bending.** The elf's limbs were one rigid mesh each, so nothing could bend. `JointMesh` now splits every
  arm/leg OBJ part at the joint plane (clipping the quads, adding cap faces so no hole opens) and `ElfObjPartMixin` (the addon's
  second mixin) draws the lower half rotated about the hinge when a bend is active; with no bend the original render runs untouched.
  Drag mapping (view moved since the grab; up = look up):
  Arm  = swing at the shoulder (up/down raises/lowers, left/right sweeps) with the forearm bending a little;
  Hand = bends the ELBOW (look up folds the forearm up, look down straightens) and sweeps the arm sideways;
  Leg  = swings at the hip, knee bending as it lifts;  Knee = bends the KNEE (look up folds the lower leg back, slight hip lift).
* **Overextension.** Pulling a limb more than ~45 deg (pitch) or ~70 deg (yaw) from where you grabbed it costs extra comfort and she says "Ow!".
* **Debug HUD.** `debugTouch = true` in the client config prints zone / side / gesture / touching / locked / comfort / drag / joint bends,
  so if something does not move you can see what state the game is in.
* Tests (offline, real OBJ): `tools/mesh-test` - zone raycast (now incl. knee/leg and hand/arm at the joints) and the joint mesh suite
  (area conserved, no holes, cap + split winding, rotation direction, every part of the model splits cleanly).
* Limits: bends apply to the OBJ parts (skin, layers, clothing meshes); armour drawn by other render layers will not bend. Zones use the rest
  pose. Seam: at large angles a block-joint wedge shows on the outer side of the bend (caps keep it solid, not smooth). If a bend or swing
  goes the wrong direction use the pose-fix flips in the client config (`flipArmPitch`, `flipArmYaw`, `flipLegPitch`, `flipTouchDragYaw/Pitch`).
  Bend direction itself comes from the geometry (forearm forward, shin back) and is not affected by those flips.

## 1.3.0
* **Touch zones now come from the elf's real mesh.** `ElfMesh` reads the same OBJ the renderer uses (found through the Elven
  Companions mod file), builds one box per named part and ray-tests them, mapping parts to zones with the renderer's own bone naming.
  Face is the central lower front of the head; head is everything else on it (so head-pats are easy to aim); arm vs hand splits at the
  lower 28% of the arm; torso is every body part; legs are the leg parts. Left/right are the elf's own sides. Rest pose only (her current
  animation is not applied). If the OBJ cannot be read it falls back to the old height bands. Tested offline: `tools/mesh-test`
  (21 cases incl. rotated elves) - all pass. Note: aiming at the INNER arm from the front hits the chest cover first and counts as
  torso (true to the geometry); aim at the outer arm.
* **Config files** (`config/elven_interactions-common.toml` / `-client.toml`, created on first launch): affection/cooldown multipliers,
  particles/sounds, all touch rules (start comfort, lock/unlock thresholds, drain/gain scale, refusal penalty, rebel on/off, damage,
  bond loss, lockout, affection cap), gift rules, camera on/off + strength + look-at strength, first-person arms on/off, touch HUD,
  and **elf pose fixes**: `flipHeadPitch/Yaw`, `flipTorsoPitch/Roll`, `flipArmPitch/Yaw/Roll`, `flipLegPitch`, `swapElfArms`,
  `flipTouchDragYaw/Pitch`. If a pose looks mirrored, flip it there - no rebuild needed.
* **Gifts.** Button **Gift** (left of the Interact GUI, under Touch) and a wheel slice: gives the item in your main hand. Loved
  (+8: golden apples, honey, cake, pumpkin pie), liked (+4: flowers, berries, apple, cookie, golden carrot, amethyst, emerald, bread,
  melon), neutral (+1), disliked (-3: rotten flesh, spider eyes, poisonous potato, pufferfish, bone). One gift per 2 minutes (config).
  Edit `GiftManager.taste`.
* **Wheel** now has Touch and Gift slices after the interactions.
* Sounds: chime on completed interactions, level-up sound on a bond level, hit sound when she lashes out, villager yes/no for gifts.

## 1.2.0 - Touch mode
Button **Touch** on the LEFT of the Interact GUI. You cannot move (camera stays free), the elf stands facing you ~1.5 blocks away
and holds still; the session ends if you or she are damaged, you move away, die, log out, change dimension, or you sneak.
* **Pointing = your crosshair.** The server raycasts from your eye and classifies the hit on her bounding box into Head, Face,
  Arm, Hand, Torso, Legs (`TouchZone.classify` - the thresholds are the knobs for your model's proportions).
* **Hold right-click to touch/drag.** Vanilla attack/use is blocked during touch (so right-click never opens her menu). Moving
  your view while holding drags the part you grabbed (head follows, arms swing). Your first-person right hand reaches out and
  follows your aim (`TouchArmAnimation`, a live Player Animator animation).
* **Gestures are decided by the server from your own look deltas:** slow left/right on the head = PAT (she bows her head);
  fast yanking = ROUGH (comfort drops fast); anything else = calm hold.
* **Comfort meter** (HUD, starts at 50): drifts toward a baseline of 50 + 10 x bond level; zone rates per bond level are in
  `TouchZone`. Torso/legs are uncomfortable at every level (a higher bond only makes her tolerate it longer); head/hand/arm
  turn pleasant as the bond grows, and gentle touch slowly earns affection (max +12 per session).
* **Refusal:** below 25 she pulls away and touching is ignored until comfort recovers to 40. **Pressing right-click again while
  she is refusing costs comfort**, which is how the meter can reach 0.
* **At 0:** she lashes out ONCE - bond loses max(40, 40%), one light hit on you (1 heart, never lethal, plus knockback), the
  session ends and she refuses touch for 3 minutes. Constants are at the top of `TouchManager`.
* Dialogue (`touch_*` lines, tiered by bond: cold / warm / close) goes through the original `ElfDialogue.say`, so her chat style and
  owner-only setting apply. Lines are boundary/comfort reactions only; nothing suggestive.
* Epic Fight: the same Vanilla Mode guard as interactions (switch only if in Epic Fight mode, restore on every end path).
Limits: the elf's reaction pose and your hand animation are local - other players do not see them. Hover accuracy depends on
the thresholds above. Mutually exclusive with normal interactions. Not compiled against Minecraft/NeoForge here (syntax-checked
only); NeoForge calls newly used from memory: `InputEvent.InteractionKeyMappingTriggered`, `RenderGuiEvent.Post`, `AABB#clip`,
`LivingEntity#knockback`.

## 1.1.0 changes
* **Blurry Interaction GUI fixed.** `renderBackground` was called twice (once by us, once by `Screen#render`); the second call blurred
  the panel that had already been drawn. The dim + panel are now drawn inside the single background pass, with a plain gradient.
* **Separate player and elf animations.** Every interaction now has its own player clip and its own elf clip (different poses,
  different timing), and the elf reacts `elfDelay` ticks after the player (`InteractionType`). Session length = the later end.
* **First-person hand movement.** Player Animator's `THIRD_PERSON_MODEL` first-person mode is enabled on the interaction layer: the
  animated arms the clip actually moves are shown, held items are hidden.
* **First-person camera effect** (`InteractionCamera`): soft pull of the view toward the elf's face + per-interaction FOV/pitch/roll
  motion (hug zoom, bow nod, high-five jolt, dance sway...). Render camera only, first person only, fades in/out.
* Heart particles on completion (happy-villager sparkles on a bond level-up).
Still not compiled against Minecraft/NeoForge here; your 1.0.0 build compiled from the 1.0.0 source unchanged.


Separate NeoForge 1.21.1 mod `elven_interactions`. **Your Elven Companions JAR is not modified** and no decompiled
code is compiled or shipped: the addon builds against `libs/elven_companions-1_4_0.jar` and calls only its public API.

## Status – read this first
Not compiled against Minecraft/NeoForge and never run (my sandbox could not reach the NeoForge/Mojang repositories).
Verified statically: all files parse; every call into Elven Companions (`ElfEntity`, `ElfManager.LOADED`, `ElfDialogue.say`,
`CommandScreen.elfId`, `ElfStatus.name`) resolves against your real JAR; Player Animator and Epic Fight signatures were read
from the real JARs with `javap`. NeoForge API details written from memory are the likeliest compile errors
(`SavedData.Factory`, `LivingDamageEvent.Post`, `MovementInputUpdateEvent`/`Input`, `Minecraft#getTimer`, vertex builder API,
`ScreenEvent.*`, `PacketDistributor.sendToPlayersTrackingEntityAndSelf`).

## Build
1. `gradle wrapper --gradle-version 8.10.2`   2. adjust `neo_version` / plugin version if needed   3. `gradlew build`
Put the resulting JAR in `mods/` next to Elven Companions 1.4.0 and Player Animator 2.0.4 (Epic Fight optional).

## How it attaches to the original mod (no source changes)
| Need | Technique |
|---|---|
| Network | own payload channel registered by the addon (`RegisterPayloadHandlersEvent`) |
| Interact button on the Elven screen | `ScreenEvent.Render.Post` / `MouseButtonPressed.Pre` on `CommandScreen`; position read from its private layout values by reflection (new row under the Back row). If that fails the button is hidden and nothing else breaks |
| Elf pose | **one mixin**, `ElfModelMixin`, injecting at the TAIL of `ElfModel#setupAnim` (the pose fields are private; no event exists there). Does nothing unless an interaction is active |
| Relationship data | addon's own world SavedData keyed by companion id |
| Wheel key, GUIs, animations, Epic Fight guard | all addon-side |

## Features
Interaction screen (with creative-only bond +/- test buttons; Shift = one full level), radial wheel (hold **V**), 7 interactions (Wave, High Five, Bow, Head Pat, Hold Hands, Dance, Hug) with
original keyframe clips for player and elf, 5-level bond with cooldowns and a small heal, server-authoritative sessions
(cancel on sneak/damage/distance/death/logout/dimension/server stop), Epic Fight Vanilla Mode guard (switch only if in Epic
Fight mode, block switching back during the animation, restore on every end path).

## Decisions
* GeckoLib not added: the elf is an OBJ mesh with six procedural bones, not a GeckoLib rig.
* BendyLib not needed: Player Animator 2.0.4 only enables bend mixins when BendyLib is present; everything else works.
* Mixin is unavoidable for a pure addon. If you ever want zero mixins, the alternative is a ~15-line public pose-hook added to
  `ElfModel` in the original mod.

## Tune in game
Pose signs (`Clip.toElfSign`, angle values in `InteractionType`), interaction distances, elf bow shown during gestures, whether elf
goals fight the hold (`InteractionManager.hold`), first-person view of the player animation, Interact button placement.

## reference/
`decompiled-elven-source/` is a readable decompile of your Elven JAR for reference only (not built; decompiler variable names).
Four decompiler artifacts were fixed in `ElfEntity`, `ElfSkills`, `Aura`, `TranscendMusic` in the earlier full-mod project, not here.
