package com.elvencompanions.interactions.mixin;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.ai.StargazeWalkGoal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fourth mixin (common): appends one extra goal to the elf's goal list so she can walk to a stargazing seat without her own
 * goals fighting the movement. The goal is inert unless a stargazing job is in its WALK phase. (Extends Mob so the protected
 * goalSelector field is directly accessible.)
 */
@Mixin(value = ElfEntity.class, remap = false)
public abstract class ElfEntityMixin extends Mob {
    protected ElfEntityMixin(EntityType<? extends Mob> type, Level level) {
        super(type, level);
    }

    @Inject(method = "registerGoals", at = @At("TAIL"), remap = false)
    private void elven_interactions$addGoals(CallbackInfo ci) {
        this.goalSelector.addGoal(-1, new StargazeWalkGoal((ElfEntity) (Object) this));
    }
}
