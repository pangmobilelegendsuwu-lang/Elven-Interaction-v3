package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.Clip.Ch;
import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.InteractionType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * First-person camera effect for the local player's interaction: a soft pull of the view toward the elf's face plus a
 * small per-interaction FOV / pitch / roll motion. Only touches the RENDER camera (never the player's real rotation),
 * only in first person, and fades in/out so it never snaps.
 * NOT RUN IN-GAME - strengths are deliberately mild; tune {@link #focus} and {@link #fx}.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class InteractionCamera {
    private static final float RAD = (float) (180.0 / Math.PI);
    private static final float MAX_YAW_PULL = 32f;
    private static final float MAX_PITCH_PULL = 22f;

    private InteractionCamera() {}

    /** FOV multiplier offset (fraction), pitch offset (degrees), roll offset (degrees) before the fade envelope. */
    private record Fx(float fov, float pitch, float roll) {}

    private static float sin(float t, float period, float phase) {
        return (float) Math.sin(t / period * Math.PI * 2.0 + phase);
    }

    private static float focus(InteractionType type) {
        return switch (type) {
            case WAVE -> 0.35f;
            case HIGH_FIVE -> 0.45f;
            case BOW -> 0.20f;
            case HEAD_PAT -> 0.50f;
            case HOLD_HANDS -> 0.50f;
            case DANCE -> 0.35f;
            case HUG -> 0.60f;
            case CHEEK_KISS -> 0.50f;
            case STARGAZE -> 0f;
        };
    }

    private static Fx fx(InteractionType type, float t) {
        return switch (type) {
            case WAVE -> new Fx(-0.03f, 0f, 0.6f * sin(t, 16f, 0f));
            case HIGH_FIVE -> {
                // a small jolt at the moment the hands meet (~tick 18 of the player clip)
                float d = t - 18f;
                float hit = d >= 0f && d < 8f ? (1f - d / 8f) : 0f;
                yield new Fx(-0.02f - 0.03f * hit, 2.2f * hit, 0f);
            }
            case BOW -> {
                // nod down with the player's own torso/head clip
                float lean = type.player.sample(Ch.TORSO_PITCH, t);
                float head = type.player.sample(Ch.HEAD_PITCH, t);
                float v = (Float.isNaN(lean) ? 0f : lean) + (Float.isNaN(head) ? 0f : head);
                yield new Fx(-0.02f, v * 13f, 0f);
            }
            case HEAD_PAT -> new Fx(-0.06f, 4.5f, 0.8f * sin(t, 28f, 0f));
            case HOLD_HANDS -> new Fx(-0.04f, 2f, 1.0f * sin(t, 40f, 0f));
            case DANCE -> new Fx(0.02f * sin(t, 12f, 0f), 1.2f * sin(t, 12f, 1.57f), 2.5f * sin(t, 24f, 0f));
            case HUG -> new Fx(-0.10f, 4f, 1.2f * sin(t, 50f, 0f));
            case CHEEK_KISS -> new Fx(-0.05f, 2.5f, 0.6f * sin(t, 36f, 0f));
            case STARGAZE -> new Fx(0f, 0f, 0f);
        };
    }

    private static float envelope(InteractionType type, float t) {
        float dur = type.duration();
        float e = Math.min(1f, Math.min(t / 10f, (dur - t) / 10f));
        e = Mth.clamp(e, 0f, 1f);
        return e * e * (3f - 2f * e);
    }

    private static boolean applies(Minecraft mc, ViewportEvent e) {
        return Cfg.CLIENT.cameraEffects.get() && mc.player != null && mc.level != null
                && mc.options.getCameraType().isFirstPerson()
                && e.getCamera().getEntity() == mc.player && ClientInteractions.selfActiveInfo() != null
                && ClientInteractions.selfActiveInfo().type.playerActs();
    }

    @SubscribeEvent
    public static void onAngles(ViewportEvent.ComputeCameraAngles e) {
        Minecraft mc = Minecraft.getInstance();
        if (!applies(mc, e)) return;
        ClientInteractions.Active a = ClientInteractions.selfActiveInfo();
        float t = ClientInteractions.elapsedWithPartial(a, (float) e.getPartialTick());
        float env = envelope(a.type, t);
        if (env <= 0f) return;

        float yaw = e.getYaw();
        float pitch = e.getPitch();
        float roll = e.getRoll();

        // 1) soft look-at toward the elf's face
        Entity elf = mc.level.getEntity(a.elfEntityId);
        if (elf != null) {
            Vec3 cam = e.getCamera().getPosition();
            Vec3 target = elf.getEyePosition((float) e.getPartialTick());
            double dx = target.x - cam.x;
            double dy = target.y - cam.y;
            double dz = target.z - cam.z;
            double h = Math.sqrt(dx * dx + dz * dz);
            if (h > 1.0E-3) {
                float ty = (float) (Mth.atan2(dz, dx) * RAD) - 90f;
                float tp = (float) (-(Mth.atan2(dy, h) * RAD));
                float dYaw = Mth.clamp(Mth.wrapDegrees(ty - yaw), -MAX_YAW_PULL, MAX_YAW_PULL);
                float dPitch = Mth.clamp(tp - pitch, -MAX_PITCH_PULL, MAX_PITCH_PULL);
                float f = Math.min(1f, focus(a.type) * Cfg.CLIENT.lookAtStrength.get().floatValue()) * env;
                yaw += dYaw * f;
                pitch += dPitch * f;
            }
        }

        // 2) per-interaction motion
        Fx fx = fx(a.type, t);
        float cs = Cfg.CLIENT.cameraStrength.get().floatValue();
        pitch += fx.pitch * env * cs;
        roll += fx.roll * env * cs;

        e.setYaw(yaw);
        e.setPitch(pitch);
        e.setRoll(roll);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov e) {
        Minecraft mc = Minecraft.getInstance();
        if (!applies(mc, e)) return;
        ClientInteractions.Active a = ClientInteractions.selfActiveInfo();
        float t = ClientInteractions.elapsedWithPartial(a, (float) e.getPartialTick());
        float env = envelope(a.type, t);
        if (env <= 0f) return;
        e.setFOV(e.getFOV() * (1.0 + fx(a.type, t).fov * env * Cfg.CLIENT.cameraStrength.get()));
    }
}
