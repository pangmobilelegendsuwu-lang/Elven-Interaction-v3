package com.elvencompanions.interactions;

/** Pure helpers for the stargazing session (no Minecraft types, unit-tested in tools/mesh-test). */
public final class StargazeMath {
    /** The elf looks around for this long before she starts walking. */
    public static final int SEARCH_TICKS = 40;
    /** Player settles in and turns to look at her. */
    public static final int SETTLE_TICKS = 15;
    /** Head turn from "looking at her" up to the sky. */
    public static final int SKY_TURN_TICKS = 30;

    /** Wire phases (0 = ended). */
    public static final int PHASE_END = 0;
    public static final int PHASE_SEARCH = 1;
    public static final int PHASE_WALK = 2;
    public static final int PHASE_SEATED = 3;
    public static final int PHASE_SCRIPT = 4;
    public static final int PHASE_HOLD = 5;

    private StargazeMath() {}

    /** Total length of the scripted part: settle, stare at her for gazeTicks, turn to the sky. */
    public static int scriptLength(int gazeTicks) {
        return SETTLE_TICKS + Math.max(0, gazeTicks) + SKY_TURN_TICKS;
    }

    /** Is the day-time inside [start, end]? A window with end < start wraps past midnight. */
    public static boolean inWindow(long dayTime, int start, int end) {
        long t = Math.floorMod(dayTime, 24000L);
        return start <= end ? (t >= start && t <= end) : (t >= start || t <= end);
    }

    /** X component of the unit vector pointing to the entity's RIGHT for a Minecraft yaw (yaw 0 faces +Z, so right is -X). */
    public static double rightX(float yawDeg) {
        return -Math.cos(Math.toRadians(yawDeg));
    }

    public static double rightZ(float yawDeg) {
        return -Math.sin(Math.toRadians(yawDeg));
    }

    /** +1 if the offset (dx, dz) from an entity facing yawDeg lies on its right, -1 on its left, 0 straight ahead/behind. */
    public static int sideOf(double dx, double dz, float yawDeg) {
        double d = dx * rightX(yawDeg) + dz * rightZ(yawDeg);
        return d > 1.0E-6 ? 1 : (d < -1.0E-6 ? -1 : 0);
    }

    /** Y of the invisible seat entity so that a rider's hips (vehicle attachment) end up on the seat surface. */
    public static double seatStandY(double surfaceY, double standHeight, double offset) {
        return surfaceY - standHeight + offset;
    }

    /** Smoothstep of x clamped to [0,1]. */
    public static float smooth(float x) {
        float c = Math.max(0f, Math.min(1f, x));
        return c * c * (3f - 2f * c);
    }
}
