package com.elvencompanions.interactions;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * A tiny keyframe clip shared by the elf pose layer and the Player Animator clip builder.
 * Angles are authored in VANILLA humanoid convention (radians): arm pitch -PI/2 = arm straight forward,
 * head pitch + = looking down, torso pitch + = leaning forward. The elf conversion (sign flips) lives in
 * {@link #toElfSign(Ch)} so there is exactly one place to tune it.
 */
public final class Clip {
    /** Animated channels. */
    public enum Ch {
        HEAD_PITCH, HEAD_YAW, TORSO_PITCH, TORSO_ROLL,
        R_ARM_PITCH, R_ARM_YAW, R_ARM_ROLL,
        L_ARM_PITCH, L_ARM_YAW, L_ARM_ROLL,
        R_LEG_PITCH, L_LEG_PITCH
    }

    private record Key(float t, float v) {}

    public final int duration;
    private final Map<Ch, List<Key>> tracks = new EnumMap<>(Ch.class);

    private Clip(int duration) {
        this.duration = duration;
    }

    public static Clip of(int durationTicks) {
        return new Clip(durationTicks);
    }

    /** Adds a keyframe at tick {@code t}. Keys must be added in ascending time order per channel. */
    public Clip key(Ch ch, float t, float v) {
        tracks.computeIfAbsent(ch, c -> new ArrayList<>()).add(new Key(t, v));
        return this;
    }

    /** Adds a sine oscillation (sampled every 2 ticks) between ticks t0 and t1, ending at 'base' value. */
    public Clip wave(Ch ch, float t0, float t1, float base, float amp, float periodTicks, float phase) {
        for (float t = t0; t <= t1; t += 2f) {
            float s = (float) Math.sin((t - t0) / periodTicks * Math.PI * 2.0 + phase);
            key(ch, t, base + amp * s);
        }
        return this;
    }

    private final Map<Ch, List<Key>> normCache = new EnumMap<>(Ch.class);

    /** Keys with an implicit neutral (0) key at tick 0 and at the clip end, so every animated channel returns home. */
    private List<Key> norm(Ch ch) {
        List<Key> cached = normCache.get(ch);
        if (cached != null) return cached;
        List<Key> ks = tracks.get(ch);
        if (ks == null || ks.isEmpty()) return null;
        List<Key> out = new ArrayList<>();
        if (ks.get(0).t > 0) out.add(new Key(0f, 0f));
        out.addAll(ks);
        if (ks.get(ks.size() - 1).t < duration) out.add(new Key(duration, 0f));
        normCache.put(ch, out);
        return out;
    }

    /** True when no channel has any keyframe (used for "elf-only" interactions). */
    public boolean isEmpty() {
        return tracks.isEmpty();
    }

    public boolean has(Ch ch) {
        return tracks.containsKey(ch);
    }

    /** Samples a channel at time t (ticks, fractional). Returns NaN when the channel is not animated. */
    public float sample(Ch ch, float t) {
        List<Key> ks = norm(ch);
        if (ks == null) return Float.NaN;
        if (t <= ks.get(0).t) return ks.get(0).v;
        Key last = ks.get(ks.size() - 1);
        if (t >= last.t) return last.v;
        for (int i = 1; i < ks.size(); i++) {
            Key b = ks.get(i);
            if (t <= b.t) {
                Key a = ks.get(i - 1);
                float u = (t - a.t) / Math.max(1e-4f, b.t - a.t);
                u = u * u * (3f - 2f * u); // smoothstep
                return a.v + (b.v - a.v) * u;
            }
        }
        return last.v;
    }

    public int keyCount(Ch ch) {
        List<Key> k = norm(ch);
        return k == null ? 0 : k.size();
    }

    public float keyTime(Ch ch, int i) {
        return norm(ch).get(i).t;
    }

    public float keyValue(Ch ch, int i) {
        return norm(ch).get(i).v;
    }

    /**
     * Sign to apply to a vanilla-convention angle to get the elf model's convention.
     * Derived from the elf model's own constants: head/arm/leg/torso X and Y are inverted, Z is not.
     * UNVERIFIED in-game: if a pose looks mirrored, flip the relevant sign here.
     */
    public static float toElfSign(Ch ch) {
        return switch (ch) {
            case R_ARM_ROLL, L_ARM_ROLL, TORSO_ROLL -> 1f;
            default -> -1f;
        };
    }
}
