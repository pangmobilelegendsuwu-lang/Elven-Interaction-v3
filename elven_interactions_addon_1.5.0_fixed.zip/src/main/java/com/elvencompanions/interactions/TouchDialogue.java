package com.elvencompanions.interactions;

import com.elvencompanions.entity.ElfDialogue;
import com.elvencompanions.entity.ElfEntity;

/**
 * Picks touch-mode lines. Uses the original mod's ElfDialogue.say (so its owner-only config and chat style apply):
 * every line is its own key "touch_<what>_<tier>_<a|b>" because say() only knows single-variant keys it was not told about.
 */
public final class TouchDialogue {
    private TouchDialogue() {}

    /** cold = Stranger/Acquaintance, warm = Friend/Close Friend, close = Bonded. */
    public static String tier(int bondLevel) {
        return bondLevel <= 1 ? "cold" : bondLevel <= 3 ? "warm" : "close";
    }

    /** Says "<base>_a" or "<base>_b". */
    public static void line(ElfEntity elf, String base) {
        ElfDialogue.say(elf, base + (elf.getRandom().nextBoolean() ? "_a" : "_b"));
    }

    public static void single(ElfEntity elf, String key) {
        ElfDialogue.say(elf, key);
    }
}
