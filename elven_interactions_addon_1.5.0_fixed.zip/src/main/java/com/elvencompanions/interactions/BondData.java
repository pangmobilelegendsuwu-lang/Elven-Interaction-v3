package com.elvencompanions.interactions;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Per-companion relationship ("bond") data, kept in world SavedData keyed by the companion id so the existing
 * ElfEntity class does not need to change. Survives respawn/revive because the companion id is stable.
 */
public final class BondData extends SavedData {
    public static final String NAME = "elven_companions_bonds";
    /** Affection needed for bond levels 0..4. */
    public static final int[] THRESHOLDS = {0, 50, 150, 350, 700};
    public static final int MAX = 1000;

    private final Map<UUID, Integer> affection = new HashMap<>();
    /** Absolute server game-time (overworld) until which each interaction type is on cooldown. */
    private final Map<UUID, long[]> cooldownUntil = new HashMap<>();

    public static BondData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(BondData::new, BondData::load, null), NAME);
    }

    public int affection(UUID elf) {
        return affection.getOrDefault(elf, 0);
    }

    public int level(UUID elf) {
        return levelOf(affection(elf));
    }

    public static int levelOf(int aff) {
        int lv = 0;
        for (int i = 0; i < THRESHOLDS.length; i++) {
            if (aff >= THRESHOLDS[i]) lv = i;
        }
        return lv;
    }

    /** Creative test helper: +/-25 affection, or (wholeLevel) the jump to the next/previous level boundary. */
    public static int adjustDelta(int aff, boolean up, boolean wholeLevel) {
        if (!wholeLevel) return up ? 25 : -25;
        int lv = levelOf(aff);
        int target;
        if (up) {
            target = lv >= maxLevel() ? MAX : THRESHOLDS[lv + 1];
        } else {
            target = aff > THRESHOLDS[lv] ? THRESHOLDS[lv] : (lv > 0 ? THRESHOLDS[lv - 1] : 0);
        }
        return target - aff;
    }

    public static int maxLevel() {
        return THRESHOLDS.length - 1;
    }

    /** Adds affection; returns true if the bond level went up. */
    public boolean add(UUID elf, int amount) {
        int before = affection(elf);
        int after = Math.min(MAX, Math.max(0, before + amount));
        affection.put(elf, after);
        setDirty();
        return levelOf(after) > levelOf(before);
    }

    /** Absolute overworld game-time until which the elf refuses touch mode (set after she lashes out). */
    private final Map<UUID, Long> touchLock = new HashMap<>();

    public long touchLockEnd(UUID elf) {
        return touchLock.getOrDefault(elf, 0L);
    }

    public void setTouchLock(UUID elf, long until) {
        affection.putIfAbsent(elf, 0);
        touchLock.put(elf, until);
        setDirty();
    }

    /** Cooldown slot used for gifts (after the interaction types). */
    public static final int GIFT_SLOT = InteractionType.values().length;

    private static int slots() {
        return InteractionType.values().length + 1;
    }

    public long cooldownEnd(UUID elf, int slot) {
        long[] a = cooldownUntil.get(elf);
        return a == null || slot >= a.length ? 0L : a[slot];
    }

    public void setCooldown(UUID elf, int slot, long until) {
        long[] a = cooldownUntil.computeIfAbsent(elf, k -> new long[slots()]);
        if (slot >= a.length) {
            a = java.util.Arrays.copyOf(a, slots());
            cooldownUntil.put(elf, a);
        }
        a[slot] = until;
        setDirty();
    }

    public long cooldownEnd(UUID elf, InteractionType t) {
        return cooldownEnd(elf, t.ordinal());
    }

    public void setCooldown(UUID elf, InteractionType t, long until) {
        setCooldown(elf, t.ordinal(), until);
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Integer> e : affection.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("id", e.getKey());
            c.putInt("aff", e.getValue());
            long[] cd = cooldownUntil.get(e.getKey());
            if (cd != null) c.putLongArray("cd", cd);
            Long tl = touchLock.get(e.getKey());
            if (tl != null && tl > 0L) c.putLong("tl", tl);
            list.add(c);
        }
        tag.put("bonds", list);
        return tag;
    }

    public static BondData load(CompoundTag tag, HolderLookup.Provider registries) {
        BondData d = new BondData();
        ListTag list = tag.getList("bonds", Tag.TAG_COMPOUND);
        int n = slots();
        for (int i = 0; i < list.size(); i++) {
            CompoundTag c = list.getCompound(i);
            if (!c.hasUUID("id")) continue;
            UUID id = c.getUUID("id");
            d.affection.put(id, c.getInt("aff"));
            if (c.contains("tl")) d.touchLock.put(id, c.getLong("tl"));
            long[] cd = c.getLongArray("cd");
            if (cd.length > 0) {
                long[] fixed = new long[n];
                System.arraycopy(cd, 0, fixed, 0, Math.min(n, cd.length));
                d.cooldownUntil.put(id, fixed);
            }
        }
        return d;
    }
}
