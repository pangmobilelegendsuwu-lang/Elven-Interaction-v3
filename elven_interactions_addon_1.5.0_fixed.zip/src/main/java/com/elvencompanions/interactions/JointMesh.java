package com.elvencompanions.interactions;

import java.util.ArrayList;
import java.util.List;

/**
 * Splits a limb mesh at a horizontal joint plane (elbow / knee) so the lower half can be rotated about the joint while the
 * upper half stays rigid, with small "cap" faces that close the cut so the bend does not open a hole. Pure geometry, no
 * Minecraft types, unit-tested against the real elf OBJ (tools/mesh-test).
 *
 * Data layout is the renderer's: quads of 4 vertices, 8 floats each (x y z u v nx ny nz). Triangles are stored as quads with
 * the last vertex repeated. Face winding convention of the elf OBJ: cross(v1 - v0, v2 - v0) points along the outward normal.
 */
public final class JointMesh {
    public static final int V = 8;
    private static final float EPS = 1.0e-5f;

    private JointMesh() {}

    public static final class Split {
        /** Pieces at or above the plane (stay rigid with the parent bone). */
        public final float[] upper;
        /** Pieces at or below the plane (rotate about the joint). */
        public final float[] lower;
        /** Closes the cut on the upper piece (faces down). Empty if the part does not cross the plane. */
        public final float[] capUpper;
        /** Closes the cut on the lower piece (faces up). Empty if the part does not cross the plane. */
        public final float[] capLower;

        Split(float[] upper, float[] lower, float[] capUpper, float[] capLower) {
            this.upper = upper;
            this.lower = lower;
            this.capUpper = capUpper;
            this.capLower = capLower;
        }
    }

    public static Split split(float[] data, float planeY) {
        List<Float> up = new ArrayList<>();
        List<Float> low = new ArrayList<>();
        List<float[]> cuts = new ArrayList<>();
        // overall extent of the part: a face lying exactly ON the plane follows the part it belongs to
        float partMin = Float.MAX_VALUE;
        float partMax = -Float.MAX_VALUE;
        for (int i = 1; i < data.length; i += V) {
            partMin = Math.min(partMin, data[i]);
            partMax = Math.max(partMax, data[i]);
        }
        for (int q = 0; q + 4 * V <= data.length; q += 4 * V) {
            List<float[]> poly = new ArrayList<>(4);
            for (int k = 0; k < 4; k++) {
                float[] v = new float[V];
                System.arraycopy(data, q + k * V, v, 0, V);
                if (!poly.isEmpty() && same(poly.get(poly.size() - 1), v)) continue;
                poly.add(v);
            }
            if (poly.size() > 1 && same(poly.get(0), poly.get(poly.size() - 1))) poly.remove(poly.size() - 1);
            if (poly.size() < 3) continue;

            float minY = Float.MAX_VALUE;
            float maxY = -Float.MAX_VALUE;
            for (float[] v : poly) {
                minY = Math.min(minY, v[1]);
                maxY = Math.max(maxY, v[1]);
            }
            if (minY >= planeY - EPS && maxY <= planeY + EPS) {
                // on the plane: lower if the whole part sits at/below the joint, otherwise upper
                emit(partMax <= planeY + EPS ? low : up, poly);
            } else if (minY >= planeY - EPS) {
                emit(up, poly);
            } else if (maxY <= planeY + EPS) {
                emit(low, poly);
            } else {
                List<float[]> u = clip(poly, planeY, true);
                List<float[]> l = clip(poly, planeY, false);
                emit(up, u);
                emit(low, l);
                for (float[] v : u) if (Math.abs(v[1] - planeY) <= EPS) cuts.add(v);
            }
        }

        float[] capUp = new float[0];
        float[] capLow = new float[0];
        if (!up.isEmpty() && !low.isEmpty() && cuts.size() >= 3) {
            List<float[]> hull = hull(cuts);
            if (hull.size() >= 3) {
                float u = cuts.get(0)[3];
                float v = cuts.get(0)[4];
                capUp = cap(hull, planeY, u, v, -1f);
                capLow = cap(hull, planeY, u, v, +1f);
            }
        }
        return new Split(toArray(up), toArray(low), capUp, capLow);
    }

    // ------------------------------------------------------------------ rotation (used by the renderer and by tests)

    /** Rotates a vertex array copy about the X axis through (y = jointY, z = pivotZ). Positive angle swings the lower part toward -Z. */
    public static float[] rotateAboutX(float[] quads, float jointY, float pivotZ, float angle) {
        float[] out = new float[quads.length];
        float c = (float) Math.cos(angle);
        float s = (float) Math.sin(angle);
        for (int i = 0; i + V <= quads.length; i += V) {
            float dy = quads[i + 1] - jointY;
            float dz = quads[i + 2] - pivotZ;
            out[i] = quads[i];
            out[i + 1] = jointY + dy * c - dz * s;
            out[i + 2] = pivotZ + dy * s + dz * c;
            out[i + 3] = quads[i + 3];
            out[i + 4] = quads[i + 4];
            float ny = quads[i + 6];
            float nz = quads[i + 7];
            out[i + 5] = quads[i + 5];
            out[i + 6] = ny * c - nz * s;
            out[i + 7] = ny * s + nz * c;
        }
        return out;
    }

    // ------------------------------------------------------------------ internals

    private static boolean same(float[] a, float[] b) {
        return Math.abs(a[0] - b[0]) < 1.0E-6f && Math.abs(a[1] - b[1]) < 1.0E-6f && Math.abs(a[2] - b[2]) < 1.0E-6f;
    }

    private static List<float[]> clip(List<float[]> poly, float plane, boolean keepUpper) {
        List<float[]> out = new ArrayList<>();
        int n = poly.size();
        for (int i = 0; i < n; i++) {
            float[] a = poly.get(i);
            float[] b = poly.get((i + 1) % n);
            boolean ain = keepUpper ? a[1] >= plane : a[1] <= plane;
            boolean bin = keepUpper ? b[1] >= plane : b[1] <= plane;
            if (ain) out.add(a);
            if (ain != bin) {
                float t = (plane - a[1]) / (b[1] - a[1]);
                float[] v = new float[V];
                for (int k = 0; k < V; k++) v[k] = a[k] + (b[k] - a[k]) * t;
                v[1] = plane;
                float len = (float) Math.sqrt(v[5] * v[5] + v[6] * v[6] + v[7] * v[7]);
                if (len > 1.0E-6f) {
                    v[5] /= len;
                    v[6] /= len;
                    v[7] /= len;
                }
                out.add(v);
            }
        }
        List<float[]> clean = new ArrayList<>();
        for (float[] v : out) {
            if (clean.isEmpty() || !same(clean.get(clean.size() - 1), v)) clean.add(v);
        }
        if (clean.size() > 1 && same(clean.get(0), clean.get(clean.size() - 1))) clean.remove(clean.size() - 1);
        return clean;
    }

    private static void emit(List<Float> out, List<float[]> poly) {
        int n = poly.size();
        if (n < 3) return;
        if (n == 4) {
            for (float[] v : poly) add(out, v);
            return;
        }
        for (int i = 1; i + 1 < n; i++) {
            add(out, poly.get(0));
            add(out, poly.get(i));
            add(out, poly.get(i + 1));
            add(out, poly.get(i + 1));
        }
    }

    private static void add(List<Float> out, float[] v) {
        for (int k = 0; k < V; k++) out.add(v[k]);
    }

    private static float[] toArray(List<Float> l) {
        float[] a = new float[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }

    /** Convex hull of the cut points in the XZ plane, counter-clockwise (viewed from +Y looking down with x right, z up). */
    private static List<float[]> hull(List<float[]> pts) {
        List<float[]> u = new ArrayList<>();
        for (float[] p : pts) {
            boolean dup = false;
            for (float[] q : u) if (Math.abs(p[0] - q[0]) < 1.0E-4f && Math.abs(p[2] - q[2]) < 1.0E-4f) { dup = true; break; }
            if (!dup) u.add(p);
        }
        u.sort((a, b) -> a[0] != b[0] ? Float.compare(a[0], b[0]) : Float.compare(a[2], b[2]));
        if (u.size() < 3) return u;
        List<float[]> h = new ArrayList<>();
        for (int pass = 0; pass < 2; pass++) {
            int start = h.size();
            for (int i = 0; i < u.size(); i++) {
                float[] p = pass == 0 ? u.get(i) : u.get(u.size() - 1 - i);
                while (h.size() >= start + 2 && cross2(h.get(h.size() - 2), h.get(h.size() - 1), p) <= 0) h.remove(h.size() - 1);
                h.add(p);
            }
            h.remove(h.size() - 1);
        }
        return h;
    }

    private static float cross2(float[] o, float[] a, float[] b) {
        return (a[0] - o[0]) * (b[2] - o[2]) - (a[2] - o[2]) * (b[0] - o[0]);
    }

    /** Fan of triangles (as quads with the last vertex repeated) closing the hull, wound so the face normal is (0, ny, 0). */
    private static float[] cap(List<float[]> hull, float planeY, float u, float v, float ny) {
        List<Float> out = new ArrayList<>();
        float[] h0 = hull.get(0);
        for (int i = 1; i + 1 < hull.size(); i++) {
            float[] a = h0;
            float[] b = hull.get(i);
            float[] c = hull.get(i + 1);
            // geometric normal y of (b-a)x(c-a) = (bz-az)*(cx-ax)... compute properly
            double ax = b[0] - a[0], ay = 0, az = b[2] - a[2];
            double bx = c[0] - a[0], bz = c[2] - a[2];
            double nyGeo = az * bx - ax * bz; // y component of cross((ax,0,az),(bx,0,bz))
            if (nyGeo * ny < 0) { float[] t = b; b = c; c = t; }
            for (float[] p : new float[][]{a, b, c, c}) {
                out.add(p[0]); out.add(planeY); out.add(p[2]);
                out.add(u); out.add(v);
                out.add(0f); out.add(ny); out.add(0f);
            }
        }
        return toArray(out);
    }
}
