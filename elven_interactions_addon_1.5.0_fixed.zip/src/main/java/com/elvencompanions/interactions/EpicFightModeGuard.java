package com.elvencompanions.interactions;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import yesman.epicfight.api.event.EpicFightEventHooks;
import yesman.epicfight.api.event.types.player.TogglePlayerModeEvent;
import yesman.epicfight.world.capabilities.EpicFightCapabilities;
import yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch;
import yesman.epicfight.world.capabilities.entitypatch.player.ServerPlayerPatch;

/**
 * Epic Fight "Vanilla Mode" guard (server side, authoritative).
 *
 * enter():  if the player is in EPICFIGHT mode, remember that and switch to VANILLA via the official
 *           PlayerPatch#toVanillaMode(true) (which also syncs to clients). Already-vanilla players are untouched.
 * hook:     while locked, TogglePlayerModeEvent -> EPICFIGHT is cancelled, so neither the player's toggle key nor
 *           Epic Fight itself can pull the player back into battle mode mid-animation.
 * exit():   removes the lock FIRST, then restores EPICFIGHT mode - only if we were the ones who switched.
 *
 * Everything here is compiled against epic-fight 21.17.3.1 but has NOT been run in-game.
 */
final class EpicFightModeGuard implements ModeGuard {
    /** Players whose EPICFIGHT mode we switched away from (value = restore needed). */
    private final Set<UUID> switched = new HashSet<>();
    /** Players for whom switching back to EPICFIGHT is currently blocked. */
    private final Set<UUID> locked = new HashSet<>();

    EpicFightModeGuard() {
        EpicFightEventHooks.Player.TOGGLE_MODE.registerEvent(this::onToggle);
    }

    private void onToggle(TogglePlayerModeEvent event) {
        if (event.getPlayerMode() != PlayerPatch.PlayerMode.EPICFIGHT) return;
        if (!(event.getPlayerPatch().getOriginal() instanceof ServerPlayer sp)) return;
        if (locked.contains(sp.getUUID())) {
            event.cancel();
        }
    }

    private static ServerPlayerPatch patch(ServerPlayer p) {
        return EpicFightCapabilities.getEntityPatch(p, ServerPlayerPatch.class);
    }

    @Override
    public void enter(ServerPlayer player) {
        ServerPlayerPatch pp = patch(player);
        if (pp == null) return;
        UUID id = player.getUUID();
        if (pp.isEpicFightMode()) {
            switched.add(id);
            locked.add(id); // lock BEFORE switching so nothing can race us back
            pp.toVanillaMode(true);
        } else if (pp.isVanillaMode()) {
            // Already vanilla: nothing to switch, but still block a mid-animation switch INTO epic fight.
            locked.add(id);
        }
    }

    @Override
    public void exit(ServerPlayer player, boolean online) {
        UUID id = player.getUUID();
        boolean wasLocked = locked.remove(id);
        boolean mustRestore = switched.remove(id);
        if (!wasLocked && !mustRestore) return;
        if (!mustRestore) return;
        ServerPlayerPatch pp = patch(player);
        if (pp != null && pp.isVanillaMode()) {
            // sync only when the client can receive it
            pp.toEpicFightMode(online);
        }
    }

    @Override
    public void clear() {
        locked.clear();
        switched.clear();
    }
}
