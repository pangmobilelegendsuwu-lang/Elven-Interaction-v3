package com.elvencompanions.interactions.client;

import com.elvencompanions.client.CommandScreen;
import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.net.ElfStatus;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/**
 * Adds the "Interact" button to the existing Elven command screen WITHOUT modifying it: the button is drawn and
 * clicked through screen events, positioned on a new row under the existing bottom row using the screen's own
 * (private) layout values, read by reflection. If reflection fails (the original mod changed), the button simply
 * does not appear and nothing else is affected.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class CommandScreenHook {
    private static Field fK, fOx, fOy, fStatus;
    private static Method mShift;
    private static boolean failed;

    private CommandScreenHook() {}

    private record Rect(int x, int y, int w, int h) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private static Rect rect(CommandScreen cs) {
        if (failed) return null;
        try {
            if (fK == null) {
                fK = CommandScreen.class.getDeclaredField("k");
                fOx = CommandScreen.class.getDeclaredField("ox");
                fOy = CommandScreen.class.getDeclaredField("oy");
                fStatus = CommandScreen.class.getDeclaredField("status");
                mShift = CommandScreen.class.getDeclaredMethod("skillShift");
                for (java.lang.reflect.AccessibleObject o : new java.lang.reflect.AccessibleObject[]{fK, fOx, fOy, fStatus, mShift}) {
                    o.setAccessible(true);
                }
            }
            float k = fK.getFloat(cs);
            int ox = fOx.getInt(cs);
            int oy = fOy.getInt(cs);
            int shift = (Integer) mShift.invoke(cs);
            // Same math as CommandScreen#X/Y/S: coordinate - 8 (x) / - 10 (y), times k, plus the screen origin.
            int x = ox + Math.round((822f - 8f) * k);
            int w = Math.max(1, Math.round((1630f - 822f) * k));
            int y = oy + Math.round((906f + shift - 10f) * k);
            int h = Math.max(1, Math.round(64f * k));
            return new Rect(x, y, w, h);
        } catch (ReflectiveOperationException | RuntimeException e) {
            failed = true;
            ElvenInteractions.LOGGER.warn("Could not position the Interact button on the Elven screen; hidden", e);
            return null;
        }
    }

    private static String elfName(CommandScreen cs) {
        try {
            return ((ElfStatus) fStatus.get(cs)).name();
        } catch (ReflectiveOperationException | RuntimeException e) {
            return "";
        }
    }

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post e) {
        if (!(e.getScreen() instanceof CommandScreen cs)) return;
        Rect r = rect(cs);
        if (r == null) return;
        GuiGraphics g = e.getGuiGraphics();
        boolean hover = r.contains(e.getMouseX(), e.getMouseY());
        g.fill(r.x - 1, r.y - 1, r.x + r.w + 1, r.y + r.h + 1, hover ? 0xFFFFE9A0 : 0xFFC9A84A);
        g.fill(r.x, r.y, r.x + r.w, r.y + r.h, hover ? 0xFF2F4A34 : 0xFF1F3324);
        var font = Minecraft.getInstance().font;
        Component label = Component.translatable("gui.elven_companions.interact");
        g.drawCenteredString(font, label, r.x + r.w / 2, r.y + (r.h - font.lineHeight) / 2 + 1, 0xFFEFEFD0);
    }

    @SubscribeEvent
    public static void onClick(ScreenEvent.MouseButtonPressed.Pre e) {
        if (!(e.getScreen() instanceof CommandScreen cs) || e.getButton() != 0) return;
        Rect r = rect(cs);
        if (r == null || !r.contains(e.getMouseX(), e.getMouseY())) return;
        Minecraft.getInstance().setScreen(new InteractionScreen(cs, cs.elfId(), -1, elfName(cs)));
        e.setCanceled(true);
    }
}
