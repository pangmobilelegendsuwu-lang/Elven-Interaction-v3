package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.Cfg;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;

/**
 * Which elves currently have their weapon put away. An elf is stowed for as long as an interaction / touch session runs on her
 * and for a short grace period afterwards (so she visibly takes the bow out again instead of it popping back). Client-side
 * and purely visual: her inventory is never touched. Read by {@code ElfHeldItemLayerMixin}.
 */
public final class StowState {
    private static final Map<Integer, Long> UNTIL = new HashMap<>();

    private StowState() {}

    private static long now() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0L : mc.level.getGameTime();
    }

    /** A session started on this elf: stowed until {@link #end}. */
    public static void begin(int elfEntityId) {
        UNTIL.put(elfEntityId, Long.MAX_VALUE);
    }

    /** The session ended: keep her hands empty for the configured grace period, then she re-equips. */
    public static void end(int elfEntityId) {
        if (!UNTIL.containsKey(elfEntityId)) return;
        UNTIL.put(elfEntityId, now() + Cfg.CLIENT.stowGraceTicks.get());
    }

    public static void clear() {
        UNTIL.clear();
    }

    public static boolean hidden(int elfEntityId) {
        Long until = UNTIL.get(elfEntityId);
        if (until == null) return false;
        if (until != Long.MAX_VALUE && now() > until) {
            UNTIL.remove(elfEntityId);
            return false;
        }
        return true;
    }
}
