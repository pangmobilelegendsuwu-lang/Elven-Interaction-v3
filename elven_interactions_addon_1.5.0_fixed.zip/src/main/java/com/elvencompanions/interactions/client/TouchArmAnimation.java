package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.Cfg;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

/**
 * Live (not keyframed) right-arm animation for touch mode: while right-click is held the arm reaches out and points where
 * the camera looks (so the first-person hand follows your aim and drag), with a little wobble while the view is moving.
 * Fades in/out; rendered in first person through Player Animator's third-person-model mode.
 * NOT RUN IN-GAME: "rightArm" is the bone name used by Player Animator's keyframe players; arm pitch convention is vanilla's
 * (-PI/2 = straight forward).
 */
final class TouchArmAnimation implements IAnimation {
    volatile boolean holding;
    volatile boolean stopping;
    private float weight;
    private float partial;
    private boolean done;

    @Override
    public void tick() {
        float target = holding && !stopping ? 1f : 0f;
        weight += Mth.clamp(target - weight, -0.18f, 0.25f);
        if (stopping && weight <= 0.001f) done = true;
    }

    @Override
    public boolean isActive() {
        return !done;
    }

    @Override
    public Vec3f get3DTransform(String modelName, TransformType type, float tickDelta, Vec3f value0) {
        if (type != TransformType.ROTATION || weight <= 0.001f || !"rightArm".equals(modelName)) return value0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return value0;
        float camPitch = mc.player.getViewXRot(partial) * Mth.DEG_TO_RAD;
        // aim: forward is -PI/2, looking down raises it toward 0
        float pitch = -Mth.HALF_PI + Mth.clamp(camPitch, -1.2f, 1.2f);
        float motion = Math.abs(TouchClient.dragYaw()) + Math.abs(TouchClient.dragPitch());
        float t = (mc.player.tickCount + partial);
        pitch += 0.05f * motion * (float) Math.sin(t * 0.7f);
        float yaw = Mth.clamp(-TouchClient.dragYaw() * 0.4f, -0.5f, 0.5f);
        float roll = 0.1f;
        float w = weight;
        return new Vec3f(Mth.lerp(w, value0.getX(), pitch), Mth.lerp(w, value0.getY(), yaw), Mth.lerp(w, value0.getZ(), roll));
    }

    @Override
    public void setupAnim(float tickDelta) {
        this.partial = tickDelta;
    }

    @Override
    public FirstPersonMode getFirstPersonMode(float tickDelta) {
        return weight > 0.001f && Cfg.CLIENT.firstPersonArms.get() ? FirstPersonMode.THIRD_PERSON_MODEL : FirstPersonMode.NONE;
    }

    @Override
    public FirstPersonConfiguration getFirstPersonConfiguration(float tickDelta) {
        return new FirstPersonConfiguration().setShowRightArm(true).setShowLeftArm(false)
                .setShowRightItem(false).setShowLeftItem(false);
    }
}
