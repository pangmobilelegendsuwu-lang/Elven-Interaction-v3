package com.elvencompanions.interactions.client;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.Clip;
import com.elvencompanions.interactions.Clip.Ch;

/**
 * Samples the elf's side of the active interaction. ElfModel calls {@link #sample} at the end of setupAnim and mixes
 * the result over its normal procedural pose (so the elf's existing poses are the blend source, not replaced).
 */
public final class InteractionPose {
    /** Output slots. [0] is blend weight, the rest are elf-convention angles (NaN = untouched). */
    public static final int W = 0, HEAD_X = 1, HEAD_Y = 2, TORSO_X = 3, TORSO_Z = 4,
            R_ARM_X = 5, R_ARM_Y = 6, R_ARM_Z = 7, L_ARM_X = 8, L_ARM_Y = 9, L_ARM_Z = 10, R_LEG_X = 11, L_LEG_X = 12;
    public static final int SIZE = 13;
    private static final float BLEND_TICKS = 6f;

    private InteractionPose() {}

    /** @return pose array, or null when this elf is not interacting. */
    public static float[] sample(ElfEntity elf) {
        ClientInteractions.Active a = ClientInteractions.activeForElf(elf.getId());
        if (a == null) return null;
        Clip c = a.type.elf;
        // The elf has its OWN timeline: it reacts type.elfDelay ticks after the player starts.
        float t = ClientInteractions.elapsedWithPartial(a) - a.type.elfDelay;
        if (t < 0f || t > c.duration) return null;
        float[] out = new float[SIZE];
        out[W] = Math.max(0f, Math.min(1f, Math.min(t / BLEND_TICKS, (c.duration - t) / BLEND_TICKS)));
        put(out, HEAD_X, c, Ch.HEAD_PITCH, t);
        put(out, HEAD_Y, c, Ch.HEAD_YAW, t);
        put(out, TORSO_X, c, Ch.TORSO_PITCH, t);
        put(out, TORSO_Z, c, Ch.TORSO_ROLL, t);
        fillArms(out,
                val(c, Ch.R_ARM_PITCH, t), val(c, Ch.R_ARM_YAW, t), val(c, Ch.R_ARM_ROLL, t),
                val(c, Ch.L_ARM_PITCH, t), val(c, Ch.L_ARM_YAW, t), val(c, Ch.L_ARM_ROLL, t));
        put(out, R_LEG_X, c, Ch.R_LEG_PITCH, t);
        put(out, L_LEG_X, c, Ch.L_LEG_PITCH, t);
        return out;
    }

    private static void put(float[] out, int slot, Clip c, Ch ch, float t) {
        out[slot] = val(c, ch, t);
    }

    /** Sample a channel and convert to the elf's convention (NaN stays NaN = channel untouched). */
    private static float val(Clip c, Ch ch, float t) {
        float v = c.sample(ch, t);
        return Float.isNaN(v) ? Float.NaN : v * sign(ch);
    }

    /** Elf-convention sign for a channel: the model-derived default, optionally flipped by the client config. */
    public static float sign(Ch ch) {
        boolean flip = switch (ch) {
            case HEAD_PITCH -> Cfg.CLIENT.flipHeadPitch.get();
            case HEAD_YAW -> Cfg.CLIENT.flipHeadYaw.get();
            case TORSO_PITCH -> Cfg.CLIENT.flipTorsoPitch.get();
            case TORSO_ROLL -> Cfg.CLIENT.flipTorsoRoll.get();
            case R_ARM_PITCH, L_ARM_PITCH -> Cfg.CLIENT.flipArmPitch.get();
            case R_ARM_YAW, L_ARM_YAW -> Cfg.CLIENT.flipArmYaw.get();
            case R_ARM_ROLL, L_ARM_ROLL -> Cfg.CLIENT.flipArmRoll.get();
            case R_LEG_PITCH, L_LEG_PITCH -> Cfg.CLIENT.flipLegPitch.get();
        };
        float base = Clip.toElfSign(ch);
        return flip ? -base : base;
    }

    /**
     * Writes both arms (values already in elf convention). With swapElfArms the clip's right arm drives the model's left
     * arm and vice versa, mirroring yaw/roll so the motion stays a mirror image rather than a copy.
     */
    public static void fillArms(float[] out, float rx, float ry, float rz, float lx, float ly, float lz) {
        if (Cfg.CLIENT.swapElfArms.get()) {
            out[R_ARM_X] = lx; out[R_ARM_Y] = -ly; out[R_ARM_Z] = -lz;
            out[L_ARM_X] = rx; out[L_ARM_Y] = -ry; out[L_ARM_Z] = -rz;
        } else {
            out[R_ARM_X] = rx; out[R_ARM_Y] = ry; out[R_ARM_Z] = rz;
            out[L_ARM_X] = lx; out[L_ARM_Y] = ly; out[L_ARM_Z] = lz;
        }
    }
}
