package com.elvencompanions.interactions.client;

import com.elvencompanions.client.ElfObjModel;
import com.elvencompanions.interactions.JointMesh;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

/**
 * Elbow/knee bend state for the elf being rendered, and the draw routine that renders a split limb with its lower half
 * rotated about the joint. {@code ElfModelMixin} sets the angles in setupAnim (right before that same elf is rendered),
 * {@code ElfObjPartMixin} reads them per OBJ part. Angles are signed radians: arms positive (forearm swings forward),
 * legs negative (shin swings back); 0 means "render normally".
 */
public final class JointBend {
    private static float armR;
    private static float armL;
    private static float legR;
    private static float legL;

    private JointBend() {}

    public static void set(float armRight, float armLeft, float legRight, float legLeft) {
        armR = armRight;
        armL = armLeft;
        legR = legRight;
        legL = legLeft;
    }

    public static void clear() {
        armR = armL = legR = legL = 0f;
    }

    public static float angleFor(ElfObjModel.Bone bone) {
        return switch (bone) {
            case R_ARM -> armR;
            case L_ARM -> armL;
            case R_LEG -> legR;
            case L_LEG -> legL;
            default -> 0f;
        };
    }

    public static void draw(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay, int color,
                            JointMesh.Split split, float angle, float jointY, float pivotZ) {
        emit(pose, vc, light, overlay, color, split.upper);
        emit(pose, vc, light, overlay, color, split.capUpper);
        emit(pose, vc, light, overlay, color, JointMesh.rotateAboutX(split.lower, jointY, pivotZ, angle));
        emit(pose, vc, light, overlay, color, JointMesh.rotateAboutX(split.capLower, jointY, pivotZ, angle));
    }

    private static void emit(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay, int color, float[] q) {
        for (int i = 0; i + JointMesh.V <= q.length; i += JointMesh.V) {
            vc.addVertex(pose.pose(), q[i], q[i + 1], q[i + 2])
                    .setColor(color)
                    .setUv(q[i + 3], q[i + 4])
                    .setOverlay(overlay)
                    .setLight(light)
                    .setNormal(pose, q[i + 5], q[i + 6], q[i + 7]);
        }
    }
}
