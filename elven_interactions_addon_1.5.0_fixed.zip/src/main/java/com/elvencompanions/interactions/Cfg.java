package com.elvencompanions.interactions;

import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * Tunables, so pose directions, camera strength, touch rules etc. can be adjusted in config/*.toml without rebuilding.
 * COMMON = gameplay rules (read on the server / integrated server), CLIENT = visuals. Values are read at use time
 * (never in static initialisers) because a config value cannot be read before its file is loaded.
 */
public final class Cfg {
    public static final Common COMMON;
    public static final ModConfigSpec COMMON_SPEC;
    public static final Client CLIENT;
    public static final ModConfigSpec CLIENT_SPEC;

    static {
        Pair<Common, ModConfigSpec> c = new ModConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ModConfigSpec> k = new ModConfigSpec.Builder().configure(Client::new);
        CLIENT = k.getLeft();
        CLIENT_SPEC = k.getRight();
    }

    private Cfg() {}

    public static final class Common {
        public final ModConfigSpec.DoubleValue affectionMultiplier;
        public final ModConfigSpec.DoubleValue cooldownMultiplier;
        public final ModConfigSpec.BooleanValue healOnInteract;
        public final ModConfigSpec.BooleanValue particles;
        public final ModConfigSpec.BooleanValue sounds;
        public final ModConfigSpec.DoubleValue distanceScale;
        public final ModConfigSpec.DoubleValue touchDistance;

        public final ModConfigSpec.BooleanValue touchEnabled;
        public final ModConfigSpec.IntValue comfortStart;
        public final ModConfigSpec.IntValue lockBelow;
        public final ModConfigSpec.IntValue unlockAt;
        public final ModConfigSpec.DoubleValue drainScale;
        public final ModConfigSpec.DoubleValue gainScale;
        public final ModConfigSpec.IntValue pressWhileRefusedPenalty;
        public final ModConfigSpec.IntValue touchAffectionCap;
        public final ModConfigSpec.BooleanValue rebelEnabled;
        public final ModConfigSpec.DoubleValue rebelDamage;
        public final ModConfigSpec.IntValue rebelBondLossPercent;
        public final ModConfigSpec.IntValue rebelBondLossMin;
        public final ModConfigSpec.IntValue rebelLockoutSeconds;

        public final ModConfigSpec.BooleanValue giftsEnabled;
        public final ModConfigSpec.IntValue giftCooldownSeconds;
        public final ModConfigSpec.DoubleValue giftScale;

        Common(ModConfigSpec.Builder b) {
            b.push("interactions");
            affectionMultiplier = b.comment("Multiplier for bond gained from interactions.").defineInRange("affectionMultiplier", 1.0, 0.0, 10.0);
            cooldownMultiplier = b.comment("Multiplier for interaction cooldowns (0 = none).").defineInRange("cooldownMultiplier", 1.0, 0.0, 10.0);
            healOnInteract = b.comment("Heal the elf a little when an interaction completes.").define("healOnInteract", true);
            particles = b.comment("Heart / sparkle particles.").define("particles", true);
            sounds = b.comment("Small chime / reaction sounds.").define("sounds", true);
            distanceScale = b.comment("Multiplier for how far apart you and the elf stand during interactions (lower = closer).").defineInRange("distanceScale", 1.0, 0.3, 3.0);
            touchDistance = b.comment("Distance between you and the elf in touch mode, in blocks.").defineInRange("touchDistance", 1.05, 0.5, 3.0);
            b.pop();

            b.push("touch");
            touchEnabled = b.define("touchEnabled", true);
            comfortStart = b.comment("Comfort meter at the start of a touch session (0-100).").defineInRange("comfortStart", 50, 10, 90);
            lockBelow = b.comment("Below this comfort she pulls away and refuses touch.").defineInRange("lockBelow", 25, 0, 60);
            unlockAt = b.comment("She accepts touch again once comfort recovers to this.").defineInRange("unlockAt", 40, 5, 90);
            drainScale = b.comment("Multiplier for comfort LOST per second (rough handling, torso, legs...).").defineInRange("drainScale", 1.0, 0.0, 5.0);
            gainScale = b.comment("Multiplier for comfort GAINED per second (pats, hands...).").defineInRange("gainScale", 1.0, 0.0, 5.0);
            pressWhileRefusedPenalty = b.comment("Comfort lost each time you press right-click while she is refusing.").defineInRange("pressWhileRefusedPenalty", 8, 0, 50);
            touchAffectionCap = b.comment("Max bond earned from gentle touch per session.").defineInRange("touchAffectionCap", 12, 0, 100);
            rebelEnabled = b.comment("At 0 comfort she lashes out once (bond loss, light hit, session ends).").define("rebelEnabled", true);
            rebelDamage = b.comment("Damage of that single hit, in half-hearts. Never lethal.").defineInRange("rebelDamage", 2.0, 0.0, 20.0);
            rebelBondLossPercent = b.defineInRange("rebelBondLossPercent", 40, 0, 100);
            rebelBondLossMin = b.defineInRange("rebelBondLossMin", 40, 0, 1000);
            rebelLockoutSeconds = b.comment("How long she refuses touch mode afterwards.").defineInRange("rebelLockoutSeconds", 180, 0, 3600);
            b.pop();

            b.push("gifts");
            giftsEnabled = b.define("giftsEnabled", true);
            giftCooldownSeconds = b.defineInRange("giftCooldownSeconds", 120, 0, 3600);
            giftScale = b.comment("Multiplier for bond change from gifts.").defineInRange("giftScale", 1.0, 0.0, 10.0);
            b.pop();
        }
    }

    public static final class Client {
        public final ModConfigSpec.BooleanValue cameraEffects;
        public final ModConfigSpec.DoubleValue cameraStrength;
        public final ModConfigSpec.DoubleValue lookAtStrength;
        public final ModConfigSpec.BooleanValue firstPersonArms;
        public final ModConfigSpec.BooleanValue stowWeapon;
        public final ModConfigSpec.IntValue stowGraceTicks;
        public final ModConfigSpec.BooleanValue touchHud;
        public final ModConfigSpec.BooleanValue debugTouch;

        // Elf pose direction fixes (applied on top of the defaults derived from the elf model). Flip whatever looks mirrored.
        public final ModConfigSpec.BooleanValue flipHeadPitch;
        public final ModConfigSpec.BooleanValue flipHeadYaw;
        public final ModConfigSpec.BooleanValue flipTorsoPitch;
        public final ModConfigSpec.BooleanValue flipTorsoRoll;
        public final ModConfigSpec.BooleanValue flipArmPitch;
        public final ModConfigSpec.BooleanValue flipArmYaw;
        public final ModConfigSpec.BooleanValue flipArmRoll;
        public final ModConfigSpec.BooleanValue flipLegPitch;
        public final ModConfigSpec.BooleanValue swapElfArms;
        public final ModConfigSpec.BooleanValue flipTouchDragYaw;
        public final ModConfigSpec.BooleanValue flipTouchDragPitch;

        Client(ModConfigSpec.Builder b) {
            b.push("camera");
            cameraEffects = b.comment("First-person camera effects during interactions.").define("cameraEffects", true);
            cameraStrength = b.comment("FOV/pitch/roll motion strength (0 = none).").defineInRange("cameraStrength", 1.0, 0.0, 3.0);
            lookAtStrength = b.comment("How strongly the view is pulled toward the elf's face.").defineInRange("lookAtStrength", 1.0, 0.0, 3.0);
            firstPersonArms = b.comment("Show the animated arms in first person (Player Animator).").define("firstPersonArms", true);
            stowWeapon = b.comment("The elf puts her bow (and anything in her hands) away during interactions and touch mode.").define("stowWeapon", true);
            stowGraceTicks = b.comment("Ticks after a session ends before she takes her bow out again.").defineInRange("stowGraceTicks", 12, 0, 100);
            b.pop();

            b.push("touch");
            touchHud = b.define("touchHud", true);
            debugTouch = b.comment("Show raw touch state (zone, side, gesture, drag, joint bends) on the HUD.").define("debugTouch", false);
            flipTouchDragYaw = b.comment("Flip the elf's response to sideways dragging.").define("flipTouchDragYaw", false);
            flipTouchDragPitch = b.comment("Flip the elf's response to up/down dragging.").define("flipTouchDragPitch", false);
            b.pop();

            b.push("elfPoseFixes");
            flipHeadPitch = b.define("flipHeadPitch", false);
            flipHeadYaw = b.define("flipHeadYaw", false);
            flipTorsoPitch = b.define("flipTorsoPitch", false);
            flipTorsoRoll = b.define("flipTorsoRoll", false);
            flipArmPitch = b.define("flipArmPitch", false);
            flipArmYaw = b.define("flipArmYaw", false);
            flipArmRoll = b.define("flipArmRoll", false);
            flipLegPitch = b.define("flipLegPitch", false);
            swapElfArms = b.comment("Swap which elf arm is animated as 'right' and 'left'.").define("swapElfArms", false);
            b.pop();
        }
    }
}
