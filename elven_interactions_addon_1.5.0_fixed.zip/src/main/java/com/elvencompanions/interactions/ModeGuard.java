package com.elvencompanions.interactions;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.ModList;

/**
 * Keeps another mod's player "mode" out of the way while a custom player animation plays.
 * The Epic Fight implementation lives in a separate class that is only touched when Epic Fight is installed,
 * so this mod loads fine without it.
 */
public interface ModeGuard {
    /** Called when an interaction starts for this player. Must be idempotent. */
    void enter(ServerPlayer player);

    /** Called when the interaction ends for ANY reason (finished, cancelled, interrupted, logout...). Idempotent. */
    void exit(ServerPlayer player, boolean playerStillOnline);

    /** Drops all state (server stopping). */
    void clear();

    ModeGuard NOOP = new ModeGuard() {
        @Override public void enter(ServerPlayer player) {}
        @Override public void exit(ServerPlayer player, boolean online) {}
        @Override public void clear() {}
    };

    final class Holder {
        private static ModeGuard instance;

        private Holder() {}

        public static synchronized ModeGuard get() {
            if (instance == null) {
                if (ModList.get().isLoaded("epicfight")) {
                    try {
                        instance = new EpicFightModeGuard();
                    } catch (Throwable t) {
                        ElvenInteractions.LOGGER.error(
                                "Epic Fight is installed but its API could not be bound; mode switching disabled", t);
                        instance = NOOP;
                    }
                } else {
                    instance = NOOP;
                }
            }
            return instance;
        }
    }
}
