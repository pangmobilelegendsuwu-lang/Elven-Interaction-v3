package com.elvencompanions.interactions.mixin;

import com.elvencompanions.client.ElfObjModel;
import com.elvencompanions.interactions.ElfMesh;
import com.elvencompanions.interactions.JointMesh;
import com.elvencompanions.interactions.client.JointBend;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Second (and last) mixin: lets an elf arm/leg mesh bend at the elbow/knee. When a joint angle is active for the elf
 * currently being rendered, the part is split at the joint plane (once, cached) and drawn with its lower half rotated; with
 * no active bend this does nothing and the original render runs untouched.
 */
@Mixin(value = ElfObjModel.Part.class, remap = false)
public abstract class ElfObjPartMixin {
    @Shadow @Final public ElfObjModel.Bone bone;
    @Shadow @Final float[] data;

    @Unique private JointMesh.Split elven_interactions$split;
    @Unique private float elven_interactions$splitY = Float.NaN;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true, remap = false)
    private void elven_interactions$joint(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay, int color,
                                          CallbackInfo ci) {
        float angle = JointBend.angleFor(this.bone);
        if (angle == 0f) return;
        boolean arm = this.bone == ElfObjModel.Bone.L_ARM || this.bone == ElfObjModel.Bone.R_ARM;
        float jointY = ElfMesh.jointY(arm);
        if (elven_interactions$split == null || elven_interactions$splitY != jointY) {
            elven_interactions$split = JointMesh.split(this.data, jointY);
            elven_interactions$splitY = jointY;
        }
        JointBend.draw(pose, vc, light, overlay, color, elven_interactions$split, angle, jointY, ElfMesh.pivotZ(arm));
        ci.cancel();
    }
}
