package com.elvencompanions.interactions.mixin;

import com.elvencompanions.client.ElfHeldItemLayer;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.client.StowState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Third (small) mixin: while an elf is "stowed" (an interaction / touch session is running on her) her held items - the bow and
 * anything in the off hand - are not drawn, so she has free hands. Her inventory is untouched; it is only a render skip.
 */
@Mixin(value = ElfHeldItemLayer.class, remap = false)
public abstract class ElfHeldItemLayerMixin {
    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILcom/elvencompanions/entity/ElfEntity;FFFFFF)V",
            at = @At("HEAD"), cancellable = true, remap = false)
    private void elven_interactions$stow(PoseStack ps, MultiBufferSource buffers, int light, ElfEntity e,
                                         float limbSwing, float limbSwingAmount, float partialTick, float age,
                                         float netHeadYaw, float headPitch, CallbackInfo ci) {
        if (Cfg.CLIENT.stowWeapon.get() && StowState.hidden(e.getId())) ci.cancel();
    }
}
