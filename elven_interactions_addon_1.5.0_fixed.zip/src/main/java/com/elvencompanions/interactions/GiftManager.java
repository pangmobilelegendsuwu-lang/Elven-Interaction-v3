package com.elvencompanions.interactions;

import com.elvencompanions.entity.ElfDialogue;
import com.elvencompanions.entity.ElfEntity;
import java.util.UUID;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Gifts: hand the elf the item in your main hand. She has tastes (loved / liked / neutral / disliked) that move the bond by
 * different amounts; one gift per cooldown. Taste table is deliberately small and easy to edit in {@link #taste}.
 */
public final class GiftManager {
    public enum Taste {
        LOVED("loved", 8), LIKED("liked", 4), NEUTRAL("neutral", 1), DISLIKED("disliked", -3);

        public final String id;
        public final int delta;

        Taste(String id, int delta) {
            this.id = id;
            this.delta = delta;
        }
    }

    private GiftManager() {}

    public static Taste taste(ItemStack s) {
        if (s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE) || s.is(Items.HONEY_BOTTLE)
                || s.is(Items.CAKE) || s.is(Items.PUMPKIN_PIE)) {
            return Taste.LOVED;
        }
        if (s.is(ItemTags.FLOWERS) || s.is(Items.SWEET_BERRIES) || s.is(Items.GLOW_BERRIES) || s.is(Items.APPLE)
                || s.is(Items.COOKIE) || s.is(Items.GOLDEN_CARROT) || s.is(Items.AMETHYST_SHARD) || s.is(Items.EMERALD)
                || s.is(Items.BREAD) || s.is(Items.MELON_SLICE)) {
            return Taste.LIKED;
        }
        if (s.is(Items.ROTTEN_FLESH) || s.is(Items.SPIDER_EYE) || s.is(Items.FERMENTED_SPIDER_EYE)
                || s.is(Items.POISONOUS_POTATO) || s.is(Items.PUFFERFISH) || s.is(Items.BONE)) {
            return Taste.DISLIKED;
        }
        return Taste.NEUTRAL;
    }

    private static void fail(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable("message.elven_companions." + key), true);
    }

    public static void give(ServerPlayer p, ElfEntity elf) {
        if (elf == null || elf.getCompanionId() == null || !Cfg.COMMON.giftsEnabled.get()) return;
        UUID id = p.getUUID();
        UUID elfId = elf.getCompanionId();
        if (InteractionManager.isActive(id) || TouchManager.isActive(id)) return;
        if (elf.level() != p.level() || elf.distanceToSqr(p) > 4.0 * 4.0) {
            fail(p, "interact.fail.too_far");
            return;
        }
        ItemStack held = p.getMainHandItem();
        if (held.isEmpty()) {
            fail(p, "gift.empty");
            return;
        }
        BondData bond = BondData.get(p.server);
        long now = p.server.overworld().getGameTime();
        if (bond.cooldownEnd(elfId, BondData.GIFT_SLOT) > now) {
            fail(p, "gift.cooldown");
            return;
        }

        Taste t = taste(held);
        int delta = Math.round(t.delta * Cfg.COMMON.giftScale.get().floatValue());
        if (!p.isCreative()) held.shrink(1);
        bond.setCooldown(elfId, BondData.GIFT_SLOT, now + 20L * Cfg.COMMON.giftCooldownSeconds.get());
        boolean up = bond.add(elfId, delta);

        TouchDialogue.line(elf, "gift_" + t.id);
        if (Cfg.COMMON.particles.get() && elf.level() instanceof ServerLevel sl && t != Taste.NEUTRAL) {
            ParticleOptions pt = t == Taste.DISLIKED ? ParticleTypes.ANGRY_VILLAGER : ParticleTypes.HEART;
            sl.sendParticles(pt, elf.getX(), elf.getY() + elf.getBbHeight() + 0.2, elf.getZ(),
                    t == Taste.LOVED ? 7 : 4, 0.3, 0.2, 0.3, 0.02);
        }
        if (Cfg.COMMON.sounds.get() && t != Taste.NEUTRAL) {
            SoundEvent snd = t == Taste.DISLIKED ? SoundEvents.VILLAGER_NO : SoundEvents.VILLAGER_YES;
            elf.level().playSound(null, elf.getX(), elf.getY(), elf.getZ(), snd, SoundSource.NEUTRAL, 0.8F, 1.1F);
        }
        if (up) {
            int lvl = bond.level(elfId);
            p.sendSystemMessage(Component.translatable("message.elven_companions.bond_up", elf.getDisplayName(),
                    Component.translatable("gui.elven_companions.interact.bond." + lvl)));
            ElfDialogue.say(elf, "bond_up");
        }
        InteractionManager.sendBond(p, elf);
    }
}
