package com.elvencompanions.interactions;

import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.client.ClientInteractions;
import com.elvencompanions.entity.ElfEntity;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Payloads for the interaction system. Registered from ModNetwork.register via {@link #register}. */
public final class InteractNet {
    private InteractNet() {}

    public static void register(PayloadRegistrar r) {
        r.playToServer(RequestC2S.TYPE, RequestC2S.CODEC, (p, c) -> {
            if (c.player() instanceof ServerPlayer sp) {
                InteractionManager.start(sp, InteractionManager.resolve(sp, p.companion(), p.entityId()),
                        InteractionType.byId(p.type()));
            }
        });
        r.playToServer(CancelC2S.TYPE, CancelC2S.CODEC, (p, c) -> {
            if (c.player() instanceof ServerPlayer sp) {
                InteractionManager.cancel(sp);
                TouchManager.cancel(sp);
            }
        });
        r.playToServer(TouchStartC2S.TYPE, TouchStartC2S.CODEC, (p, c) -> {
            if (c.player() instanceof ServerPlayer sp) {
                TouchManager.start(sp, InteractionManager.resolve(sp, p.companion(), p.entityId()));
            }
        });
        r.playToServer(GiftC2S.TYPE, GiftC2S.CODEC, (p, c) -> {
            if (c.player() instanceof ServerPlayer sp) {
                GiftManager.give(sp, InteractionManager.resolve(sp, p.companion(), p.entityId()));
            }
        });
        r.playToServer(TouchHoldC2S.TYPE, TouchHoldC2S.CODEC, (p, c) -> {
            if (c.player() instanceof ServerPlayer sp) TouchManager.setHolding(sp, p.holding());
        });
        r.playToClient(TouchStateS2C.TYPE, TouchStateS2C.CODEC, (p, c) -> com.elvencompanions.interactions.client.TouchClient.onState(p));
        r.playToServer(BondRequestC2S.TYPE, BondRequestC2S.CODEC, (p, c) -> {
            if (c.player() instanceof ServerPlayer sp) {
                ElfEntity e = InteractionManager.resolve(sp, p.companion(), p.entityId());
                if (e != null) InteractionManager.sendBond(sp, e);
            }
        });
        r.playToServer(BondAdjustC2S.TYPE, BondAdjustC2S.CODEC, (p, c) -> {
            // Creative-mode testing aid. Enforced here, never trusted from the client.
            if (c.player() instanceof ServerPlayer sp && sp.isCreative()) {
                ElfEntity e = InteractionManager.resolve(sp, p.companion(), p.entityId());
                if (e != null && e.getCompanionId() != null) {
                    BondData bond = BondData.get(sp.server);
                    bond.add(e.getCompanionId(), BondData.adjustDelta(bond.affection(e.getCompanionId()), p.up(), p.wholeLevel()));
                    InteractionManager.sendBond(sp, e);
                }
            }
        });
        r.playToClient(StateS2C.TYPE, StateS2C.CODEC, (p, c) -> ClientInteractions.onState(p));
        r.playToClient(BondS2C.TYPE, BondS2C.CODEC, (p, c) -> ClientInteractions.onBond(p));
    }

    // ------------------------------------------------------------------ C2S

    /** The elf is addressed by companion id (GUI) and/or entity id (wheel); the server accepts either. */
    public record RequestC2S(UUID companion, int entityId, int type) implements CustomPacketPayload {
        public static final Type<RequestC2S> TYPE = new Type<>(ElvenInteractions.rl("interact_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, RequestC2S> CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, RequestC2S::companion,
                ByteBufCodecs.INT, RequestC2S::entityId,
                ByteBufCodecs.VAR_INT, RequestC2S::type, RequestC2S::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record CancelC2S() implements CustomPacketPayload {
        public static final Type<CancelC2S> TYPE = new Type<>(ElvenInteractions.rl("interact_cancel"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CancelC2S> CODEC = StreamCodec.unit(new CancelC2S());

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record BondRequestC2S(UUID companion, int entityId) implements CustomPacketPayload {
        public static final Type<BondRequestC2S> TYPE = new Type<>(ElvenInteractions.rl("bond_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BondRequestC2S> CODEC =
                StreamCodec.composite(
                        UUIDUtil.STREAM_CODEC, BondRequestC2S::companion, ByteBufCodecs.INT, BondRequestC2S::entityId,
                        BondRequestC2S::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record BondAdjustC2S(UUID companion, int entityId, boolean up, boolean wholeLevel)
            implements CustomPacketPayload {
        public static final Type<BondAdjustC2S> TYPE = new Type<>(ElvenInteractions.rl("bond_adjust"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BondAdjustC2S> CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, BondAdjustC2S::companion,
                ByteBufCodecs.INT, BondAdjustC2S::entityId,
                ByteBufCodecs.BOOL, BondAdjustC2S::up,
                ByteBufCodecs.BOOL, BondAdjustC2S::wholeLevel,
                BondAdjustC2S::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record TouchStartC2S(UUID companion, int entityId) implements CustomPacketPayload {
        public static final Type<TouchStartC2S> TYPE = new Type<>(ElvenInteractions.rl("touch_start"));
        public static final StreamCodec<RegistryFriendlyByteBuf, TouchStartC2S> CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, TouchStartC2S::companion, ByteBufCodecs.INT, TouchStartC2S::entityId,
                TouchStartC2S::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Give the item in the player's main hand to the elf. */
    public record GiftC2S(UUID companion, int entityId) implements CustomPacketPayload {
        public static final Type<GiftC2S> TYPE = new Type<>(ElvenInteractions.rl("gift"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GiftC2S> CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, GiftC2S::companion, ByteBufCodecs.INT, GiftC2S::entityId, GiftC2S::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Right-click held / released while in touch mode. */
    public record TouchHoldC2S(boolean holding) implements CustomPacketPayload {
        public static final Type<TouchHoldC2S> TYPE = new Type<>(ElvenInteractions.rl("touch_hold"));
        public static final StreamCodec<RegistryFriendlyByteBuf, TouchHoldC2S> CODEC =
                StreamCodec.composite(ByteBufCodecs.BOOL, TouchHoldC2S::holding, TouchHoldC2S::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // ------------------------------------------------------------------ S2C

    /**
     * Touch-mode state for the HUD and the elf's reaction pose. flags: bits0-3 zone+1 (0 = none), bit4 elf's left side,
     * bits5-7 gesture, bit8 locked (she is refusing), bit9 touching now, bit10 session active.
     */
    public record TouchStateS2C(int elfEntityId, int flags, int comfortTenths) implements CustomPacketPayload {
        public static final Type<TouchStateS2C> TYPE = new Type<>(ElvenInteractions.rl("touch_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, TouchStateS2C> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, TouchStateS2C::elfEntityId,
                ByteBufCodecs.VAR_INT, TouchStateS2C::flags,
                ByteBufCodecs.VAR_INT, TouchStateS2C::comfortTenths,
                TouchStateS2C::new);

        public TouchZone zone() {
            return TouchZone.byId((flags & 15) - 1);
        }

        public boolean left() {
            return (flags & (1 << 4)) != 0;
        }

        public TouchGesture gesture() {
            return TouchGesture.byId((flags >> 5) & 7);
        }

        public boolean locked() {
            return (flags & (1 << 8)) != 0;
        }

        public boolean touching() {
            return (flags & (1 << 9)) != 0;
        }

        public boolean active() {
            return (flags & (1 << 10)) != 0;
        }

        public float comfort() {
            return comfortTenths / 10f;
        }

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Start/stop of an interaction. Entity ids are used so remote players see the animation too. */
    public record StateS2C(int playerId, int elfEntityId, int type, boolean start) implements CustomPacketPayload {
        public static final Type<StateS2C> TYPE = new Type<>(ElvenInteractions.rl("interact_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, StateS2C> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_INT, StateS2C::playerId,
                ByteBufCodecs.VAR_INT, StateS2C::elfEntityId,
                ByteBufCodecs.VAR_INT, StateS2C::type,
                ByteBufCodecs.BOOL, StateS2C::start,
                StateS2C::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Relationship snapshot for the GUI/wheel: affection + remaining cooldown seconds per interaction type. */
    public record BondS2C(UUID companion, int entityId, int affection, List<Integer> cooldownSecs)
            implements CustomPacketPayload {
        public static final Type<BondS2C> TYPE = new Type<>(ElvenInteractions.rl("bond_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, BondS2C> CODEC = StreamCodec.composite(
                UUIDUtil.STREAM_CODEC, BondS2C::companion,
                ByteBufCodecs.INT, BondS2C::entityId,
                ByteBufCodecs.VAR_INT, BondS2C::affection,
                ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), BondS2C::cooldownSecs,
                BondS2C::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}
