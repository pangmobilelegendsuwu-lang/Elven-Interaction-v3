package com.elvencompanions.interactions;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import org.slf4j.Logger;

/** Addon for Elven Companions: interactions, radial wheel, bonds, paired animations. */
@Mod(ElvenInteractions.MODID)
public final class ElvenInteractions {
    public static final String MODID = "elven_interactions";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ElvenInteractions(IEventBus modBus, ModContainer container) {
        modBus.addListener(ElvenInteractions::registerPayloads);
        container.registerConfig(ModConfig.Type.COMMON, Cfg.COMMON_SPEC);
        container.registerConfig(ModConfig.Type.CLIENT, Cfg.CLIENT_SPEC);
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        InteractNet.register(event.registrar("1"));
    }

    public static ResourceLocation rl(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
