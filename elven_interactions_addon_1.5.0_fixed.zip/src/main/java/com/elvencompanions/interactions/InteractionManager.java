package com.elvencompanions.interactions;

import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.data.ElfManager;
import com.elvencompanions.entity.ElfDialogue;
import com.elvencompanions.entity.ElfEntity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Server-authoritative interaction sessions: one per player. Validates the request, holds the elf in place and
 * facing the player, tells clients to start/stop the paired animation, applies the Epic Fight mode guard, and
 * awards affection on completion. Every way a session can end funnels through {@link #end}.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME)
public final class InteractionManager {
    private static final double MAX_START_DIST_SQ = 3.5 * 3.5;
    private static final double MAX_DRIFT_SQ = 1.5 * 1.5;

    private static final class Session {
        final UUID player;
        final UUID elfId;
        final int elfEntityId;
        final InteractionType type;
        final int endTick;
        final Vec3 anchor;

        Session(UUID player, UUID elfId, int elfEntityId, InteractionType type, int endTick, Vec3 anchor) {
            this.player = player;
            this.elfId = elfId;
            this.elfEntityId = elfEntityId;
            this.type = type;
            this.endTick = endTick;
            this.anchor = anchor;
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();

    private InteractionManager() {}

    public static boolean isActive(UUID player) {
        return SESSIONS.containsKey(player);
    }

    // ------------------------------------------------------------------ start

    /** Resolves an owned, living elf by entity id (wheel) or companion id (GUI). Returns null if not found/not owned. */
    public static ElfEntity resolve(ServerPlayer p, UUID companion, int entityId) {
        ElfEntity elf = null;
        if (entityId >= 0 && p.level().getEntity(entityId) instanceof ElfEntity e) {
            elf = e;
        } else if (companion != null) {
            elf = ElfManager.LOADED.get(companion);
        }
        return elf != null && elf.isAlive() && !elf.isRemoved() && elf.isOwnedBy(p) ? elf : null;
    }

    public static void start(ServerPlayer p, ElfEntity elf, InteractionType type) {
        if (type == null || elf == null || elf.getCompanionId() == null) return;
        UUID companionId = elf.getCompanionId();
        MinecraftServer server = p.server;
        if (SESSIONS.containsKey(p.getUUID()) || TouchManager.isActive(p.getUUID())) return;

        if (elf.level() != p.level() || elf.distanceToSqr(p) > MAX_START_DIST_SQ) {
            fail(p, "too_far");
            return;
        }
        if (!p.onGround() || p.isPassenger() || p.isSleeping() || p.isSwimming() || p.isFallFlying() || p.isUsingItem()) {
            fail(p, "player_busy");
            return;
        }
        if (elf.isBusyForMovement() || elf.isCarried() || elf.isMounted() || elf.getTarget() != null || !elf.onGround()
                || elf.getAnim() != 0 || elf.isSleeping()) {
            fail(p, "elf_busy");
            return;
        }
        BondData bond = BondData.get(server);
        if (bond.level(companionId) < type.minBond) {
            fail(p, "bond_low");
            return;
        }
        long now = server.overworld().getGameTime();
        if (bond.cooldownEnd(companionId, type) > now) {
            fail(p, "cooldown");
            return;
        }

        // Stand the elf in front of the player at the interaction distance, if there is room.
        Vec3 look = p.getLookAngle();
        Vec3 h = new Vec3(look.x, 0, look.z);
        if (h.lengthSqr() < 1.0E-4) h = Vec3.directionFromRotation(0, p.getYRot());
        h = h.normalize();
        Vec3 target = p.position().add(h.scale(type.distance * Cfg.COMMON.distanceScale.get().floatValue()));
        if (elf.distanceToSqr(target.x, p.getY(), target.z) > 0.04) {
            AABB box = elf.getBoundingBox().move(target.x - elf.getX(), p.getY() - elf.getY(), target.z - elf.getZ());
            if (p.level().noCollision(elf, box)) {
                elf.getNavigation().stop();
                elf.moveTo(target.x, p.getY(), target.z, elf.getYRot(), elf.getXRot());
            }
        }

        Session s = new Session(p.getUUID(), companionId, elf.getId(), type,
                server.getTickCount() + type.duration(), p.position());
        SESSIONS.put(p.getUUID(), s);
        if (type.playerActs()) ModeGuard.Holder.get().enter(p); // elf-only bow: nothing to protect
        hold(elf, p);
        broadcast(p, new InteractNet.StateS2C(p.getId(), elf.getId(), type.ordinal(), true));
    }

    /** Can this elf take part in an interaction / touch session right now? */
    public static boolean elfAvailable(ElfEntity elf) {
        return !(elf.isBusyForMovement() || elf.isCarried() || elf.isMounted() || elf.getTarget() != null || !elf.onGround()
                || elf.getAnim() != 0 || elf.isSleeping());
    }

    /** Stands the elf in front of the player at the given distance if there is room (same logic as start()). */
    public static void placeElfInFront(ServerPlayer p, ElfEntity elf, float distance) {
        Vec3 look = p.getLookAngle();
        Vec3 h = new Vec3(look.x, 0, look.z);
        if (h.lengthSqr() < 1.0E-4) h = Vec3.directionFromRotation(0, p.getYRot());
        h = h.normalize();
        Vec3 target = p.position().add(h.scale(distance));
        if (elf.distanceToSqr(target.x, p.getY(), target.z) > 0.04) {
            AABB box = elf.getBoundingBox().move(target.x - elf.getX(), p.getY() - elf.getY(), target.z - elf.getZ());
            if (p.level().noCollision(elf, box)) {
                elf.getNavigation().stop();
                elf.moveTo(target.x, p.getY(), target.z, elf.getYRot(), elf.getXRot());
            }
        }
    }

    private static void fail(ServerPlayer p, String reason) {
        p.displayClientMessage(Component.translatable("message.elven_companions.interact.fail." + reason), true);
    }

    // ------------------------------------------------------------------ end

    public static void cancel(ServerPlayer p) {
        Session s = SESSIONS.get(p.getUUID());
        if (s != null) end(p.server, s, false, true, p);
    }

    private static void end(MinecraftServer server, Session s, boolean completed, boolean playerOnline, ServerPlayer known) {
        if (!SESSIONS.remove(s.player, s)) return; // already ended
        ServerPlayer p = known != null ? known : server.getPlayerList().getPlayer(s.player);
        ElfEntity elf = ElfManager.LOADED.get(s.elfId);

        if (p != null) {
            ModeGuard.Holder.get().exit(p, playerOnline);
            broadcast(p, new InteractNet.StateS2C(p.getId(), s.elfEntityId, s.type.ordinal(), false));
        }
        if (completed && p != null && elf != null && elf.isAlive()) {
            BondData bond = BondData.get(server);
            long now = server.overworld().getGameTime();
            bond.setCooldown(s.elfId, s.type,
                    now + Math.round(s.type.cooldownTicks * Cfg.COMMON.cooldownMultiplier.get().floatValue()));
            boolean up = bond.add(s.elfId, Math.round(s.type.affection * Cfg.COMMON.affectionMultiplier.get().floatValue()));
            int lvl = bond.level(s.elfId);
            if (Cfg.COMMON.healOnInteract.get()) elf.heal(1.0F + lvl);
            if (Cfg.COMMON.particles.get() && elf.level() instanceof ServerLevel sl) {
                sl.sendParticles(up ? ParticleTypes.HAPPY_VILLAGER : ParticleTypes.HEART,
                        elf.getX(), elf.getY() + elf.getBbHeight() + 0.2, elf.getZ(), up ? 10 : 4, 0.3, 0.2, 0.3, 0.02);
            }
            if (Cfg.COMMON.sounds.get()) {
                elf.level().playSound(null, elf.getX(), elf.getY(), elf.getZ(),
                        up ? SoundEvents.PLAYER_LEVELUP : SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL,
                        up ? 0.5F : 0.7F, up ? 1.2F : 1.3F);
            }
            ElfDialogue.say(elf, "interact_" + s.type.id);
            if (up) {
                p.sendSystemMessage(Component.translatable("message.elven_companions.bond_up", elf.getDisplayName(),
                        Component.translatable("gui.elven_companions.interact.bond." + lvl)));
                ElfDialogue.say(elf, "bond_up");
            }
            sendBond(p, elf);
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Keeps the elf still and facing the player. Shared with touch mode. */
    public static void hold(ElfEntity elf, ServerPlayer p) {
        elf.getNavigation().stop();
        Vec3 dm = elf.getDeltaMovement();
        elf.setDeltaMovement(0, dm.y, 0);
        double dx = p.getX() - elf.getX();
        double dz = p.getZ() - elf.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        elf.setYRot(yaw);
        elf.yBodyRot = yaw;
        elf.setYHeadRot(yaw);
    }

    private static void broadcast(ServerPlayer p, InteractNet.StateS2C pkt) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(p, pkt);
    }

    public static void sendBond(ServerPlayer p, ElfEntity elf) {
        UUID elfId = elf.getCompanionId();
        if (elfId == null) return;
        BondData bond = BondData.get(p.server);
        long now = p.server.overworld().getGameTime();
        List<Integer> cds = new ArrayList<>();
        for (InteractionType t : InteractionType.values()) {
            long left = bond.cooldownEnd(elfId, t) - now;
            cds.add(left <= 0 ? 0 : (int) ((left + 19) / 20));
        }
        PacketDistributor.sendToPlayer(p, new InteractNet.BondS2C(elfId, elf.getId(), bond.affection(elfId), cds));
    }

    // ------------------------------------------------------------------ events

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        if (SESSIONS.isEmpty()) return;
        MinecraftServer server = e.getServer();
        for (Session s : new ArrayList<>(SESSIONS.values())) {
            ServerPlayer p = server.getPlayerList().getPlayer(s.player);
            ElfEntity elf = ElfManager.LOADED.get(s.elfId);
            if (p == null || !p.isAlive() || p.isRemoved() || elf == null || !elf.isAlive() || elf.isRemoved()
                    || elf.level() != p.level()) {
                end(server, s, false, p != null, p);
                continue;
            }
            if (p.position().distanceToSqr(s.anchor) > MAX_DRIFT_SQ || elf.distanceToSqr(p) > 3.0 * 3.0
                    || p.isPassenger() || p.isSleeping() || elf.isBusyForMovement() || elf.getTarget() != null) {
                end(server, s, false, true, p);
                continue;
            }
            hold(elf, p);
            if (server.getTickCount() >= s.endTick) {
                end(server, s, true, true, p);
            }
        }
    }

    @SubscribeEvent
    public static void onDamaged(LivingDamageEvent.Post e) {
        if (SESSIONS.isEmpty()) return;
        if (e.getEntity() instanceof ServerPlayer sp) {
            cancel(sp);
        } else if (e.getEntity() instanceof ElfEntity elf) {
            for (Session s : new ArrayList<>(SESSIONS.values())) {
                if (s.elfId.equals(elf.getCompanionId())) {
                    ServerPlayer p = elf.getServer() == null ? null : elf.getServer().getPlayerList().getPlayer(s.player);
                    if (p != null) cancel(p);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (SESSIONS.isEmpty()) return;
        if (e.getEntity() instanceof ServerPlayer sp) cancel(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Session s = SESSIONS.get(sp.getUUID());
            if (s != null) end(sp.server, s, false, false, sp);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) cancel(sp);
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        for (Session s : new ArrayList<>(SESSIONS.values())) {
            end(e.getServer(), s, false, false, null);
        }
        SESSIONS.clear();
        ModeGuard.Holder.get().clear();
    }
}
