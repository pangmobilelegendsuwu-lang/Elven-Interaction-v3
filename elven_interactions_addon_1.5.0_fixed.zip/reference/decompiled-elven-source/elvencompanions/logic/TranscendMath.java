package com.elvencompanions.logic;

public final class TranscendMath {
   public static int transcendXp(int lastLevelXp, double multiplier) {
      return (int)Math.max(1L, Math.round(lastLevelXp * multiplier));
   }

   public static int rageInterval(int baseInterval, boolean raging, double rageMult, int minInterval) {
      return !raging ? Math.max(minInterval, baseInterval) : Math.max(minInterval, (int)Math.round(baseInterval / Math.max(1.0, rageMult)));
   }

   public static double rageArrow(double arrowMult, boolean raging, double rageMult, double cap) {
      return raging ? Math.min(cap, arrowMult * rageMult) : arrowMult;
   }

   public static double rageSpeed(double baseSpeed, boolean raging, double rageMult, double cap) {
      return raging ? Math.min(cap, baseSpeed * rageMult) : baseSpeed;
   }

   public static double combined(boolean transcended, double transcendMult, boolean raging, double rageMult) {
      return (transcended ? transcendMult : 1.0) * (raging ? rageMult : 1.0);
   }

   public static boolean shouldStartRage(
      float health, float maxHealth, double fraction, boolean transcended, boolean active, int cooldownTicks, boolean cinematic, boolean alive
   ) {
      return alive && transcended && !active && cooldownTicks <= 0 && !cinematic && maxHealth > 0.0F && health > 0.0F && health <= maxHealth * fraction;
   }

   private TranscendMath() {
   }
}
