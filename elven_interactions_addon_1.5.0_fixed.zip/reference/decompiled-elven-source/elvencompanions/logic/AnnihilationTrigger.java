package com.elvencompanions.logic;

import java.util.UUID;

public final class AnnihilationTrigger {
   public static final int HORDE_COUNT = 32;
   public static final float HORDE_MAX_HEALTH_EXCLUSIVE = 99.0F;
   public static final float BOSS_MIN_HEALTH = 100.0F;
   public static final int BOSS_TICKS = 400;
   private UUID boss;
   private int ticks;

   public static boolean isHordeMember(float maxHealth) {
      return maxHealth < 99.0F;
   }

   public static boolean isBossLike(float maxHealth) {
      return maxHealth >= 100.0F;
   }

   public static boolean hordeReached(int count) {
      return count >= 32;
   }

   public boolean updateBoss(UUID candidate, int elapsed) {
      if (candidate == null || !candidate.equals(this.boss)) {
         this.boss = candidate;
         this.ticks = 0;
         if (candidate == null) {
            return false;
         }
      }

      this.ticks = this.ticks + Math.max(0, elapsed);
      return this.ticks >= 400;
   }

   public void reset() {
      this.boss = null;
      this.ticks = 0;
   }

   public UUID tracked() {
      return this.boss;
   }

   public int ticks() {
      return this.ticks;
   }
}
