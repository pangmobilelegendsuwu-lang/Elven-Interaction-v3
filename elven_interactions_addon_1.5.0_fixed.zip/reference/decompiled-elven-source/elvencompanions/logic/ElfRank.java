package com.elvencompanions.logic;

public final class ElfRank {
   private static final Object[][] TABLE = new Object[][]{
      {1, "woodland_initiate"},
      {5, "verdant_scout"},
      {10, "thorn_archer"},
      {15, "emerald_ranger"},
      {20, "sylvan_sentinel"},
      {25, "moonlit_marksman"},
      {30, "verdant_warden"},
      {35, "elder_ranger"},
      {40, "spirit_guardian"},
      {45, "mythic_huntress"},
      {50, "ascendant_of_the_grove"}
   };
   public static final String TRANSCENDED_ID = "celestial_transcendent";

   public static int count() {
      return TABLE.length;
   }

   public static int index(int level) {
      int l = Math.max(1, Math.min(50, level));
      int idx = 0;

      for (int i = 0; i < TABLE.length; i++) {
         if (l >= (Integer)TABLE[i][0]) {
            idx = i;
         }
      }

      return idx;
   }

   public static String id(int level) {
      return (String)TABLE[index(level)][1];
   }

   public static String key(int level) {
      return "rank.elven_companions." + id(level);
   }

   public static String key(int level, boolean transcended) {
      return transcended ? "rank.elven_companions.celestial_transcendent" : key(level);
   }

   private ElfRank() {
   }
}
