package com.elvencompanions.logic;

import java.util.Locale;

public enum RestSchedule {
   OFF,
   DAY,
   NOON,
   EVENING,
   NIGHT;

   public RestSchedule next() {
      RestSchedule[] v = values();
      return v[(this.ordinal() + 1) % v.length];
   }

   public static RestSchedule byId(int id) {
      RestSchedule[] v = values();
      return v[Math.floorMod(id, v.length)];
   }

   public static boolean inWindow(long dayTime, int start, int end) {
      int t = (int)Math.floorMod(dayTime, 24000L);
      int s = Math.floorMod(start, 24000);
      int e = Math.floorMod(end, 24000);
      if (s == e) {
         return false;
      } else {
         return s < e ? t >= s && t < e : t >= s || t < e;
      }
   }

   public static long occurrenceId(long dayTime, int start, int end) {
      long day = Math.floorDiv(dayTime, 24000L);
      int t = (int)Math.floorMod(dayTime, 24000L);
      int s = Math.floorMod(start, 24000);
      int e = Math.floorMod(end, 24000);
      if (s > e && t < e) {
         day--;
      }

      return day * 24000L + s;
   }

   public String id() {
      return this.name().toLowerCase(Locale.ROOT);
   }
}
