package com.elvencompanions.logic;

public final class CarryLayout {
   public static final double STACK_STEP_Y = 0.92;
   public static final double STACK_STEP_BACK = 0.22;
   public static final double BASE_BACK = 0.55;
   public static final double BASE_Y = 1.02;

   public static double[] offset(int index, double bodyYawDeg, boolean carrierLying, double carrierHeightScale) {
      int i = Math.max(0, index);
      double rad = Math.toRadians(bodyYawDeg);
      double fx = -Math.sin(rad);
      double fz = Math.cos(rad);
      double back = 0.55 + i * 0.22;
      double y = (carrierLying ? 0.45 : 1.02 * carrierHeightScale) + i * 0.92;
      if (carrierLying) {
         back += 0.05;
      }

      return new double[]{-fx * back, y, -fz * back};
   }

   private CarryLayout() {
   }
}
