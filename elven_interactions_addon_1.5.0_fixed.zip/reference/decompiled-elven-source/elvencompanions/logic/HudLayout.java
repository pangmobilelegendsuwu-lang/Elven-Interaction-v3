package com.elvencompanions.logic;

public final class HudLayout {
   public static final int WIDTH = 124;
   public static final int HEADER = 13;
   public static final int ROW = 15;
   public static final int COLS = 2;
   public static final int PAD = 3;
   public static final int FOOTER = 17;

   public static int rows(int buttons) {
      return (buttons + 2 - 1) / 2;
   }

   public static int height(int buttons) {
      return 16 + rows(buttons) * 15 + 17 + 3;
   }

   public static int defaultX(int screenW) {
      return screenW - 124 - 4;
   }

   public static int defaultY(int screenH, int buttons) {
      return Math.max(4, (screenH - height(buttons)) / 2);
   }

   public static int clampX(int x, int screenW) {
      return Math.max(0, Math.min(x, Math.max(0, screenW - 124)));
   }

   public static int clampY(int y, int screenH, int buttons) {
      return Math.max(0, Math.min(y, Math.max(0, screenH - height(buttons))));
   }

   public static boolean inHeader(double mx, double my, int px, int py) {
      return mx >= px && mx < px + 124 && my >= py && my < py + 13;
   }

   public static int buttonAt(double mx, double my, int px, int py, int buttons) {
      double lx = mx - px - 3.0;
      double ly = my - py - 13.0 - 3.0;
      int cw = 59;
      if (!(lx < 0.0) && !(ly < 0.0) && !(lx >= cw * 2) && !(ly >= rows(buttons) * 15)) {
         int idx = (int)(ly / 15.0) * 2 + (int)(lx / cw);
         return idx < buttons ? idx : -1;
      } else {
         return -1;
      }
   }

   public static int footerAt(double mx, double my, int px, int py, int buttons) {
      double fy = py + 13 + 3 + rows(buttons) * 15 + 2;
      if (!(my < fy) && !(my >= fy + 17.0 - 3.0) && !(mx < px + 3) && !(mx >= px + 124 - 3)) {
         return mx < px + 62.0 ? 0 : 1;
      } else {
         return -1;
      }
   }

   private HudLayout() {
   }
}
