package com.elvencompanions.net;

import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.client.ClientHooks;
import com.elvencompanions.data.ElfManager;
import com.elvencompanions.data.ElfRegistry;
import com.elvencompanions.entity.ElfAction;
import com.elvencompanions.entity.ElfDialogue;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.item.SoulItem;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.jetbrains.annotations.Nullable;

public final class ModNetwork {
   public static final double GROUP_RADIUS = 128.0;
   public static final int MAX_NAME = 24;

   public static void register(RegisterPayloadHandlersEvent event) {
      PayloadRegistrar r = event.registrar("1");
      r.playToServer(ModNetwork.CommandC2S.TYPE, ModNetwork.CommandC2S.CODEC, ModNetwork::onCommand);
      r.playToServer(ModNetwork.SelectC2S.TYPE, ModNetwork.SelectC2S.CODEC, ModNetwork::onSelect);
      r.playToServer(ModNetwork.RenameC2S.TYPE, ModNetwork.RenameC2S.CODEC, ModNetwork::onRename);
      r.playToServer(ModNetwork.SkinC2S.TYPE, ModNetwork.SkinC2S.CODEC, ModNetwork::onSkin);
      r.playToServer(ModNetwork.DeleteC2S.TYPE, ModNetwork.DeleteC2S.CODEC, ModNetwork::onDelete);
      r.playToServer(ModNetwork.LevelC2S.TYPE, ModNetwork.LevelC2S.CODEC, ModNetwork::onLevel);
      r.playToServer(ModNetwork.SkillPickC2S.TYPE, ModNetwork.SkillPickC2S.CODEC, (p, c) -> SkillWandManager.onPick(player(c), p.elf()));
      r.playToServer(ModNetwork.SkillSwitchC2S.TYPE, ModNetwork.SkillSwitchC2S.CODEC, (p, c) -> SkillWandManager.onSwitch(player(c)));
      r.playToServer(ModNetwork.SkillActionC2S.TYPE, ModNetwork.SkillActionC2S.CODEC, (p, c) -> SkillWandManager.onAction(player(c), p.elf(), p.action()));
      r.playToServer(ModNetwork.SkillBypassC2S.TYPE, ModNetwork.SkillBypassC2S.CODEC, (p, c) -> SkillWandManager.onBypass(player(c), p.on()));
      r.playToServer(ModNetwork.StatusRequestC2S.TYPE, ModNetwork.StatusRequestC2S.CODEC, ModNetwork::onStatusRequest);
      r.playToServer(ModNetwork.RosterRequestC2S.TYPE, ModNetwork.RosterRequestC2S.CODEC, (p, c) -> sendRoster(player(c)));
      r.playToServer(ModNetwork.UnmountC2S.TYPE, ModNetwork.UnmountC2S.CODEC, ModNetwork::onUnmount);
      r.playToClient(ModNetwork.RosterS2C.TYPE, ModNetwork.RosterS2C.CODEC, (p, c) -> ClientHooks.roster(p.list()));
      r.playToClient(ModNetwork.StatusS2C.TYPE, ModNetwork.StatusS2C.CODEC, (p, c) -> ClientHooks.status(p.status(), p.open()));
      r.playToClient(ModNetwork.SkillSelectS2C.TYPE, ModNetwork.SkillSelectS2C.CODEC, (p, c) -> ClientHooks.skillSelect(p.list()));
      r.playToClient(
         ModNetwork.SkillWandStateS2C.TYPE, ModNetwork.SkillWandStateS2C.CODEC, (p, c) -> ClientHooks.skillState(p.selected(), p.visible(), p.bypass())
      );
      r.playToClient(ModNetwork.CinematicS2C.TYPE, ModNetwork.CinematicS2C.CODEC, (p, c) -> ClientHooks.cinematic(p.cinematicType(), p.ticks()));
      r.playToClient(ModNetwork.SilenceS2C.TYPE, ModNetwork.SilenceS2C.CODEC, (p, c) -> ClientHooks.silence(p.ticks()));
      r.playToClient(
         ModNetwork.CelestialArrowS2C.TYPE,
         ModNetwork.CelestialArrowS2C.CODEC,
         (p, c) -> ClientHooks.celestialArrow(p.x(), p.y(), p.z(), p.ticks(), p.startY())
      );
      r.playToClient(ModNetwork.ImpactS2C.TYPE, ModNetwork.ImpactS2C.CODEC, (p, c) -> ClientHooks.impact());
      VfxNet.register(r);
   }

   private static ServerPlayer player(IPayloadContext c) {
      return c.player() instanceof ServerPlayer sp ? sp : null;
   }

   public static void sendRoster(ServerPlayer p) {
      if (p != null) {
         List<ElfStatus> list = new ArrayList<>();

         for (ElfRegistry.Record r : ElfRegistry.get(p.server).ownedBy(p.getUUID())) {
            list.add(ElfStatus.of(r));
         }

         PacketDistributor.sendToPlayer(p, new ModNetwork.RosterS2C(list), new CustomPacketPayload[0]);
      }
   }

   public static void sendStatus(ServerPlayer p, UUID id, boolean open) {
      ElfRegistry.Record r = ElfRegistry.get(p.server).byId(id);
      if (r != null && r.owner.equals(p.getUUID())) {
         PacketDistributor.sendToPlayer(p, new ModNetwork.StatusS2C(ElfStatus.of(r), open), new CustomPacketPayload[0]);
      }
   }

   private static ElfRegistry.Record owned(ServerPlayer p, UUID id) {
      ElfRegistry.Record r = ElfRegistry.get(p.server).byId(id);
      if (r != null && r.owner.equals(p.getUUID())) {
         return r;
      } else {
         p.displayClientMessage(Component.translatable("message.elven_companions.not_yours"), true);
         return null;
      }
   }

   private static void onSelect(ModNetwork.SelectC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         ElfRegistry.Record r = owned(p, pk.elf());
         if (r != null) {
            ElfEntity elf = ElfManager.LOADED.get(r.id);
            if (r.dead || elf == null || !elf.isAlive()) {
               p.displayClientMessage(Component.translatable("message.elven_companions.unavailable"), true);
               sendRoster(p);
            } else if (elf.skills.isUltimate()) {
               p.displayClientMessage(Component.translatable("message.elven_companions.ult_locked", new Object[]{elf.getName()}), true);
               sendRoster(p);
            } else {
               PacketDistributor.sendToPlayer(p, new ModNetwork.StatusS2C(ElfStatus.of(elf), true), new CustomPacketPayload[0]);
            }
         }
      }
   }

   private static void onStatusRequest(ModNetwork.StatusRequestC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         sendStatus(p, pk.elf(), false);
      }
   }

   private static void onRename(ModNetwork.RenameC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         ElfRegistry.Record r = owned(p, pk.elf());
         if (r != null) {
            ElfEntity elf = ElfManager.LOADED.get(r.id);
            if (elf != null && elf.isAlive() && !elf.skills.isUltimate()) {
               StringBuilder sb = new StringBuilder();

               for (char ch : pk.name().toCharArray()) {
                  if (ch >= ' ' && ch != 127 && ch != 167) {
                     sb.append(ch);
                  }
               }

               String name = sb.toString().strip();
               if (name.length() > 24) {
                  name = name.substring(0, 24).strip();
               }

               if (name.isEmpty()) {
                  p.displayClientMessage(Component.translatable("message.elven_companions.rename_invalid"), true);
               } else {
                  elf.setCustomName(Component.literal(name));
                  elf.setCustomNameVisible(true);
                  ElfRegistry.get(p.server).update(elf);
                  p.displayClientMessage(Component.translatable("message.elven_companions.renamed", new Object[]{name}), true);
                  sendStatus(p, r.id, false);
               }
            } else {
               p.displayClientMessage(Component.translatable("message.elven_companions.unavailable"), true);
            }
         }
      }
   }

   private static void onDelete(ModNetwork.DeleteC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         ElfRegistry reg = ElfRegistry.get(p.server);
         ElfRegistry.Record r = owned(p, pk.elf());
         if (r != null) {
            ElfEntity elf = ElfManager.LOADED.get(r.id);
            if (elf != null && elf.skills.isUltimate()) {
               p.displayClientMessage(Component.translatable("message.elven_companions.ult_locked", new Object[]{elf.getName()}), true);
            } else {
               String name = r.name;
               reg.delete(r.id);
               if (elf != null) {
                  elf.deletePermanently();
               }

               for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
                  CompoundTag soul = SoulItem.read(p.getInventory().getItem(i));
                  if (soul != null && soul.hasUUID("CompanionId") && soul.getUUID("CompanionId").equals(r.id)) {
                     p.getInventory().setItem(i, ItemStack.EMPTY);
                  }
               }

               p.displayClientMessage(Component.translatable("message.elven_companions.deleted", new Object[]{name}), true);
               sendRoster(p);
            }
         }
      }
   }

   private static void onLevel(ModNetwork.LevelC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         if (!p.isCreative()) {
            p.displayClientMessage(Component.translatable("message.elven_companions.creative_only"), true);
         } else if (pk.delta() == 1 || pk.delta() == -1) {
            ElfRegistry.Record r = owned(p, pk.elf());
            if (r != null) {
               ElfEntity elf = ElfManager.LOADED.get(r.id);
               if (elf != null && elf.isAlive()) {
                  if (pk.delta() > 0 && elf.getElfLevel() >= 50 && !elf.isTranscended()) {
                     elf.setTranscended(true);
                  } else if (pk.delta() < 0 && elf.isTranscended()) {
                     elf.setTranscended(false);
                  } else {
                     elf.setLevelQuiet(elf.getElfLevel() + pk.delta());
                  }

                  sendStatus(p, r.id, false);
               } else {
                  p.displayClientMessage(Component.translatable("message.elven_companions.unavailable"), true);
               }
            }
         }
      }
   }

   private static void onSkin(ModNetwork.SkinC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         ElfRegistry.Record r = owned(p, pk.elf());
         if (r != null) {
            ElfEntity elf = ElfManager.LOADED.get(r.id);
            if (elf != null && elf.isAlive() && !elf.skills.isUltimate() && pk.skin() >= 0 && pk.skin() < 6) {
               elf.setSkin(pk.skin());
               ElfRegistry.get(p.server).update(elf);
               sendStatus(p, r.id, false);
            } else {
               p.displayClientMessage(Component.translatable("message.elven_companions.unavailable"), true);
            }
         }
      }
   }

   private static void onUnmount(ModNetwork.UnmountC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         for (ElfEntity elf : new ArrayList<>(ElfManager.LOADED.values())) {
            if (elf.isCarried() && elf.isOwnedBy(p) && !elf.skills.isUltimate()) {
               elf.dismount();
               ElfDialogue.say(elf, "unmount");
            }
         }
      }
   }

   private static void onCommand(ModNetwork.CommandC2S pk, IPayloadContext ctx) {
      ServerPlayer p = player(ctx);
      if (p != null) {
         ElfAction action = ElfAction.byId(pk.action());
         ElfRegistry.Record r = owned(p, pk.elf());
         if (action != null && r != null) {
            ElfEntity selected = ElfManager.LOADED.get(r.id);
            if (pk.all() && action != ElfAction.INVENTORY && action.ordinal() < ElfAction.SKILL_0.ordinal()) {
               List<ElfEntity> targets = new ArrayList<>();

               for (ElfRegistry.Record o : ElfRegistry.get(p.server).ownedBy(p.getUUID())) {
                  ElfEntity e = ElfManager.LOADED.get(o.id);
                  if (e != null && e.isAlive() && e.level() == p.level() && e.distanceToSqr(p) <= 16384.0) {
                     targets.add(e);
                  }
               }

               if (targets.isEmpty()) {
                  p.displayClientMessage(Component.translatable("message.elven_companions.group_none"), true);
                  sendStatus(p, r.id, false);
               } else {
                  int applied = 0;
                  boolean rodePlayer = false;

                  for (ElfEntity e : targets) {
                     if (action == ElfAction.RIDE_PLAYER) {
                        if (!rodePlayer && e.executeCommand(p, action)) {
                           applied++;
                           rodePlayer = true;
                        }
                     } else if (e.executeCommand(p, action, true)) {
                        applied++;
                     }
                  }

                  p.displayClientMessage(Component.translatable("message.elven_companions.group_result", new Object[]{applied}), true);
                  sendStatus(p, r.id, false);
               }
            } else {
               if (selected != null && selected.isAlive()) {
                  selected.executeCommand(p, action);
               } else if (!r.dead && action.queueable()) {
                  ElfRegistry.get(p.server).queue(r.id, action.ordinal());
                  p.displayClientMessage(Component.translatable("message.elven_companions.queued"), true);
               } else {
                  p.displayClientMessage(
                     Component.translatable(action.queueable() ? "message.elven_companions.unavailable" : "message.elven_companions.not_queueable"), true
                  );
               }

               sendStatus(p, r.id, false);
            }
         }
      }
   }

   private ModNetwork() {
   }

   public record CelestialArrowS2C(double x, double y, double z, int ticks, double startY) implements CustomPacketPayload {
      public static final Type<ModNetwork.CelestialArrowS2C> TYPE = new Type(ElvenCompanions.rl("celestial_arrow"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.CelestialArrowS2C> CODEC = StreamCodec.of((b, p) -> {
         b.writeDouble(p.x);
         b.writeDouble(p.y);
         b.writeDouble(p.z);
         b.writeVarInt(p.ticks);
         b.writeDouble(p.startY);
      }, b -> new ModNetwork.CelestialArrowS2C(b.readDouble(), b.readDouble(), b.readDouble(), b.readVarInt(), b.readDouble()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record CinematicS2C(int cinematicType, int ticks) implements CustomPacketPayload {
      public static final Type<ModNetwork.CinematicS2C> TYPE = new Type(ElvenCompanions.rl("cinematic"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.CinematicS2C> CODEC = StreamCodec.of((b, p) -> {
         b.writeVarInt(p.cinematicType);
         b.writeVarInt(p.ticks);
      }, b -> new ModNetwork.CinematicS2C(b.readVarInt(), b.readVarInt()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record CommandC2S(UUID elf, int action, boolean all) implements CustomPacketPayload {
      public static final Type<ModNetwork.CommandC2S> TYPE = new Type(ElvenCompanions.rl("command"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.CommandC2S> CODEC = StreamCodec.of((b, p) -> {
         b.writeUUID(p.elf);
         b.writeVarInt(p.action);
         b.writeBoolean(p.all);
      }, b -> new ModNetwork.CommandC2S(b.readUUID(), b.readVarInt(), b.readBoolean()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record DeleteC2S(UUID elf) implements CustomPacketPayload {
      public static final Type<ModNetwork.DeleteC2S> TYPE = new Type(ElvenCompanions.rl("delete"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.DeleteC2S> CODEC = StreamCodec.of(
         (b, p) -> b.writeUUID(p.elf), b -> new ModNetwork.DeleteC2S(b.readUUID())
      );

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record ImpactS2C() implements CustomPacketPayload {
      public static final Type<ModNetwork.ImpactS2C> TYPE = new Type(ElvenCompanions.rl("impact"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.ImpactS2C> CODEC = StreamCodec.of((b, p) -> {}, b -> new ModNetwork.ImpactS2C());

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record LevelC2S(UUID elf, int delta) implements CustomPacketPayload {
      public static final Type<ModNetwork.LevelC2S> TYPE = new Type(ElvenCompanions.rl("level"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.LevelC2S> CODEC = StreamCodec.of((b, p) -> {
         b.writeUUID(p.elf);
         b.writeVarInt(p.delta);
      }, b -> new ModNetwork.LevelC2S(b.readUUID(), b.readVarInt()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record RenameC2S(UUID elf, String name) implements CustomPacketPayload {
      public static final Type<ModNetwork.RenameC2S> TYPE = new Type(ElvenCompanions.rl("rename"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.RenameC2S> CODEC = StreamCodec.of((b, p) -> {
         b.writeUUID(p.elf);
         b.writeUtf(p.name, 64);
      }, b -> new ModNetwork.RenameC2S(b.readUUID(), b.readUtf(64)));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record RosterRequestC2S() implements CustomPacketPayload {
      public static final Type<ModNetwork.RosterRequestC2S> TYPE = new Type(ElvenCompanions.rl("roster_request"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.RosterRequestC2S> CODEC = StreamCodec.of((b, p) -> {}, b -> new ModNetwork.RosterRequestC2S());

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record RosterS2C(List<ElfStatus> list) implements CustomPacketPayload {
      public static final Type<ModNetwork.RosterS2C> TYPE = new Type(ElvenCompanions.rl("roster"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.RosterS2C> CODEC = StreamCodec.of((b, p) -> {
         b.writeVarInt(p.list.size());

         for (ElfStatus s : p.list) {
            s.write(b);
         }
      }, b -> {
         int n = b.readVarInt();
         List<ElfStatus> l = new ArrayList<>();

         for (int i = 0; i < n; i++) {
            l.add(ElfStatus.read(b));
         }

         return new ModNetwork.RosterS2C(l);
      });

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SelectC2S(UUID elf) implements CustomPacketPayload {
      public static final Type<ModNetwork.SelectC2S> TYPE = new Type(ElvenCompanions.rl("select"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SelectC2S> CODEC = StreamCodec.of(
         (b, p) -> b.writeUUID(p.elf), b -> new ModNetwork.SelectC2S(b.readUUID())
      );

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SilenceS2C(int ticks) implements CustomPacketPayload {
      public static final Type<ModNetwork.SilenceS2C> TYPE = new Type(ElvenCompanions.rl("silence"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SilenceS2C> CODEC = StreamCodec.of(
         (b, p) -> b.writeVarInt(p.ticks), b -> new ModNetwork.SilenceS2C(b.readVarInt())
      );

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkillActionC2S(UUID elf, int action) implements CustomPacketPayload {
      public static final Type<ModNetwork.SkillActionC2S> TYPE = new Type(ElvenCompanions.rl("skill_action"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkillActionC2S> CODEC = StreamCodec.of((b, p) -> {
         b.writeUUID(p.elf);
         b.writeVarInt(p.action);
      }, b -> new ModNetwork.SkillActionC2S(b.readUUID(), b.readVarInt()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkillBypassC2S(boolean on) implements CustomPacketPayload {
      public static final Type<ModNetwork.SkillBypassC2S> TYPE = new Type(ElvenCompanions.rl("skill_bypass"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkillBypassC2S> CODEC = StreamCodec.of(
         (b, p) -> b.writeBoolean(p.on), b -> new ModNetwork.SkillBypassC2S(b.readBoolean())
      );

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkillPickC2S(UUID elf) implements CustomPacketPayload {
      public static final Type<ModNetwork.SkillPickC2S> TYPE = new Type(ElvenCompanions.rl("skill_pick"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkillPickC2S> CODEC = StreamCodec.of(
         (b, p) -> b.writeUUID(p.elf), b -> new ModNetwork.SkillPickC2S(b.readUUID())
      );

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkillSelectS2C(List<ElfStatus> list) implements CustomPacketPayload {
      public static final Type<ModNetwork.SkillSelectS2C> TYPE = new Type(ElvenCompanions.rl("skill_select"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkillSelectS2C> CODEC = StreamCodec.of((b, p) -> {
         b.writeVarInt(p.list.size());

         for (ElfStatus s : p.list) {
            s.write(b);
         }
      }, b -> {
         int n = b.readVarInt();
         List<ElfStatus> l = new ArrayList<>();

         for (int i = 0; i < n; i++) {
            l.add(ElfStatus.read(b));
         }

         return new ModNetwork.SkillSelectS2C(l);
      });

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkillSwitchC2S() implements CustomPacketPayload {
      public static final Type<ModNetwork.SkillSwitchC2S> TYPE = new Type(ElvenCompanions.rl("skill_switch"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkillSwitchC2S> CODEC = StreamCodec.of((b, p) -> {}, b -> new ModNetwork.SkillSwitchC2S());

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkillWandStateS2C(@Nullable UUID selected, boolean visible, boolean bypass) implements CustomPacketPayload {
      public static final Type<ModNetwork.SkillWandStateS2C> TYPE = new Type(ElvenCompanions.rl("skill_state"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkillWandStateS2C> CODEC = StreamCodec.of((b, p) -> {
         b.writeBoolean(p.selected != null);
         if (p.selected != null) {
            b.writeUUID(p.selected);
         }

         b.writeBoolean(p.visible);
         b.writeBoolean(p.bypass);
      }, b -> new ModNetwork.SkillWandStateS2C(b.readBoolean() ? b.readUUID() : null, b.readBoolean(), b.readBoolean()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record SkinC2S(UUID elf, int skin) implements CustomPacketPayload {
      public static final Type<ModNetwork.SkinC2S> TYPE = new Type(ElvenCompanions.rl("skin"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.SkinC2S> CODEC = StreamCodec.of((b, p) -> {
         b.writeUUID(p.elf);
         b.writeVarInt(p.skin);
      }, b -> new ModNetwork.SkinC2S(b.readUUID(), b.readVarInt()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record StatusRequestC2S(UUID elf) implements CustomPacketPayload {
      public static final Type<ModNetwork.StatusRequestC2S> TYPE = new Type(ElvenCompanions.rl("status_request"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.StatusRequestC2S> CODEC = StreamCodec.of(
         (b, p) -> b.writeUUID(p.elf), b -> new ModNetwork.StatusRequestC2S(b.readUUID())
      );

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record StatusS2C(ElfStatus status, boolean open) implements CustomPacketPayload {
      public static final Type<ModNetwork.StatusS2C> TYPE = new Type(ElvenCompanions.rl("status"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.StatusS2C> CODEC = StreamCodec.of((b, p) -> {
         p.status.write(b);
         b.writeBoolean(p.open);
      }, b -> new ModNetwork.StatusS2C(ElfStatus.read(b), b.readBoolean()));

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   public record UnmountC2S() implements CustomPacketPayload {
      public static final Type<ModNetwork.UnmountC2S> TYPE = new Type(ElvenCompanions.rl("unmount"));
      public static final StreamCodec<FriendlyByteBuf, ModNetwork.UnmountC2S> CODEC = StreamCodec.of((b, p) -> {}, b -> new ModNetwork.UnmountC2S());

      public Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }
}
