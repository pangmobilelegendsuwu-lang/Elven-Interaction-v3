package com.elvencompanions.net;

import com.elvencompanions.client.ClientHooksVfx;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class VfxNet {
   public static void register(PayloadRegistrar var0) {
      var0.playToClient(VfxS2C.TYPE, VfxS2C.CODEC, (var0x, var1) -> ClientHooksVfx.play(var0x));
   }

   private VfxNet() {
   }
}
