package com.elvencompanions.net;

import com.elvencompanions.ECConfig;
import com.elvencompanions.data.ElfManager;
import com.elvencompanions.data.ElfRegistry;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.entity.ElfLevel;
import com.elvencompanions.entity.ElfStats;
import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.player.Player;

public record ElfStatus(
   UUID id,
   String name,
   int skin,
   int stance,
   int combat,
   int rest,
   int riding,
   boolean pickup,
   boolean loaded,
   boolean dead,
   boolean ultimate,
   float health,
   float maxHealth,
   int stamina,
   int maxStamina,
   int invUsed,
   int[] cooldownSecs,
   boolean manualSkills,
   int level,
   int xp,
   int xpNext,
   int schedule,
   boolean hasHome,
   float[] stats,
   float[] base,
   boolean transcended,
   int rageTicks
) {
   public void write(FriendlyByteBuf b) {
      b.writeUUID(this.id);
      b.writeUtf(this.name, 64);
      b.writeVarInt(this.skin);
      b.writeVarInt(this.stance);
      b.writeVarInt(this.combat);
      b.writeVarInt(this.rest);
      b.writeVarInt(this.riding);
      b.writeBoolean(this.pickup);
      b.writeBoolean(this.loaded);
      b.writeBoolean(this.dead);
      b.writeBoolean(this.ultimate);
      b.writeFloat(this.health);
      b.writeFloat(this.maxHealth);
      b.writeVarInt(this.stamina);
      b.writeVarInt(this.maxStamina);
      b.writeVarInt(this.invUsed);
      b.writeVarInt(this.cooldownSecs.length);

      for (int c : this.cooldownSecs) {
         b.writeVarInt(c);
      }

      b.writeBoolean(this.manualSkills);
      b.writeVarInt(this.level);
      b.writeVarInt(this.xp);
      b.writeVarInt(this.xpNext);
      b.writeVarInt(this.schedule);
      b.writeBoolean(this.hasHome);
      b.writeVarInt(this.stats.length);

      for (float f : this.stats) {
         b.writeFloat(f);
      }

      b.writeVarInt(this.base.length);

      for (float f : this.base) {
         b.writeFloat(f);
      }

      b.writeBoolean(this.transcended);
      b.writeVarInt(this.rageTicks);
   }

   public static ElfStatus read(FriendlyByteBuf b) {
      UUID id = b.readUUID();
      String name = b.readUtf(64);
      int skin = b.readVarInt();
      int stance = b.readVarInt();
      int combat = b.readVarInt();
      int rest = b.readVarInt();
      int riding = b.readVarInt();
      boolean pickup = b.readBoolean();
      boolean loaded = b.readBoolean();
      boolean dead = b.readBoolean();
      boolean ult = b.readBoolean();
      float hp = b.readFloat();
      float max = b.readFloat();
      int stamina = b.readVarInt();
      int maxStamina = b.readVarInt();
      int inv = b.readVarInt();
      int n = b.readVarInt();
      int[] cds = new int[n];

      for (int i = 0; i < n; i++) {
         cds[i] = b.readVarInt();
      }

      boolean manual = b.readBoolean();
      int level = b.readVarInt();
      int xp = b.readVarInt();
      int xpNext = b.readVarInt();
      int schedule = b.readVarInt();
      boolean hasHome = b.readBoolean();
      float[] stats = new float[b.readVarInt()];

      for (int i = 0; i < stats.length; i++) {
         stats[i] = b.readFloat();
      }

      float[] base = new float[b.readVarInt()];

      for (int i = 0; i < base.length; i++) {
         base[i] = b.readFloat();
      }

      boolean transcended = b.readBoolean();
      int rageTicks = b.readVarInt();
      return new ElfStatus(
         id,
         name,
         skin,
         stance,
         combat,
         rest,
         riding,
         pickup,
         loaded,
         dead,
         ult,
         hp,
         max,
         stamina,
         maxStamina,
         inv,
         cds,
         manual,
         level,
         xp,
         xpNext,
         schedule,
         hasHome,
         stats,
         base,
         transcended,
         rageTicks
      );
   }

   public static ElfStatus of(ElfEntity e) {
      int riding = e.isCarried() ? 1 : (!e.isPassenger() ? 0 : (e.getVehicle() instanceof Player ? 1 : 2));
      return new ElfStatus(
         e.getCompanionId(),
         e.getName().getString(),
         e.getSkin(),
         e.getStance(),
         e.getCombat(),
         e.getRestState(),
         riding,
         e.isPickup(),
         true,
         false,
         e.skills.isUltimate(),
         e.getHealth(),
         e.getMaxHealth(),
         e.defense.getStamina(),
         e.defense.maxStamina(),
         e.inventory.usedSlots(),
         e.skills.cooldownSeconds(),
         (Boolean)ECConfig.allowManualSkills.get(),
         e.getElfLevel(),
         e.getXp(),
         e.getElfLevel() >= 50 ? (e.isTranscended() ? 0 : ElfLevel.transcendXp()) : ElfLevel.xpForNext(e.getElfLevel()),
         e.getSchedule().ordinal(),
         e.hasHome(),
         ElfStats.of(e),
         ElfStats.byLevel(1, e.level().getDifficulty()),
         e.isTranscended(),
         e.getRageTicks()
      );
   }

   public static ElfStatus of(ElfRegistry.Record r) {
      ElfEntity live = ElfManager.LOADED.get(r.id);
      return live != null && !r.dead
         ? of(live)
         : new ElfStatus(
            r.id,
            r.name,
            r.skin,
            r.stance,
            r.combat,
            0,
            0,
            r.pickup,
            false,
            r.dead,
            false,
            r.health,
            r.maxHealth,
            0,
            (Integer)ECConfig.maxStamina.get(),
            r.invUsed,
            new int[13],
            (Boolean)ECConfig.allowManualSkills.get(),
            r.level,
            r.xp,
            r.level >= 50 ? (r.transcended ? 0 : ElfLevel.transcendXp()) : ElfLevel.xpForNext(r.level),
            0,
            false,
            ElfStats.of(r),
            ElfStats.byLevel(1, Difficulty.NORMAL),
            r.transcended,
            0
         );
   }
}
