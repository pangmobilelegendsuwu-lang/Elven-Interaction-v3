package com.elvencompanions.net;

import com.elvencompanions.ECConfig;
import com.elvencompanions.data.ElfManager;
import com.elvencompanions.data.ElfRegistry;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.entity.ElfNew;
import com.elvencompanions.entity.ElfSkills;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "elven_companions"
)
public final class SkillWandManager {
   private static final Map<UUID, SkillWandManager.State> STATES = new HashMap<>();

   private static SkillWandManager.State state(ServerPlayer p) {
      return STATES.computeIfAbsent(p.getUUID(), k -> new SkillWandManager.State());
   }

   private static boolean owns(ServerPlayer p, UUID elf) {
      if (elf == null) {
         return false;
      } else {
         ElfRegistry reg = ElfRegistry.get(p.server);
         ElfRegistry.Record r = reg.byId(elf);
         return r != null && r.owner.equals(p.getUUID()) && !reg.isDeleted(elf) && !r.dead;
      }
   }

   public static void sendState(ServerPlayer p) {
      SkillWandManager.State s = state(p);
      PacketDistributor.sendToPlayer(p, new ModNetwork.SkillWandStateS2C(s.elf, s.visible, s.bypass && p.isCreative()), new CustomPacketPayload[0]);
      if (s.elf != null) {
         ModNetwork.sendStatus(p, s.elf, false);
      }
   }

   private static void sendSelect(ServerPlayer p) {
      List<ElfStatus> list = new ArrayList<>();

      for (ElfRegistry.Record r : ElfRegistry.get(p.server).ownedBy(p.getUUID())) {
         if (!r.dead) {
            list.add(ElfStatus.of(r));
         }
      }

      PacketDistributor.sendToPlayer(p, new ModNetwork.SkillSelectS2C(list), new CustomPacketPayload[0]);
   }

   public static void onWandUse(ServerPlayer p) {
      SkillWandManager.State s = state(p);
      if (s.elf != null && owns(p, s.elf)) {
         s.visible = !s.visible;
         sendState(p);
      } else {
         s.elf = null;
         s.visible = false;
         sendState(p);
         sendSelect(p);
      }
   }

   public static void onSwitch(ServerPlayer p) {
      if (p != null) {
         sendSelect(p);
      }
   }

   public static void onPick(ServerPlayer p, UUID elf) {
      if (p != null) {
         if (!owns(p, elf)) {
            p.displayClientMessage(Component.translatable("message.elven_companions.not_yours"), true);
         } else {
            SkillWandManager.State s = state(p);
            s.elf = elf;
            s.visible = true;
            sendState(p);
         }
      }
   }

   public static void onBypass(ServerPlayer p, boolean on) {
      if (p != null) {
         SkillWandManager.State s = state(p);
         if (!p.isCreative()) {
            s.bypass = false;
            p.displayClientMessage(Component.translatable("message.elven_companions.creative_only"), true);
         } else {
            s.bypass = on;
         }

         sendState(p);
      }
   }

   public static void onAction(ServerPlayer p, UUID elfId, int action) {
      if (p != null) {
         SkillWandManager.State s = state(p);
         if (s.elf != null && s.elf.equals(elfId) && owns(p, elfId)) {
            ElfEntity elf = ElfManager.LOADED.get(elfId);
            if (elf != null && elf.isAlive()) {
               double range = ((Integer)ECConfig.skillWandRange.get()).intValue();
               if (elf.level() == p.level() && !(elf.distanceToSqr(p) > range * range)) {
                  ElfSkills.ManualResult res = ElfNew.manualAction(elf.skills, action, s.bypass && p.isCreative());
                  p.displayClientMessage(
                     Component.translatable("message.elven_companions.skill_result." + res.name().toLowerCase(Locale.ROOT), new Object[]{elf.getName()}), true
                  );
                  ModNetwork.sendStatus(p, elfId, false);
               } else {
                  p.displayClientMessage(
                     Component.translatable(
                        "message.elven_companions.too_far_dist",
                        new Object[]{elf.getName(), String.format(Locale.ROOT, "%.0f", Math.sqrt(elf.distanceToSqr(p))), (int)range}
                     ),
                     true
                  );
               }
            } else {
               p.displayClientMessage(Component.translatable("message.elven_companions.unavailable"), true);
            }
         } else {
            p.displayClientMessage(Component.translatable("message.elven_companions.not_yours"), true);
            if (s.elf != null && !owns(p, s.elf)) {
               s.elf = null;
               s.visible = false;
               sendState(p);
            }
         }
      }
   }

   @SubscribeEvent
   public static void onLogout(PlayerLoggedOutEvent event) {
      STATES.remove(event.getEntity().getUUID());
   }

   private SkillWandManager() {
   }

   public static final class State {
      public UUID elf;
      public boolean visible;
      public boolean bypass;
   }
}
