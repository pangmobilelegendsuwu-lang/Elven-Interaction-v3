package com.elvencompanions.net;

import com.elvencompanions.ElvenCompanions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;

public record VfxS2C(int kind, int entity, double x, double y, double z, double x2, double y2, double z2, int ticks, float scale) implements CustomPacketPayload {
   public static final Type<VfxS2C> TYPE = new Type(ElvenCompanions.rl("vfx"));
   public static final StreamCodec<FriendlyByteBuf, VfxS2C> CODEC = StreamCodec.of(
      (var0, var1) -> {
         var0.writeVarInt(var1.kind);
         var0.writeVarInt(var1.entity + 1);
         var0.writeDouble(var1.x);
         var0.writeDouble(var1.y);
         var0.writeDouble(var1.z);
         var0.writeDouble(var1.x2);
         var0.writeDouble(var1.y2);
         var0.writeDouble(var1.z2);
         var0.writeVarInt(var1.ticks);
         var0.writeFloat(var1.scale);
      },
      var0 -> new VfxS2C(
         var0.readVarInt(),
         var0.readVarInt() - 1,
         var0.readDouble(),
         var0.readDouble(),
         var0.readDouble(),
         var0.readDouble(),
         var0.readDouble(),
         var0.readDouble(),
         var0.readVarInt(),
         var0.readFloat()
      )
   );

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
