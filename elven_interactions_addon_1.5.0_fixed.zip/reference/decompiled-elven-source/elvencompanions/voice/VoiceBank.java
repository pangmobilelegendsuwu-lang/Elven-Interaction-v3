package com.elvencompanions.voice;

import com.elvencompanions.ElvenCompanions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class VoiceBank {
   public static final Map<String, List<VoiceBank.Clip>> CLIPS = new HashMap<>();

   public static void register(DeferredRegister<SoundEvent> reg) {
      for (String[] d : VoiceClips.DATA) {
         String name = d[1];
         DeferredHolder<SoundEvent, SoundEvent> h = reg.register(name, () -> SoundEvent.createVariableRangeEvent(ElvenCompanions.rl(name)));
         CLIPS.computeIfAbsent(d[0], k -> new ArrayList<>()).add(new VoiceBank.Clip(h, Integer.parseInt(d[2])));
      }
   }

   private VoiceBank() {
   }

   public record Clip(DeferredHolder<SoundEvent, SoundEvent> sound, int ticks) {
   }
}
