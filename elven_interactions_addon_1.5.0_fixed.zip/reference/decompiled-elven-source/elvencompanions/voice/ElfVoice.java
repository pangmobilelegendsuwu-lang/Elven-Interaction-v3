package com.elvencompanions.voice;

import com.elvencompanions.ECConfig;
import com.elvencompanions.entity.ElfEntity;
import java.util.Arrays;
import java.util.List;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class ElfVoice {
   private final ElfEntity elf;
   private final int[] nextAllowed = new int[ElfVoice.Cat.values().length];
   private final int[] lastIdx = new int[ElfVoice.Cat.values().length];
   private int busyUntil;
   private int curPrio;
   private ResourceLocation curId;
   private final ItemStack[] armor = new ItemStack[4];
   private boolean armorInit;
   private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};

   public ElfVoice(ElfEntity elf) {
      this.elf = elf;
      Arrays.fill(this.lastIdx, -1);
   }

   public boolean play(ElfVoice.Cat c) {
      if (this.elf.level() instanceof ServerLevel sl && (Boolean)ECConfig.voiceEnabled.get()) {
         List<VoiceBank.Clip> list = VoiceBank.CLIPS.get(c.key);
         if (list != null && !list.isEmpty()) {
            int now = this.elf.tickCount;
            if (now < this.nextAllowed[c.ordinal()]) {
               return false;
            } else {
               boolean busy = now < this.busyUntil;
               if (busy && c.prio <= this.curPrio) {
                  return false;
               } else {
                  if (busy) {
                     this.stopCurrent(sl);
                  }

                  int i = this.elf.getRandom().nextInt(list.size());
                  if (list.size() > 1 && i == this.lastIdx[c.ordinal()]) {
                     i = (i + 1 + this.elf.getRandom().nextInt(list.size() - 1)) % list.size();
                  }

                  this.lastIdx[c.ordinal()] = i;
                  VoiceBank.Clip clip = list.get(i);
                  sl.playSound(
                     null,
                     this.elf.getX(),
                     this.elf.getY(),
                     this.elf.getZ(),
                     (SoundEvent)clip.sound().get(),
                     SoundSource.VOICE,
                     ((Double)ECConfig.voiceVolume.get()).floatValue(),
                     1.0F
                  );
                  this.busyUntil = now + clip.ticks() + 4;
                  this.curPrio = c.prio;
                  this.curId = clip.sound().getId();
                  this.nextAllowed[c.ordinal()] = now + c.gap;
                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void stopCurrent(ServerLevel sl) {
      if (this.curId != null) {
         for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this.elf) < 2304.0) {
               p.connection.send(new ClientboundStopSoundPacket(this.curId, SoundSource.VOICE));
            }
         }

         this.curId = null;
      }
   }

   public void onTarget(LivingEntity t) {
      float hp = t.getMaxHealth();
      ElfVoice.Cat c = hp >= ((Integer)ECConfig.encounterBossHealth.get()).intValue()
         ? ElfVoice.Cat.ENC_BOSS
         : (hp >= ((Integer)ECConfig.encounterEliteHealth.get()).intValue() ? ElfVoice.Cat.ENC_ELITE : ElfVoice.Cat.ENC_NORMAL);
      if (this.play(c)) {
         int until = this.elf.tickCount + c.gap;
         this.nextAllowed[ElfVoice.Cat.ENC_BOSS.ordinal()] = until;
         this.nextAllowed[ElfVoice.Cat.ENC_ELITE.ordinal()] = until;
         this.nextAllowed[ElfVoice.Cat.ENC_NORMAL.ordinal()] = until;
      }
   }

   public void onBasicShot() {
      if (this.elf.getRandom().nextDouble() < (Double)ECConfig.attackVoiceChance.get()) {
         this.play(ElfVoice.Cat.ATTACK);
      }
   }

   public void onSkill() {
      this.play(this.elf.getRandom().nextDouble() < ECConfig.skillLineChance.get() ? ElfVoice.Cat.SKILL_LINE : ElfVoice.Cat.SKILL_VOICE);
   }

   public void onHurt(float amount) {
      if (this.elf.isAlive()) {
         float max = this.elf.getMaxHealth();
         ElfVoice.Cat c = this.elf.getHealth() < max * ECConfig.lowHealthFraction.get()
            ? ElfVoice.Cat.HURT_LOW
            : (amount >= max * ECConfig.hurtHeavyFraction.get() ? ElfVoice.Cat.HURT_HEAVY : ElfVoice.Cat.HURT_LIGHT);
         this.play(c);
      }
   }

   public void onDeath() {
      this.nextAllowed[ElfVoice.Cat.DEATH.ordinal()] = 0;
      this.busyUntil = 0;
      this.play(ElfVoice.Cat.DEATH);
   }

   public void tick() {
      int t = this.elf.tickCount;
      if (t % 10 == 0) {
         this.checkEquipment();
      }

      if (t % 20 == 0 && this.elf.isAlive()) {
         boolean calm = this.elf.getTarget() == null
            && this.elf.getRestState() == 0
            && !this.elf.skills.isUltimate()
            && !this.elf.skills.hasCast()
            && !this.elf.defense.isDrinking();
         if (calm) {
            Player owner = this.elf.getOwnerPlayer();
            double d = ((Integer)ECConfig.talkDistance.get()).intValue();
            if (owner == null
               || owner.level() != this.elf.level()
               || !(this.elf.distanceToSqr(owner) <= d * d)
               || !(this.elf.getRandom().nextDouble() < (Double)ECConfig.talkChancePerSecond.get())
               || !this.play(ElfVoice.Cat.TALK)) {
               if (this.elf.getRestState() == 0 && this.elf.getRandom().nextDouble() < (Double)ECConfig.idleChancePerSecond.get()) {
                  this.play(ElfVoice.Cat.IDLE);
               }
            }
         }
      }
   }

   private void checkEquipment() {
      if (this.armorInit) {
         boolean equipped = false;

         for (int i = 0; i < 4; i++) {
            ItemStack cur = this.elf.getItemBySlot(ARMOR_SLOTS[i]);
            if (!cur.isEmpty() && !ItemStack.isSameItemSameComponents(cur, this.armor[i])) {
               equipped = true;
            }

            this.armor[i] = cur.copy();
         }

         if (equipped) {
            this.play(ElfVoice.Cat.EQUIPMENT);
         }
      } else {
         for (int i = 0; i < 4; i++) {
            this.armor[i] = this.elf.getItemBySlot(ARMOR_SLOTS[i]).copy();
         }

         this.armorInit = true;
      }
   }

   public static enum Cat {
      DEATH("death", 100, 0),
      HURT_LOW("hurt_low", 80, 30),
      HURT_HEAVY("hurt_heavy", 80, 30),
      HURT_LIGHT("hurt_light", 70, 30),
      KNOCKBACK("knockback", 60, 0),
      DODGE("dodge", 60, 0),
      SKILL_LINE("skill_line", 55, 0),
      SKILL_VOICE("skill_voice", 50, 0),
      EQUIPMENT("equipment", 45, 0),
      ENC_BOSS("encounter_boss", 45, 400),
      ENC_ELITE("encounter_elite", 45, 400),
      ENC_NORMAL("encounter_normal", 40, 400),
      ATTACK("attack", 30, 120),
      TALK("talk", 20, 1800),
      IDLE("idle", 10, 400);

      final String key;
      final int prio;
      final int gap;

      private Cat(String key, int prio, int gap) {
         this.key = key;
         this.prio = prio;
         this.gap = gap;
      }
   }
}
