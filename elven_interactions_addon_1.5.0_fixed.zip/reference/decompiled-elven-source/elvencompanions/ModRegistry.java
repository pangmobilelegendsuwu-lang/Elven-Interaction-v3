package com.elvencompanions;

import com.elvencompanions.block.SoulwoodTreeBlock;
import com.elvencompanions.block.SoulwoodTreeBlockEntity;
import com.elvencompanions.entity.ElfArrow;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.entity.ElfInventoryMenu;
import com.elvencompanions.entity.SpectralStagEntity;
import com.elvencompanions.item.ElfBowItem;
import com.elvencompanions.item.SigilItem;
import com.elvencompanions.item.SkillWandItem;
import com.elvencompanions.item.SoulItem;
import com.elvencompanions.item.WandItem;
import com.elvencompanions.voice.VoiceBank;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Blocks;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public final class ModRegistry {
   public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, "elven_companions");
   public static final Items ITEMS = DeferredRegister.createItems("elven_companions");
   public static final Blocks BLOCKS = DeferredRegister.createBlocks("elven_companions");
   public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "elven_companions");
   public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, "elven_companions");
   public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, "elven_companions");
   public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, "elven_companions");
   public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "elven_companions");
   public static final DeferredHolder<EntityType<?>, EntityType<ElfEntity>> ELF = ENTITIES.register(
      "elf", () -> Builder.of(ElfEntity::new, MobCategory.CREATURE).sized(0.6F, 1.9F).eyeHeight(1.7F).clientTrackingRange(10).build("elf")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<SpectralStagEntity>> SPECTRAL_STAG = ENTITIES.register(
      "spectral_stag",
      () -> Builder.of(SpectralStagEntity::new, MobCategory.MISC)
         .sized(1.8F, 2.4F)
         .noSave()
         .noSummon()
         .fireImmune()
         .clientTrackingRange(10)
         .updateInterval(1)
         .build("spectral_stag")
   );
   public static final DeferredHolder<EntityType<?>, EntityType<ElfArrow>> ELF_ARROW = ENTITIES.register(
      "elf_arrow",
      () -> Builder.of(ElfArrow::new, MobCategory.MISC).sized(0.5F, 0.5F).eyeHeight(0.13F).clientTrackingRange(4).updateInterval(20).build("elf_arrow")
   );
   public static final DeferredItem<SigilItem> SIGIL = ITEMS.registerItem("elven_summoning_sigil", SigilItem::new, new Properties().stacksTo(16));
   public static final DeferredItem<WandItem> WAND = ITEMS.registerItem("command_wand", WandItem::new, new Properties().stacksTo(1));
   public static final DeferredItem<ElfBowItem> ELF_BOW = ITEMS.registerItem("elven_bow", ElfBowItem::new, new Properties().stacksTo(1));
   public static final DeferredItem<ElfBowItem> CELESTIAL_BOW = ITEMS.registerItem("celestial_bow", ElfBowItem::new, new Properties().stacksTo(1));
   public static final DeferredItem<SkillWandItem> SKILL_WAND = ITEMS.registerItem("skill_wand", SkillWandItem::new, new Properties().stacksTo(1));
   public static final DeferredItem<SoulItem> SOUL = ITEMS.registerItem("elf_soul", SoulItem::new, new Properties().stacksTo(1));
   public static final DeferredBlock<SoulwoodTreeBlock> TREE = BLOCKS.registerBlock(
      "soulwood_revival_tree",
      SoulwoodTreeBlock::new,
      net.minecraft.world.level.block.state.BlockBehaviour.Properties.of()
         .mapColor(MapColor.WOOD)
         .strength(2.0F)
         .sound(SoundType.WOOD)
         .noOcclusion()
         .lightLevel(s -> 7)
   );
   public static final DeferredItem<BlockItem> TREE_ITEM = ITEMS.registerSimpleBlockItem("soulwood_revival_tree", TREE);
   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SoulwoodTreeBlockEntity>> TREE_BE = BLOCK_ENTITIES.register(
      "soulwood_tree",
      () -> net.minecraft.world.level.block.entity.BlockEntityType.Builder.of(SoulwoodTreeBlockEntity::new, new Block[]{(Block)TREE.get()}).build(null)
   );
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GLOW_GREEN = particle("glow_green");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GLOW_GOLD = particle("glow_gold");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GLOW_FIRE = particle("glow_fire");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GLOW_MOON = particle("glow_moon");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> STAR = particle("star");
   public static final DeferredHolder<ParticleType<?>, SimpleParticleType> LEAF = particle("leaf");
   public static final DeferredHolder<MenuType<?>, MenuType<ElfInventoryMenu>> ELF_MENU = MENUS.register(
      "elf_inventory", () -> IMenuTypeExtension.create(ElfInventoryMenu::new)
   );
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_TRANSCEND_MUSIC = sound("transcend_music");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_ANNIHILATION_VOICE = sound("annihilation_voiceline");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_RAGING_VOICE = sound("raging_voiceline");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_SUMMON = sound("summon");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_UI = sound("ui_click");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_SKILL = sound("skill_cast");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_ULT_IMPACT = sound("ultimate_impact");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_REST = sound("rest");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_SOUL = sound("soul_store");
   public static final DeferredHolder<SoundEvent, SoundEvent> SND_REVIVE = sound("revive");
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register(
      "main",
      () -> CreativeModeTab.builder()
         .title(Component.translatable("itemGroup.elven_companions"))
         .icon(() -> new ItemStack((ItemLike)SIGIL.get()))
         .displayItems((params, out) -> {
            out.accept((ItemLike)SIGIL.get());
            out.accept((ItemLike)WAND.get());
            out.accept((ItemLike)SKILL_WAND.get());
            out.accept((ItemLike)TREE_ITEM.get());
         })
         .build()
   );

   private static DeferredHolder<ParticleType<?>, SimpleParticleType> particle(String name) {
      return PARTICLES.register(name, () -> new SimpleParticleType(true));
   }

   private static DeferredHolder<SoundEvent, SoundEvent> sound(String name) {
      return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ElvenCompanions.rl(name)));
   }

   public static void register(IEventBus bus) {
      VoiceBank.register(SOUNDS);
      ENTITIES.register(bus);
      ITEMS.register(bus);
      BLOCKS.register(bus);
      BLOCK_ENTITIES.register(bus);
      MENUS.register(bus);
      SOUNDS.register(bus);
      PARTICLES.register(bus);
      TABS.register(bus);
   }

   private ModRegistry() {
   }
}
