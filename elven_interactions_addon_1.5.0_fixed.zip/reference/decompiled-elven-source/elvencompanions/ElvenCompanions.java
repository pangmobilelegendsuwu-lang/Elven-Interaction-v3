package com.elvencompanions;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.net.ModNetwork;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig.Type;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import org.slf4j.Logger;

@Mod("elven_companions")
public class ElvenCompanions {
   public static final String MODID = "elven_companions";
   public static final Logger LOGGER = LogUtils.getLogger();

   public ElvenCompanions(IEventBus modBus, ModContainer container) {
      ModRegistry.register(modBus);
      container.registerConfig(Type.COMMON, ECConfig.SPEC);
      modBus.addListener(ModNetwork::register);
      modBus.addListener(this::onAttributes);
   }

   private void onAttributes(EntityAttributeCreationEvent event) {
      event.put((EntityType)ModRegistry.ELF.get(), ElfEntity.createAttributes().build());
   }

   public static ResourceLocation rl(String path) {
      return ResourceLocation.fromNamespaceAndPath("elven_companions", path);
   }
}
