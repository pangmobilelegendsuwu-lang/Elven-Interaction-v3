package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.data.ElfRegistry;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.ai.attributes.Attributes;

public final class ElfStats {
   public static final int HEALTH = 0;
   public static final int MAX_HEALTH = 1;
   public static final int REDUCTION = 2;
   public static final int ARROW = 3;
   public static final int INTERVAL = 4;
   public static final int CHANCE = 5;
   public static final int SKILL_DMG = 6;
   public static final int AREA = 7;
   public static final int STAMINA = 8;
   public static final int MAX_STAMINA = 9;
   public static final int SPEED = 10;
   public static final int SPREAD = 11;
   public static final int POTION = 12;
   public static final int COOLDOWN = 13;
   public static final int COUNT = 14;

   public static float[] of(ElfEntity e) {
      int lv = e.getElfLevel();
      float[] v = byLevel(lv, e.level().getDifficulty());
      v[0] = e.getHealth();
      v[1] = e.getMaxHealth();
      v[8] = e.defense.getStamina();
      v[9] = e.defense.maxStamina();
      v[10] = (float)(e.getAttributeValue(Attributes.MOVEMENT_SPEED) / 0.3);
      v[4] = e.fireInterval();
      return v;
   }

   public static float[] of(ElfRegistry.Record r) {
      float[] v = byLevel(r.level, Difficulty.NORMAL);
      v[0] = r.health;
      if (r.maxHealth > 0.0F) {
         v[1] = r.maxHealth;
      }

      return v;
   }

   public static float[] byLevel(int lv, Difficulty d) {
      float[] v = new float[14];
      v[1] = (float)ElfLevel.maxHealth(lv);
      v[0] = v[1];
      v[2] = (float)ElfLevel.damageReduction(lv) * 100.0F;
      v[3] = (float)ElfLevel.arrowMult(lv);
      v[4] = ElfLevel.fireInterval(lv, d);
      v[5] = ElfSkills.totalChance(lv);
      v[6] = (float)ElfLevel.skillDamage(lv);
      v[7] = (float)ElfLevel.area(lv);
      v[9] = (float)Math.max(1L, Math.round(((Integer)ECConfig.maxStamina.get()).intValue() * ElfLevel.staminaMult(lv)));
      v[8] = v[9];
      v[10] = (float)ElfLevel.walkSpeed(lv);
      v[11] = (float)ElfLevel.inaccuracy(lv);
      v[12] = ElfLevel.potionTicks(lv) / 20.0F;
      v[13] = (float)ElfLevel.cooldownFactor(lv);
      return v;
   }

   private ElfStats() {
   }
}
