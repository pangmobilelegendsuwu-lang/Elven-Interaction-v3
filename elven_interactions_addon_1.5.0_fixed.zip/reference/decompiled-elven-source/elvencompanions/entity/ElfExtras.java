package com.elvencompanions.entity;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;

public final class ElfExtras {
   public static boolean command(ElfEntity var0, ServerPlayer var1, ElfAction var2) {
      if (var2 != ElfAction.FLIGHT_TOGGLE && var2 != ElfAction.TRANSCEND_STOP && var2 != ElfAction.TRANSCEND_START && var2 != ElfAction.TRANSCEND_START_INSTANT
         )
       {
         return false;
      } else {
         if (var0.isOwnedBy(var1) && var0.isAlive() && !var0.skills.isUltimate()) {
            var0.skills.extraCommand(var1, var2);
         }

         return true;
      }
   }

   public static boolean blocksDamage(ElfEntity var0, DamageSource var1) {
      return var0.defense.hasDashIFrames() && (var1.is(DamageTypes.SONIC_BOOM) || var1.is(DamageTypeTags.IS_PROJECTILE));
   }

   private ElfExtras() {
   }
}
