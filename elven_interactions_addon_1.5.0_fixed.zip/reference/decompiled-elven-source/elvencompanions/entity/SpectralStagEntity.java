package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ModRegistry;
import com.elvencompanions.data.ElfManager;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class SpectralStagEntity extends Entity {
   private UUID companionId;
   private UUID targetId;
   private Vec3 lastTargetPos = Vec3.ZERO;
   private Vec3 dir = new Vec3(0.0, 0.0, 1.0);
   private double speed = 1.5;
   private float damage;
   private float pathDamage;
   private int life;
   private int overrun;
   private boolean overrunning;
   private final Set<Integer> hit = new HashSet<>();

   public SpectralStagEntity(EntityType<? extends SpectralStagEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public void setup(ElfEntity elf, LivingEntity target, double speed, float damage, float pathDamage) {
      this.companionId = elf.getCompanionId();
      this.targetId = target.getUUID();
      this.lastTargetPos = target.position().add(0.0, target.getBbHeight() * 0.4, 0.0);
      this.speed = speed;
      this.damage = damage;
      this.pathDamage = pathDamage;
      this.dir = this.lastTargetPos.subtract(this.position()).normalize();
      this.faceDir();
   }

   protected void defineSynchedData(Builder b) {
   }

   protected void readAdditionalSaveData(CompoundTag t) {
   }

   protected void addAdditionalSaveData(CompoundTag t) {
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isPushable() {
      return false;
   }

   private void faceDir() {
      float yaw = (float)Math.toDegrees(Math.atan2(-this.dir.x, this.dir.z));
      this.yRotO = this.getYRot();
      this.setYRot(yaw);
   }

   public void tick() {
      super.tick();
      if (this.level().isClientSide) {
         if (this.tickCount % 2 == 0) {
            this.level()
               .addParticle(
                  (ParticleOptions)ModRegistry.GLOW_GREEN.get(),
                  this.getX() + (this.random.nextDouble() - 0.5),
                  this.getY() + 0.3 + this.random.nextDouble() * 1.5,
                  this.getZ() + (this.random.nextDouble() - 0.5),
                  0.0,
                  0.02,
                  0.0
               );
            if (this.tickCount % 4 == 0) {
               this.level()
                  .addParticle(
                     (ParticleOptions)ModRegistry.LEAF.get(),
                     this.getX() + (this.random.nextDouble() - 0.5),
                     this.getY() + 1.4,
                     this.getZ() + (this.random.nextDouble() - 0.5),
                     0.0,
                     0.0,
                     0.0
                  );
            }
         }
      } else if (this.level() instanceof ServerLevel sl) {
         this.life++;
         ElfEntity elf = this.companionId == null ? null : ElfManager.LOADED.get(this.companionId);
         if (elf != null && elf.isAlive() && this.life <= (Integer)ECConfig.huntMaxTicks.get()) {
            LivingEntity target = this.targetId != null && sl.getEntity(this.targetId) instanceof LivingEntity le && le.isAlive() ? le : null;
            if (!this.overrunning) {
               if (target != null) {
                  this.lastTargetPos = target.position().add(0.0, target.getBbHeight() * 0.4, 0.0);
               }

               Vec3 to = this.lastTargetPos.subtract(this.position());
               double dist = to.length();
               if (dist > 1.0E-4) {
                  this.dir = to.scale(1.0 / dist);
               }

               if (target == null && dist <= 2.0) {
                  this.startOverrun();
               } else if (target != null && dist <= 2.6) {
                  this.strike(sl, elf, target);
                  this.startOverrun();
               }
            }

            this.faceDir();
            Vec3 step = this.overrunning ? new Vec3(this.dir.x, this.dir.y * 0.15, this.dir.z).normalize().scale(this.speed) : this.dir.scale(this.speed);
            this.setPos(this.getX() + step.x, this.getY() + step.y, this.getZ() + step.z);
            this.pathHits(sl, elf);
            if (this.tickCount % 2 == 0) {
               ElfFx.p(sl, ElfFx.green(), this.getX(), this.getY() + 1.0, this.getZ(), 3, 0.5, 0.7, 0.5, 0.0);
               ElfFx.p(sl, ElfFx.gold(), this.getX(), this.getY() + 1.8, this.getZ(), 1, 0.4, 0.4, 0.4, 0.0);
            }

            if (this.tickCount % 5 == 0) {
               sl.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.HORSE_GALLOP, SoundSource.NEUTRAL, 1.2F, 0.6F);
            }

            if (this.overrunning && --this.overrun <= 0) {
               this.dissolve();
            }
         } else {
            this.dissolve();
         }
      }
   }

   private void startOverrun() {
      this.overrunning = true;
      this.overrun = 14;
   }

   private void strike(ServerLevel sl, ElfEntity elf, LivingEntity target) {
      this.hit.add(target.getId());
      boolean powerful = target.getMaxHealth() >= ((Integer)ECConfig.thornBossHealth.get()).intValue();
      elf.skills.huntHit(target, this.damage);
      if (!powerful) {
         target.setDeltaMovement(target.getDeltaMovement().add(this.dir.x * 0.6, 0.7, this.dir.z * 0.6));
         target.hasImpulse = true;
         target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 3, false, true));
      }

      Vec3 at = target.position().add(0.0, target.getBbHeight() * 0.5, 0.0);
      ElfFx.p(sl, ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
      ElfFx.burst(sl, ElfFx.gold(), at.x, at.y, at.z, 60, 0.7);
      ElfFx.burst(sl, ElfFx.star(), at.x, at.y, at.z, 40, 0.8);
      ElfFx.burst(sl, ElfFx.leaf(), at.x, at.y, at.z, 30, 0.5);
      elf.skills.addFx(ElfFx.shockwave(sl, target.position(), 5.0, 10, ElfFx.gold(), ElfFx.green()));
      sl.playSound(null, at.x, at.y, at.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 1.6F, 1.3F);
      sl.playSound(null, at.x, at.y, at.z, SoundEvents.IRON_GOLEM_DAMAGE, SoundSource.NEUTRAL, 1.4F, 0.6F);
   }

   private void pathHits(ServerLevel sl, ElfEntity elf) {
      for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(0.8, 0.4, 0.8), elf::isHostile)) {
         if (this.hit.add(e.getId())) {
            elf.skills.huntHit(e, this.pathDamage);
            e.knockback(1.2, -this.dir.x, -this.dir.z);
            ElfFx.burst(sl, ElfFx.green(), e.getX(), e.getY() + 1.0, e.getZ(), 14, 0.4);
         }
      }
   }

   public void dissolve() {
      if (!this.isRemoved()) {
         if (this.level() instanceof ServerLevel sl) {
            ElfFx.burst(sl, ElfFx.leaf(), this.getX(), this.getY() + 1.4, this.getZ(), 40, 0.4);
            ElfFx.burst(sl, ElfFx.green(), this.getX(), this.getY() + 1.4, this.getZ(), 40, 0.5);
            ElfFx.burst(sl, ElfFx.gold(), this.getX(), this.getY() + 1.6, this.getZ(), 20, 0.4);
            sl.playSound(null, this.getX(), this.getY(), this.getZ(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.NEUTRAL, 1.4F, 0.6F);
         }

         this.discard();
      }
   }
}
