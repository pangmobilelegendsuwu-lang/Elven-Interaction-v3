package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.ModRegistry;
import com.elvencompanions.net.ModNetwork;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.Map.Entry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class ElfNew {
   static final int CD_MIRROR = 75;
   static final int CD_FALCON = 14;
   static final int CD_SUNDER = 12;
   static final int CD_STAGGER = 10;
   static final int CD_REPRISAL = 8;
   static final double CH_MIRROR = 0.07;
   static final double CH_FALCON = 0.1;
   static final double CH_SUNDER = 0.1;
   static final double CH_STAGGER = 0.1;
   static final int RH_BUILD = 200;
   static final int RH_EXHAUST = 100;
   static final int RH_IDLE_RESET = 60;
   static final double RH_DMG = 0.35;
   static final double RH_SPEED = 0.5;
   static final double DMG_FALCON_OUT = 1.0;
   static final double DMG_FALCON_RET = 0.45;
   static final double DMG_SUNDER = 0.9;
   static final double DMG_STAGGER = 1.0;
   static final double DMG_REPRISAL = 1.3;
   static final double COPY_BIG_DMG = 0.5;
   static final int MIRROR_T_LV1 = 20;
   static final int MIRROR_T_LV50 = 50;
   static final int MIRROR_T_TRANSC = 100;
   static final int MIRROR_MAX_CASTS = 6;
   static final int S_FALCON = 19;
   static final int S_SUNDER = 20;
   static final int S_REPRISAL = 21;
   static final int S_STAGGER = 22;
   public static final int V_FALCON = 31;
   public static final int V_BOLT = 32;
   public static final int V_SUNDER = 33;
   public static final int V_STAGGER = 34;
   public static final int V_RHYTHM = 35;
   public static final int V_GHOST = 36;
   public static final int V_VANISH = 37;
   public static final int V_AFTER = 38;
   private static final ResourceLocation BREAK_ID = ElvenCompanions.rl("sundering_break");
   private static final ResourceLocation BREAK_T_ID = ElvenCompanions.rl("sundering_break_t");
   private static final String TAG = "ec_mirror";
   private static final WeakHashMap<ElfEntity, ElfNew.St> S = new WeakHashMap<>();
   private static final Set<ElfEntity> LIVE = Collections.newSetFromMap(new WeakHashMap<>());
   private static final WeakHashMap<LivingEntity, int[]> BREAKS = new WeakHashMap<>();
   private static boolean inited;
   private static boolean ok = true;
   private static Field fGLatch;
   private static Field fGCd;
   private static Field fUltObj;
   private static Field fElf;
   private static Field fCd;
   private static Field fCasts;
   private static Field fPending;
   private static Field fVfxSeen;
   private static Field fFx;
   private static Field fUlt;
   private static Field fHunt;
   private static Field fAnnih;
   private static Field fChrono;
   private static Field fRico;
   private static Field fWorld;
   private static Field fUltCd;
   private static Method mGuard;
   private static Method mDmg;
   private static Method mHurt;
   private static Method mActivate;
   private static Method mStartExtra;
   private static Method mStartHunt;
   private static Method mStartUlt;
   private static Method mCastVfx;
   private static Method mAnnounce;
   private static Method mCastTick;
   private static Method mCastFinish;
   private static Method mCastStart;
   private static Method mFxTick;
   private static final String AIM_TAG = "ec_aim";
   private static final WeakHashMap<ElfEntity, Creeper> AIMS = new WeakHashMap<>();
   private static final WeakHashMap<ElfEntity, int[]> AIM_UNTIL = new WeakHashMap<>();
   private static boolean inMirror;
   private static final double MIRROR_ULT_CHANCE = 0.65;
   private static Field fAnimAcc;
   private static Field fEntityData;
   private static Method mSet;

   static int mirrorWindow(int var0, boolean var1) {
      return var1 ? 100 : (int)Math.round(20.0 + 30.0 * ((Math.max(1, Math.min(50, var0)) - 1) / 49.0));
   }

   static boolean once(int var0) {
      return var0 == 6 || var0 == 7 || var0 == 10 || var0 == 15;
   }

   static boolean copyable(int var0) {
      return var0 >= 0 && var0 <= 7 || var0 == 10 || var0 >= 13 && var0 <= 15 || var0 >= 19 && var0 <= 22;
   }

   static int copies(int var0, boolean var1) {
      if (var1) {
         return 12;
      } else if (var0 >= 50) {
         return 8;
      } else if (var0 >= 40) {
         return 7;
      } else if (var0 >= 30) {
         return 6;
      } else if (var0 >= 20) {
         return 4;
      } else {
         return var0 >= 10 ? 3 : 2;
      }
   }

   private ElfNew() {
   }

   private static ElfNew.St st(ElfEntity var0) {
      ElfNew.St var1 = S.get(var0);
      if (var1 == null) {
         var1 = new ElfNew.St();
         S.put(var0, var1);
      }

      return var1;
   }

   private static void init() {
      if (!inited) {
         inited = true;

         try {
            Class<ElfSkills> var0 = ElfSkills.class;
            fElf = acc(var0.getDeclaredField("elf"));
            fCd = acc(var0.getDeclaredField("cd"));
            fCasts = acc(var0.getDeclaredField("casts"));
            fPending = acc(var0.getDeclaredField("pending"));
            fVfxSeen = acc(var0.getDeclaredField("vfxSeen"));
            fFx = acc(var0.getDeclaredField("fx"));
            fUlt = acc(var0.getDeclaredField("ultCd"));
            fHunt = acc(var0.getDeclaredField("huntCd"));
            fAnnih = acc(var0.getDeclaredField("annihilationCd"));
            fChrono = acc(var0.getDeclaredField("chronoCd"));
            fRico = acc(var0.getDeclaredField("ricochetCd"));
            fWorld = acc(var0.getDeclaredField("worldCd"));
            fGLatch = acc(var0.getDeclaredField("guardianLatch"));
            fGCd = acc(var0.getDeclaredField("guardianCd"));
            fUltObj = acc(var0.getDeclaredField("ult"));
            mGuard = acc(var0.getDeclaredMethod("activateGuardian", ServerLevel.class, Player.class));
            mDmg = acc(var0.getDeclaredMethod("dmg", double.class));
            mHurt = acc(var0.getDeclaredMethod("hurt", LivingEntity.class, float.class));
            mActivate = acc(var0.getDeclaredMethod("activate", int.class, LivingEntity.class, boolean.class));
            mStartExtra = acc(var0.getDeclaredMethod("startExtra", int.class, LivingEntity.class, boolean.class));
            mStartHunt = acc(var0.getDeclaredMethod("startHunt", LivingEntity.class));
            mStartUlt = acc(var0.getDeclaredMethod("startUltimate"));
            mAnnounce = acc(var0.getDeclaredMethod("announce", String.class, double.class));
            Class var1 = Class.forName("com.elvencompanions.entity.ElfSkills$Cast");
            mCastTick = acc(var1.getDeclaredMethod("tick"));
            mCastFinish = acc(var1.getDeclaredMethod("finish"));
            mCastStart = acc(var1.getDeclaredMethod("start"));
            mCastVfx = acc(var0.getDeclaredMethod("castVfx", var1));
            mFxTick = acc(Class.forName("com.elvencompanions.entity.ElfFx$Tick").getDeclaredMethod("tick"));
         } catch (Throwable var2) {
            ok = false;
         }
      }
   }

   private static <T extends AccessibleObject> T acc(T var0) {
      var0.setAccessible(true);
      return (T)var0;
   }

   private static int geti(Field var0, Object var1) throws Exception {
      return (Integer)var0.get(var1);
   }

   static boolean armored(LivingEntity var0) {
      try {
         return var0 != null && var0.getArmorValue() > 0;
      } catch (Throwable var2) {
         return false;
      }
   }

   private static boolean recentlyAttacked(LivingEntity var0) {
      LivingEntity var1 = var0.getLastHurtByMob();
      return var1 != null && var1.isAlive() && var0.tickCount - var0.getLastHurtByMobTimestamp() <= 60;
   }

   private static void guardianTick(ElfEntity var0, ServerLevel var1) throws Exception {
      ElfSkills var2 = var0.skills;
      fGLatch.setBoolean(var2, true);
      if (var0.tickCount % 10 == 5) {
         if ((Boolean)ECConfig.guardianEnabled.get()) {
            if (geti(fGCd, var2) <= 0 && fUltObj.get(var2) == null && var0.isAlive() && var0.getRestState() == 0) {
               Player var3 = var0.getOwnerPlayer();
               if (var3 != null && var3.level() == var0.level() && var3.isAlive() && !var3.isSpectator()) {
                  int var4 = (Integer)ECConfig.guardianRange.get();
                  if (!(var0.distanceToSqr(var3) > (double)var4 * var4)) {
                     boolean var5 = recentlyAttacked(var3);
                     if (!var5) {
                        double var6 = ((Integer)ECConfig.guardianMobRadius.get()).intValue();
                        UUID var8 = var3.getUUID();
                        List var9 = var1.getEntitiesOfClass(
                           LivingEntity.class,
                           var3.getBoundingBox().inflate(var6),
                           var3x -> var3x != var0
                              && var3x != var3
                              && var3x.isAlive()
                              && var3x instanceof OwnableEntity var4x
                              && var8.equals(var4x.getOwnerUUID())
                              && !isDecoy(var3x)
                              && recentlyAttacked(var3x)
                        );
                        var5 = !var9.isEmpty();
                     }

                     if (var5) {
                        fGCd.setInt(var2, ECConfig.ticks(ECConfig.guardianCooldownSec));
                        mGuard.invoke(var2, var1, var3);
                     }
                  }
               }
            }
         }
      }
   }

   private static boolean isDecoy(LivingEntity var0) {
      return var0 instanceof ElfEntity var1 && isDecoy(var1);
   }

   public static void fillCooldowns(int[] var0, ElfSkills var1) {
      try {
         if (var0.length < 23) {
            return;
         }

         init();
         if (!ok) {
            return;
         }

         ElfEntity var2 = (ElfEntity)fElf.get(var1);
         ElfNew.St var3 = S.get(var2);
         if (var3 == null) {
            return;
         }

         var0[18] = (var3.cdMirror + 19) / 20;
         var0[19] = (var3.cdFalcon + 19) / 20;
         var0[20] = (var3.cdSunder + 19) / 20;
         var0[21] = (var3.cdReprisal + 19) / 20;
         var0[22] = (var3.cdStagger + 19) / 20;
      } catch (Throwable var4) {
      }
   }

   public static ElfSkills.ManualResult manualAction(ElfSkills var0, int var1, boolean var2) {
      try {
         init();
         if (ok && var1 >= 0 && var1 <= 22) {
            ElfEntity var3 = (ElfEntity)fElf.get(var0);
            if (var3.isAlive() && var3.level() instanceof ServerLevel && !var0.isUltimate()) {
               interrupt(var0);
               if (needsTarget(var1)) {
                  ensureAim(var3, (ServerLevel)var3.level());
               }
            }
         }
      } catch (Throwable var11) {
      }

      if (var1 >= 18 && var1 <= 22) {
         try {
            init();
            if (!ok) {
               return ElfSkills.ManualResult.INVALID;
            } else {
               ElfEntity var13 = (ElfEntity)fElf.get(var0);
               if (var13.isAlive() && var13.level() instanceof ServerLevel && !var0.isUltimate()) {
                  ElfNew.St var4 = st(var13);
                  double var5 = ((Integer)ECConfig.attackRange.get()).intValue();
                  LivingEntity var7 = var13.nearestHostile(var5);
                  if (var1 == 20 && !armored(var7)) {
                     LivingEntity var8 = null;

                     for (LivingEntity var10 : var13.level()
                        .getEntitiesOfClass(LivingEntity.class, var13.getBoundingBox().inflate(var5), var1x -> var13.isHostile(var1x) && armored(var1x))) {
                        if (var8 == null || var10.distanceToSqr(var13) < var8.distanceToSqr(var13)) {
                           var8 = var10;
                        }
                     }

                     var7 = var8;
                  }

                  if (var7 == null) {
                     return ElfSkills.ManualResult.NO_TARGET;
                  } else {
                     ServerLevel var14 = (ServerLevel)var13.level();
                     if (var1 == 18) {
                        if (!var2 && var4.cdMirror > 0) {
                           return ElfSkills.ManualResult.COOLDOWN;
                        } else {
                           if (var2) {
                              var4.cdMirror = 0;
                           }

                           castMirror(var13, var4, var14, var7);
                           return var4.cdMirror > 0 ? ElfSkills.ManualResult.OK : ElfSkills.ManualResult.INVALID;
                        }
                     } else {
                        if (var1 == 19) {
                           if (!var2 && var4.cdFalcon > 0) {
                              return ElfSkills.ManualResult.COOLDOWN;
                           }

                           if (!castSub(var13, 19, var7, true)) {
                              return ElfSkills.ManualResult.INVALID;
                           }

                           var4.cdFalcon = cdTicks(var13, 14);
                        } else if (var1 == 20) {
                           if (!var2 && var4.cdSunder > 0) {
                              return ElfSkills.ManualResult.COOLDOWN;
                           }

                           if (!castSub(var13, 20, var7, true)) {
                              return ElfSkills.ManualResult.INVALID;
                           }

                           var4.cdSunder = cdTicks(var13, 12);
                        } else {
                           if (var1 != 22) {
                              return ElfSkills.ManualResult.INVALID;
                           }

                           if (!var2 && var4.cdStagger > 0) {
                              return ElfSkills.ManualResult.COOLDOWN;
                           }

                           if (!castSub(var13, 22, var7, true)) {
                              return ElfSkills.ManualResult.INVALID;
                           }

                           var4.cdStagger = cdTicks(var13, 10);
                        }

                        return ElfSkills.ManualResult.OK;
                     }
                  }
               } else {
                  return ElfSkills.ManualResult.BUSY;
               }
            }
         } catch (Throwable var12) {
            return ElfSkills.ManualResult.INVALID;
         }
      } else {
         return var0.manualAction(var1, var2);
      }
   }

   private static boolean needsTarget(int var0) {
      return var0 >= 0 && var0 <= 5
         || var0 == 7
         || var0 == 10
         || var0 == 13
         || var0 == 14
         || var0 == 15
         || var0 == 18
         || var0 == 19
         || var0 == 20
         || var0 == 22;
   }

   private static void interrupt(ElfSkills var0) throws Exception {
      if (var0.hasCast()) {
         List var1 = (List)fCasts.get(var0);

         for (Object var3 : new ArrayList(var1)) {
            try {
               mCastFinish.invoke(var3);
            } catch (Throwable var5) {
            }
         }

         var1.clear();
         ((List)fPending.get(var0)).clear();
      }
   }

   private static void ensureAim(ElfEntity var0, ServerLevel var1) {
      double var2 = ((Integer)ECConfig.attackRange.get()).intValue();
      LivingEntity var4 = var0.nearestHostile(var2);
      Creeper var5 = AIMS.get(var0);
      if (var4 != null) {
         if (var4 == var5) {
            AIM_UNTIL.put(var0, new int[]{var0.tickCount + 220});
         }
      } else {
         if (var5 != null) {
            var5.discard();
         }

         Vec3 var6 = var0.getLookAngle();
         Player var7 = var0.getOwnerPlayer();
         if (var7 != null && var7.level() == var0.level()) {
            var6 = var7.getLookAngle();
         }

         var6 = new Vec3(var6.x, 0.0, var6.z);
         var6 = var6.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 0.0, 1.0) : var6.normalize();
         Creeper var8 = (Creeper)EntityType.CREEPER.create(var1);
         if (var8 != null) {
            double[] var9 = new double[]{Math.min(9.0, var2 - 2.0), 6.0, 4.0, 2.5};
            boolean var10 = false;

            for (double var14 : var9) {
               for (int var16 = 0; var16 < 2 && !var10; var16++) {
                  var8.moveTo(var0.getX() + var6.x * var14, var0.getY() + var16, var0.getZ() + var6.z * var14, var0.getYRot() + 180.0F, 0.0F);
                  if (var1.noCollision(var8) && var0.hasLineOfSight(var8)) {
                     var10 = true;
                  }
               }

               if (var10) {
                  break;
               }
            }

            if (!var10) {
               var8.moveTo(var0.getX() + var6.x * 2.5, var0.getY(), var0.getZ() + var6.z * 2.5, var0.getYRot() + 180.0F, 0.0F);
            }

            var8.addTag("ec_aim");
            var8.setNoAi(true);
            var8.setNoGravity(true);
            var8.setInvisible(true);
            var8.setInvulnerable(true);
            var8.setSilent(true);
            var8.setPersistenceRequired();
            AttributeInstance var19 = var8.getAttribute(Attributes.ARMOR);
            if (var19 != null) {
               var19.setBaseValue(6.0);
            }

            if (var1.addFreshEntity(var8)) {
               AIMS.put(var0, var8);
               AIM_UNTIL.put(var0, new int[]{var0.tickCount + 220});
            }
         }
      }
   }

   private static void tickAim(ElfEntity var0) {
      Creeper var1 = AIMS.get(var0);
      if (var1 != null) {
         int[] var2 = AIM_UNTIL.get(var0);
         if (var1.isRemoved() || var2 == null || var0.tickCount >= var2[0] || !var0.isAlive()) {
            if (!var1.isRemoved()) {
               var1.discard();
            }

            AIMS.remove(var0);
            AIM_UNTIL.remove(var0);
         }
      }
   }

   public static int[] cdExtend(int[] var0, ElfSkills var1) {
      try {
         init();
         ElfEntity var2 = (ElfEntity)fElf.get(var1);
         ElfNew.St var3 = S.get(var2);
         int[] var4 = Arrays.copyOf(var0, 23);
         if (var3 != null) {
            var4[18] = (var3.cdMirror + 19) / 20;
            var4[19] = (var3.cdFalcon + 19) / 20;
            var4[20] = (var3.cdSunder + 19) / 20;
            var4[21] = (var3.cdReprisal + 19) / 20;
            var4[22] = (var3.cdStagger + 19) / 20;
         }

         return var4;
      } catch (Throwable var5) {
         return var0;
      }
   }

   static boolean isDecoy(ElfEntity var0) {
      try {
         return var0.getTags().contains("ec_mirror");
      } catch (Throwable var2) {
         return false;
      }
   }

   public static boolean guard(ElfEntity var0) {
      try {
         if (!isDecoy(var0)) {
            return false;
         } else {
            if (!LIVE.contains(var0) && !var0.level().isClientSide) {
               var0.discard();
            }

            return true;
         }
      } catch (Throwable var2) {
         return false;
      }
   }

   public static void onJoin(ElfEntity var0) {
      try {
         if (isDecoy(var0) && !LIVE.contains(var0)) {
            var0.discard();
         }

         if (var0.level() instanceof ServerLevel var1 && !isDecoy(var0)) {
            for (LivingEntity var3 : var1.getEntitiesOfClass(
               LivingEntity.class, var0.getBoundingBox().inflate(48.0), var0x -> var0x.getTags().contains("ec_aim")
            )) {
               if (!AIMS.containsValue(var3)) {
                  var3.discard();
               }
            }
         }
      } catch (Throwable var4) {
      }
   }

   private static double prog(int var0) {
      return (Math.max(1, Math.min(50, var0)) - 1) / 49.0;
   }

   private static double lerp(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * var4;
   }

   private static int cdTicks(ElfEntity var0, int var1) {
      return (int)Math.round(var1 * 20 * ElfLevel.cooldownFactor(var0.getElfLevel()));
   }

   private static float dmg(ElfEntity var0, double var1) {
      try {
         init();
         return (Float)mDmg.invoke(var0.skills, var1);
      } catch (Throwable var4) {
         return (float)(var1 * ElfLevel.skillDamage(var0.getElfLevel()));
      }
   }

   private static void hurt(ElfEntity var0, LivingEntity var1, float var2) {
      try {
         init();
         mHurt.invoke(var0.skills, var1, var2);
      } catch (Throwable var4) {
         var1.hurt(var0.damageSources().mobProjectile(var0, var0), var2);
      }
   }

   private static Vec3 feet(LivingEntity var0) {
      return new Vec3(var0.getX(), var0.getY(), var0.getZ());
   }

   private static Vec3 size(LivingEntity var0) {
      return new Vec3(var0.getBbHeight(), var0.getBbWidth(), 0.0);
   }

   private static Vec3 center(LivingEntity var0) {
      return new Vec3(var0.getX(), var0.getY() + var0.getBbHeight() * 0.55, var0.getZ());
   }

   private static void announce(ElfEntity var0, String var1) {
      try {
         init();
         mAnnounce.invoke(var0.skills, var1, 32.0);
      } catch (Throwable var3) {
      }
   }

   private static void face(ElfEntity var0, LivingEntity var1) {
      double var2 = var1.getX() - var0.getX();
      double var4 = var1.getZ() - var0.getZ();
      float var6 = (float)(Math.toDegrees(Math.atan2(var4, var2)) - 90.0);
      var0.setYRot(var6);
      var0.yBodyRot = var6;
      var0.yHeadRot = var6;
   }

   private static void snd(ElfEntity var0, float var1) {
      try {
         var0.level().playSound(null, var0.getX(), var0.getY(), var0.getZ(), (SoundEvent)ModRegistry.SND_SKILL.get(), SoundSource.NEUTRAL, 0.55F, var1);
      } catch (Throwable var3) {
      }
   }

   public static void tick(ElfEntity var0) {
      ElfNew.St var1 = st(var0);
      if (!var1.broken) {
         try {
            init();
            if (!ok || !(var0.level() instanceof ServerLevel)) {
               return;
            }

            ServerLevel var2 = (ServerLevel)var0.level();
            if (isDecoy(var0)) {
               return;
            }

            guardianTick(var0, var2);
            tickAim(var0);
            tickBreaks(var0);
            tickRhythm(var0, var1, var2);
            tickProjs(var2, var1);
            tickDecoys(var0, var1, var2);
            tickReprisal(var0, var1, var2);
            if (var1.cdMirror > 0) {
               var1.cdMirror--;
            }

            if (var1.cdFalcon > 0) {
               var1.cdFalcon--;
            }

            if (var1.cdSunder > 0) {
               var1.cdSunder--;
            }

            if (var1.cdStagger > 0) {
               var1.cdStagger--;
            }

            if (var1.cdReprisal > 0) {
               var1.cdReprisal--;
            }

            if (var0.tickCount % 10 == 3) {
               autoCast(var0, var1, var2);
            }
         } catch (Throwable var3) {
            var1.broken = true;
         }
      }
   }

   private static boolean calm(ElfEntity var0) {
      return var0.isAlive()
         && !var0.skills.hasCast()
         && !var0.skills.isUltimate()
         && !var0.isMounted()
         && var0.getRestState() == 0
         && !var0.defense.isDrinking()
         && !var0.defense.isEscaping()
         && var0.canFight();
   }

   private static LivingEntity pickTarget(ElfEntity var0) {
      if (var0.getCombat() != 1 && var0.canFight()) {
         LivingEntity var1 = var0.getTarget();
         return var1 != null && var1.isAlive() && var0.isHostile(var1) && var0.distanceToSqr(var1) < 784.0 ? var1 : null;
      } else {
         return null;
      }
   }

   private static LivingEntity nearTarget(ElfEntity var0) {
      LivingEntity var1 = pickTarget(var0);
      return var1 != null ? var1 : var0.nearestHostile(24.0);
   }

   private static void autoCast(ElfEntity var0, ElfNew.St var1, ServerLevel var2) {
      if (calm(var0)) {
         LivingEntity var3 = pickTarget(var0);
         if (var3 != null && var0.getSensing().hasLineOfSight(var3)) {
            double var4 = ElfLevel.chanceMult(var0.getElfLevel());
            double var6 = var0.getRandom().nextDouble();
            if (var1.cdMirror <= 0 && var6 < 0.07 * var4) {
               castMirror(var0, var1, var2, var3);
            } else {
               var6 = var0.getRandom().nextDouble();
               if (var1.cdFalcon <= 0 && var6 < 0.1 * var4) {
                  var1.cdFalcon = cdTicks(var0, 14);
                  castSub(var0, 19, var3, true);
               } else {
                  var6 = var0.getRandom().nextDouble();
                  if (var1.cdSunder <= 0 && armored(var3) && var6 < 0.1 * var4) {
                     var1.cdSunder = cdTicks(var0, 12);
                     castSub(var0, 20, var3, true);
                  } else {
                     var6 = var0.getRandom().nextDouble();
                     if (var1.cdStagger <= 0 && var6 < 0.1 * var4) {
                        var1.cdStagger = cdTicks(var0, 10);
                        castSub(var0, 22, var3, true);
                     }
                  }
               }
            }
         }
      }
   }

   private static double rhythmF(ElfEntity var0) {
      ElfNew.St var1 = S.get(var0);
      if (var1 == null) {
         return 0.0;
      } else if (var1.fixedF >= 0.0) {
         return var1.fixedF;
      } else if (var1.rhExhausted) {
         return 0.0;
      } else if (var1.rhT <= 0) {
         return 0.0;
      } else {
         return var1.rhT < 20 ? 0.12 : Math.min(1.0, 0.12 + 0.88 * ((var1.rhT - 20) / 180.0));
      }
   }

   private static void tickRhythm(ElfEntity var0, ElfNew.St var1, ServerLevel var2) {
      boolean var3 = var0.isAlive() && (var0.skills.hasCast() || var0.getTarget() != null && var0.getTarget().isAlive() || var0.isAggressive());
      if (var3) {
         var1.rhOut = 0;
      } else if (var1.rhOut++ > 60 && !var1.rhExhausted) {
         var1.rhT = 0;
      }

      if (var1.rhExhausted) {
         if (--var1.rhEx <= 0) {
            var1.rhExhausted = false;
            var1.rhT = 0;
         }
      } else if (var3 && ++var1.rhT >= 200) {
         var1.rhExhausted = true;
         var1.rhEx = 100;
         var1.rhT = 0;
      }

      double var4 = rhythmF(var0);
      if (var4 > 0.0 && ++var1.fxTick >= 8) {
         var1.fxTick = 0;
         ElfVfx.send(var2, 35, var0, ElfFx.handPos(var0), 10, (float)(0.05 + var4));
      }
   }

   public static double dmgMul(ElfEntity var0) {
      try {
         double var1 = 1.0 + 0.35 * rhythmF(var0);
         if (isDecoy(var0)) {
            var1 *= st(var0).dmgScale;
         }

         return var1;
      } catch (Throwable var3) {
         return 1.0;
      }
   }

   public static float scaleDmg(float var0, ElfSkills var1) {
      try {
         init();
         return !ok ? var0 : (float)(var0 * dmgMul((ElfEntity)fElf.get(var1)));
      } catch (Throwable var3) {
         return var0;
      }
   }

   public static double scaleMult(double var0, ElfEntity var2) {
      return var0 * dmgMul(var2);
   }

   public static int scaleInterval(int var0, ElfEntity var1) {
      try {
         double var2 = rhythmF(var1);
         return var2 <= 0.0 ? var0 : Math.max(2, (int)Math.round(var0 / (1.0 + 0.5 * var2)));
      } catch (Throwable var4) {
         return var0;
      }
   }

   private static void tickProjs(ServerLevel var0, ElfNew.St var1) {
      if (!var1.projs.isEmpty()) {
         Iterator var2 = var1.projs.iterator();

         while (var2.hasNext()) {
            boolean var3;
            try {
               var3 = ((ElfNew.Proj)var2.next()).tick(var0);
            } catch (Throwable var5) {
               var3 = true;
            }

            if (var3) {
               var2.remove();
            }
         }
      }
   }

   private static LivingEntity firstHit(ServerLevel var0, ElfEntity var1, Vec3 var2, Vec3 var3, double var4, Set<LivingEntity> var6) {
      AABB var7 = new AABB(
         Math.min(var2.x, var3.x) - 1.0,
         Math.min(var2.y, var3.y) - 1.0,
         Math.min(var2.z, var3.z) - 1.0,
         Math.max(var2.x, var3.x) + 1.0,
         Math.max(var2.y, var3.y) + 1.0,
         Math.max(var2.z, var3.z) + 1.0
      );
      List var8 = var0.getEntitiesOfClass(
         LivingEntity.class, var7, var2x -> var2x.isAlive() && var1.isHostile(var2x) && (var6 == null || !var6.contains(var2x))
      );
      LivingEntity var9 = null;
      double var10 = 1.0E18;

      for (LivingEntity var13 : var8) {
         AABB var14 = var13.getBoundingBox();
         double var15 = segBox(var2, var3, var14.minX - var4, var14.minY - var4, var14.minZ - var4, var14.maxX + var4, var14.maxY + var4, var14.maxZ + var4);
         if (var15 >= 0.0 && var15 < var10) {
            var10 = var15;
            var9 = var13;
         }
      }

      return var9;
   }

   private static double segBox(Vec3 var0, Vec3 var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      double var14 = var1.x - var0.x;
      double var16 = var1.y - var0.y;
      double var18 = var1.z - var0.z;
      double var20 = 0.0;
      double var22 = 1.0;
      double[] var24 = new double[]{var0.x, var0.y, var0.z};
      double[] var25 = new double[]{var14, var16, var18};
      double[] var26 = new double[]{var2, var4, var6};
      double[] var27 = new double[]{var8, var10, var12};

      for (int var28 = 0; var28 < 3; var28++) {
         if (Math.abs(var25[var28]) < 1.0E-9) {
            if (var24[var28] < var26[var28] || var24[var28] > var27[var28]) {
               return -1.0;
            }
         } else {
            double var29 = (var26[var28] - var24[var28]) / var25[var28];
            double var31 = (var27[var28] - var24[var28]) / var25[var28];
            if (var29 > var31) {
               double var33 = var29;
               var29 = var31;
               var31 = var33;
            }

            var20 = Math.max(var20, var29);
            var22 = Math.min(var22, var31);
            if (var20 > var22) {
               return -1.0;
            }
         }
      }

      return var20;
   }

   private static void applyBreak(LivingEntity var0, double var1) {
      int[] var3 = BREAKS.get(var0);
      if (var3 == null) {
         var3 = new int[]{0, 0};
         BREAKS.put(var0, var3);
      }

      if (var3[0] < 3) {
         var3[0]++;
      }

      double var4 = Math.min(1.0, var1 * (1.0 + 0.3 * (var3[0] - 1)));
      var3[1] = var0.tickCount + 160;
      setBreak(var0, var4);
   }

   private static void setBreak(LivingEntity var0, double var1) {
      AttributeInstance var3 = var0.getAttribute(Attributes.ARMOR);
      if (var3 != null) {
         var3.removeModifier(BREAK_ID);
         if (var1 > 0.0) {
            var3.addTransientModifier(new AttributeModifier(BREAK_ID, -var1, Operation.ADD_MULTIPLIED_TOTAL));
         }
      }

      AttributeInstance var4 = var0.getAttribute(Attributes.ARMOR_TOUGHNESS);
      if (var4 != null) {
         var4.removeModifier(BREAK_T_ID);
         if (var1 > 0.0) {
            var4.addTransientModifier(new AttributeModifier(BREAK_T_ID, -var1, Operation.ADD_MULTIPLIED_TOTAL));
         }
      }
   }

   private static void tickBreaks(ElfEntity var0) {
      if (!BREAKS.isEmpty() && var0.tickCount % 10 == 0) {
         Iterator var1 = BREAKS.entrySet().iterator();

         while (var1.hasNext()) {
            Entry var2 = (Entry)var1.next();
            LivingEntity var3 = (LivingEntity)var2.getKey();
            if (var3 == null || !var3.isAlive() || var3.tickCount >= ((int[])var2.getValue())[1]) {
               if (var3 != null) {
                  setBreak(var3, 0.0);
               }

               var1.remove();
            }
         }
      }
   }

   static boolean castSub(ElfEntity var0, int var1, LivingEntity var2, boolean var3) {
      try {
         init();
         if (ok && var2 != null && var2.isAlive() && var0.level() instanceof ServerLevel) {
            ServerLevel var4 = (ServerLevel)var0.level();
            if (var1 == 20 && !armored(var2)) {
               return false;
            } else {
               if (var3) {
                  onElfCast(var0, var1);
               }

               ElfNew.St var5 = st(var0);
               face(var0, var2);

               try {
                  var0.swing(InteractionHand.MAIN_HAND);
               } catch (Throwable var14) {
               }

               Vec3 var6 = ElfFx.handPos(var0);
               int var7 = var0.getElfLevel();
               boolean var8 = var0.isTranscended();
               double var9 = prog(var7);
               Vec3 var11 = center(var2);
               if (var1 == 19) {
                  int var12 = var8 ? 10 : (int)Math.round(lerp(2.0, 6.0, var9));
                  var5.projs.add(new ElfNew.Falcon(var0, var6, var11, var12));
                  ElfVfx.send(var4, 31, -1, var6, var11, FalconPath.total(var12) + 8, var12);
                  if (var3) {
                     announce(var0, "falcons_return");
                  }
               } else if (var1 == 20) {
                  double var16 = 2.6;
                  fireBolt(var4, var0, 20, var2, var6, var16, 0.25, 1);
                  if (var3) {
                     announce(var0, "sundering_arrow");
                  }
               } else if (var1 == 22) {
                  fireBolt(var4, var0, 22, var2, var6, 2.8, 0.45, 2);
                  if (var3) {
                     announce(var0, "staggerpoint_shot");
                  }
               } else {
                  if (var1 != 21) {
                     return false;
                  }

                  double var17 = var8 ? lerp(1.6, 3.2, 1.0) * 2.0 : lerp(1.6, 3.2, var9);
                  fireBolt(var4, var0, 21, var2, var6, var17, 0.5, 3);
                  if (var3) {
                     announce(var0, "reprisal_shot");
                  }
               }

               snd(var0, 1.3F);
               return true;
            }
         } else {
            return false;
         }
      } catch (Throwable var15) {
         return false;
      }
   }

   private static void fireBolt(ServerLevel var0, ElfEntity var1, int var2, LivingEntity var3, Vec3 var4, double var5, double var7, int var9) {
      ElfNew.Bolt var10 = new ElfNew.Bolt(var1, var2, var3, var4, var5, var7, 40);
      st(var1).projs.add(var10);
      Vec3 var11 = center(var3);
      double var12 = Math.max(1.0, var11.subtract(var4).length());
      int var14 = Math.max(3, (int)Math.ceil(var12 / var5) + 2);
      ElfVfx.send(var0, 32, -1, var4, var11, var14, var9);
   }

   public static void onDodge(ElfEntity var0, LivingEntity var1) {
      try {
         if (isDecoy(var0) || var1 == null || !(var0.level() instanceof ServerLevel)) {
            return;
         }

         init();
         if (!ok) {
            return;
         }

         ElfNew.St var2 = st(var0);
         if (var2.broken) {
            return;
         }

         if (var2.cdReprisal > 0) {
            return;
         }

         if (!var0.canFight() || pickTarget(var0) == null) {
            return;
         }

         var2.cdReprisal = cdTicks(var0, 8);
         int var3 = var0.getElfLevel();
         boolean var4 = var0.isTranscended();
         double var5 = prog(var3);
         int var7 = (int)Math.round(lerp(8.0, 2.0, var5));
         if (var4) {
            var7 = 1;
         }

         var2.repDelay = var7;
         var2.repTarget = var1;
         ServerLevel var8 = (ServerLevel)var0.level();
         Vec3 var9 = var0.getDeltaMovement();
         double var10 = var4 ? 9.0 : 5.0;
         Vec3 var12 = new Vec3(var9.x, 0.0, var9.z);
         Vec3 var13 = var12.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 0.0) : var12.normalize();
         Vec3 var14 = var0.position();
         Vec3 var15 = new Vec3(var14.x + var13.x * var10, var14.y, var14.z + var13.z * var10);
         ElfVfx.send(var8, 38, var0.getId(), var14, var15, var4 ? 22 : 14, var4 ? 2.0F : 1.0F);
         if (var4) {
            var2.glide = 18;
            var2.glideVel = var12;
            var2.glideFlying = true;
         }

         if (var2.standby > 0 && var2.standbyDecoys != null) {
            for (ElfEntity var17 : var2.standbyDecoys) {
               if (var17 != null && !var17.isRemoved() && var1.isAlive()) {
                  ElfNew.Decoy var19 = new ElfNew.Decoy();
                  var19.e = var17;
                  var19.idx = 21;
                  var19.target = var1;
                  var19.delay = var7 + 1 + var2.decoys.size() % 5;
                  var2.decoys.add(var19);
               }
            }

            var2.standbyDecoys = null;
            var2.standby = 0;
         }
      } catch (Throwable var20) {
      }
   }

   private static void tickReprisal(ElfEntity var0, ElfNew.St var1, ServerLevel var2) {
      if (var1.glide > 0) {
         var1.glide--;
         Vec3 var3 = var0.getDeltaMovement();
         double var4 = 0.55 + 0.45 * (var1.glide / 18.0);
         double var6 = var0.onGround() ? var3.y : Math.max(var3.y, -0.02);
         if (var1.glideVel != null) {
            var0.setDeltaMovement(var1.glideVel.x * var4, var6, var1.glideVel.z * var4);
         }

         var0.fallDistance = 0.0F;
         var0.hasImpulse = true;
      }

      if (var1.repDelay >= 0 && --var1.repDelay < 0) {
         LivingEntity var8 = var1.repTarget;
         var1.repTarget = null;
         if (var8 != null && var8.isAlive() && var0.isAlive()) {
            castSub(var0, 21, var8, true);
         }
      }

      if (var1.standby > 0) {
         var1.standby--;
      }
   }

   private static boolean ready(int var0) {
      return var0 <= 0;
   }

   private static int pickSkill(ElfEntity var0, ElfNew.St var1, LivingEntity var2) throws Exception {
      int var3 = var0.getElfLevel();
      int[] var4 = (int[])fCd.get(var0.skills);
      ArrayList var5 = new ArrayList();

      for (int var6 = 0; var6 < 6; var6++) {
         if (ready(var4[var6])) {
            var5.add(new int[]{var6, 10});
         }
      }

      if (var3 >= 12 && ready(geti(fChrono, var0.skills))) {
         var5.add(new int[]{13, 8});
      }

      if (var3 >= 6 && ready(geti(fRico, var0.skills))) {
         var5.add(new int[]{14, 8});
      }

      if (var0.isTranscended() && ready(geti(fWorld, var0.skills))) {
         var5.add(new int[]{15, 7});
      }

      if (var3 >= (Integer)ECConfig.huntMinLevel.get() && ready(geti(fHunt, var0.skills))) {
         var5.add(new int[]{7, 6});
      }

      if (ready(geti(fAnnih, var0.skills))) {
         var5.add(new int[]{10, 3});
      }

      if (ready(geti(fUlt, var0.skills)) && var0.getHealth() < var0.getMaxHealth() * 0.6F) {
         var5.add(new int[]{6, 3});
      }

      if (ready(var1.cdFalcon)) {
         var5.add(new int[]{19, 8});
      }

      if (ready(var1.cdSunder) && armored(var2)) {
         var5.add(new int[]{20, 8});
      }

      if (ready(var1.cdStagger)) {
         var5.add(new int[]{22, 8});
      }

      if (ready(var1.cdReprisal)) {
         var5.add(new int[]{21, 4});
      }

      if (var5.isEmpty()) {
         return -1;
      } else {
         int var10 = 0;

         for (int[] var8 : var5) {
            var10 += var8[1];
         }

         int var11 = var0.getRandom().nextInt(var10);

         for (int[] var9 : var5) {
            var11 -= var9[1];
            if (var11 < 0) {
               return var9[0];
            }
         }

         return ((int[])var5.get(0))[0];
      }
   }

   private static boolean startOn(ElfEntity var0, int var1, LivingEntity var2, boolean var3) throws Exception {
      return startOn(var0, var1, var2, var3, null);
   }

   private static boolean startOn(ElfEntity var0, int var1, LivingEntity var2, boolean var3, Vec3 var4) throws Exception {
      ElfSkills var5 = var0.skills;
      if (var1 >= 0 && var1 < 6) {
         return (Boolean)mActivate.invoke(var5, var1, var2, var3);
      } else if (var1 == 13 || var1 == 14 || var1 == 15) {
         return (Boolean)mStartExtra.invoke(var5, var1, var2, var3);
      } else if (var1 == 7) {
         mStartHunt.invoke(var5, var2);
         return true;
      } else if (var1 == 10) {
         return var5.startAnnihilation(var4 != null ? var4 : var2.position());
      } else if (var1 == 6) {
         mStartUlt.invoke(var5);
         return true;
      } else {
         return var1 >= 19 && var1 <= 22 ? castSub(var0, var1, var2, false) : false;
      }
   }

   private static void castMirror(ElfEntity var0, ElfNew.St var1, ServerLevel var2, LivingEntity var3) {
      try {
         int var4 = pickSkill(var0, var1, var3);
         if (var4 < 0) {
            return;
         }

         inMirror = true;

         boolean var5;
         try {
            if (var4 == 21) {
               var5 = true;
            } else if (var4 >= 19) {
               int var6 = var4 == 19 ? 14 : (var4 == 20 ? 12 : 10);
               var5 = castSub(var0, var4, var3, true);
               if (var5) {
                  if (var4 == 19) {
                     var1.cdFalcon = cdTicks(var0, var6);
                  } else if (var4 == 20) {
                     var1.cdSunder = cdTicks(var0, var6);
                  } else {
                     var1.cdStagger = cdTicks(var0, var6);
                  }
               }
            } else {
               var5 = startOn(var0, var4, var3, false);
            }
         } finally {
            inMirror = false;
         }

         if (!var5) {
            return;
         }

         summon(var0, var1, var2, var3, var4, null);
      } catch (Throwable var11) {
         var1.broken = true;
      }
   }

   private static void summon(ElfEntity var0, ElfNew.St var1, ServerLevel var2, LivingEntity var3, int var4, Vec3 var5) {
      var1.cdMirror = cdTicks(var0, 75);
      var1.mirrorIdx = var4 != 21 && !once(var4) ? var4 : -1;
      var1.mirrorEnd = var0.tickCount + mirrorWindow(var0.getElfLevel(), var0.isTranscended()) + 30;
      announce(var0, "mirrorleaf_decoy");
      int var6 = copies(var0.getElfLevel(), var0.isTranscended());
      double var7 = rhythmF(var0);
      ArrayList var9 = new ArrayList();

      for (int var10 = 0; var10 < var6; var10++) {
         ElfEntity var11 = spawnDecoy(var0, var2, var10, var6, var3, var7);
         if (var11 != null) {
            var9.add(var11);
            if (var4 != 21) {
               ElfNew.Decoy var12 = new ElfNew.Decoy();
               var12.e = var11;
               var12.idx = var4;
               var12.target = var3;
               var12.impact = var5;
               var12.delay = 6 + var10 * 4;
               var1.decoys.add(var12);
            }
         }
      }

      if (var4 == 21) {
         var1.standby = 140;
         var1.standbyDecoys = var9;

         for (ElfEntity var14 : var9) {
            ElfNew.Decoy var15 = new ElfNew.Decoy();
            var15.e = var14;
            var15.idx = -1;
            var15.delay = 140;
            var1.decoys.add(var15);
         }
      }

      snd(var0, 1.6F);
   }

   public static double nearScale(ElfSkills var0, Object var1) {
      try {
         if (var1 instanceof ModNetwork.CinematicS2C || var1 instanceof ModNetwork.SilenceS2C || var1 instanceof ModNetwork.ImpactS2C) {
            init();
            if (ok && isDecoy((ElfEntity)fElf.get(var0))) {
               return 0.0;
            }
         }
      } catch (Throwable var3) {
      }

      return 1.0;
   }

   public static void onUlt(ElfSkills var0) {
      follow(var0, 6, null, null);
   }

   public static void onAnnih(ElfSkills var0, Vec3 var1) {
      follow(var0, 10, null, var1);
   }

   public static void onHunt(ElfSkills var0, LivingEntity var1) {
      follow(var0, 7, var1, null);
   }

   public static void onExtra(ElfSkills var0, int var1, LivingEntity var2) {
      follow(var0, var1, var2, null);
   }

   private static void follow(ElfSkills var0, int var1, LivingEntity var2, Vec3 var3) {
      try {
         if (inMirror || !copyable(var1)) {
            return;
         }

         init();
         if (!ok) {
            return;
         }

         ElfEntity var4 = (ElfEntity)fElf.get(var0);
         if (isDecoy(var4) || !(var4.level() instanceof ServerLevel)) {
            return;
         }

         ElfNew.St var5 = st(var4);
         if (var5.broken) {
            return;
         }

         ServerLevel var6 = (ServerLevel)var4.level();
         if (var2 == null) {
            var2 = pickTarget(var4);
         }

         if (var2 == null) {
            var2 = nearTarget(var4);
         }

         boolean var7 = false;
         int var8 = 0;

         for (ElfNew.Decoy var10 : var5.decoys) {
            if (var10.e != null && !var10.e.isRemoved() && var10.idx >= 0 && var10.idx != 21) {
               var10.idx = var1;
               var10.started = false;
               var10.delay = 6 + var8 * 4;
               var10.target = var2;
               var10.impact = var3;
               var10.casts = 0;
               var10.quiet = 0;
               var8++;
               var7 = true;
            }
         }

         if (var7) {
            var5.mirrorIdx = once(var1) ? -1 : var1;
            var5.mirrorEnd = Math.max(var5.mirrorEnd, var4.tickCount + mirrorWindow(var4.getElfLevel(), var4.isTranscended()) + 30);
         } else if (once(var1) && var2 != null && var5.cdMirror <= 0 && var4.getRandom().nextDouble() < 0.65) {
            summon(var4, var5, var6, var2, var1, var3);
         }
      } catch (Throwable var11) {
      }
   }

   private static ElfEntity spawnDecoy(ElfEntity var0, ServerLevel var1, int var2, int var3, LivingEntity var4, double var5) {
      try {
         ElfEntity var7 = (ElfEntity)var0.getType().create(var1);
         if (var7 == null) {
            return null;
         } else {
            double var8 = Math.atan2(var4.getZ() - var0.getZ(), var4.getX() - var0.getX());
            double var10 = var8 + (Math.PI / 2) + Math.PI * (var2 + 0.5) / var3 * (var2 % 2 == 0 ? 1 : -1) * 0.9 + var2 / 2 * 0.35;
            double var12 = 2.2 + var2 % 3 * 0.9 + (var3 > 6 ? 1.0 : 0.0);
            double var14 = var0.getX() + Math.cos(var10) * var12;
            double var16 = var0.getZ() + Math.sin(var10) * var12;
            double var18 = var0.getY();
            var7.moveTo(var14, var18, var16, var0.getYRot(), 0.0F);
            if (!var1.noCollision(var7)) {
               var7.moveTo(var0.getX() + Math.cos(var10) * 1.2, var18, var0.getZ() + Math.sin(var10) * 1.2, var0.getYRot(), 0.0F);
            }

            var7.addTag("ec_mirror");
            LIVE.add(var7);
            var7.setNoAi(true);
            var7.setInvulnerable(true);
            var7.setSilent(true);
            var7.setSkin(var0.getSkin());
            var7.setLevelQuiet(var0.getElfLevel());
            var7.setTranscended(var0.isTranscended());

            for (EquipmentSlot var23 : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
               var7.setItemSlot(var23, var0.getItemBySlot(var23).copy());
            }

            var7.setItemSlot(EquipmentSlot.MAINHAND, var7.bowStack());
            ElfNew.St var25 = st(var7);
            var25.fixedF = var5;
            var25.cdMirror = 1073741823;
            init();
            int[] var26 = (int[])fCd.get(var7.skills);

            for (int var27 = 0; var27 < var26.length; var27++) {
               var26[var27] = 268435456;
            }

            fUlt.setInt(var7.skills, 268435456);
            fHunt.setInt(var7.skills, 268435456);
            fAnnih.setInt(var7.skills, 268435456);
            fChrono.setInt(var7.skills, 268435456);
            fRico.setInt(var7.skills, 268435456);
            fWorld.setInt(var7.skills, 268435456);
            if (!var1.addFreshEntity(var7)) {
               LIVE.remove(var7);
               return null;
            } else {
               face(var7, var4);
               ElfVfx.send(var1, 36, var7.getId(), var7.position(), null, 600, 1.0F);
               return var7;
            }
         }
      } catch (Throwable var24) {
         return null;
      }
   }

   private static void tickDecoys(ElfEntity var0, ElfNew.St var1, ServerLevel var2) {
      if (!var1.decoys.isEmpty()) {
         Iterator var3 = var1.decoys.iterator();

         while (var3.hasNext()) {
            ElfNew.Decoy var4 = (ElfNew.Decoy)var3.next();
            ElfEntity var5 = var4.e;
            if (var5 != null && !var5.isRemoved()) {
               var4.age++;

               try {
                  ElfNew.St var6 = st(var5);
                  if (var4.target != null && var4.target.isAlive() && var4.idx != -1 || var4.started) {
                     face(var5, (LivingEntity)(var4.target != null ? var4.target : var0));
                  }

                  if (!var4.started) {
                     if (var5.skills.hasCast()) {
                        runCasts(var5, var2);
                        tickProjs(var2, var6);
                     }

                     if (var4.idx < 0 || --var4.delay > 0 || !var5.skills.hasCast() && !var5.skills.isUltimate()) {
                        if (var4.idx >= 0 && var4.delay <= 0) {
                           var4.started = true;
                           var4.casts = 1;
                           var6.dmgScale = once(var4.idx) ? 0.5 : 1.0;
                           var4.endAge = var4.age + mirrorWindow(var0.getElfLevel(), var0.isTranscended());
                           if ((var4.target == null || !var4.target.isAlive()) && var4.idx != 6 && (var4.idx != 10 || var4.impact == null)) {
                              vanish(var5, var2, var3);
                              continue;
                           }

                           ElfVfx.send(var2, 35, var5, ElfFx.handPos(var5), 12, (float)(0.05 + Math.max(0.0, var6.fixedF)));
                           if (!startOn(var5, var4.idx, var4.target, true, var4.impact)) {
                              vanish(var5, var2, var3);
                              continue;
                           }
                        } else if (var4.idx < 0 && --var4.delay <= 0) {
                           vanish(var5, var2, var3);
                           continue;
                        }
                     } else {
                        var4.delay = 1;
                     }
                  } else {
                     runCasts(var5, var2);
                     tickProjs(var2, var6);
                     boolean var7 = var5.skills.hasCast() || !var6.projs.isEmpty();
                     if (var7) {
                        var4.quiet = 0;
                     } else {
                        var4.quiet++;
                        if (var4.quiet >= 3 && tryRepeat(var0, var1, var4, var5, var2)) {
                           var4.quiet = 0;
                        } else if (var4.quiet > 6) {
                           vanish(var5, var2, var3);
                           continue;
                        }
                     }
                  }

                  if (var4.age > 2400) {
                     vanish(var5, var2, var3);
                  }
               } catch (Throwable var8) {
                  vanish(var5, var2, var3);
               }
            } else {
               var3.remove();
            }
         }
      }
   }

   private static boolean tryRepeat(ElfEntity var0, ElfNew.St var1, ElfNew.Decoy var2, ElfEntity var3, ServerLevel var4) throws Exception {
      if (var2.idx >= 0 && var2.age < var2.endAge - 3 && var2.casts < 6) {
         int var5 = var1.mirrorIdx;
         if (var5 >= 0 && !once(var5)) {
            if (var2.target == null || !var2.target.isAlive()) {
               var2.target = nearTarget(var0);
               if (var2.target == null) {
                  return false;
               }
            }

            if (!startOn(var3, var5, var2.target, true)) {
               return false;
            } else {
               var2.casts++;
               var2.idx = var5;
               ElfVfx.send(var4, 35, var3, ElfFx.handPos(var3), 12, (float)(0.05 + Math.max(0.0, st(var3).fixedF)));
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static void onElfCast(ElfEntity var0, int var1) {
      try {
         if (isDecoy(var0)) {
            return;
         }

         ElfNew.St var2 = S.get(var0);
         if (var2 != null && var0.tickCount < var2.mirrorEnd && !once(var1)) {
            var2.mirrorIdx = var1;
         }
      } catch (Throwable var3) {
      }
   }

   private static void vanish(ElfEntity var0, ServerLevel var1, Iterator<ElfNew.Decoy> var2) {
      ElfVfx.send(var1, 37, var0.getId(), var0.position(), null, 24, 1.0F);
      LIVE.remove(var0);
      var0.discard();
      S.remove(var0);
      var2.remove();
   }

   private static void runCasts(ElfEntity var0, ServerLevel var1) throws Exception {
      ElfSkills var2 = var0.skills;
      List var3 = (List)fCasts.get(var2);
      Set var4 = (Set)fVfxSeen.get(var2);
      var4.retainAll(var3);

      for (Object var6 : new ArrayList(var3)) {
         if (var4.add(var6)) {
            mCastVfx.invoke(var2, var6);
         }
      }

      Iterator var12 = var3.iterator();

      while (var12.hasNext()) {
         Object var14 = var12.next();

         boolean var7;
         try {
            var7 = (Boolean)mCastTick.invoke(var14);
         } catch (Throwable var11) {
            var7 = true;
         }

         if (var7) {
            try {
               mCastFinish.invoke(var14);
            } catch (Throwable var10) {
            }

            var12.remove();
         }
      }

      List var13 = (List)fPending.get(var2);
      if (!var13.isEmpty()) {
         ArrayList var15 = new ArrayList(var13);
         var13.clear();

         for (Object var8 : var15) {
            var3.add(var8);
            mCastStart.invoke(var8);
         }
      }

      List var16 = (List)fFx.get(var2);
      if (!var16.isEmpty()) {
         var16.removeIf(var0x -> {
            try {
               return (Boolean)mFxTick.invoke(var0x);
            } catch (Throwable var2x) {
               return true;
            }
         });
      }

      int var18 = var2.currentAnim();
      if (var18 != var0.getAnim()) {
         try {
            setAnim(var0, var18);
         } catch (Throwable var9) {
         }
      }
   }

   private static void setAnim(ElfEntity var0, int var1) throws Exception {
      if (fAnimAcc == null) {
         fAnimAcc = acc(ElfEntity.class.getDeclaredField("DATA_ANIM"));
         fEntityData = acc(Entity.class.getDeclaredField("entityData"));
         mSet = acc(fEntityData.getType().getMethod("set", Class.forName("net.minecraft.network.syncher.EntityDataAccessor"), Object.class));
      }

      mSet.invoke(fEntityData.get(var0), fAnimAcc.get(null), var1);
   }

   private static final class Bolt extends ElfNew.Proj {
      final ElfEntity shooter;
      final LivingEntity target;
      final int kind;
      final int maxT;
      final double speed;
      Vec3 pos;
      Vec3 dir;
      int t;
      final float dmg;
      final int lv;
      final boolean transc;
      final double homing;

      Bolt(ElfEntity var1, int var2, LivingEntity var3, Vec3 var4, double var5, double var7, int var9) {
         this.shooter = var1;
         this.kind = var2;
         this.target = var3;
         this.pos = var4;
         this.speed = var5;
         this.homing = var7;
         this.maxT = var9;
         this.lv = var1.getElfLevel();
         this.transc = var1.isTranscended();
         double var10 = var2 == 20 ? 0.9 : (var2 == 22 ? 1.0 : 1.3);
         this.dmg = ElfNew.dmg(var1, var10);
         Vec3 var12 = ElfNew.center(var3).subtract(var4);
         this.dir = var12.lengthSqr() < 1.0E-6 ? new Vec3(0.0, 0.0, 1.0) : var12.normalize();
      }

      @Override
      boolean tick(ServerLevel var1) {
         if (this.target.isAlive()) {
            Vec3 var2 = ElfNew.center(this.target).subtract(this.pos);
            if (var2.lengthSqr() > 1.0E-6) {
               Vec3 var3 = var2.normalize();
               Vec3 var4 = new Vec3(
                  this.dir.x + (var3.x - this.dir.x) * this.homing,
                  this.dir.y + (var3.y - this.dir.y) * this.homing,
                  this.dir.z + (var3.z - this.dir.z) * this.homing
               );
               this.dir = var4.lengthSqr() < 1.0E-6 ? var3 : var4.normalize();
            }
         }

         Vec3 var5 = this.pos.add(this.dir.scale(this.speed));
         LivingEntity var6 = ElfNew.firstHit(var1, this.shooter, this.pos, var5, 0.3, null);
         this.t++;
         if (var6 != null) {
            this.impact(var1, var6);
            return true;
         } else {
            this.pos = var5;
            return this.t >= this.maxT;
         }
      }

      void impact(ServerLevel var1, LivingEntity var2) {
         ElfNew.hurt(this.shooter, var2, this.dmg);
         Vec3 var3 = ElfNew.center(var2);
         ElfFx.burst(var1, this.kind == 22 ? ElfFx.star() : ElfFx.green(), var3.x, var3.y, var3.z, 8, 0.15);
         double var4 = ElfNew.prog(this.lv);
         if (this.kind == 20) {
            double var6 = ElfNew.lerp(0.1, 0.5, var4) * (this.transc ? 2.0 : 1.0);
            ElfNew.applyBreak(var2, var6);
            ElfVfx.send(var1, 33, var2.getId(), ElfNew.feet(var2), ElfNew.size(var2), 44, (float)(0.5 + var4 + (this.transc ? 0.5 : 0.0)));
         } else if (this.kind == 22) {
            int var8 = this.transc ? 4 : (int)Math.round(ElfNew.lerp(0.0, 3.0, var4));
            int var7 = this.transc ? 120 : (int)Math.round(ElfNew.lerp(40.0, 80.0, var4));
            var2.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, var7, var8, false, true));
            ElfVfx.send(
               var1, 34, var2.getId(), ElfNew.feet(var2), ElfNew.size(var2), 40 + (int)(var4 * 20.0), (float)(0.4 + var4 * 0.8 + (this.transc ? 0.6 : 0.0))
            );
         } else {
            ElfFx.burst(var1, ElfFx.green(), var3.x, var3.y, var3.z, 14, 0.2);
         }
      }
   }

   private static final class Decoy {
      ElfEntity e;
      int delay;
      int age;
      int quiet;
      int endAge;
      int casts;
      Vec3 impact;
      boolean started;
      int idx;
      LivingEntity target;
   }

   private static final class Falcon extends ElfNew.Proj {
      final ElfEntity shooter;
      final double ox;
      final double oy;
      final double oz;
      final double cx;
      final double cy;
      final double cz;
      final int returns;
      final int total;
      final float dmgOut;
      final float dmgRet;
      int t;
      int lastPass = -1;
      final Set<LivingEntity> hit = Collections.newSetFromMap(new IdentityHashMap<>());
      final double[] p0 = new double[3];
      final double[] p1 = new double[3];

      Falcon(ElfEntity var1, Vec3 var2, Vec3 var3, int var4) {
         this.shooter = var1;
         this.ox = var2.x;
         this.oy = var2.y;
         this.oz = var2.z;
         this.cx = var3.x;
         this.cy = var3.y;
         this.cz = var3.z;
         this.returns = var4;
         this.total = FalconPath.total(var4);
         this.dmgOut = ElfNew.dmg(var1, 1.0);
         this.dmgRet = ElfNew.dmg(var1, 0.45);
      }

      @Override
      boolean tick(ServerLevel var1) {
         if (!this.shooter.isAlive() && !ElfNew.isDecoy(this.shooter)) {
            return true;
         } else {
            FalconPath.pos(this.ox, this.oy, this.oz, this.cx, this.cy, this.cz, this.t, this.p0);
            this.t++;
            FalconPath.pos(this.ox, this.oy, this.oz, this.cx, this.cy, this.cz, this.t, this.p1);
            int var2 = FalconPath.pass(this.t - 0.5);
            if (var2 != this.lastPass) {
               this.lastPass = var2;
               this.hit.clear();
            }

            Vec3 var3 = new Vec3(this.p0[0], this.p0[1], this.p0[2]);
            Vec3 var4 = new Vec3(this.p1[0], this.p1[1], this.p1[2]);

            for (int var5 = 0; var5 < 6; var5++) {
               LivingEntity var6 = ElfNew.firstHit(var1, this.shooter, var3, var4, 0.55, this.hit);
               if (var6 == null) {
                  break;
               }

               this.hit.add(var6);
               ElfNew.hurt(this.shooter, var6, var2 == 0 ? this.dmgOut : this.dmgRet);
               Vec3 var7 = ElfNew.center(var6);
               ElfFx.burst(var1, ElfFx.green(), var7.x, var7.y, var7.z, 6, 0.12);
            }

            return this.t >= this.total;
         }
      }
   }

   private abstract static class Proj {
      abstract boolean tick(ServerLevel var1);
   }

   private static final class St {
      int cdMirror;
      int cdFalcon;
      int cdSunder;
      int cdStagger;
      int cdReprisal;
      double dmgScale = 1.0;
      int mirrorIdx = -1;
      int mirrorEnd;
      int rhT;
      int rhEx;
      int rhOut;
      boolean rhExhausted;
      double fixedF = -1.0;
      int repDelay = -1;
      LivingEntity repTarget;
      int standby;
      List<ElfEntity> standbyDecoys;
      int glide;
      Vec3 glideVel;
      boolean glideFlying;
      final List<ElfNew.Proj> projs = new ArrayList<>();
      final List<ElfNew.Decoy> decoys = new ArrayList<>();
      int fxTick;
      boolean broken;
   }
}
