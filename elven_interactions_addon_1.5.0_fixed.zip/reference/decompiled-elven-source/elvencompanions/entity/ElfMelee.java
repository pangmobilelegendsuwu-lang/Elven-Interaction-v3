package com.elvencompanions.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

public final class ElfMelee {
   private static final double REACH = 3.4;
   private static final int SLAM_MAX_TICKS = 10;
   private static final WeakHashMap<ElfEntity, ElfMelee.State> STATES = new WeakHashMap<>();
   private static final double SWEEP_RADIUS = 3.6;
   private static final int SWEEP_MAX = 8;
   private static final double SHOCK_RADIUS = 5.0;
   private static final int SHOCK_MAX = 12;

   private static ElfMelee.State st(ElfEntity var0) {
      ElfMelee.State var1 = STATES.get(var0);
      if (var1 == null) {
         var1 = new ElfMelee.State();
         STATES.put(var0, var1);
      }

      return var1;
   }

   public static LivingEntity filter(LivingEntity var0, ElfEntity var1, ServerLevel var2) {
      try {
         if (var0 != null && var0.isAlive()) {
            ElfMelee.State var3 = st(var1);
            if (var3.slamT > 0) {
               return null;
            } else if (var1.tickCount < var3.nextOk) {
               return var0;
            } else if (var1.distanceToSqr(var0) > 11.559999999999999) {
               return var0;
            } else {
               int var4 = var1.getElfLevel();
               double var5 = ElfLevel.lerp(0.4, 0.65, var4);
               if (var1.getRandom().nextDouble() >= var5) {
                  return var0;
               } else {
                  var3.nextOk = var1.tickCount + 40;
                  if (var1.isTranscended()) {
                     var3.slamTarget = var0;
                     var3.slamT = 10;
                     var1.getNavigation().stop();
                     var2.playSound(null, var1.getX(), var1.getY(), var1.getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.NEUTRAL, 1.0F, 0.6F);
                     return null;
                  } else {
                     if (var1.getRandom().nextBoolean()) {
                        push(var1, var2, var0, var4);
                     } else {
                        kick(var1, var2, var0, var4);
                     }

                     return var0;
                  }
               }
            }
         } else {
            return var0;
         }
      } catch (Throwable var7) {
         return var0;
      }
   }

   public static double dashDist(ElfEntity var0, double var1) {
      try {
         ElfMelee.State var3 = STATES.get(var0);
         if (var3 != null && var3.boostUntil > var0.tickCount && var0.isTranscended()) {
            var3.boostUntil = 0;
            return Math.min(14.0, var1 * 1.9);
         }
      } catch (Throwable var4) {
      }

      return var1;
   }

   public static void update(ElfEntity var0) {
      ElfMelee.State var1 = STATES.get(var0);
      if (var1 != null) {
         try {
            if (var1.slamT > 0) {
               slamStep(var0, var1);
            }

            if (!var1.stuns.isEmpty()) {
               Iterator var2 = var1.stuns.iterator();

               while (var2.hasNext()) {
                  ElfMelee.Stun var3 = (ElfMelee.Stun)var2.next();
                  if (--var3.ticks > 0 && var3.mob.isAlive()) {
                     var3.mob.setTarget(null);
                     var3.mob.getNavigation().stop();
                  } else {
                     var2.remove();
                  }
               }
            }
         } catch (Throwable var4) {
            var1.slamT = 0;
            var1.stuns.clear();
         }
      }
   }

   private static void hit(ElfEntity var0, LivingEntity var1, float var2) {
      var1.invulnerableTime = 0;
      DamageSource var3 = var0.damageSources().mobAttack(var0);
      var1.hurt(var3, var2);
      var0.noteDamaged(var1);
   }

   private static List<LivingEntity> sweepTargets(ElfEntity var0, LivingEntity var1) {
      return sweepTargets(var0, var1, 3.6, 8);
   }

   private static List<LivingEntity> sweepTargets(ElfEntity var0, LivingEntity var1, double var2, int var4) {
      ArrayList var5 = new ArrayList();
      var5.add(var1);

      try {
         for (LivingEntity var8 : var0.level()
            .getEntitiesOfClass(LivingEntity.class, var0.getBoundingBox().inflate(var2), var2x -> var2x != var1 && var0.isHostile(var2x))) {
            if (var5.size() >= var4) {
               break;
            }

            if (var0.distanceToSqr(var8) <= var2 * var2) {
               var5.add(var8);
            }
         }
      } catch (Throwable var9) {
      }

      return var5;
   }

   private static void push(ElfEntity var0, ServerLevel var1, LivingEntity var2, int var3) {
      float var4 = (float)ElfLevel.lerp(3.0, 6.0, var3);
      double var5 = ElfLevel.lerp(2.0, 5.0, var3);
      var0.swing(InteractionHand.MAIN_HAND);

      for (LivingEntity var8 : sweepTargets(var0, var2)) {
         hit(var0, var8, var4);
         var8.knockback(var5 * 0.15, var0.getX() - var8.getX(), var0.getZ() - var8.getZ());
         var8.hurtMarked = true;
         ElfFx.burst(var1, ElfFx.green(), var8.getX(), var8.getY() + var8.getBbHeight() * 0.5, var8.getZ(), 10, 0.2);
         ElfFx.ring(var1, ElfFx.gold(), var8.getX(), var8.getY() + 0.2, var8.getZ(), 0.4, 14, 0.2, 0.05);
      }

      var1.playSound(null, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.NEUTRAL, 1.1F, 0.9F);
      ElfFx.ring(var1, ElfFx.gold(), var0.getX(), var0.getY() + 0.3, var0.getZ(), 2.8800000000000003, 24, 0.0, 0.08);
   }

   private static void kick(ElfEntity var0, ServerLevel var1, LivingEntity var2, int var3) {
      float var4 = (float)ElfLevel.lerp(1.0, 3.0, var3);
      int var5 = (int)Math.round(ElfLevel.lerp(40.0, 80.0, var3));

      for (LivingEntity var7 : sweepTargets(var0, var2)) {
         hit(var0, var7, var4);
         var7.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, var5, 6, false, true));
         ElfFx.burst(var1, ElfFx.leaf(), var7.getX(), var7.getY() + 0.2, var7.getZ(), 12, 0.15);
         ElfFx.ring(var1, ElfFx.green(), var7.getX(), var7.getY() + 0.1, var7.getZ(), 0.3, 12, 0.15, 0.03);
      }

      var1.playSound(null, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.NEUTRAL, 1.0F, 1.3F);
      ElfFx.ring(var1, ElfFx.green(), var0.getX(), var0.getY() + 0.1, var0.getZ(), 2.8800000000000003, 24, 0.0, 0.06);
   }

   private static void slamStep(ElfEntity var0, ElfMelee.State var1) {
      LivingEntity var2 = var1.slamTarget;
      if (var2 != null && var2.isAlive() && var0.level() instanceof ServerLevel) {
         ServerLevel var3 = (ServerLevel)var0.level();
         Vec3 var4 = var2.position().subtract(var0.position());
         Vec3 var5 = new Vec3(var4.x, 0.0, var4.z);
         double var6 = var5.length();
         var1.slamT--;
         if (!(var6 < 1.5) && var1.slamT > 0) {
            Vec3 var8 = var5.scale(1.0 / var6);
            var0.setDeltaMovement(var8.x * 1.15, 0.05, var8.z * 1.15);
            var0.hasImpulse = true;
            ElfFx.burst(var3, ElfFx.star(), var0.getX(), var0.getY() + 0.9, var0.getZ(), 4, 0.1);
         } else {
            impact(var0, var3, var2, var1, var5);
         }
      } else {
         var1.slamT = 0;
         var1.slamTarget = null;
      }
   }

   private static void impact(ElfEntity var0, ServerLevel var1, LivingEntity var2, ElfMelee.State var3, Vec3 var4) {
      int var5 = var0.getElfLevel();
      var3.slamT = 0;
      var3.slamTarget = null;
      var3.nextOk = var0.tickCount + 80;
      var3.boostUntil = var0.tickCount + 6;
      var0.setDeltaMovement(0.0, 0.0, 0.0);
      float var6 = (float)ElfLevel.lerp(4.0, 8.0, var5);
      int var7 = (int)Math.round(ElfLevel.lerp(40.0, 70.0, var5));
      double var8 = var0.getX();
      double var10 = var0.getZ();

      for (LivingEntity var13 : sweepTargets(var0, var2, 5.0, 12)) {
         hit(var0, var13, var6);
         double var14 = var13.getX() - var8;
         double var16 = var13.getZ() - var10;
         if (var14 * var14 + var16 * var16 < 1.0E-4) {
            var14 = var4.lengthSqr() < 1.0E-4 ? 0.0 : var4.x;
            var16 = var4.lengthSqr() < 1.0E-4 ? 1.0 : var4.z;
         }

         var13.knockback(0.45, -var14, -var16);
         var13.hurtMarked = true;
         var13.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, var7, 9, false, true));
         var13.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, var7, 9, false, true));
         if (var13 instanceof Mob var18) {
            var18.setTarget(null);
            boolean var19 = false;

            for (ElfMelee.Stun var21 : var3.stuns) {
               if (var21.mob == var18) {
                  var21.ticks = var7;
                  var19 = true;
                  break;
               }
            }

            if (!var19) {
               var3.stuns.add(new ElfMelee.Stun(var18, var7));
            }
         }

         ElfFx.burst(var1, ElfFx.star(), var13.getX(), var13.getY() + var13.getBbHeight() * 0.5, var13.getZ(), 18, 0.35);
      }

      var1.playSound(null, var8, var0.getY(), var10, SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 1.0F, 1.5F);
      var1.playSound(null, var8, var0.getY(), var10, SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.NEUTRAL, 1.3F, 0.6F);
      ElfFx.ring(var1, ElfFx.moon(), var8, var0.getY() + 0.2, var10, 1.2, 28, 0.35, 0.18);
      ElfFx.ring(var1, ElfFx.moon(), var8, var0.getY() + 0.2, var10, 4.0, 36, 0.1, 0.12);
      ElfFx.ring(var1, ElfFx.star(), var8, var0.getY() + 0.4, var10, 5.0, 40, 0.0, 0.1);
      ElfFx.burst(var1, ElfFx.star(), var8, var0.getY() + 0.9, var10, 24, 0.5);
   }

   private ElfMelee() {
   }

   private static final class State {
      int nextOk;
      int slamT;
      LivingEntity slamTarget;
      int boostUntil;
      final List<ElfMelee.Stun> stuns = new ArrayList<>();
   }

   private static final class Stun {
      final Mob mob;
      int ticks;

      Stun(Mob var1, int var2) {
         this.mob = var1;
         this.ticks = var2;
      }
   }
}
