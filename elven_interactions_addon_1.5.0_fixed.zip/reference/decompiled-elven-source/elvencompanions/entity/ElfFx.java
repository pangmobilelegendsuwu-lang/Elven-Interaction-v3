package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ModRegistry;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

public final class ElfFx {
   private static long budgetTick = Long.MIN_VALUE;
   private static int budgetUsed;

   public static ParticleOptions green() {
      return (ParticleOptions)ModRegistry.GLOW_GREEN.get();
   }

   public static ParticleOptions gold() {
      return (ParticleOptions)ModRegistry.GLOW_GOLD.get();
   }

   public static ParticleOptions fire() {
      return (ParticleOptions)ModRegistry.GLOW_FIRE.get();
   }

   public static ParticleOptions moon() {
      return (ParticleOptions)ModRegistry.GLOW_MOON.get();
   }

   public static ParticleOptions star() {
      return (ParticleOptions)ModRegistry.STAR.get();
   }

   public static ParticleOptions leaf() {
      return (ParticleOptions)ModRegistry.LEAF.get();
   }

   private static boolean on() {
      return (Boolean)ECConfig.particles.get();
   }

   private static int cnt(int var0) {
      return Math.max(1, (int)Math.round(var0 * (Double)ECConfig.particleDensity.get()));
   }

   private static boolean take(ServerLevel var0, int var1) {
      long var2 = var0.getGameTime();
      if (var2 != budgetTick) {
         budgetTick = var2;
         budgetUsed = 0;
      }

      if (budgetUsed + var1 > (Integer)ECConfig.particleBudgetPerTick.get()) {
         return false;
      } else {
         budgetUsed += var1;
         return true;
      }
   }

   public static void p(
      ServerLevel var0, ParticleOptions var1, double var2, double var4, double var6, int var8, double var9, double var11, double var13, double var15
   ) {
      var8 = cnt(var8);
      if (on() && take(var0, var8)) {
         var0.sendParticles(var1, var2, var4, var6, var8, var9, var11, var13, var15);
      }
   }

   public static void vel(ServerLevel var0, ParticleOptions var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      if (on() && take(var0, 1)) {
         var0.sendParticles(var1, var2, var4, var6, 0, var8, var10, var12, 1.0);
      }
   }

   public static void ring(ServerLevel var0, ParticleOptions var1, double var2, double var4, double var6, double var8, int var10, double var11, double var13) {
      var10 = cnt(var10);
      if (on() && take(var0, var10)) {
         for (int var15 = 0; var15 < var10; var15++) {
            double var16 = var15 * Math.PI * 2.0 / var10;
            double var18 = Math.cos(var16);
            double var20 = Math.sin(var16);
            var0.sendParticles(var1, var2 + var18 * var8, var4, var6 + var20 * var8, 0, var18 * var11, var13, var20 * var11, 1.0);
            if (var15 % 4 == 0 && take(var0, 1)) {
               var0.sendParticles(
                  star(), var2 + var18 * var8, var4 + 0.08, var6 + var20 * var8, 0, -var20 * var11 * 0.8, var13 * 2.0 + 0.02, var18 * var11 * 0.8, 1.0
               );
            }

            if (var15 % 2 == 0 && var8 > 1.0 && take(var0, 1)) {
               var0.sendParticles(
                  var1, var2 + var18 * var8 * 0.88, var4 + 0.04, var6 + var20 * var8 * 0.88, 0, var18 * var11 * 0.5, var13 * 1.4, var20 * var11 * 0.5, 1.0
               );
            }
         }
      }
   }

   public static void helix(
      ServerLevel var0, ParticleOptions var1, double var2, double var4, double var6, double var8, double var10, int var12, double var13, double var15
   ) {
      var12 = cnt(var12);
      if (on() && take(var0, var12 * 2)) {
         for (int var17 = 0; var17 < var12; var17++) {
            double var18 = (double)var17 / var12;
            double var20 = var13 + var18 * Math.PI * 4.0;
            double var22 = var8 * (1.0 - 0.35 * var18);

            for (int var24 = 0; var24 < 2; var24++) {
               double var25 = var20 + var24 * Math.PI;
               var0.sendParticles(
                  var1,
                  var2 + Math.cos(var25) * var22,
                  var4 + var18 * var10,
                  var6 + Math.sin(var25) * var22,
                  0,
                  -Math.sin(var25) * 0.04,
                  var15,
                  Math.cos(var25) * 0.04,
                  1.0
               );
            }
         }
      }
   }

   public static void sparkle(ServerLevel var0, double var1, double var3, double var5, double var7, int var9) {
      var9 = cnt(var9);
      if (on() && take(var0, var9 * 2)) {
         RandomSource var10 = var0.random;

         for (int var11 = 0; var11 < var9; var11++) {
            double var12 = (var10.nextDouble() - 0.5) * 2.0 * var7;
            double var14 = (var10.nextDouble() - 0.5) * 2.0 * var7;
            double var16 = (var10.nextDouble() - 0.5) * 2.0 * var7;
            var0.sendParticles(star(), var1 + var12, var3 + var14, var5 + var16, 0, 0.0, 0.01 + var10.nextDouble() * 0.03, 0.0, 1.0);
            if (var11 % 2 == 0) {
               var0.sendParticles(gold(), var1 + var12, var3 + var14, var5 + var16, 0, 0.0, 0.02, 0.0, 1.0);
            }
         }
      }
   }

   public static void disc(ServerLevel var0, ParticleOptions var1, Vec3 var2, Vec3 var3, double var4, int var6) {
      var6 = cnt(var6);
      if (on() && take(var0, var6)) {
         Vec3 var7 = Math.abs(var3.y) > 0.95 ? new Vec3(1.0, 0.0, 0.0) : var3.cross(new Vec3(0.0, 1.0, 0.0)).normalize();
         Vec3 var8 = var3.cross(var7).normalize();

         for (int var9 = 0; var9 < var6; var9++) {
            double var10 = var9 * Math.PI * 2.0 / var6;
            Vec3 var12 = var2.add(var7.scale(Math.cos(var10) * var4)).add(var8.scale(Math.sin(var10) * var4));
            var0.sendParticles(var1, var12.x, var12.y, var12.z, 0, var3.x * 0.05, var3.y * 0.05, var3.z * 0.05, 1.0);
         }

         if (take(var0, 3)) {
            var0.sendParticles(star(), var2.x, var2.y, var2.z, 0, var3.x * 0.08, var3.y * 0.08, var3.z * 0.08, 1.0);
            var0.sendParticles(star(), var2.x, var2.y, var2.z, 0, var3.x * 0.16, var3.y * 0.16, var3.z * 0.16, 1.0);
            var0.sendParticles(var1, var2.x, var2.y, var2.z, 0, var3.x * 0.22, var3.y * 0.22, var3.z * 0.22, 1.0);
         }
      }
   }

   public static void burst(ServerLevel var0, ParticleOptions var1, double var2, double var4, double var6, int var8, double var9) {
      var8 = cnt(var8);
      if (on() && take(var0, var8)) {
         RandomSource var11 = var0.random;

         for (int var12 = 0; var12 < var8; var12++) {
            double var13 = var11.nextGaussian();
            double var15 = var11.nextGaussian();
            double var17 = var11.nextGaussian();
            double var19 = Math.max(1.0E-4, Math.sqrt(var13 * var13 + var15 * var15 + var17 * var17));
            double var21 = var9 * (0.4 + var11.nextDouble() * 0.8) / var19;
            var0.sendParticles(var1, var2, var4, var6, 0, var13 * var21, var15 * var21, var17 * var21, 1.0);
            if (var12 % 4 == 0 && take(var0, 1)) {
               var0.sendParticles(star(), var2, var4, var6, 0, var13 * var21 * 0.6, var15 * var21 * 0.6 + 0.01, var17 * var21 * 0.6, 1.0);
            }
         }
      }
   }

   public static void converge(ServerLevel var0, ParticleOptions var1, Vec3 var2, double var3, int var5, double var6) {
      var5 = cnt(var5);
      if (on() && take(var0, var5)) {
         RandomSource var8 = var0.random;

         for (int var9 = 0; var9 < var5; var9++) {
            double var10 = var8.nextDouble() * Math.PI * 2.0;
            double var12 = (var8.nextDouble() - 0.5) * Math.PI;
            Vec3 var14 = new Vec3(Math.cos(var10) * Math.cos(var12), Math.sin(var12), Math.sin(var10) * Math.cos(var12)).scale(var3);
            var0.sendParticles(var1, var2.x + var14.x, var2.y + var14.y, var2.z + var14.z, 0, -var14.x * var6, -var14.y * var6, -var14.z * var6, 1.0);
         }
      }
   }

   public static Vec3 handPos(ElfEntity var0) {
      double var1 = Math.toRadians(var0.yBodyRot);
      double var3 = Math.toRadians(var0.yHeadRot);
      double var5 = -Math.cos(var1);
      double var7 = -Math.sin(var1);
      double var9 = -Math.sin(var3);
      double var11 = Math.cos(var3);
      return new Vec3(var0.getX() + var5 * 0.34 + var9 * 0.5, var0.getY() + 1.15, var0.getZ() + var7 * 0.34 + var11 * 0.5);
   }

   public static void muzzle(ServerLevel var0, ElfEntity var1, Vec3 var2) {
      Vec3 var3 = handPos(var1);
      int var4 = ElfLevel.tier(var1.getElfLevel());
      disc(var0, var4 >= 3 ? gold() : green(), var3.add(var2.scale(0.4)), var2, 0.35, 10);
      burst(var0, star(), var3.x, var3.y, var3.z, 4, 0.12);
      p(var0, green(), var3.x, var3.y, var3.z, 4, 0.1, 0.1, 0.1, 0.01);

      for (int var5 = 0; var5 < 4; var5++) {
         double var6 = (var0.random.nextDouble() - 0.5) * 0.12;
         double var8 = (var0.random.nextDouble() - 0.5) * 0.12;
         double var10 = (var0.random.nextDouble() - 0.5) * 0.12;
         vel(var0, var4 >= 3 ? gold() : green(), var3.x, var3.y, var3.z, var2.x * 0.35 + var6, var2.y * 0.35 + var8, var2.z * 0.35 + var10);
      }
   }

   public static ElfFx.Tick shockwave(ServerLevel var0, Vec3 var1, double var2, int var4, ParticleOptions var5, ParticleOptions var6) {
      int[] var7 = new int[]{0};
      return () -> {
         var7[0]++;
         double var8 = (double)var7[0] / var4;
         double var10 = Math.max(0.5, var2 * var8);
         int var12 = (int)Math.min(96.0, 16.0 + var10 * 8.0);
         ring(var0, var5, var1.x, var1.y + 0.15, var1.z, var10, var12, 0.02, 0.03);
         if (var7[0] % 2 == 0) {
            ring(var0, var6, var1.x, var1.y + 0.35, var1.z, var10 * 0.72, Math.max(12, var12 / 2), 0.01, 0.07);
         }

         if (var7[0] % 3 == 0 && take(var0, 8)) {
            for (int var13 = 0; var13 < 8; var13++) {
               double var14 = var13 * Math.PI / 4.0 + var7[0] * 0.35;
               var0.sendParticles(star(), var1.x + Math.cos(var14) * var10, var1.y + 0.2, var1.z + Math.sin(var14) * var10, 0, 0.0, 0.16, 0.0, 1.0);
            }
         }

         if (var7[0] % 4 == 0) {
            p(var0, leaf(), var1.x, var1.y + 0.4, var1.z, 3, var10 * 0.6, 0.2, var10 * 0.6, 0.0);
         }

         return var7[0] >= var4;
      };
   }

   public static ElfFx.Tick levelBeam(ElfEntity var0, int var1) {
      int[] var2 = new int[]{0};
      return () -> {
         if (var0.level() instanceof ServerLevel var3 && var0.isAlive()) {
            var2[0]++;
            double var18 = var0.getX();
            double var6 = var0.getY();
            double var8 = var0.getZ();
            double var10 = 46.0;
            double var12 = var10 * (1.0 - Math.min(1.0, var2[0] / 10.0));

            for (double var14 = var12; var14 <= var10; var14++) {
               double var16 = 0.35 + 0.25 * Math.sin(var14 * 0.4 + var2[0]);
               p(var3, gold(), var18, var6 + var14, var8, 2, var16, 0.4, var16, 0.0);
               if (((int)(var14 / 1.6) + var2[0]) % 3 == 0) {
                  p(var3, star(), var18, var6 + var14, var8, 1, 0.5, 0.4, 0.5, 0.0);
               }
            }

            p(var3, green(), var18, var6 + var12, var8, 6, 0.8, 0.8, 0.8, 0.0);
            helix(var3, var2[0] % 2 == 0 ? gold() : green(), var18, var6 + 0.1, var8, 1.1, 5.0, 18, var2[0] * 0.5, 0.18);
            if (var2[0] < 10) {
               converge(var3, star(), new Vec3(var18, var6 + 1.0, var8), 3.0, 6, 0.12);
            }

            if (var2[0] == 10) {
               var3.playSound(null, var18, var6, var8, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.NEUTRAL, 0.7F, 1.6F);
               var3.playSound(null, var18, var6, var8, SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 1.2F, 0.9F);
               var3.playSound(null, var18, var6, var8, SoundEvents.BEACON_POWER_SELECT, SoundSource.NEUTRAL, 1.5F, 1.2F);
               burst(var3, star(), var18, var6 + 1.0, var8, 40, 0.5);
               burst(var3, gold(), var18, var6 + 1.0, var8, 30, 0.35);
               ring(var3, gold(), var18, var6 + 0.2, var8, 0.8, 40, 0.35, 0.02);
               ring(var3, green(), var18, var6 + 0.3, var8, 0.5, 28, 0.22, 0.05);
               ring(var3, moon(), var18, var6 + 0.5, var8, 1.4, 44, 0.3, 0.04);
               sparkle(var3, var18, var6 + 1.2, var8, 1.6, 22);
               p(var3, ParticleTypes.FLASH, var18, var6 + 1.0, var8, 1, 0.0, 0.0, 0.0, 0.0);
            }

            if (var2[0] > 10) {
               p(var3, leaf(), var18, var6 + 3.0, var8, 2, 1.2, 1.0, 1.2, 0.0);
               p(var3, gold(), var18, var6 + 0.2, var8, 3, 0.7, 0.1, 0.7, 0.02);
            }

            return var2[0] >= var1;
         } else {
            return true;
         }
      };
   }

   private ElfFx() {
   }

   public interface Tick {
      boolean tick();
   }
}
