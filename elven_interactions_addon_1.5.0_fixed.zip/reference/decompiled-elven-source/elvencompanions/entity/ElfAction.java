package com.elvencompanions.entity;

public enum ElfAction {
   RIDE_PLAYER,
   RIDE_MOUNT,
   UNMOUNT,
   NEUTRAL,
   PASSIVE,
   AGGRESSIVE,
   INVENTORY,
   REST,
   PICKUP,
   TELEPORT,
   STANCE,
   HOME_TOGGLE,
   GO_HOME,
   REST_SCHEDULE,
   SKILL_0,
   SKILL_1,
   SKILL_2,
   SKILL_3,
   SKILL_4,
   SKILL_5,
   FLIGHT_TOGGLE,
   TRANSCEND_STOP,
   TRANSCEND_START,
   TRANSCEND_START_INSTANT;

   public boolean queueable() {
      return this == NEUTRAL || this == PASSIVE || this == AGGRESSIVE || this == PICKUP || this == REST_SCHEDULE;
   }

   public static ElfAction byId(int var0) {
      ElfAction[] var1 = values();
      return var0 >= 0 && var0 < var1.length ? var1[var0] : null;
   }
}
