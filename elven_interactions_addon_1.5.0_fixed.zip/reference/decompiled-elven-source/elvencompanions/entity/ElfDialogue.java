package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

public final class ElfDialogue {
   private static final Map<String, Integer> VARIANTS = Map.ofEntries(
      Map.entry("follow", 3),
      Map.entry("sit", 3),
      Map.entry("guard", 3),
      Map.entry("neutral", 3),
      Map.entry("passive", 3),
      Map.entry("aggressive", 3),
      Map.entry("rest", 2),
      Map.entry("wake", 3),
      Map.entry("ride_player", 2),
      Map.entry("ride_mount", 2),
      Map.entry("unmount", 2),
      Map.entry("pickup_on", 2),
      Map.entry("pickup_off", 2),
      Map.entry("inventory", 1),
      Map.entry("skill", 1),
      Map.entry("revive", 2),
      Map.entry("teleport", 2),
      Map.entry("wander", 3),
      Map.entry("go_home", 2)
   );

   public static void say(ElfEntity elf, String key) {
      if (!elf.level().isClientSide && elf.getOwnerUUID() != null) {
         int v = 1 + elf.getRandom().nextInt(VARIANTS.getOrDefault(key, 1));
         MutableComponent msg = Component.empty()
            .append(Component.literal("<").withStyle(ChatFormatting.GRAY))
            .append(elf.getDisplayName().copy().withStyle(ChatFormatting.GREEN))
            .append(Component.literal("> ").withStyle(ChatFormatting.GRAY))
            .append(Component.translatable("elven_companions.dialogue." + key + "." + v).withStyle(ChatFormatting.ITALIC));
         if ((Boolean)ECConfig.dialogueOwnerOnly.get()) {
            if (elf.getOwnerPlayer() instanceof ServerPlayer sp) {
               sp.sendSystemMessage(msg);
            }
         } else {
            for (Player p : elf.level().players()) {
               if (p instanceof ServerPlayer sp && sp.distanceToSqr(elf) <= 256.0) {
                  sp.sendSystemMessage(msg);
               }
            }
         }
      }
   }

   private ElfDialogue() {
   }
}
