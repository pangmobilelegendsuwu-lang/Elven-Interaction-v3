package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.voice.ElfVoice;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class ElfDefense {
   private static final ResourceLocation SPEED_ID = ElvenCompanions.rl("stealth_speed");
   private final ElfEntity elf;
   private int stealthTicks;
   private int stealthCd;
   private int potionCd;
   private int drinkTicks;
   private int dashCd;
   private int kbCd;
   private int dashAnim;
   private int dashIFrames;
   private int chargeT;
   private int launchT;
   private LivingEntity chargeTarget;
   private int projCheck;
   private final Map<Integer, Integer> wardenSeen = new HashMap<>();
   private int staminaTimer;
   private int airCd;
   private int waterTicks;
   private int escapeDashCd;
   private int escapeRegenTimer;
   private int stamina = -1;
   private boolean reapply;
   private boolean escaping;

   public ElfDefense(ElfEntity var1) {
      this.elf = var1;
   }

   public boolean isStealth() {
      return this.stealthTicks > 0;
   }

   public boolean isDrinking() {
      return this.drinkTicks > 0;
   }

   public boolean hasDashIFrames() {
      return this.dashIFrames > 0;
   }

   public boolean isChargeStriking() {
      return this.chargeT > 0 || this.launchT > 0;
   }

   public boolean isDashing() {
      return this.dashAnim > 0;
   }

   public boolean isEscaping() {
      return this.escaping;
   }

   public boolean manualStealth() {
      if (this.elf.level() instanceof ServerLevel var1 && this.stealthTicks <= 0) {
         this.startStealth(var1);
         return true;
      } else {
         return false;
      }
   }

   public boolean potionReady() {
      return this.potionCd == 0 && this.drinkTicks == 0;
   }

   public int maxStamina() {
      return Math.max(
         1,
         (int)Math.round(
            ((Integer)ECConfig.maxStamina.get()).intValue() * ElfLevel.staminaMult(this.elf.getElfLevel()) * (this.elf.skills.isFlying() ? 0.7 : 1.0)
         )
      );
   }

   public int getStamina() {
      return this.stamina < 0 ? this.maxStamina() : Math.min(this.stamina, this.maxStamina());
   }

   public void save(CompoundTag var1) {
      var1.putInt("StealthTicks", this.stealthTicks);
      var1.putInt("StealthCd", this.stealthCd);
      var1.putInt("PotionCd", this.potionCd);
      var1.putInt("DashCd", this.dashCd);
      var1.putInt("KbCd", this.kbCd);
      var1.putInt("Stamina", this.getStamina());
      var1.putBoolean("Escaping", this.escaping);
   }

   public void load(CompoundTag var1) {
      this.stealthTicks = var1.getInt("StealthTicks");
      this.stealthCd = var1.getInt("StealthCd");
      this.potionCd = var1.getInt("PotionCd");
      this.dashCd = var1.getInt("DashCd");
      this.kbCd = var1.getInt("KbCd");
      this.stamina = var1.contains("Stamina") ? var1.getInt("Stamina") : -1;
      this.escaping = var1.getBoolean("Escaping");
      this.drinkTicks = 0;
      this.reapply = this.stealthTicks > 0;
   }

   private boolean idle() {
      return !this.elf.skills.isUltimate() && !this.elf.skills.isBusy() && !this.elf.isMounted() && this.elf.getRestState() == 0;
   }

   public void tick() {
      if (this.elf.level() instanceof ServerLevel var1) {
         int var3 = this.maxStamina();
         if (this.stamina < 0) {
            this.stamina = var3;
         }

         if (this.stealthCd > 0) {
            this.stealthCd--;
         }

         if (this.potionCd > 0) {
            this.potionCd--;
         }

         if (this.dashCd > 0) {
            this.dashCd--;
         }

         if (this.kbCd > 0) {
            this.kbCd--;
         }

         if (this.airCd > 0) {
            this.airCd--;
         }

         if (this.escapeDashCd > 0) {
            this.escapeDashCd--;
         }

         if (this.dashIFrames > 0) {
            this.dashIFrames--;
         }

         if (this.dashAnim > 0 && --this.dashAnim == 0) {
            this.elf.setDashDir(0);
         }

         if (this.stamina < var3) {
            if (++this.staminaTimer >= (Integer)ECConfig.staminaRegenTicks.get()) {
               this.stamina = Math.min(
                  var3,
                  this.stamina
                     + (int)Math.round(
                        ((Integer)ECConfig.staminaRegen.get()).intValue()
                           * ElfLevel.staminaMult(this.elf.getElfLevel())
                           * (this.elf.skills.isRaging() ? (Double)ECConfig.ragingMultiplier.get() : 1.0)
                     )
               );
               this.staminaTimer = 0;
            }
         } else {
            this.staminaTimer = 0;
         }

         this.tickStealth(var1);
         this.tickEscape(var1);
         this.tickPotion(var1);
         this.tickDodge(var1);
         this.tickAerial(var1);
         this.tickChargeStrike(var1);
         this.tickTranscendDodges(var1);
      }
   }

   private void tickChargeStrike(ServerLevel var1) {
      if (this.chargeT > 0) {
         this.chargeT--;
         LivingEntity var7 = this.chargeTarget;
         this.elf.setNoGravity(true);
         this.elf.getNavigation().stop();
         this.elf.setDeltaMovement(0.0, 0.0, 0.0);
         this.elf.hasImpulse = true;
         this.dashIFrames = Math.max(this.dashIFrames, 3);
         if (var7 != null && var7.isAlive()) {
            this.elf.getLookControl().setLookAt(var7, 60.0F, 60.0F);
         }

         double var8 = 1.0 - this.chargeT / 30.0;
         ElfFx.ring(var1, ElfFx.green(), this.elf.getX(), this.elf.getY() + 0.9, this.elf.getZ(), 2.4 * (1.0 - var8) + 0.3, 20, 0.0, 0.0);
         ElfFx.converge(var1, ElfFx.star(), this.elf.position().add(0.0, 0.9, 0.0), 3.0, 6, 0.25);
         if (this.chargeT % 6 == 0) {
            var1.playSound(null, this.elf.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.2F, 0.6F + (float)var8);
         }

         if (this.chargeT == 0) {
            this.launchT = 28;
            var1.playSound(null, this.elf.blockPosition(), SoundEvents.PHANTOM_SWOOP, SoundSource.NEUTRAL, 1.6F, 0.6F);
         }
      } else {
         if (this.launchT > 0) {
            this.launchT--;
            LivingEntity var2 = this.chargeTarget;
            if (var2 == null || !var2.isAlive()) {
               var2 = this.elf.nearestHostile(32.0);
               this.chargeTarget = var2;
            }

            this.dashIFrames = Math.max(this.dashIFrames, 3);
            if (var2 == null) {
               this.launchT = 0;
            } else {
               Vec3 var3 = var2.position().add(0.0, var2.getBbHeight() * 0.5, 0.0).subtract(this.elf.position().add(0.0, 0.9, 0.0));
               double var4 = var3.length();
               this.elf.setNoGravity(true);
               this.elf.getLookControl().setLookAt(var2, 60.0F, 60.0F);
               if (var4 < 1.7) {
                  this.impact(var1, var2);
                  this.launchT = 0;
               } else {
                  Vec3 var6 = var3.normalize();
                  this.elf.setDeltaMovement(var6.x * 1.5, var6.y * 1.5, var6.z * 1.5);
                  this.elf.hasImpulse = true;
                  ElfFx.p(var1, ElfFx.green(), this.elf.getX(), this.elf.getY() + 0.9, this.elf.getZ(), 4, 0.25, 0.3, 0.25, 0.0);
                  ElfFx.p(var1, ElfFx.gold(), this.elf.getX(), this.elf.getY() + 0.9, this.elf.getZ(), 2, 0.2, 0.2, 0.2, 0.0);
               }
            }

            if (this.launchT == 0) {
               this.finishCharge();
            }
         }
      }
   }

   private void impact(ServerLevel var1, LivingEntity var2) {
      Vec3 var3 = var2.position().add(0.0, var2.getBbHeight() * 0.5, 0.0);
      var1.playSound(null, var3.x, var3.y, var3.z, SoundEvents.WITHER_BREAK_BLOCK, SoundSource.NEUTRAL, 2.4F, 1.0F);
      ElfFx.burst(var1, ElfFx.gold(), var3.x, var3.y, var3.z, 40, 0.5);
      ElfFx.ring(var1, ElfFx.green(), var3.x, var3.y, var3.z, 0.8, 40, 0.5, 0.05);
      ElfFx.ring(var1, ElfFx.star(), var3.x, var3.y, var3.z, 0.5, 24, 0.7, 0.05);
      float var4 = this.elf.skills.chargeDamage();

      for (LivingEntity var6 : var1.getEntitiesOfClass(
         LivingEntity.class, new AABB(var3, var3).inflate(3.5), var1x -> var1x.isAlive() && this.elf.isHostile(var1x)
      )) {
         var6.invulnerableTime = 0;
         var6.hurt(var1.damageSources().mobAttack(this.elf), var4);
         var6.knockback(2.0, this.elf.getX() - var6.getX(), this.elf.getZ() - var6.getZ());
         var6.push(0.0, 0.4, 0.0);
         var6.hurtMarked = true;
      }
   }

   private void finishCharge() {
      Vec3 var1 = this.elf.getDeltaMovement();
      this.elf.setDeltaMovement(var1.x * 0.15, var1.y * 0.15, var1.z * 0.15);
      if (!this.elf.skills.isFlying()) {
         this.elf.setNoGravity(false);
      }

      this.elf.skills.grantFallGuard(120);
      this.chargeTarget = null;
   }

   private void tickTranscendDodges(ServerLevel var1) {
      if (this.elf.isTranscended() && this.idle() && !this.isChargeStriking()) {
         boolean var2 = this.elf.skills.isFlying();
         if (this.elf.onGround() || var2) {
            this.projCheck++;
            if (this.projCheck % 2 == 0) {
               HashSet var3 = new HashSet();

               for (Warden var5 : var1.getEntitiesOfClass(Warden.class, this.elf.getBoundingBox().inflate(26.0), var0 -> var0.isAlive())) {
                  if (ec$sonicWindup(var5)) {
                     var3.add(var5.getId());
                     int var6 = this.wardenSeen.computeIfAbsent(var5.getId(), var1x -> this.elf.tickCount);
                     if (this.elf.tickCount - var6 >= 20 && this.dashIFrames < 6) {
                        Vec3 var7 = this.elf.position().subtract(var5.position()).multiply(1.0, 0.0, 1.0);
                        Vec3 var8 = var7.lengthSqr() < 1.0E-4 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(-var7.z, 0.0, var7.x).normalize();
                        if (this.forcedDash(var1, var8, 30)) {
                           this.wardenSeen.put(var5.getId(), 1073741823);
                        }
                     }
                  }
               }

               this.wardenSeen.keySet().retainAll(var3);
            }

            if (this.projCheck % 2 == 1 && this.dashCd <= 0 && this.stamina >= (Integer)ECConfig.dashCost.get()) {
               Vec3 var14 = this.elf.position().add(0.0, 0.9, 0.0);

               for (Projectile var16 : var1.getEntitiesOfClass(
                  Projectile.class, this.elf.getBoundingBox().inflate(14.0), var1x -> var1x.isAlive() && this.hostileProjectile(var1x)
               )) {
                  Vec3 var17 = var16.getDeltaMovement();
                  double var18 = var17.lengthSqr();
                  if (!(var18 < 0.04)) {
                     Vec3 var9 = var14.subtract(var16.position());
                     double var10 = var9.dot(var17) / var18;
                     if (var10 > 0.0 && var10 < 12.0) {
                        Vec3 var12 = var9.subtract(var17.scale(var10));
                        if (var12.length() < 1.6) {
                           Vec3 var13 = new Vec3(-var17.z, 0.0, var17.x);
                           if (var13.lengthSqr() < 1.0E-4) {
                              var13 = new Vec3(1.0, 0.0, 0.0);
                           }

                           var13 = var13.normalize();
                           if (this.elf.getRandom().nextBoolean()) {
                              var13 = var13.scale(-1.0);
                           }

                           if (this.forcedDash(var1, var13, 14) || this.forcedDash(var1, var13.scale(-1.0), 14)) {
                              this.elf.voice.play(ElfVoice.Cat.DODGE);
                              break;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean hostileProjectile(Projectile var1) {
      Entity var2 = var1.getOwner();
      return var2 != this.elf && !(var2 instanceof ElfEntity) && !(var2 instanceof Player) ? !(var1 instanceof ElfArrow) : false;
   }

   private boolean forcedDash(ServerLevel var1, Vec3 var2, int var3) {
      double var4 = ((Integer)ECConfig.dashDistance.get()).intValue() * (this.elf.skills.isFlying() ? 1.8 : 1.0);
      if (this.dash(var1, var2, var4)) {
         this.dashIFrames = Math.max(this.dashIFrames, var3);
         return true;
      } else {
         return false;
      }
   }

   private void tickStealth(ServerLevel var1) {
      if (this.stealthTicks > 0) {
         if (this.reapply) {
            this.applyStealthEffects();
            this.reapply = false;
         }

         this.stealthTicks--;
         if (this.elf.tickCount % 5 == 0) {
            this.scareHostiles();
         }

         if (this.stealthTicks == 0) {
            this.endStealth();
         }
      } else if (this.stealthCd == 0
         && this.elf.getHealth() < ((Double)ECConfig.stealthHealthBelow.get()).floatValue()
         && this.elf.getTarget() != null
         && this.elf.isValidTarget(this.elf.getTarget())) {
         this.startStealth(var1);
      }
   }

   private void startStealth(ServerLevel var1) {
      this.stealthTicks = (Integer)ECConfig.stealthDurationSec.get() * 20;
      this.stealthCd = (Integer)ECConfig.stealthCooldownSec.get() * 20;
      this.applyStealthEffects();
      this.scareHostiles();
      ElfVfx.send(var1, 11, this.elf.getId(), this.elf.position(), null, 30, 1.0F);
      ElfFx.burst(var1, ElfFx.moon(), this.elf.getX(), this.elf.getY() + 1.0, this.elf.getZ(), 24, 0.2);
      ElfFx.p(var1, ParticleTypes.CLOUD, this.elf.getX(), this.elf.getY() + 1.0, this.elf.getZ(), 12, 0.4, 0.6, 0.4, 0.02);
      var1.playSound(null, this.elf.blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.NEUTRAL, 1.0F, 1.2F);
   }

   private void applyStealthEffects() {
      this.elf.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, Math.max(this.stealthTicks, 20), 0, false, false));
      AttributeInstance var1 = this.elf.getAttribute(Attributes.MOVEMENT_SPEED);
      if (var1 != null) {
         var1.removeModifier(SPEED_ID);
         var1.addTransientModifier(new AttributeModifier(SPEED_ID, (Double)ECConfig.stealthSpeedMultiplier.get() - 1.0, Operation.ADD_MULTIPLIED_BASE));
      }
   }

   private void endStealth() {
      this.elf.removeEffect(MobEffects.INVISIBILITY);
      AttributeInstance var1 = this.elf.getAttribute(Attributes.MOVEMENT_SPEED);
      if (var1 != null) {
         var1.removeModifier(SPEED_ID);
      }

      this.stealthTicks = 0;
   }

   private void scareHostiles() {
      double var1 = ((Integer)ECConfig.stealthRadius.get()).intValue();

      for (Mob var4 : this.elf
         .level()
         .getEntitiesOfClass(Mob.class, this.elf.getBoundingBox().inflate(var1), var3 -> var3 instanceof Enemy && var3.distanceToSqr(this.elf) <= var1 * var1)) {
         if (var4.getTarget() == this.elf) {
            var4.getBrain().eraseMemory(MemoryModuleType.ATTACK_TARGET);
            var4.setTarget(null);
            var4.getNavigation().stop();
         }

         if (var4.getLastHurtByMob() == this.elf) {
            var4.setLastHurtByMob(null);
         }
      }
   }

   private void tickEscape(ServerLevel var1) {
      if (!(Boolean)ECConfig.escapeEnabled.get()) {
         this.escaping = false;
      } else {
         float var2 = this.elf.getHealth();
         if (!this.escaping) {
            if (var2 > 0.0F && var2 < ((Double)ECConfig.potionHealthBelow.get()).floatValue() && !this.elf.skills.isUltimate() && this.elf.getRestState() == 0) {
               this.escaping = true;
               this.escapeRegenTimer = 0;
               this.elf.setTarget(null);
               this.elf.getNavigation().stop();
               ElfFx.burst(var1, ElfFx.moon(), this.elf.getX(), this.elf.getY() + 1.0, this.elf.getZ(), 14, 0.15);
            }
         } else if (var2 > ((Double)ECConfig.escapeExitHealth.get()).floatValue()) {
            this.escaping = false;
         }

         if (this.escaping) {
            if (this.elf.getTarget() != null) {
               this.elf.setTarget(null);
            }

            if (++this.escapeRegenTimer >= 20) {
               this.escapeRegenTimer = 0;
               this.elf.heal(((Double)ECConfig.escapeRegenPerSecond.get()).floatValue());
            }

            if (this.drinkTicks == 0 && this.potionCd == 0) {
               this.startDrink(var1);
            }

            Player var3 = this.elf.getOwnerPlayer();
            if (var3 != null
               && var3.level() == this.elf.level()
               && !this.elf.isMounted()
               && this.elf.onGround()
               && this.escapeDashCd == 0
               && this.stamina >= (Integer)ECConfig.dashCost.get()
               && this.dashCd == 0
               && !this.elf.skills.isBusy()) {
               Vec3 var4 = var3.position().subtract(this.elf.position()).multiply(1.0, 0.0, 1.0);
               if (var4.length() > 7.0 && this.dash(var1, var4.normalize(), ((Integer)ECConfig.dashDistance.get()).intValue() + 1.5)) {
                  this.escapeDashCd = (Integer)ECConfig.escapeDashCooldownTicks.get();
               }
            }
         }
      }
   }

   private void tickPotion(ServerLevel var1) {
      if (this.drinkTicks > 0) {
         this.drinkTicks--;
         if (this.drinkTicks % 3 == 0) {
            ElfFx.p(var1, ElfFx.green(), this.elf.getX(), this.elf.getEyeY() - 0.2, this.elf.getZ(), 3, 0.15, 0.1, 0.15, 0.0);
         }

         if (this.drinkTicks == 0) {
            this.finishDrink(var1);
         }
      } else if (!(Boolean)ECConfig.escapeEnabled.get()
         && this.potionCd == 0
         && this.elf.getHealth() > 0.0F
         && this.elf.getHealth() < ((Double)ECConfig.potionHealthBelow.get()).floatValue()
         && !this.elf.skills.isUltimate()
         && this.elf.getRestState() == 0) {
         this.startDrink(var1);
      }
   }

   private void startDrink(ServerLevel var1) {
      this.drinkTicks = Math.max(5, ElfLevel.potionTicks(this.elf.getElfLevel()));
      this.potionCd = (Integer)ECConfig.potionCooldownTicks.get();
      this.elf.setItemSlot(EquipmentSlot.MAINHAND, PotionContents.createItemStack(Items.POTION, Potions.HEALING));
      this.elf.setDrinking(true);
      var1.playSound(null, this.elf.blockPosition(), SoundEvents.WITCH_DRINK, SoundSource.NEUTRAL, 1.0F, 1.0F);
   }

   private void finishDrink(ServerLevel var1) {
      this.elf.heal(((Double)ECConfig.potionHeal.get()).floatValue());
      this.elf.setItemSlot(EquipmentSlot.MAINHAND, this.elf.bowStack());
      this.elf.setDrinking(false);
      ElfFx.burst(var1, ElfFx.green(), this.elf.getX(), this.elf.getY() + 1.2, this.elf.getZ(), 26, 0.25);
      ElfFx.ring(var1, ElfFx.gold(), this.elf.getX(), this.elf.getY() + 0.2, this.elf.getZ(), 0.5, 20, 0.2, 0.05);
      ElfFx.p(var1, ParticleTypes.HEART, this.elf.getX(), this.elf.getY() + 1.8, this.elf.getZ(), 4, 0.3, 0.3, 0.3, 0.0);
      var1.playSound(null, this.elf.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 0.5F, 1.8F);
   }

   private void tickDodge(ServerLevel var1) {
      if (this.stamina >= (Integer)ECConfig.dashCost.get()
         && this.dashCd <= 0
         && (this.elf.onGround() || this.elf.skills.isFlying())
         && !this.escaping
         && this.idle()
         && this.elf.getStance() != 1
         && this.drinkTicks <= 0) {
         LivingEntity var2 = ElfMelee.filter(this.elf.nearestHostile(((Integer)ECConfig.dashTriggerDistance.get()).intValue()), this.elf, var1);
         if (var2 != null) {
            Vec3 var3 = this.elf.position().subtract(var2.position()).multiply(1.0, 0.0, 1.0);
            if (var3.lengthSqr() < 1.0E-4) {
               var3 = new Vec3(this.elf.getRandom().nextDouble() - 0.5, 0.0, this.elf.getRandom().nextDouble() - 0.5);
            }

            var3 = var3.normalize();
            Vec3 var4 = new Vec3(-var3.z, 0.0, var3.x);
            Vec3 var5 = var4.scale(-1.0);
            int var6 = this.elf.getRandom().nextInt(10);
            Vec3[] var7 = var6 < 4 ? new Vec3[]{var3, var4, var5} : (var6 < 7 ? new Vec3[]{var4, var3, var5} : new Vec3[]{var5, var3, var4});

            for (Vec3 var11 : var7) {
               if (this.dash(var1, var11, ((Integer)ECConfig.dashDistance.get()).intValue() * (this.elf.skills.isFlying() ? 1.8 : 1.0))) {
                  this.elf.voice.play(ElfVoice.Cat.DODGE);
                  ElfNew.onDodge(this.elf, var2);
                  return;
               }
            }
         }
      }
   }

   private boolean dash(ServerLevel var1, Vec3 var2, double var3) {
      var3 = ElfMelee.dashDist(this.elf, var3);
      Vec3 var5 = this.elf.position().add(0.0, 0.6, 0.0);
      Vec3 var6 = var5.add(var2.scale(var3 + 0.4));
      BlockHitResult var7 = var1.clip(new ClipContext(var5, var6, Block.COLLIDER, Fluid.NONE, this.elf));
      if (var7.getType() != Type.MISS && var7.getLocation().distanceTo(var5) < var3) {
         return false;
      } else {
         double var8 = var3 / 2.2;
         this.elf.setDeltaMovement(var2.x * var8, this.elf.skills.isFlying() ? 0.0 : 0.22, var2.z * var8);
         this.elf.hasImpulse = true;
         this.stamina = this.stamina - (Integer)ECConfig.dashCost.get();
         this.dashCd = (Integer)ECConfig.dashCooldownTicks.get();
         this.dashAnim = 10;
         if (this.elf.isTranscended()) {
            this.dashIFrames = Math.max(this.dashIFrames, 14);
         }

         this.elf.setDashDir(this.relativeDir(var2));
         ElfFx.burst(var1, ElfFx.green(), this.elf.getX(), this.elf.getY() + 0.15, this.elf.getZ(), 6, 0.08);
         ElfFx.p(var1, ParticleTypes.CLOUD, this.elf.getX(), this.elf.getY() + 0.1, this.elf.getZ(), 4, 0.2, 0.05, 0.2, 0.02);
         return true;
      }
   }

   private int relativeDir(Vec3 var1) {
      double var2 = Math.toRadians(this.elf.getYRot());
      double var4 = -Math.sin(var2);
      double var6 = Math.cos(var2);
      double var8 = -Math.cos(var2);
      double var10 = -Math.sin(var2);
      double var12 = var1.x * var8 + var1.z * var10;
      double var14 = var1.x * var4 + var1.z * var6;
      if (Math.abs(var12) > Math.abs(var14)) {
         return var12 > 0.0 ? 2 : 1;
      } else {
         return var14 > 0.0 ? 3 : 0;
      }
   }

   private void tickAerial(ServerLevel var1) {
      boolean var2 = this.elf.isInWater() && this.elf.isEyeInFluid(FluidTags.WATER);
      this.waterTicks = var2 ? this.waterTicks + 1 : 0;
      if (this.airCd <= 0 && this.idle() && !this.elf.isInLava()) {
         boolean var3 = !this.elf.onGround()
            && !this.elf.isInWater()
            && this.elf.getDeltaMovement().y < -0.35
            && this.elf.fallDistance >= ((Double)ECConfig.airJumpFallDistance.get()).floatValue();
         if (var3) {
            this.airJump(var1, false);
         } else if (var2 && this.waterTicks >= 25 && (Boolean)ECConfig.waterJumpEnabled.get()) {
            this.airJump(var1, true);
         }
      }
   }

   private void airJump(ServerLevel var1, boolean var2) {
      Vec3 var3 = this.elf.getLookAngle().multiply(1.0, 0.0, 1.0);
      Player var4 = this.elf.getOwnerPlayer();
      if (var4 != null && var4.level() == this.elf.level() && var4.distanceToSqr(this.elf) < 1600.0) {
         Vec3 var5 = var4.position().subtract(this.elf.position()).multiply(1.0, 0.0, 1.0);
         if (var5.lengthSqr() > 4.0) {
            var3 = var5;
         }
      }

      if (var2) {
         var3 = this.shoreDirection(var1, var3);
      }

      var3 = var3.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 0.0, 1.0) : var3.normalize();
      this.elf.setDeltaMovement(var3.x * 0.65, var2 ? 1.0 : 0.9, var3.z * 0.65);
      this.elf.hasImpulse = true;
      this.elf.fallDistance = 0.0F;
      this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 110, 0, false, false));
      this.elf.skills.grantFallGuard(180);
      this.airCd = (Integer)ECConfig.airJumpCooldownTicks.get();
      this.dashAnim = 16;
      this.elf.setDashDir(3);
      ElfFx.ring(var1, var2 ? ElfFx.moon() : ElfFx.green(), this.elf.getX(), this.elf.getY() + 0.2, this.elf.getZ(), 0.6, 24, 0.18, 0.05);
      ElfFx.burst(var1, ElfFx.star(), this.elf.getX(), this.elf.getY() + 0.5, this.elf.getZ(), 12, 0.2);
      var1.playSound(null, this.elf.blockPosition(), var2 ? SoundEvents.PLAYER_SPLASH_HIGH_SPEED : SoundEvents.PHANTOM_FLAP, SoundSource.NEUTRAL, 0.9F, 1.4F);
   }

   private Vec3 shoreDirection(ServerLevel var1, Vec3 var2) {
      double[] var3 = new double[]{0.0, 0.8, -0.8, 1.6, -1.6, 2.4, -2.4, 3.14};
      Vec3 var4 = var2.lengthSqr() < 1.0E-4 ? this.elf.getLookAngle().multiply(1.0, 0.0, 1.0) : var2.normalize();

      for (double var8 : var3) {
         Vec3 var10 = var4.yRot((float)var8);

         for (double var11 = 3.0; var11 <= 6.0; var11++) {
            BlockPos var13 = BlockPos.containing(this.elf.getX() + var10.x * var11, this.elf.getY(), this.elf.getZ() + var10.z * var11);

            for (int var14 = -1; var14 <= 2; var14++) {
               BlockPos var15 = var13.above(var14);
               if (var1.getBlockState(var15.below()).isSolid()
                  && var1.getBlockState(var15).getFluidState().isEmpty()
                  && var1.getBlockState(var15.above()).getFluidState().isEmpty()
                  && !var1.getBlockState(var15).isSolid()) {
                  return var10;
               }
            }
         }
      }

      return var4;
   }

   public void onDamaged(DamageSource var1, float var2) {
      if (this.elf.level() instanceof ServerLevel var3 && !(var2 <= 0.0F) && this.kbCd <= 0 && this.dashAnim <= 0 && !this.elf.skills.isUltimate()) {
         double var9 = ((Integer)ECConfig.knockbackRadius.get()).intValue();
         List var6 = this.elf
            .level()
            .getEntitiesOfClass(
               LivingEntity.class, this.elf.getBoundingBox().inflate(var9), var3x -> this.elf.isHostile(var3x) && var3x.distanceToSqr(this.elf) <= var9 * var9
            );
         if (!var6.isEmpty() && this.elf.isTranscended() && this.chargeT <= 0 && this.launchT <= 0) {
            if (this.elf.getRandom().nextDouble() < (Double)ECConfig.knockbackChance.get() * 1.5) {
               LivingEntity var10 = this.elf.getTarget() != null && this.elf.getTarget().isAlive() ? this.elf.getTarget() : this.elf.nearestHostile(32.0);
               if (var10 != null) {
                  this.kbCd = (Integer)ECConfig.knockbackCooldownTicks.get() + 60;
                  this.chargeT = 30;
                  this.chargeTarget = var10;
                  this.elf.voice.play(ElfVoice.Cat.KNOCKBACK);
                  var3.playSound(null, this.elf.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.NEUTRAL, 1.6F, 1.6F);
               }
            }
         } else if (!this.elf.isTranscended()) {
            if (!var6.isEmpty() && !(this.elf.getRandom().nextDouble() >= (Double)ECConfig.knockbackChance.get())) {
               this.kbCd = (Integer)ECConfig.knockbackCooldownTicks.get();
               this.elf.voice.play(ElfVoice.Cat.KNOCKBACK);

               for (LivingEntity var8 : var6) {
                  var8.knockback((Double)ECConfig.knockbackStrength.get(), this.elf.getX() - var8.getX(), this.elf.getZ() - var8.getZ());
               }

               ElfFx.ring(var3, ElfFx.green(), this.elf.getX(), this.elf.getY() + 0.3, this.elf.getZ(), 0.6, 36, 0.3, 0.03);
               ElfFx.ring(var3, ElfFx.star(), this.elf.getX(), this.elf.getY() + 0.6, this.elf.getZ(), 0.4, 20, 0.45, 0.02);
               var3.playSound(null, this.elf.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.NEUTRAL, 1.0F, 1.4F);
            }
         }
      }
   }

   public void endAll() {
      if (this.stealthTicks > 0) {
         this.endStealth();
      }

      if (this.drinkTicks > 0) {
         this.drinkTicks = 0;
         this.elf.setDrinking(false);
      }
   }

   public int stealthRemaining() {
      return this.stealthCd;
   }
}
