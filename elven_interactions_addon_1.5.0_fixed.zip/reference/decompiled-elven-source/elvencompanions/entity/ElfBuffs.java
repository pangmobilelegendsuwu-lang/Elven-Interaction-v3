package com.elvencompanions.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class ElfBuffs {
   private static List<LivingEntity> lastVictims;
   private static final double R0 = 4.5;
   private static final double R1 = 9.0;
   private static final int MAX_VICTIMS = 16;

   private ElfBuffs() {
   }

   public static void chronoGrow(ElfEntity var0, List<LivingEntity> var1, Map<Integer, Boolean> var2, LivingEntity var3, Vec3 var4, int var5) {
      lastVictims = var1;

      try {
         if (var5 < 2 || var5 > 40 || (var5 & 1) != 0) {
            return;
         }

         if (!(var0.level() instanceof ServerLevel)) {
            return;
         }

         ServerLevel var6 = (ServerLevel)var0.level();
         double var7 = 4.5 + 4.5 * (var5 / 40.0);
         if (var5 % 4 == 0) {
            ElfFx.ring(var6, ElfFx.moon(), var4.x, var4.y - 0.6, var4.z, var7, 40, 0.0, 0.0);
         }

         if (var1.size() >= 16) {
            return;
         }

         double var9 = var4.x;
         double var11 = var4.y;
         double var13 = var4.z;
         List var15 = var6.getEntitiesOfClass(
            LivingEntity.class,
            new AABB(var9 - var7, var11 - var7, var13 - var7, var9 + var7, var11 + var7, var13 + var7),
            var3x -> var3x != var3 && var3x.isAlive() && !var1.contains(var3x) && var0.isHostile(var3x)
         );
         int var16 = Math.max(20, 74 - var5);

         for (LivingEntity var18 : var15) {
            if (var1.size() >= 16) {
               break;
            }

            double var19 = var18.getX() - var9;
            double var21 = var18.getY() + var18.getBbHeight() * 0.5 - var11;
            double var23 = var18.getZ() - var13;
            if (!(var19 * var19 + var21 * var21 + var23 * var23 > var7 * var7)) {
               var1.add(var18);
               if (var18 instanceof Mob var25) {
                  var2.put(var18.getId(), var25.isNoAi());
                  var25.setNoAi(true);
               }

               var18.addEffect(new MobEffectInstance(MobEffects.GLOWING, var16, 0, false, false));
               var18.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, var16, 9, false, true));
               ElfFx.burst(var6, ElfFx.star(), var18.getX(), var18.getY() + var18.getBbHeight() * 0.5, var18.getZ(), 10, 0.2);
            }
         }
      } catch (Throwable var26) {
      }
   }

   public static Vec3 aim(Entity var0, Vec3 var1) {
      try {
         List var2 = lastVictims;
         if (var2 != null && var2.size() >= 2) {
            int var3 = var0.getId();
            if ((var3 & 1) == 0) {
               return var1;
            } else {
               ArrayList var4 = new ArrayList();

               for (int var5 = 1; var5 < var2.size(); var5++) {
                  LivingEntity var6 = (LivingEntity)var2.get(var5);
                  if (var6.isAlive()) {
                     var4.add(var6);
                  }
               }

               if (var4.isEmpty()) {
                  return var1;
               } else {
                  LivingEntity var8 = (LivingEntity)var4.get(Math.floorMod(var3 >> 1, var4.size()));
                  Vec3 var9 = var8.position();
                  return new Vec3(var9.x, var9.y + var8.getBbHeight() * 0.5, var9.z);
               }
            }
         } else {
            return var1;
         }
      } catch (Throwable var7) {
         return var1;
      }
   }
}
