package com.elvencompanions.entity;

import com.elvencompanions.net.VfxS2C;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public final class ElfVfx {
   public static final int VERDANT = 1;
   public static final int SKYFALL = 2;
   public static final int VOLLEY = 3;
   public static final int WILDFIRE = 4;
   public static final int MOONFALL = 5;
   public static final int THORN = 6;
   public static final int HUNT = 7;
   public static final int GUARDIAN = 8;
   public static final int SEED = 9;
   public static final int RAGE = 10;
   public static final int STEALTH = 11;
   public static final int ASCEND = 12;
   public static final int ANNIHILATION = 13;
   public static final int CHRONO = 14;
   public static final int RICOCHET = 15;
   public static final int WORLD = 16;
   public static final int TRANSCEND = 20;
   public static final int STAR_HIT = 21;

   public static void send(ServerLevel var0, int var1, int var2, Vec3 var3, Vec3 var4, int var5, float var6) {
      Vec3 var7 = var4 == null ? var3 : var4;
      PacketDistributor.sendToPlayersNear(
         var0,
         null,
         var3.x,
         var3.y,
         var3.z,
         112.0,
         new VfxS2C(var1, var2, var3.x, var3.y, var3.z, var7.x, var7.y, var7.z, var5, var6),
         new CustomPacketPayload[0]
      );
   }

   public static void send(ServerLevel var0, int var1, ElfEntity var2, Vec3 var3, int var4, float var5) {
      send(var0, var1, var2.getId(), var2.position(), var3, var4, var5);
   }

   private ElfVfx() {
   }
}
