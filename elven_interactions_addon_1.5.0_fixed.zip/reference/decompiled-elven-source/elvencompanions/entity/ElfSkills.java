package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.ModRegistry;
import com.elvencompanions.logic.AnnihilationTrigger;
import com.elvencompanions.logic.TranscendMath;
import com.elvencompanions.net.ModNetwork;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow.Pickup;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

public class ElfSkills {
   public static final int VERDANT = 0;
   public static final int SKYFALL = 1;
   public static final int VOLLEY = 2;
   public static final int WILDFIRE = 3;
   public static final int MOONFALL = 4;
   public static final int THORN = 5;
   private static final int SKILLS = 6;
   public static final int A_ASCENDANCE = 6;
   public static final int A_HUNT = 7;
   public static final int A_GUARDIAN = 8;
   public static final int A_SEED = 9;
   public static final int A_ANNIHILATION = 10;
   public static final int A_RAGING = 11;
   public static final int A_STEALTH = 12;
   public static final int A_COUNT = 13;
   private static final ResourceLocation RAGE_SPEED_ID = ElvenCompanions.rl("rage_speed");
   private static final String[] KEYS = new String[]{
      "verdant_piercer", "skyfall_burst", "tenfold_volley", "wildfire_piercer", "moonfall_arrow_circle", "thornroot_snare"
   };
   private static final int[] ANIMS = new int[]{1, 2, 3, 4, 5, 1};
   private final ElfEntity elf;
   private final int[] cd = new int[6];
   private int ultCd;
   private int huntCd;
   private int guardianCd;
   private int seedCd;
   private int guardianClear;
   private boolean guardianLatch;
   private int annihilationCd;
   private int ragingCd;
   private int chronoCd;
   private final Set<Object> vfxSeen = Collections.newSetFromMap(new IdentityHashMap<>());
   private boolean flightMode;
   private boolean everTranscended;
   private boolean transcendHeld;
   private boolean forceTranscend;
   private float flightVy;
   private float flightSeed = (float)(Math.random() * 6.28);
   private int ricochetCd;
   private int worldCd;
   private boolean rageAnnihRolled;
   private boolean ascRolled;
   private int ascQuiet;
   private boolean flying;
   private int flightLost;
   private int flightCd;
   private int flightDir = 1;
   private int flightFlip;
   private Vec3 flightLastTarget;
   private int jumpPhase;
   private int jumpT;
   private int stuckT;
   private int jumpCd;
   private Vec3 stuckPos;
   private Vec3 jumpDir;
   private int ragingTicks;
   private int rageAnim;
   private boolean rageModApplied;
   private final AnnihilationTrigger trigger = new AnnihilationTrigger();
   private ElfSkills.Cast cinematic;
   private final List<ElfSkills.Cast> casts = new ArrayList<>();
   private final List<ElfSkills.Cast> pending = new ArrayList<>();
   private final List<ElfFx.Tick> fx = new ArrayList<>();
   private ElfSkills.Ultimate ult;
   private int explosionImmune;
   private int fallGuard;
   private static final double AREA_RADIUS = 20.0;
   private static final float AREA_SMALL_MAX_HEALTH = 80.0F;
   private static final int AREA_SMALL_COUNT = 8;
   private static final int CHRONO_COOLDOWN_SEC = 30;
   private static final int RICOCHET_COOLDOWN_SEC = 12;
   private static final int WORLD_COOLDOWN_SEC = 150;

   public ElfSkills(ElfEntity var1) {
      this.elf = var1;
   }

   public boolean isUltimate() {
      return this.ult != null || this.cinematic != null;
   }

   public boolean isRaging() {
      return this.ragingTicks > 0;
   }

   public int getRageTicks() {
      return this.ragingTicks;
   }

   public boolean isBusy() {
      for (ElfSkills.Cast var2 : this.casts) {
         if (var2.holds()) {
            return true;
         }
      }

      return false;
   }

   public boolean hasCast() {
      return !this.casts.isEmpty();
   }

   public boolean explosionImmune() {
      return this.explosionImmune > 0;
   }

   public boolean fallGuard() {
      return this.fallGuard > 0;
   }

   public void grantFallGuard(int var1) {
      this.fallGuard = Math.max(this.fallGuard, var1);
   }

   public void addFx(ElfFx.Tick var1) {
      this.fx.add(var1);
   }

   public int currentAnim() {
      if (this.ult != null) {
         return 6;
      } else {
         Iterator var1 = this.casts.iterator();
         if (var1.hasNext()) {
            ElfSkills.Cast var2 = (ElfSkills.Cast)var1.next();
            return var2.anim;
         } else {
            return this.rageAnim > 0 ? 8 : 0;
         }
      }
   }

   public int[] cooldownSeconds() {
      int[] var1 = new int[23];

      for (int var2 = 0; var2 < 6; var2++) {
         var1[var2] = (this.cd[var2] + 19) / 20;
      }

      var1[6] = (this.ultCd + 19) / 20;
      var1[7] = (this.huntCd + 19) / 20;
      var1[8] = (this.guardianCd + 19) / 20;
      var1[9] = (this.seedCd + 19) / 20;
      var1[10] = (this.annihilationCd + 19) / 20;
      var1[11] = (this.ragingCd + 19) / 20;
      var1[12] = (this.elf.defense.stealthRemaining() + 19) / 20;
      var1[13] = (this.chronoCd + 19) / 20;
      var1[14] = (this.ricochetCd + 19) / 20;
      var1[15] = (this.worldCd + 19) / 20;
      var1[16] = this.flightMode ? 1 : 0;
      var1[17] = this.elf.getElfLevel() >= 50 && this.elf.getXp() >= ElfLevel.transcendXp() ? 1 : 0;
      ElfNew.fillCooldowns(var1, this);
      return var1;
   }

   public static int totalChance(int var0) {
      double var1 = ElfLevel.chanceMult(var0);
      int[] var3 = baseChances();
      int var4 = 0;

      for (int var8 : var3) {
         var4 += (int)Math.round(var8 * var1);
      }

      return Math.min(100, var4);
   }

   private static int[] baseChances() {
      return new int[]{
         (Integer)ECConfig.chanceVerdant.get(),
         (Integer)ECConfig.chanceSkyfall.get(),
         (Integer)ECConfig.chanceVolley.get(),
         (Integer)ECConfig.chanceWildfire.get(),
         (Integer)ECConfig.chanceMoonfall.get(),
         (Integer)ECConfig.chanceThorn.get()
      };
   }

   public void save(CompoundTag var1) {
      var1.putIntArray("SkillCd", this.cd);
      var1.putInt("UltCd", this.ultCd);
      var1.putInt("HuntCd", this.huntCd);
      var1.putInt("GuardianCd", this.guardianCd);
      var1.putInt("SeedCd", this.seedCd);
      var1.putInt("AnnihilationCd", this.annihilationCd);
      var1.putInt("RagingCd", this.ragingCd);
      var1.putInt("RageTicks", this.ragingTicks);
      var1.putInt("ChronoCd", this.chronoCd);
      var1.putBoolean("FlightMode", this.flightMode);
      var1.putBoolean("EverTranscended", this.everTranscended);
      var1.putBoolean("TranscendHeld", this.transcendHeld);
      var1.putInt("RicochetCd", this.ricochetCd);
      var1.putInt("WorldCd", this.worldCd);
   }

   public void load(CompoundTag var1) {
      int[] var2 = var1.getIntArray("SkillCd");

      for (int var3 = 0; var3 < 6 && var3 < var2.length; var3++) {
         this.cd[var3] = Math.max(0, var2[var3]);
      }

      this.ultCd = Math.max(0, var1.getInt("UltCd"));
      this.huntCd = Math.max(0, var1.getInt("HuntCd"));
      this.guardianCd = Math.max(0, var1.getInt("GuardianCd"));
      this.seedCd = Math.max(0, var1.getInt("SeedCd"));
      this.annihilationCd = Math.max(0, var1.getInt("AnnihilationCd"));
      this.ragingCd = Math.max(0, var1.getInt("RagingCd"));
      this.ragingTicks = Math.max(0, var1.getInt("RageTicks"));
      this.chronoCd = Math.max(0, var1.getInt("ChronoCd"));
      this.flightMode = var1.getBoolean("FlightMode");
      this.everTranscended = var1.getBoolean("EverTranscended");
      this.transcendHeld = var1.getBoolean("TranscendHeld");
      this.ricochetCd = Math.max(0, var1.getInt("RicochetCd"));
      this.worldCd = Math.max(0, var1.getInt("WorldCd"));
      this.rageModApplied = false;
      this.cinematic = null;
      this.trigger.reset();
      this.casts.clear();
      this.pending.clear();
      this.fx.clear();
      this.ult = null;
      this.explosionImmune = 0;
      this.fallGuard = 0;
   }

   private int lv() {
      return this.elf.getElfLevel();
   }

   private double tMul() {
      return Math.min(
         6.0,
         TranscendMath.combined(
            this.elf.isTranscended(), (Double)ECConfig.transcendSpellMultiplier.get(), this.isRaging(), (Double)ECConfig.ragingMultiplier.get()
         )
      );
   }

   private double area() {
      return Math.min(8.0, ElfLevel.area(this.lv()) * this.tMul());
   }

   private double ultScale(double var1) {
      return 1.0 + (var1 - 1.0) * 0.6;
   }

   private float dmg(double var1) {
      double var3 = ElfLevel.skillDamage(this.lv()) * this.tMul();
      if ((Boolean)ECConfig.skillsUseArrowMultiplier.get()) {
         var3 *= this.elf.defense.isStealth() ? (Double)ECConfig.stealthArrowMultiplier.get() : (Double)ECConfig.arrowDamageMultiplier.get();
      }

      return ElfNew.scaleDmg((float)(var1 * var3), this);
   }

   private int cooldownTicks(int var1) {
      int var2 = switch (var1) {
         case 0 -> ECConfig.cdVerdant.get();
         case 1 -> ECConfig.cdSkyfall.get();
         case 2 -> ECConfig.cdVolley.get();
         case 3 -> ECConfig.cdWildfire.get();
         default -> ECConfig.cdMoonfall.get();
         case 5 -> ECConfig.cdThorn.get();
      };
      return (int)Math.round(var2 * 20 * ElfLevel.cooldownFactor(this.lv()));
   }

   public void tick() {
      ElfCombos.tick(this);

      for (int var1 = 0; var1 < 6; var1++) {
         if (this.cd[var1] > 0) {
            this.cd[var1]--;
         }
      }

      if (this.ultCd > 0) {
         this.ultCd--;
      }

      if (this.huntCd > 0) {
         this.huntCd--;
      }

      if (this.guardianCd > 0) {
         this.guardianCd--;
      }

      if (this.seedCd > 0) {
         this.seedCd--;
      }

      if (this.annihilationCd > 0) {
         this.annihilationCd--;
      }

      if (this.ragingCd > 0) {
         this.ragingCd--;
      }

      this.tickSupport();
      this.tickRaging();
      this.tickAnnihilationTrigger();

      try {
         this.tickExtras();
      } catch (RuntimeException var6) {
         ElvenCompanions.LOGGER.error("Elf extra behaviours failed", var6);
      }

      if (this.explosionImmune > 0) {
         this.explosionImmune--;
      }

      if (this.fallGuard > 0) {
         this.fallGuard--;
         if (this.elf.onGround() && this.fallGuard > 5) {
            this.fallGuard = 5;
         }
      }

      if (!this.fx.isEmpty()) {
         this.fx.removeIf(var0 -> {
            try {
               return var0.tick();
            } catch (RuntimeException var2x) {
               return true;
            }
         });
      }

      if (!this.casts.isEmpty()) {
         Iterator var7 = this.casts.iterator();

         while (var7.hasNext()) {
            ElfSkills.Cast var2 = (ElfSkills.Cast)var7.next();

            boolean var3;
            try {
               var3 = var2.tick();
            } catch (RuntimeException var5) {
               var3 = true;
               ElvenCompanions.LOGGER.error("Elf cast failed", var5);
            }

            if (var3) {
               var2.finish();
               var7.remove();
            }
         }

         if (!this.pending.isEmpty()) {
            ArrayList var8 = new ArrayList<>(this.pending);
            this.pending.clear();

            for (ElfSkills.Cast var4 : var8) {
               this.casts.add(var4);
               var4.start();
            }
         }
      }
   }

   private void tickExtras() {
      if (this.elf.level() instanceof ServerLevel && this.elf.isAlive()) {
         if (this.chronoCd > 0) {
            this.chronoCd--;
         }

         if (this.ricochetCd > 0) {
            this.ricochetCd--;
         }

         if (this.worldCd > 0) {
            this.worldCd--;
         }

         if (this.elf.isTranscended()) {
            this.everTranscended = true;
         }

         this.scanCastVfx();
         this.tickAreaTriggers();
         this.tickFlight();
         this.tickWallJump();
      }
   }

   private LivingEntity[] areaScan(int[] var1) {
      ServerLevel var2 = this.sl();
      List var3 = var2.getEntitiesOfClass(
         LivingEntity.class,
         this.elf.getBoundingBox().inflate(20.0),
         var1x -> var1x != this.elf && var1x.isAlive() && this.elf.isHostile(var1x) && var1x.distanceToSqr(this.elf) <= 400.0
      );
      LivingEntity var4 = null;
      int var5 = 0;
      int var6 = 0;

      for (LivingEntity var8 : var3) {
         if (var8.getMaxHealth() > 80.0F) {
            var6++;
            if (var4 == null || var8.getMaxHealth() > var4.getMaxHealth()) {
               var4 = var8;
            }
         } else {
            var5++;
         }
      }

      var1[0] = var5;
      var1[1] = var6;
      return new LivingEntity[]{var4};
   }

   private void tickAreaTriggers() {
      if (this.elf.tickCount % 20 == 7 && this.elf.getTarget() != null) {
         boolean var1 = this.isRaging();
         if (!var1) {
            this.rageAnnihRolled = false;
         }

         boolean var2 = this.elf.getHealth() <= this.elf.getMaxHealth() * 0.5F;
         if (!var1 && !var2) {
            this.ascQuiet += 20;
            if (this.ascQuiet >= 200) {
               this.ascRolled = false;
            }
         } else {
            int[] var3 = new int[2];
            LivingEntity var4 = this.areaScan(var3)[0];
            boolean var5 = var3[1] > 0 || var3[0] >= 8;
            if (!var5) {
               this.ascQuiet += 20;
               if (this.ascQuiet >= 200) {
                  this.ascRolled = false;
               }
            } else {
               this.ascQuiet = 0;
               RandomSource var6 = this.elf.getRandom();
               if (var1
                  && !this.rageAnnihRolled
                  && this.elf.isTranscended()
                  && (Boolean)ECConfig.annihilationEnabled.get()
                  && this.annihilationCd <= 0
                  && this.idleForCinematic()) {
                  this.rageAnnihRolled = true;
                  if (var6.nextDouble() < 0.5) {
                     Vec3 var7 = var4 != null ? var4.position() : this.pickAnnihilationImpact();
                     if (var7 != null) {
                        this.startAnnihilation(var7);
                        return;
                     }
                  }
               }

               if (var2 && !this.ascRolled && this.ult == null && this.ultCd == 0 && this.idleForCinematic()) {
                  this.ascRolled = true;
                  if (var6.nextDouble() < 0.25) {
                     this.startUltimate();
                  }
               }
            }
         }
      } else {
         if (!this.isRaging()) {
            this.rageAnnihRolled = false;
         }
      }
   }

   private double groundDistance() {
      for (double var1 = 0.5; var1 <= 16.0; var1 += 0.5) {
         if (!this.elf.level().noCollision(this.elf, this.elf.getBoundingBox().move(0.0, -var1, 0.0))) {
            return var1 - 0.5;
         }
      }

      return 16.0;
   }

   public boolean isFlying() {
      return this.flying;
   }

   public float chargeDamage() {
      return this.dmg(12.0);
   }

   public void extraCommand(ServerPlayer var1, ElfAction var2) {
      switch (var2) {
         case FLIGHT_TOGGLE:
            this.flightMode = !this.flightMode;
            var1.displayClientMessage(
               Component.translatable(
                  this.flightMode ? "message.elven_companions.flight_on" : "message.elven_companions.flight_off", new Object[]{this.elf.getName()}
               ),
               true
            );
            if (!this.flightMode && this.flying && this.elf.getTarget() == null) {
               this.flightLost = 41;
            }
            break;
         case TRANSCEND_STOP:
            if (this.elf.isTranscended()) {
               this.cancelAll();
               this.transcendHeld = true;
               this.elf.setTranscended(false);
               this.elf.setNoGravity(false);
               this.stopRagingNow();
               this.grantFallGuard(160);
               this.elf.level().playSound(null, this.elf.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.NEUTRAL, 1.4F, 1.0F);
               ElfFx.ring(this.sl(), ElfFx.moon(), this.elf.getX(), this.elf.getY() + 0.3, this.elf.getZ(), 0.6, 36, 0.3, 0.05);
               var1.displayClientMessage(Component.translatable("message.elven_companions.transcend_stopped", new Object[]{this.elf.getName()}), true);
            }
            break;
         case TRANSCEND_START:
            if (!this.elf.isTranscended()) {
               this.transcendHeld = false;
               this.forceTranscend = true;
               boolean var3 = this.tryStartTranscend();
               this.forceTranscend = false;
               var1.displayClientMessage(
                  Component.translatable(
                     var3 ? "message.elven_companions.transcend_started" : "message.elven_companions.transcend_unavailable", new Object[]{this.elf.getName()}
                  ),
                  true
               );
            }
            break;
         case TRANSCEND_START_INSTANT:
            if (!this.elf.isTranscended() && this.elf.getElfLevel() >= 50 && this.elf.getXp() >= ElfLevel.transcendXp() && this.casts.isEmpty()) {
               this.transcendHeld = false;
               this.elf.setTranscended(true);
               this.elf.level().playSound(null, this.elf.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.NEUTRAL, 1.6F, 1.2F);
               ElfFx.ring(this.sl(), ElfFx.gold(), this.elf.getX(), this.elf.getY() + 0.3, this.elf.getZ(), 0.6, 40, 0.4, 0.05);
               ElfFx.burst(this.sl(), ElfFx.star(), this.elf.getX(), this.elf.getY() + 1.0, this.elf.getZ(), 40, 0.4);
               var1.displayClientMessage(Component.translatable("message.elven_companions.transcend_started", new Object[]{this.elf.getName()}), true);
            } else {
               var1.displayClientMessage(Component.translatable("message.elven_companions.transcend_unavailable", new Object[]{this.elf.getName()}), true);
            }
      }
   }

   private void stopRagingNow() {
      this.ragingTicks = 0;
      this.elf.setRageTicksSync(0);
   }

   private boolean flightAllowed() {
      return this.elf.getRestState() == 0 && !this.elf.isMounted() && !this.elf.isCarried() && !this.elf.isPassenger() && !this.elf.isInWater();
   }

   private void tickFlight() {
      if (this.flightCd > 0) {
         this.flightCd--;
      }

      LivingEntity var1 = this.elf.getTarget();
      boolean var2 = this.elf.isTranscended()
         && var1 != null
         && var1.isAlive()
         && this.elf.isHostile(var1)
         && this.elf.canFight()
         && this.flightAllowed()
         && this.elf.distanceToSqr(var1) <= 2500.0;
      Player var3 = this.elf.getOwnerPlayer();
      boolean var4 = !var2
         && this.flightMode
         && this.elf.isTranscended()
         && this.flightAllowed()
         && this.elf.getStance() == 0
         && var3 != null
         && var3.level() == this.elf.level()
         && this.elf.distanceToSqr(var3) < 4096.0;
      boolean var5 = var2 || var4;
      if (var2) {
         this.flightLastTarget = var1.position();
      }

      if (var5) {
         this.flightLost = 0;
      } else if (this.flying) {
         this.flightLost++;
      }

      boolean var6 = this.isBusy() || this.elf.defense.isChargeStriking();
      if (!this.flying) {
         if (var5 && this.flightCd <= 0 && this.jumpPhase == 0 && !this.isUltimate() && !var6 && this.elf.onGround()) {
            this.flying = true;
            this.flightFlip = 60 + this.elf.getRandom().nextInt(80);
            this.flightDir = this.elf.getRandom().nextBoolean() ? 1 : -1;
            this.flightVy = 0.0F;
            this.elf.setNoGravity(true);
            this.elf.setDeltaMovement(this.elf.getDeltaMovement().x, 0.42, this.elf.getDeltaMovement().z);
            this.snd(SoundEvents.PHANTOM_SWOOP, 0.8F, 1.3F);
            ElfFx.ring(this.sl(), ElfFx.green(), this.elf.getX(), this.elf.getY() + 0.2, this.elf.getZ(), 0.8, 20, 0.2, 0.03);
         }
      } else if (this.elf.isTranscended() && !this.isUltimate() && this.flightLost <= 40 && this.flightAllowed()) {
         this.elf.setNoGravity(true);
         this.elf.fallDistance = 0.0F;
         if (!var6 && !this.elf.defense.isDashing()) {
            Vec3 var7 = this.elf.position();
            Vec3 var8 = var2 ? var1.position() : (var4 ? var3.position() : this.flightLastTarget);
            if (var8 == null) {
               this.endFlight();
            } else {
               double var9 = var8.x - var7.x;
               double var11 = var8.z - var7.z;
               double var13 = Math.sqrt(var9 * var9 + var11 * var11);
               double var15 = var13 > 0.001 ? var9 / var13 : 1.0;
               double var17 = var13 > 0.001 ? var11 / var13 : 0.0;
               double var19 = this.groundDistance();
               double var21 = this.elf.tickCount;
               double var23 = 0.55 * Math.sin(var21 * 0.045 + this.flightSeed) + 0.25 * Math.sin(var21 * 0.113 + this.flightSeed * 1.7);
               double var25 = (var5 ? (var2 ? 4.2 : 3.2) : 0.0) + (var5 ? var23 : 0.0);
               double var27 = var19 >= 16.0 ? 0.0 : Mth.clamp((var25 - var19) * 0.09, -0.12, 0.14);
               if (var27 > 0.0 && !this.elf.level().noCollision(this.elf, this.elf.getBoundingBox().move(0.0, var27 + 0.4, 0.0))) {
                  var27 = 0.0;
               }

               this.flightVy = this.flightVy * 0.88F + (float)var27 * 0.12F;
               if (--this.flightFlip <= 0) {
                  this.flightDir = -this.flightDir;
                  this.flightFlip = 90 + this.elf.getRandom().nextInt(100);
               }

               double var29;
               double var31;
               if (var2) {
                  double var33 = 15.0;
                  double var35 = Mth.clamp((var13 - var33) * 0.035, -0.18, 0.08);
                  double var37 = 0.11 * this.flightDir * (0.75 + 0.25 * Math.sin(var21 * 0.07));
                  var29 = var15 * var35 + -var17 * var37;
                  var31 = var17 * var35 + var15 * var37;
               } else if (var4) {
                  double var39 = Mth.clamp((var13 - 4.5) * 0.06, -0.06, 0.38);
                  double var41 = 0.025 * Math.sin(var21 * 0.06 + this.flightSeed);
                  var29 = var15 * var39 + -var17 * var41;
                  var31 = var17 * var39 + var15 * var41;
               } else {
                  var29 = 0.0;
                  var31 = 0.0;
               }

               Vec3 var40 = this.elf.getDeltaMovement();
               double var34 = var40.x * 0.72 + var29 * 0.28;
               double var36 = var40.z * 0.72 + var31 * 0.28;
               if (!this.elf.level().noCollision(this.elf, this.elf.getBoundingBox().move(var34 * 4.0, 0.0, var36 * 4.0))) {
                  this.flightDir = -this.flightDir;
                  var34 = 0.0;
                  var36 = 0.0;
               }

               this.elf.setDeltaMovement(var34, this.flightVy, var36);
               this.elf.hasImpulse = true;
               this.elf.getNavigation().stop();
               if (var2) {
                  this.elf.lookAt(var1, 30.0F, 30.0F);
               } else if (var4 && var13 > 0.5) {
                  this.elf.getLookControl().setLookAt(var8.x, var7.y + 1.6, var8.z);
               }

               if (this.elf.tickCount % 24 == 0) {
                  this.snd(SoundEvents.PHANTOM_FLAP, 0.3F, 1.5F);
               }

               if (this.elf.tickCount % 3 == 0) {
                  ElfFx.p(this.sl(), ElfFx.star(), var7.x - var15 * 0.3, var7.y + 0.9, var7.z - var17 * 0.3, 1, 0.35, 0.4, 0.35, 0.0);
                  if (this.elf.tickCount % 6 == 0) {
                     ElfFx.p(this.sl(), ElfFx.leaf(), var7.x, var7.y + 1.2, var7.z, 1, 0.5, 0.2, 0.5, 0.0);
                  }
               }

               if (!var5 && var19 < 1.0 && this.elf.onGround()) {
                  this.endFlight();
               }
            }
         }
      } else {
         this.endFlight();
      }
   }

   private void endFlight() {
      if (this.flying) {
         this.flying = false;
         this.flightLost = 0;
         this.flightCd = 60;
         this.elf.setNoGravity(false);
         this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, false, false));
         this.grantFallGuard(120);
      }
   }

   private void tickWallJump() {
      if (this.jumpCd > 0) {
         this.jumpCd--;
      }

      if (!this.flying
         && !this.isBusy()
         && !this.isUltimate()
         && this.elf.getRestState() == 0
         && !this.elf.isMounted()
         && !this.elf.isCarried()
         && !this.elf.isPassenger()) {
         ServerLevel var1 = this.sl();
         Vec3 var2 = this.elf.position();
         if (this.jumpPhase == 0) {
            LivingEntity var20 = this.elf.getTarget();
            Vec3 var4 = null;
            if (var20 != null && var20.isAlive()) {
               var4 = var20.position();
            } else if (this.elf.getOwnerPlayer() != null && this.elf.getStance() == 0) {
               var4 = this.elf.getOwnerPlayer().position();
            }

            if (var4 != null && this.elf.onGround() && this.jumpCd <= 0) {
               double var5 = var4.x - var2.x;
               double var7 = var4.z - var2.z;
               double var9 = Math.sqrt(var5 * var5 + var7 * var7);
               if (!(var9 < 3.0) && this.stuckPos != null && !(var2.distanceToSqr(this.stuckPos) > 0.04)) {
                  if (++this.stuckT >= 12) {
                     this.stuckT = 0;
                     double var11 = var5 / var9;
                     double var13 = var7 / var9;
                     AABB var15 = this.elf.getBoundingBox();
                     boolean var16 = !var1.noCollision(this.elf, var15.move(var11 * 0.7, 0.0, var13 * 0.7));
                     boolean var17 = !var1.noCollision(this.elf, var15.move(var11 * 0.7, 1.6, var13 * 0.7));
                     boolean var18 = var1.noCollision(this.elf, var15.move(var11 * 0.7, 2.4, var13 * 0.7));
                     if (var16 && var17 && var18) {
                        this.jumpDir = new Vec3(var11, 0.0, var13);
                        this.jumpPhase = 1;
                        this.jumpT = 0;
                        this.grantFallGuard(120);
                        Vec3 var19 = this.elf.getDeltaMovement();
                        this.elf.setDeltaMovement(var19.x + var11 * 0.08, 0.5, var19.z + var13 * 0.08);
                        this.elf.hasImpulse = true;
                        this.elf.getNavigation().stop();
                        this.snd(SoundEvents.PHANTOM_FLAP, 0.7F, 1.2F);
                     }
                  }
               } else {
                  this.stuckPos = var2;
                  this.stuckT = 0;
               }
            } else {
               this.stuckT = 0;
               this.stuckPos = var2;
            }
         } else {
            this.jumpT++;
            this.elf.getNavigation().stop();
            Vec3 var3 = this.elf.getDeltaMovement();
            if (this.jumpPhase == 1) {
               if (this.jumpT >= 4 && var3.y <= 0.12 || this.jumpT > 10) {
                  this.jumpPhase = 2;
                  this.jumpT = 0;
                  this.elf.setDeltaMovement(var3.x + this.jumpDir.x * 0.3, 0.5, var3.z + this.jumpDir.z * 0.3);
                  this.elf.hasImpulse = true;
                  ElfFx.ring(var1, ElfFx.green(), var2.x, var2.y + 0.2, var2.z, 0.7, 16, 0.15, 0.02);
                  this.snd(SoundEvents.PHANTOM_SWOOP, 0.6F, 1.5F);
               }
            } else {
               this.elf.setDeltaMovement(this.jumpDir.x * 0.42, var3.y, this.jumpDir.z * 0.42);
               this.elf.hasImpulse = true;
               if (this.jumpT % 2 == 0) {
                  ElfFx.p(var1, ElfFx.green(), var2.x, var2.y + 0.6, var2.z, 2, 0.2, 0.3, 0.2, 0.0);
               }

               if (this.jumpT > 3 && this.elf.onGround() || this.jumpT > 50) {
                  this.jumpPhase = 0;
                  this.jumpCd = 40;
                  this.stuckPos = this.elf.position();
               }
            }
         }
      } else {
         this.jumpPhase = 0;
         this.stuckT = 0;
      }
   }

   private int extraCd(int var1) {
      return (int)Math.round(var1 * 20 * ElfLevel.cooldownFactor(this.lv()));
   }

   private boolean canCastExtra(LivingEntity var1) {
      return this.ult == null
         && this.cinematic == null
         && this.casts.isEmpty()
         && !this.elf.isMounted()
         && this.elf.getRestState() == 0
         && !this.elf.defense.isDrinking()
         && !this.elf.defense.isEscaping()
         && var1 != null
         && var1.isAlive();
   }

   private boolean tryExtraSkills(LivingEntity var1, RandomSource var2) {
      if (this.canCastExtra(var1) && this.elf.getSensing().hasLineOfSight(var1) && !(this.elf.distanceToSqr(var1) > 1024.0)) {
         double var3 = ElfLevel.chanceMult(this.lv());
         int[] var5 = new int[2];
         this.areaScan(var5);
         if (this.elf.isTranscended() && this.worldCd <= 0 && (var5[1] > 0 || var5[0] >= 6) && var2.nextDouble() < 0.06 * var3) {
            return this.startExtra(15, var1, false);
         } else if (this.lv() >= 12 && this.chronoCd <= 0 && var2.nextDouble() < 0.05 * var3) {
            return this.startExtra(13, var1, false);
         } else {
            double var6 = var5[0] + var5[1] >= 3 ? 0.12 : 0.07;
            return this.lv() >= 6 && this.ricochetCd <= 0 && var2.nextDouble() < var6 * var3 ? this.startExtra(14, var1, false) : false;
         }
      } else {
         return false;
      }
   }

   private ElfSkills.ManualResult manualExtra(int var1, boolean var2) {
      if (!this.casts.isEmpty()) {
         return ElfSkills.ManualResult.BUSY;
      } else {
         int var3 = var1 == 13 ? this.chronoCd : (var1 == 14 ? this.ricochetCd : this.worldCd);
         if (var1 == 15 && !this.elf.isTranscended()) {
            return ElfSkills.ManualResult.LOCKED;
         } else if (!var2 && var3 > 0) {
            return ElfSkills.ManualResult.COOLDOWN;
         } else {
            LivingEntity var4 = this.elf.nearestHostile(((Integer)ECConfig.attackRange.get()).intValue());
            if (var4 == null) {
               return ElfSkills.ManualResult.NO_TARGET;
            } else {
               return this.canCastExtra(var4) && this.startExtra(var1, var4, var2) ? ElfSkills.ManualResult.OK : ElfSkills.ManualResult.INVALID;
            }
         }
      }
   }

   private boolean startExtra(int var1, LivingEntity var2, boolean var3) {
      Object var4;
      String var5;
      if (var1 == 13) {
         var4 = new ElfSkills.ChronoLock(var2);
         var5 = "chrono_lock";
         ((ElfSkills.Cast)var4).anim = ANIMS[2];
      } else if (var1 == 14) {
         var4 = new ElfSkills.Ricochet(var2);
         var5 = "starlit_ricochet";
         ((ElfSkills.Cast)var4).anim = ANIMS[0];
      } else {
         var4 = new ElfSkills.WorldWrath();
         var5 = "worldtree_wrath";
         ((ElfSkills.Cast)var4).anim = ANIMS[4];
      }

      if (var1 == 13) {
         this.chronoCd = this.extraCd(30);
      } else if (var1 == 14) {
         this.ricochetCd = this.extraCd(12);
      } else {
         this.worldCd = this.extraCd(150);
      }

      this.casts.add((ElfSkills.Cast)var4);
      this.announce(var5, ((Integer)ECConfig.announceRadius.get()).intValue());
      this.elf.level().playSound(null, this.elf.blockPosition(), (SoundEvent)ModRegistry.SND_SKILL.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
      ((ElfSkills.Cast)var4).start();
      ElfNew.onExtra(this, var1, var2);
      this.elf.voice.onSkill();
      return true;
   }

   private static void beam(ServerLevel var0, Vec3 var1, Vec3 var2, ParticleOptions var3) {
      double var4 = var1.distanceTo(var2);
      int var6 = Math.max(2, (int)(var4 / 0.45));

      for (int var7 = 0; var7 <= var6; var7++) {
         Vec3 var8 = var1.lerp(var2, (double)var7 / var6);
         ElfFx.p(var0, var3, var8.x, var8.y, var8.z, 1, 0.03, 0.03, 0.03, 0.0);
      }
   }

   private void scanCastVfx() {
      this.vfxSeen.retainAll(this.casts);

      for (ElfSkills.Cast var2 : new ArrayList<>(this.casts)) {
         if (this.vfxSeen.add(var2)) {
            this.castVfx(var2);
         }
      }
   }

   private void castVfx(ElfSkills.Cast var1) {
      ServerLevel var2 = this.sl();
      Vec3 var3 = this.elf.position();
      Vec3 var4 = ElfFx.handPos(this.elf);
      Vec3 var5 = this.elf.getLookAngle();
      int var6 = this.elf.getId();
      if (var1 instanceof ElfSkills.Piercer var7) {
         ElfVfx.send(var2, var7.fire ? 4 : 1, -1, var7.pos, var7.pos.add(var7.dir.scale(30.0)), 16, 1.0F);
      } else if (var1 instanceof ElfSkills.Volley) {
         ElfVfx.send(var2, 3, -1, var4, var4.add(var5.x * 16.0, var5.y * 4.0, var5.z * 16.0), 18, 1.0F);
      } else if (var1 instanceof ElfSkills.Skyfall) {
         ElfVfx.send(var2, 2, var6, var3, null, 36, 1.0F);
      } else if (var1 instanceof ElfSkills.Moonfall var8) {
         ElfVfx.send(var2, 5, -1, var8.center, null, 80, (float)(var8.radius / 5.5));
      } else if (var1 instanceof ElfSkills.Thorn var9) {
         ElfVfx.send(var2, 6, -1, var9.target.position(), null, Math.min(120, var9.duration), (float)(var9.radius / 4.0));
      } else if (var1 instanceof ElfSkills.Hunt) {
         ElfVfx.send(var2, 7, var6, var3, null, 60, 1.0F);
      } else if (var1 instanceof ElfSkills.Ultimate) {
         ElfVfx.send(var2, 12, var6, var3, null, 110, 1.0F);
      } else if (var1 instanceof ElfSkills.Annihilation var10) {
         ElfVfx.send(var2, 13, -1, var10.impact, null, var10.impactAt + 12, 1.0F);
      } else if (var1 instanceof ElfSkills.Transcend) {
         ElfVfx.send(var2, 20, var6, var3, null, 200, 1.0F);
      } else if (var1 instanceof ElfSkills.ChronoLock) {
         ElfVfx.send(var2, 14, var6, var3, null, 66, 1.0F);
      } else if (var1 instanceof ElfSkills.WorldWrath) {
         ElfVfx.send(var2, 16, -1, var3, null, 150, 1.0F);
      }
   }

   public void cancelAll() {
      this.endFlight();
      this.jumpPhase = 0;

      for (ElfSkills.Cast var2 : new ArrayList<>(this.casts)) {
         var2.finish();
      }

      this.casts.clear();
      this.pending.clear();
      this.ult = null;
      this.cinematic = null;
      this.removeRageModifier();
   }

   public void onDeath() {
      this.ragingTicks = 0;
      this.elf.setRageTicksSync(0);
      this.removeRageModifier();
   }

   public void onBasicShot(LivingEntity var1) {
      if (this.elf.level() instanceof ServerLevel && this.ult == null && var1 != null) {
         RandomSource var2 = this.elf.getRandom();
         if (this.ultCd == 0
            && this.elf.getHealth() < ((Double)ECConfig.ultHealthBelow.get()).floatValue()
            && this.elf.isValidTarget(var1)
            && var2.nextDouble() < (Double)ECConfig.ultAttemptChance.get() * ElfLevel.lerp(1.0, 2.0, this.lv())) {
            double var11 = Math.min(0.9, (Double)ECConfig.ultSuccessChance.get() + ElfLevel.lerp(0.0, 0.25, this.lv()));
            if (var2.nextDouble() < var11) {
               this.startUltimate();
            } else {
               this.ultCd = ECConfig.ticks(ECConfig.ultRetryCooldownSec);
            }
         } else if (!this.maybeStartHunt()) {
            if (this.tryExtraSkills(var1, var2)) {
               return;
            }

            double var3 = ElfLevel.chanceMult(this.lv());
            int[] var5 = baseChances();
            int[] var6 = new int[6];
            int var7 = 0;

            for (int var8 = 0; var8 < 6; var8++) {
               var6[var8] = (int)Math.round(var5[var8] * var3);
               var7 += var6[var8];
            }

            if (var7 > 100) {
               for (int var12 = 0; var12 < 6; var12++) {
                  var6[var12] = var6[var12] * 100 / var7;
               }
            }

            int var13 = var2.nextInt(100);
            int var9 = 0;

            for (int var10 = 0; var10 < 6; var10++) {
               var9 += var6[var10];
               if (var13 < var9) {
                  this.activate(var10, var1, false);
                  return;
               }
            }
         }
      }
   }

   public boolean manual(int var1) {
      if (var1 >= 0 && var1 < 6) {
         LivingEntity var2 = this.elf.nearestHostile(((Integer)ECConfig.attackRange.get()).intValue());
         return var2 != null && this.activate(var1, var2, false);
      } else {
         return false;
      }
   }

   private Supplier<ElfSkills.Cast> factory(int var1, LivingEntity var2) {
      return switch (var1) {
         case 0 -> () -> this.piercer(false, var2);
         case 1 -> this::skyfall;
         case 2 -> () -> this.volley(var2);
         case 3 -> () -> this.piercer(true, var2);
         default -> this::moonfall;
         case 5 -> () -> this.thorn(var2);
      };
   }

   private boolean activate(int var1, LivingEntity var2, boolean var3) {
      if ((var3 || this.cd[var1] <= 0)
         && this.ult == null
         && this.cinematic == null
         && this.casts.isEmpty()
         && !this.elf.isMounted()
         && this.elf.getRestState() == 0
         && !this.elf.defense.isDrinking()
         && !this.elf.defense.isEscaping()
         && var2.isAlive()) {
         Supplier var4 = this.factory(var1, var2);
         Object var5 = (ElfSkills.Cast)var4.get();
         if (var5 == null) {
            return false;
         } else {
            boolean var6 = false;
            if (var1 != 1 && this.elf.getRandom().nextDouble() < (Double)ECConfig.airVariantChance.get() && this.canAirVariant()) {
               var5 = new ElfSkills.AirVariant(var4);
               var6 = true;
            }

            ((ElfSkills.Cast)var5).anim = var6 ? 2 : ANIMS[var1];
            this.cd[var1] = this.cooldownTicks(var1);
            this.casts.add((ElfSkills.Cast)var5);
            this.announce(KEYS[var1], ((Integer)ECConfig.announceRadius.get()).intValue());
            this.elf.level().playSound(null, this.elf.blockPosition(), (SoundEvent)ModRegistry.SND_SKILL.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
            ((ElfSkills.Cast)var5).start();
            ElfCombos.onActivated(this, var1, var2);
            this.elf.voice.onSkill();
            return true;
         }
      } else {
         return false;
      }
   }

   private ServerLevel sl() {
      return (ServerLevel)this.elf.level();
   }

   private void announce(String var1, double var2) {
      MutableComponent var4 = Component.empty()
         .append(this.elf.getDisplayName())
         .append(": ")
         .append(Component.translatable("skill.elven_companions." + var1))
         .append("!");
      this.bar(var4, var2);
   }

   private void bar(Component var1, double var2) {
      for (ServerPlayer var5 : this.sl().players()) {
         if (var5.distanceToSqr(this.elf) <= var2 * var2) {
            var5.displayClientMessage(var1, true);
         }
      }
   }

   private void hurt(LivingEntity var1, float var2) {
      var1.invulnerableTime = 0;
      DamageSource var3 = this.elf.damageSources().mobProjectile(this.elf, this.elf);
      var1.hurt(var3, var2);
      this.elf.noteDamaged(var1);
   }

   private double riseAvailable() {
      double var1 = (Double)ECConfig.skyfallJumpHeight.get();

      for (double var3 = 0.25; var3 <= var1 + 0.5; var3 += 0.25) {
         if (!this.elf.level().noCollision(this.elf, this.elf.getBoundingBox().move(0.0, var3, 0.0))) {
            return Math.min(var1, var3 - 0.5);
         }
      }

      return var1;
   }

   private boolean canAirVariant() {
      return this.elf.onGround() && !this.elf.isInWater() && this.riseAvailable() >= 2.5;
   }

   private ElfSkills.Cast piercer(boolean var1, LivingEntity var2) {
      if (var2.isAlive() && !(this.elf.distanceToSqr(var2) > 2304.0) && this.elf.getSensing().hasLineOfSight(var2)) {
         Vec3 var3 = this.elf.getEyePosition().add(0.0, -0.15, 0.0);
         Vec3 var4 = var2.position().add(0.0, var2.getBbHeight() * 0.5, 0.0).subtract(var3).normalize();
         return new ElfSkills.Piercer(var1, var3, var4);
      } else {
         return null;
      }
   }

   private ElfSkills.Cast volley(LivingEntity var1) {
      return var1.isAlive() && !(this.elf.distanceToSqr(var1) > 1600.0) && this.elf.getSensing().hasLineOfSight(var1) ? new ElfSkills.Volley(var1) : null;
   }

   private ElfSkills.Cast skyfall() {
      if (this.elf.onGround() && !this.elf.isInWater() && !this.elf.isMounted()) {
         LivingEntity var1 = this.elf.nearestHostile(((Integer)ECConfig.attackRange.get()).intValue());
         if (var1 == null) {
            return null;
         } else {
            double var2 = this.riseAvailable();
            return var2 < 2.0 ? null : new ElfSkills.Skyfall(var1, this.elf.getY() + var2);
         }
      } else {
         return null;
      }
   }

   private ElfSkills.Cast moonfall() {
      LivingEntity var1 = this.elf.nearestHostile(32.0);
      return var1 == null ? null : new ElfSkills.Moonfall(var1.position());
   }

   private void sendNear(Vec3 var1, double var2, CustomPacketPayload var4) {
      var2 *= ElfNew.nearScale(this, var4);
      PacketDistributor.sendToPlayersNear(this.sl(), null, var1.x, var1.y, var1.z, var2, var4, new CustomPacketPayload[0]);
   }

   private void snd(SoundEvent var1, float var2, float var3) {
      this.sl().playSound(null, this.elf.getX(), this.elf.getY(), this.elf.getZ(), var1, SoundSource.NEUTRAL, var2, var3);
   }

   private boolean idleForCinematic() {
      return this.elf.isAlive()
         && this.casts.isEmpty()
         && this.ult == null
         && this.cinematic == null
         && this.elf.getRestState() == 0
         && !this.elf.isMounted()
         && !this.elf.defense.isEscaping()
         && !this.elf.defense.isDrinking()
         && this.elf.level() instanceof ServerLevel;
   }

   private void magicCircle(Vec3 var1, double var2, double var4, ParticleOptions var6, ParticleOptions var7) {
      ServerLevel var8 = this.sl();

      for (int var9 = 0; var9 < 36; var9++) {
         double var10 = var4 + var9 * Math.PI * 2.0 / 36.0;
         ElfFx.p(var8, var6, var1.x + Math.cos(var10) * var2, var1.y + 0.1, var1.z + Math.sin(var10) * var2, 1, 0.0, 0.0, 0.0, 0.0);
      }

      for (int var18 = 0; var18 < 20; var18++) {
         double var21 = -var4 * 1.3 + var18 * Math.PI * 2.0 / 20.0;
         ElfFx.p(var8, var7, var1.x + Math.cos(var21) * var2 * 0.72, var1.y + 0.1, var1.z + Math.sin(var21) * var2 * 0.72, 1, 0.0, 0.0, 0.0, 0.0);
      }

      for (int var19 = 0; var19 < 2; var19++) {
         for (int var22 = 0; var22 < 3; var22++) {
            double var11 = var4 * 0.5 + var19 * Math.PI / 3.0 + var22 * 2 * Math.PI / 3.0;
            double var13 = var11 + (Math.PI * 2.0 / 3.0);

            for (int var15 = 0; var15 < 5; var15++) {
               double var16 = var15 / 5.0;
               ElfFx.p(
                  var8,
                  var7,
                  var1.x + var2 * 0.72 * (Math.cos(var11) * (1.0 - var16) + Math.cos(var13) * var16),
                  var1.y + 0.12,
                  var1.z + var2 * 0.72 * (Math.sin(var11) * (1.0 - var16) + Math.sin(var13) * var16),
                  1,
                  0.0,
                  0.0,
                  0.0,
                  0.0
               );
            }
         }
      }

      for (int var20 = 0; var20 < 12; var20++) {
         double var23 = var4 * 0.4 + var20 * Math.PI / 6.0;

         for (double var12 = 0.86; var12 < 1.0; var12 += 0.07) {
            ElfFx.p(var8, var6, var1.x + Math.cos(var23) * var2 * var12, var1.y + 0.12, var1.z + Math.sin(var23) * var2 * var12, 1, 0.0, 0.0, 0.0, 0.0);
         }
      }
   }

   public boolean tryStartTranscend() {
      if ((!this.transcendHeld || this.forceTranscend)
         && !this.elf.isTranscended()
         && this.elf.getElfLevel() >= 50
         && this.elf.getXp() >= ElfLevel.transcendXp()
         && this.idleForCinematic()) {
         ElfSkills.Transcend var1 = new ElfSkills.Transcend();
         var1.anim = 9;
         this.casts.add(var1);
         var1.start();
         return true;
      } else {
         return false;
      }
   }

   private int annihilationHeight() {
      double var1 = Math.min((double)((Integer)ECConfig.annihilationHeight.get()).intValue(), this.sl().getMaxBuildHeight() - 6 - this.elf.getY());
      int var3 = 0;

      for (byte var4 = 2; var4 <= var1 && this.elf.level().noCollision(this.elf, this.elf.getBoundingBox().move(0.0, var4, 0.0)); var4 += 2) {
         var3 = var4;
      }

      var3 -= 2;
      return var3 >= 30 ? (int)Math.min((double)var3, var1) : 0;
   }

   @Nullable
   private Vec3 pickAnnihilationImpact() {
      ServerLevel var1 = this.sl();
      if (this.trigger.tracked() != null && var1.getEntity(this.trigger.tracked()) instanceof LivingEntity var2 && var2.isAlive() && this.elf.isHostile(var2)) {
         return var2.position();
      } else {
         List var11 = var1.getEntitiesOfClass(
            LivingEntity.class, this.elf.getBoundingBox().inflate(32.0), var1x -> this.elf.isHostile(var1x) && var1x.distanceToSqr(this.elf) <= 1024.0
         );
         if (var11.isEmpty()) {
            return null;
         } else {
            if (var11.size() > 160) {
               var11 = var11.subList(0, 160);
            }

            LivingEntity var4 = null;
            int var5 = -1;

            for (LivingEntity var7 : var11) {
               int var8 = 0;

               for (LivingEntity var10 : var11) {
                  if (var7.distanceToSqr(var10) <= 100.0) {
                     var8++;
                  }
               }

               if (var8 > var5) {
                  var5 = var8;
                  var4 = var7;
               }
            }

            return var4.position();
         }
      }
   }

   public boolean startAnnihilation(Vec3 var1) {
      if ((Boolean)ECConfig.annihilationEnabled.get() && this.elf.isTranscended() && this.idleForCinematic()) {
         int var2 = this.annihilationHeight();
         if (var2 <= 0) {
            return false;
         } else {
            this.annihilationCd = ECConfig.ticks(ECConfig.annihilationCooldownSec);
            this.trigger.reset();
            ElfSkills.Annihilation var3 = new ElfSkills.Annihilation(var1, var2);
            var3.anim = 10;
            this.casts.add(var3);
            this.announce("celestial_annihilation", 80.0);
            var3.start();
            ElfNew.onAnnih(this, var1);
            return true;
         }
      } else {
         return false;
      }
   }

   private void markBoss(LivingEntity var1) {
      ServerLevel var2 = this.sl();
      double var3 = this.elf.tickCount * 0.08;
      double var5 = Math.max(1.4, var1.getBbWidth() * 0.9);

      for (int var7 = 0; var7 < 14; var7++) {
         double var8 = var3 + var7 * Math.PI * 2.0 / 14.0;
         ElfFx.p(var2, ElfFx.moon(), var1.getX() + Math.cos(var8) * var5, var1.getY() + 0.1, var1.getZ() + Math.sin(var8) * var5, 1, 0.0, 0.0, 0.0, 0.0);
      }

      for (int var16 = 0; var16 < 2; var16++) {
         for (int var17 = 0; var17 < 3; var17++) {
            double var9 = -var3 + var16 * Math.PI / 3.0 + var17 * 2 * Math.PI / 3.0;
            double var11 = var9 + (Math.PI * 2.0 / 3.0);

            for (int var13 = 0; var13 < 4; var13++) {
               double var14 = var13 / 4.0;
               ElfFx.p(
                  var2,
                  ElfFx.star(),
                  var1.getX() + var5 * (Math.cos(var9) * (1.0 - var14) + Math.cos(var11) * var14),
                  var1.getY() + var1.getBbHeight() + 0.6,
                  var1.getZ() + var5 * (Math.sin(var9) * (1.0 - var14) + Math.sin(var11) * var14),
                  1,
                  0.0,
                  0.0,
                  0.0,
                  0.0
               );
            }
         }
      }
   }

   private void tickAnnihilationTrigger() {
      if (this.elf.tickCount % 10 == 0 && this.elf.level() instanceof ServerLevel var1) {
         if ((Boolean)ECConfig.annihilationEnabled.get() && this.elf.isTranscended() && this.elf.isAlive()) {
            LivingEntity var9 = this.elf.getTarget();
            UUID var3 = null;
            double var4 = ((Integer)ECConfig.attackRange.get()).intValue() * 1.5;
            if (var9 != null
               && var9.isAlive()
               && this.elf.isHostile(var9)
               && AnnihilationTrigger.isBossLike(var9.getMaxHealth())
               && this.elf.canFight()
               && !this.isUltimate()
               && this.elf.distanceToSqr(var9) <= var4 * var4) {
               var3 = var9.getUUID();
            }

            boolean var6 = this.trigger.updateBoss(var3, 10);
            if (var3 != null) {
               this.markBoss(var9);
            }

            if (this.annihilationCd <= 0 && this.idleForCinematic()) {
               Vec3 var7 = null;
               if (var6 && (Integer)ECConfig.annihilationBossSeconds.get() > 0) {
                  var7 = var9 != null ? var9.position() : null;
               } else if (var9 != null && this.elf.tickCount % 20 == 0) {
                  int var8 = var1.getEntitiesOfClass(
                        LivingEntity.class,
                        this.elf.getBoundingBox().inflate(32.0),
                        var1x -> this.elf.isHostile(var1x)
                           && AnnihilationTrigger.isHordeMember(var1x.getMaxHealth())
                           && var1x.distanceToSqr(this.elf) <= 1024.0
                     )
                     .size();
                  if (var8 >= (Integer)ECConfig.annihilationHordeCount.get()) {
                     var7 = this.pickAnnihilationImpact();
                  }
               }

               if (var7 != null) {
                  this.startAnnihilation(var7);
               }
            }
         } else {
            this.trigger.reset();
         }
      }
   }

   private void applyRageModifier() {
      AttributeInstance var1 = this.elf.getAttribute(Attributes.MOVEMENT_SPEED);
      if (var1 != null) {
         var1.removeModifier(RAGE_SPEED_ID);
         double var2 = var1.getBaseValue();
         double var4 = TranscendMath.rageSpeed(var2, true, (Double)ECConfig.ragingMultiplier.get(), (Double)ECConfig.ragingSpeedCap.get());
         double var6 = var2 <= 0.0 ? 0.0 : var4 / var2 - 1.0;
         if (var6 > 0.0) {
            var1.addTransientModifier(new AttributeModifier(RAGE_SPEED_ID, var6, Operation.ADD_MULTIPLIED_BASE));
         }

         this.rageModApplied = true;
      }
   }

   private void removeRageModifier() {
      AttributeInstance var1 = this.elf.getAttribute(Attributes.MOVEMENT_SPEED);
      if (var1 != null) {
         var1.removeModifier(RAGE_SPEED_ID);
      }

      this.rageModApplied = false;
   }

   private void tickRaging() {
      if (this.rageAnim > 0) {
         this.rageAnim--;
      }

      if (this.ragingTicks > 0) {
         if (!this.rageModApplied) {
            this.applyRageModifier();
         }

         this.ragingTicks--;
         this.elf.setRageTicksSync(this.ragingTicks);
         if (this.elf.tickCount % 4 == 0 && this.elf.level() instanceof ServerLevel var1) {
            double var7 = this.elf.tickCount * 0.5;

            for (int var4 = 0; var4 < 6; var4++) {
               double var5 = var7 + var4 * Math.PI / 3.0;
               ElfFx.p(
                  var1,
                  ElfFx.gold(),
                  this.elf.getX() + Math.cos(var5) * 1.0,
                  this.elf.getY() + 0.9 + Math.sin(var7 + var4) * 0.6,
                  this.elf.getZ() + Math.sin(var5) * 1.0,
                  1,
                  0.0,
                  0.02,
                  0.0,
                  0.0
               );
            }

            ElfFx.p(var1, ElfFx.green(), this.elf.getX(), this.elf.getY() + 1.0, this.elf.getZ(), 3, 0.5, 0.7, 0.5, 0.01);
         }

         if (this.ragingTicks <= 0) {
            this.endRaging();
         }
      } else {
         if (this.rageModApplied) {
            this.removeRageModifier();
         }

         if (TranscendMath.shouldStartRage(
            this.elf.getHealth(),
            this.elf.getMaxHealth(),
            (Double)ECConfig.ragingHealthFraction.get(),
            this.elf.isTranscended(),
            false,
            this.ragingCd,
            this.isUltimate(),
            this.elf.isAlive()
         )) {
            this.startRaging();
         }
      }
   }

   public boolean startRaging() {
      if (this.ragingTicks <= 0 && this.elf.isTranscended() && this.elf.isAlive() && !this.isUltimate() && this.elf.level() instanceof ServerLevel var1) {
         this.ragingTicks = (Integer)ECConfig.ragingDurationTicks.get();
         this.ragingCd = ECConfig.ticks(ECConfig.ragingCooldownSec);
         this.rageAnim = 30;
         this.applyRageModifier();
         this.elf.setRageTicksSync(this.ragingTicks);
         ElfVfx.send(var1, 10, this.elf.getId(), this.elf.position(), null, 70, 1.0F);
         Vec3 var3 = this.elf.position();
         ElfFx.p(var1, ParticleTypes.FLASH, var3.x, var3.y + 1.0, var3.z, 1, 0.0, 0.0, 0.0, 0.0);
         ElfFx.burst(var1, ElfFx.green(), var3.x, var3.y + 1.0, var3.z, 60, 0.7);
         ElfFx.burst(var1, ElfFx.gold(), var3.x, var3.y + 1.0, var3.z, 50, 0.6);
         this.fx.add(ElfFx.shockwave(var1, var3, 9.0, 14, ElfFx.gold(), ElfFx.green()));
         var1.playSound(null, var3.x, var3.y, var3.z, (SoundEvent)ModRegistry.SND_RAGING_VOICE.get(), SoundSource.VOICE, 3.0F, 1.0F);
         var1.playSound(null, var3.x, var3.y, var3.z, SoundEvents.ENDER_DRAGON_GROWL, SoundSource.NEUTRAL, 1.2F, 1.3F);
         var1.playSound(null, var3.x, var3.y, var3.z, SoundEvents.BEACON_POWER_SELECT, SoundSource.NEUTRAL, 2.0F, 1.6F);
         this.sendNear(var3, 64.0, new ModNetwork.CinematicS2C(3, 24));
         this.announce("raging_mode", ((Integer)ECConfig.announceRadius.get()).intValue());
         return true;
      } else {
         return false;
      }
   }

   private void endRaging() {
      this.ragingTicks = 0;
      this.elf.setRageTicksSync(0);
      this.removeRageModifier();
      if (this.elf.level() instanceof ServerLevel var1) {
         ElfFx.burst(var1, ElfFx.green(), this.elf.getX(), this.elf.getY() + 1.0, this.elf.getZ(), 20, 0.3);
      }
   }

   private boolean wrongState() {
      return this.elf.getRestState() != 0 || this.elf.defense.isDrinking() || this.elf.defense.isEscaping();
   }

   @Nullable
   private LivingEntity pickHuntTargetAny() {
      double var1 = ((Integer)ECConfig.huntRadius.get()).intValue();
      List var3 = this.elf
         .level()
         .getEntitiesOfClass(
            LivingEntity.class, this.elf.getBoundingBox().inflate(var1), var3x -> this.elf.isHostile(var3x) && var3x.distanceToSqr(this.elf) <= var1 * var1
         );
      if (var3.isEmpty()) {
         return null;
      } else {
         var3.sort(Comparator.<LivingEntity>comparingDouble(var0 -> -var0.getMaxHealth()).thenComparingDouble(var1x -> var1x.distanceToSqr(this.elf)));
         return (LivingEntity)var3.get(0);
      }
   }

   public ElfSkills.ManualResult manualAction(int var1, boolean var2) {
      if (var1 < 0 || var1 >= 16) {
         return ElfSkills.ManualResult.INVALID;
      } else if (this.elf.isAlive() && this.ult == null && this.cinematic == null) {
         switch (var1) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
               if (!this.casts.isEmpty()) {
                  return ElfSkills.ManualResult.BUSY;
               } else {
                  LivingEntity var9 = this.elf.nearestHostile(((Integer)ECConfig.attackRange.get()).intValue());
                  if (var9 == null) {
                     return ElfSkills.ManualResult.NO_TARGET;
                  } else {
                     if (!var2 && this.cd[var1] > 0) {
                        return ElfSkills.ManualResult.COOLDOWN;
                     }

                     return this.activate(var1, var9, var2) ? ElfSkills.ManualResult.OK : ElfSkills.ManualResult.INVALID;
                  }
               }
            case 6:
               if (!this.casts.isEmpty()) {
                  return ElfSkills.ManualResult.BUSY;
               } else if (!var2 && this.ultCd > 0) {
                  return ElfSkills.ManualResult.COOLDOWN;
               } else {
                  if (!this.wrongState() && !this.elf.isMounted()) {
                     this.startUltimate();
                     return ElfSkills.ManualResult.OK;
                  }

                  return ElfSkills.ManualResult.INVALID;
               }
            case 7:
               if (this.lv() < (Integer)ECConfig.huntMinLevel.get()) {
                  return ElfSkills.ManualResult.LOCKED;
               } else if (!this.casts.isEmpty()) {
                  return ElfSkills.ManualResult.BUSY;
               } else if (!var2 && this.huntCd > 0) {
                  return ElfSkills.ManualResult.COOLDOWN;
               } else {
                  if (!this.wrongState() && !this.elf.isMounted()) {
                     LivingEntity var8 = this.pickHuntTargetAny();
                     if (var8 == null) {
                        return ElfSkills.ManualResult.NO_TARGET;
                     }

                     this.startHunt(var8);
                     return ElfSkills.ManualResult.OK;
                  }

                  return ElfSkills.ManualResult.INVALID;
               }
            case 8:
               Player var3 = this.elf.getOwnerPlayer();
               if (var3 != null
                  && var3.level() == this.elf.level()
                  && !(
                     this.elf.distanceToSqr(var3)
                        > (double)((Integer)ECConfig.guardianRange.get()).intValue() * ((Integer)ECConfig.guardianRange.get()).intValue()
                  )) {
                  if (!var2 && this.guardianCd > 0) {
                     return ElfSkills.ManualResult.COOLDOWN;
                  }

                  if (this.wrongState()) {
                     return ElfSkills.ManualResult.INVALID;
                  }

                  this.guardianCd = ECConfig.ticks(ECConfig.guardianCooldownSec);
                  this.activateGuardian(this.sl(), var3);
                  return ElfSkills.ManualResult.OK;
               }

               return ElfSkills.ManualResult.INVALID;
            case 9:
               if (!var2 && this.seedCd > 0) {
                  return ElfSkills.ManualResult.COOLDOWN;
               } else if (this.wrongState()) {
                  return ElfSkills.ManualResult.INVALID;
               } else {
                  Player var10 = this.elf.getOwnerPlayer();
                  Object var5 = null;
                  float var6 = 2.0F;
                  if (var10 != null && var10.level() == this.elf.level() && var10.getHealth() < var10.getMaxHealth()) {
                     var5 = var10;
                     var6 = var10.getHealth() / var10.getMaxHealth();
                  }

                  float var7 = this.elf.getHealth() / Math.max(1.0F, this.elf.getMaxHealth());
                  if (this.elf.getHealth() < this.elf.getMaxHealth() && var7 < var6) {
                     var5 = this.elf;
                  }

                  if (var5 == null) {
                     return ElfSkills.ManualResult.INVALID;
                  }

                  this.seedCd = ECConfig.ticks(ECConfig.seedCooldownSec);
                  this.plantSeed(this.sl(), (LivingEntity)var5);
                  return ElfSkills.ManualResult.OK;
               }
            case 10:
               if (!this.elf.isTranscended()) {
                  return ElfSkills.ManualResult.LOCKED;
               } else if (!this.casts.isEmpty()) {
                  return ElfSkills.ManualResult.BUSY;
               } else if (!var2 && this.annihilationCd > 0) {
                  return ElfSkills.ManualResult.COOLDOWN;
               } else {
                  Vec3 var4 = this.pickAnnihilationImpact();
                  if (var4 == null) {
                     return ElfSkills.ManualResult.NO_TARGET;
                  }

                  return this.startAnnihilation(var4) ? ElfSkills.ManualResult.OK : ElfSkills.ManualResult.INVALID;
               }
            case 11:
               if (!this.elf.isTranscended()) {
                  return ElfSkills.ManualResult.LOCKED;
               } else if (this.ragingTicks > 0) {
                  return ElfSkills.ManualResult.INVALID;
               } else {
                  if (!var2 && this.ragingCd > 0) {
                     return ElfSkills.ManualResult.COOLDOWN;
                  }

                  return this.startRaging() ? ElfSkills.ManualResult.OK : ElfSkills.ManualResult.INVALID;
               }
            case 12:
            default:
               if (this.elf.defense.isStealth()) {
                  return ElfSkills.ManualResult.INVALID;
               } else {
                  if (!var2 && this.elf.defense.stealthRemaining() > 0) {
                     return ElfSkills.ManualResult.COOLDOWN;
                  }

                  return this.elf.defense.manualStealth() ? ElfSkills.ManualResult.OK : ElfSkills.ManualResult.INVALID;
               }
            case 13:
            case 14:
            case 15:
               return this.manualExtra(var1, var2);
         }
      } else {
         return ElfSkills.ManualResult.BUSY;
      }
   }

   private ElfSkills.Cast thorn(LivingEntity var1) {
      return var1.isAlive() && !(this.elf.distanceToSqr(var1) > 1600.0) && this.elf.getSensing().hasLineOfSight(var1) ? new ElfSkills.Thorn(var1) : null;
   }

   @Nullable
   private LivingEntity pickHuntTarget() {
      double var1 = ((Integer)ECConfig.huntRadius.get()).intValue();
      List var3 = this.elf
         .level()
         .getEntitiesOfClass(
            LivingEntity.class, this.elf.getBoundingBox().inflate(var1), var3x -> this.elf.isHostile(var3x) && var3x.distanceToSqr(this.elf) <= var1 * var1
         );
      if (var3.isEmpty()) {
         return null;
      } else {
         var3.sort(Comparator.<LivingEntity>comparingDouble(var0 -> -var0.getMaxHealth()).thenComparingDouble(var1x -> var1x.distanceToSqr(this.elf)));
         LivingEntity var4 = (LivingEntity)var3.get(0);
         long var5 = var3.stream().filter(var1x -> var1x.distanceToSqr(var4) <= 64.0).count();
         return !(var4.getMaxHealth() >= ((Integer)ECConfig.huntMinTargetHealth.get()).intValue()) && var5 < 4L ? null : var4;
      }
   }

   private boolean maybeStartHunt() {
      if (this.huntCd <= 0
         && this.lv() >= (Integer)ECConfig.huntMinLevel.get()
         && this.casts.isEmpty()
         && this.ult == null
         && this.cinematic == null
         && !this.elf.defense.isEscaping()
         && !this.elf.isMounted()
         && this.elf.getRestState() == 0
         && !(this.elf.getRandom().nextDouble() >= (Double)ECConfig.huntChancePerShot.get())) {
         LivingEntity var1 = this.pickHuntTarget();
         if (var1 == null) {
            return false;
         } else {
            this.startHunt(var1);
            return true;
         }
      } else {
         return false;
      }
   }

   private void startHunt(LivingEntity var1) {
      ElfSkills.Hunt var2 = new ElfSkills.Hunt(var1);
      var2.anim = 1;
      this.casts.add(var2);
      this.huntCd = ECConfig.ticks(ECConfig.huntCooldownSec);
      this.announce("verdant_wild_hunt", ((Integer)ECConfig.ultAnnounceRadius.get()).intValue());
      var2.start();
      ElfNew.onHunt(this, var1);
   }

   public void huntHit(LivingEntity var1, float var2) {
      this.hurt(var1, var2);
   }

   private void tickSupport() {
      if (this.elf.tickCount % 10 == 0
         && this.elf.level() instanceof ServerLevel var1
         && this.elf.isAlive()
         && this.elf.getRestState() == 0
         && this.ult == null) {
         Player var13 = this.elf.getOwnerPlayer();
         if (var13 != null && var13.level() == this.elf.level() && var13.isAlive() && !var13.isSpectator()) {
            double var3 = this.elf.distanceToSqr(var13);
            if ((Boolean)ECConfig.guardianEnabled.get()) {
               double var5 = ((Integer)ECConfig.guardianMobRadius.get()).intValue();
               int var7 = var13.level()
                  .getEntitiesOfClass(
                     LivingEntity.class, var13.getBoundingBox().inflate(var5), var4 -> this.elf.isHostile(var4) && var4.distanceToSqr(var13) <= var5 * var5
                  )
                  .size();
               boolean var8 = var13.getHealth() <= var13.getMaxHealth() * (Double)ECConfig.guardianOwnerHealthFraction.get();
               boolean var9 = var8 && var7 >= 1 || var7 >= (Integer)ECConfig.guardianMobCount.get();
               if (!var9) {
                  if (this.guardianLatch && ++this.guardianClear >= 10) {
                     this.guardianLatch = false;
                     this.guardianClear = 0;
                  }
               } else {
                  this.guardianClear = 0;
               }

               if (var9
                  && !this.guardianLatch
                  && this.guardianCd == 0
                  && var3 <= (double)((Integer)ECConfig.guardianRange.get()).intValue() * ((Integer)ECConfig.guardianRange.get()).intValue()) {
                  this.guardianLatch = true;
                  this.guardianCd = ECConfig.ticks(ECConfig.guardianCooldownSec);
                  this.activateGuardian(var1, var13);
               }
            }

            if ((Boolean)ECConfig.seedEnabled.get() && this.seedCd == 0 && var3 <= 1600.0) {
               double var14 = (Double)ECConfig.seedHealthFraction.get();
               Object var15 = null;
               double var16 = var14 + 1.0;
               float var10 = var13.getHealth() / Math.max(1.0F, var13.getMaxHealth());
               boolean var11 = this.elf.nearestHostile(16.0) != null
                  || var13.level().getEntitiesOfClass(LivingEntity.class, var13.getBoundingBox().inflate(12.0), var1x -> this.elf.isHostile(var1x)).size() > 0
                  || var13.tickCount - var13.getLastHurtByMobTimestamp() < 200;
               if (var10 <= var14 && var11) {
                  var15 = var13;
                  var16 = var10;
               }

               float var12 = this.elf.getHealth() / Math.max(1.0F, this.elf.getMaxHealth());
               if (var12 <= var14 && var12 < var16 && !this.elf.defense.isDrinking() && !this.elf.defense.potionReady()) {
                  var15 = this.elf;
                  var16 = var12;
               }

               if (var15 != null) {
                  this.seedCd = ECConfig.ticks(ECConfig.seedCooldownSec);
                  this.plantSeed(var1, (LivingEntity)var15);
               }
            }
         }
      }
   }

   private void activateGuardian(ServerLevel var1, Player var2) {
      double var3 = (Double)ECConfig.guardianRadius.get() * this.area();
      int var5 = (Integer)ECConfig.guardianDurationTicks.get();
      ElfVfx.send(var1, 8, -1, var2.position(), null, 70, (float)(var3 / 6.0));
      ArrayList var6 = new ArrayList();
      var6.add(var2);

      for (LivingEntity var8 : var1.getEntitiesOfClass(
         LivingEntity.class, var2.getBoundingBox().inflate(var3), var3x -> var3x != var2 && var3x.distanceToSqr(var2) <= var3 * var3
      )) {
         if (var8 instanceof ElfEntity var9 && var9.isOwnedBy(var2)) {
            var6.add(var8);
         } else if (var8 instanceof OwnableEntity var13 && var2.getUUID().equals(var13.getOwnerUUID())) {
            var6.add(var8);
         }
      }

      for (LivingEntity var12 : var6) {
         var12.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, var5, (Integer)ECConfig.guardianAmplifier.get(), false, true));
      }

      this.announce("grove_guardian", ((Integer)ECConfig.announceRadius.get()).intValue());
      var1.playSound(null, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.NEUTRAL, 1.6F, 1.5F);
      var1.playSound(null, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.NEUTRAL, 1.6F, 0.8F);
      this.elf.swing(InteractionHand.MAIN_HAND);
      int[] var11 = new int[]{0};
      this.fx
         .add(
            () -> {
               var11[0]++;
               if (var2.isAlive() && var11[0] <= var5) {
                  if (var11[0] % 3 == 0) {
                     double var6x = var11[0] * 0.12;

                     for (int var8x = 0; var8x < 5; var8x++) {
                        double var9x = var8x * Math.PI / 10.0;
                        double var11x = var3 * Math.cos(var9x);
                        double var13x = var3 * Math.sin(var9x) * 0.8;

                        for (int var15 = 0; var15 < 10; var15++) {
                           double var16 = var6x * (var8x % 2 == 0 ? 1 : -1) + var15 * Math.PI / 5.0;
                           ElfFx.p(
                              var1,
                              var8x % 2 == 0 ? ElfFx.green() : ElfFx.gold(),
                              var2.getX() + Math.cos(var16) * var11x,
                              var2.getY() + var13x,
                              var2.getZ() + Math.sin(var16) * var11x,
                              1,
                              0.0,
                              0.0,
                              0.0,
                              0.0
                           );
                        }
                     }

                     ElfFx.p(var1, ElfFx.leaf(), var2.getX(), var2.getY() + var3 * 0.8, var2.getZ(), 1, var3 * 0.5, 0.3, var3 * 0.5, 0.0);
                  }

                  if (var11[0] == 1) {
                     ElfFx.ring(var1, ElfFx.green(), var2.getX(), var2.getY() + 0.2, var2.getZ(), 0.5, 40, var3 * 0.12, 0.02);
                     ElfFx.burst(var1, ElfFx.star(), var2.getX(), var2.getY() + 1.0, var2.getZ(), 30, 0.5);
                  }

                  return false;
               } else {
                  return true;
               }
            }
         );
   }

   private void plantSeed(ServerLevel var1, LivingEntity var2) {
      ElfVfx.send(var1, 9, -1, var2.position(), null, 44, 1.0F);
      this.announce("life_seed", ((Integer)ECConfig.announceRadius.get()).intValue());
      this.elf.swing(InteractionHand.MAIN_HAND);
      this.elf.playSound(SoundEvents.AMETHYST_CLUSTER_PLACE, 1.4F, 1.4F);
      Vec3[] var3 = new Vec3[]{ElfFx.handPos(this.elf)};
      double var4 = var2.getMaxHealth() * (Double)ECConfig.seedHealFraction.get() * ElfLevel.lerp(1.0, 1.25, this.lv());
      int var6 = (Integer)ECConfig.seedHealTicks.get();
      int[] var7 = new int[]{0, 0};
      boolean[] var8 = new boolean[]{false};
      this.fx
         .add(
            () -> {
               if (!var2.isAlive()) {
                  return true;
               } else if (!var8[0]) {
                  var7[0]++;
                  Vec3 var13 = var2.position().add(0.0, var2.getBbHeight() * 0.6, 0.0);
                  Vec3 var9 = var13.subtract(var3[0]);
                  double var10 = var9.length();
                  if (!(var10 < 0.8) && var7[0] <= 80) {
                     Vec3 var12 = var9.normalize().scale(Math.min(var10, 0.9)).add(0.0, Math.sin(var7[0] * 0.25) * 0.08, 0.0);
                     var3[0] = var3[0].add(var12);
                     ElfFx.p(var1, ElfFx.green(), var3[0].x, var3[0].y, var3[0].z, 2, 0.05, 0.05, 0.05, 0.0);
                     ElfFx.p(var1, ElfFx.star(), var3[0].x, var3[0].y, var3[0].z, 1, 0.1, 0.1, 0.1, 0.01);
                     ElfFx.p(var1, ElfFx.leaf(), var3[0].x, var3[0].y, var3[0].z, 1, 0.1, 0.1, 0.1, 0.0);
                     return false;
                  } else {
                     var8[0] = true;
                     var1.playSound(null, var2.getX(), var2.getY(), var2.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.NEUTRAL, 1.4F, 1.6F);
                     ElfFx.burst(var1, ElfFx.green(), var13.x, var13.y, var13.z, 40, 0.35);
                     ElfFx.ring(var1, ElfFx.gold(), var2.getX(), var2.getY() + 0.2, var2.getZ(), 0.4, 30, 0.2, 0.04);
                     return false;
                  }
               } else {
                  var7[1]++;
                  if (var7[1] % 10 == 0) {
                     var2.heal((float)(var4 * 10.0 / var6));
                  }

                  if (var7[1] % 3 == 0) {
                     double var8x = var7[1] * 0.4;
                     ElfFx.p(
                        var1,
                        ElfFx.green(),
                        var2.getX() + Math.cos(var8x) * 0.6,
                        var2.getY() + var7[1] % 24 / 24.0 * var2.getBbHeight(),
                        var2.getZ() + Math.sin(var8x) * 0.6,
                        1,
                        0.0,
                        0.02,
                        0.0,
                        0.0
                     );
                     ElfFx.p(var1, ElfFx.leaf(), var2.getX(), var2.getY() + var2.getBbHeight() + 0.2, var2.getZ(), 1, 0.4, 0.2, 0.4, 0.0);
                     if (var7[1] % 12 == 0) {
                        ElfFx.p(var1, ParticleTypes.HAPPY_VILLAGER, var2.getX(), var2.getY() + 1.0, var2.getZ(), 3, 0.4, 0.5, 0.4, 0.0);
                     }
                  }

                  return var7[1] >= var6;
               }
            }
         );
   }

   private void startUltimate() {
      this.ult = new ElfSkills.Ultimate();
      this.ultCd = ECConfig.ticks(ECConfig.ultSuccessCooldownSec);
      this.casts.add(this.ult);
      this.announce("verdant_ascendance", ((Integer)ECConfig.ultAnnounceRadius.get()).intValue());
      this.ult.start();
      ElfNew.onUlt(this);
   }

   private final class AirVariant extends ElfSkills.Cast {
      final Supplier<ElfSkills.Cast> factory;
      ElfSkills.Cast inner;
      boolean innerDone;
      int phase;
      int t;
      double targetY;

      AirVariant(Supplier<ElfSkills.Cast> nullx) {
         this.factory = nullx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.elf.setNoGravity(true);
         ElfSkills.this.explosionImmune = 120;
         ElfSkills.this.elf.getNavigation().stop();
         this.targetY = ElfSkills.this.elf.getY() + Math.min((Double)ECConfig.skyfallJumpHeight.get(), ElfSkills.this.riseAvailable());
         ElfFx.ring(
            ElfSkills.this.sl(), ElfFx.green(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 0.15, ElfSkills.this.elf.getZ(), 0.5, 28, 0.25, 0.03
         );
         ElfFx.burst(ElfSkills.this.sl(), ElfFx.star(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 0.5, ElfSkills.this.elf.getZ(), 14, 0.25);
      }

      @Override
      boolean tick() {
         this.t++;
         if (this.phase == 0) {
            double var1 = this.targetY - ElfSkills.this.elf.getY();
            ElfFx.p(
               ElfSkills.this.sl(),
               ElfFx.green(),
               ElfSkills.this.elf.getX(),
               ElfSkills.this.elf.getY() + 0.1,
               ElfSkills.this.elf.getZ(),
               3,
               0.25,
               0.05,
               0.25,
               0.0
            );
            if (!(var1 <= 0.25)
               && this.t <= 40
               && ElfSkills.this.elf.level().noCollision(ElfSkills.this.elf, ElfSkills.this.elf.getBoundingBox().move(0.0, 0.3, 0.0))) {
               ElfSkills.this.elf.setDeltaMovement(0.0, Math.min(0.6, var1 * 0.5 + 0.1), 0.0);
            } else {
               this.phase = 1;
               this.t = 0;
               ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
            }
         } else if (this.phase == 1) {
            ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
            LivingEntity var3 = ElfSkills.this.elf.nearestHostile(((Integer)ECConfig.attackRange.get()).intValue());
            if (var3 != null) {
               ElfSkills.this.elf.getLookControl().setLookAt(var3, 60.0F, 60.0F);
            }

            ElfFx.converge(ElfSkills.this.sl(), ElfFx.green(), ElfSkills.this.elf.position().add(0.0, 1.2, 0.0), 2.2, 3, 0.13);
            if (this.t >= 6) {
               this.inner = this.factory.get();
               if (this.inner == null) {
                  return true;
               }

               this.anim = this.inner.anim == 0 ? 2 : this.inner.anim;
               this.inner.start();
               this.phase = 2;
            }
         } else {
            ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
            if (this.inner.tick()) {
               this.inner.finish();
               this.innerDone = true;
               return true;
            }
         }

         return false;
      }

      @Override
      void finish() {
         if (this.inner != null && !this.innerDone) {
            this.inner.finish();
            this.innerDone = true;
         }

         ElfSkills.this.elf.setNoGravity(false);
         if (ElfSkills.this.elf.isAlive() && ElfSkills.this.elf.getRandom().nextDouble() < (Double)ECConfig.stompChance.get()) {
            ElfSkills.this.pending.add(ElfSkills.this.new Stomp());
         } else {
            ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 120, 0, false, false));
            ElfSkills.this.fallGuard = 180;
         }
      }
   }

   private final class Annihilation extends ElfSkills.Cast {
      final Vec3 impact;
      final int height;
      int t;
      int landT;
      double y0;
      boolean detonated;
      final int ascentEnd = 112;
      final int descent = (Integer)ECConfig.annihilationDescentTicks.get();
      final int silence = (Integer)ECConfig.annihilationSilenceTicks.get();
      final int impactAt = 112 + this.descent;

      Annihilation(Vec3 nullx, int nullxx) {
         this.impact = nullx;
         this.height = nullxx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.cinematic = this;
         this.y0 = ElfSkills.this.elf.getY();
         ElfSkills.this.elf.setNoGravity(true);
         ElfSkills.this.elf.getNavigation().stop();
         ElfSkills.this.explosionImmune = this.impactAt + this.silence + 700;
         ElfSkills.this.sendNear(ElfSkills.this.elf.position(), 128.0, new ModNetwork.CinematicS2C(1, 112));
      }

      @Override
      boolean tick() {
         this.t++;
         ServerLevel var1 = ElfSkills.this.sl();
         if (this.t <= 12) {
            ElfSkills.this.elf.setDeltaMovement(0.0, 0.0, 0.0);
            if (this.t == 1) {
               Vec3 var2 = ElfSkills.this.elf.position();
               ElfFx.p(var1, ParticleTypes.FLASH, var2.x, var2.y + 0.3, var2.z, 1, 0.0, 0.0, 0.0, 0.0);
               ElfFx.burst(var1, ElfFx.gold(), var2.x, var2.y + 0.3, var2.z, 50, 0.7);
               ElfFx.burst(var1, ElfFx.fire(), var2.x, var2.y + 0.3, var2.z, 30, 0.5);
               ElfSkills.this.fx.add(ElfFx.shockwave(var1, var2, 7.0, 10, ElfFx.gold(), ElfFx.fire()));
               ElfSkills.this.snd((SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), 2.0F, 1.2F);
               ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
            }
         } else if (this.t < 112) {
            if (this.t == 13) {
               var1.playSound(
                  null,
                  ElfSkills.this.elf.getX(),
                  ElfSkills.this.elf.getY(),
                  ElfSkills.this.elf.getZ(),
                  (SoundEvent)ModRegistry.SND_ANNIHILATION_VOICE.get(),
                  SoundSource.VOICE,
                  6.0F,
                  1.0F
               );
            }

            double var9 = Mth.clamp((this.t - 6) / 106.0, 0.0, 1.0);
            double var4 = this.y0 + this.height * (1.0 - Math.pow(1.0 - var9, 2.0));
            ElfSkills.this.elf.setDeltaMovement(0.0, Mth.clamp(var4 - ElfSkills.this.elf.getY(), 0.0, 2.2), 0.0);
            Vec3 var6 = ElfSkills.this.elf.position();

            for (double var7 = 1.0; var7 < 9.0; var7 += 2.0) {
               ElfFx.p(var1, ElfFx.gold(), var6.x, var6.y - var7, var6.z, 1, 0.3, 0.2, 0.3, 0.0);
            }

            if (this.t % 4 == 0) {
               ElfFx.disc(var1, ElfFx.star(), var6.add(0.0, 0.5, 0.0), new Vec3(0.0, 1.0, 0.0), 1.2 + var9, 14);
               ElfFx.p(var1, ElfFx.green(), var6.x, var6.y - 2.0, var6.z, 4, 0.6, 1.0, 0.6, 0.0);
            }

            if (this.t == 20 || this.t == 55 || this.t == 90) {
               ElfSkills.this.bar(Component.translatable("annihilation.elven_companions.line" + (this.t == 20 ? 1 : (this.t == 55 ? 2 : 3))), 96.0);
            }
         } else if (this.t < this.impactAt) {
            ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
            if (this.t == 112) {
               PacketDistributor.sendToPlayersNear(
                  var1,
                  null,
                  this.impact.x,
                  this.impact.y,
                  this.impact.z,
                  200.0,
                  new ModNetwork.CelestialArrowS2C(this.impact.x, this.impact.y, this.impact.z, this.descent, this.impact.y + 150.0),
                  new CustomPacketPayload[0]
               );
               ElfSkills.this.sendNear(ElfSkills.this.elf.position(), 128.0, new ModNetwork.CinematicS2C(1, this.descent));
               ElfSkills.this.snd(SoundEvents.BEACON_POWER_SELECT, 3.0F, 0.5F);
            }

            ElfSkills.this.elf.getLookControl().setLookAt(this.impact.x, this.impact.y, this.impact.z);
            if (this.t % 3 == 0) {
               ElfFx.converge(var1, ElfFx.gold(), ElfSkills.this.elf.position().add(0.0, 1.2, 0.0), 3.0, 3, 0.1);
            }

            if (this.t % 10 == 0) {
               ElfSkills.this.magicCircle(this.impact, 7.0, this.t * 0.05, ElfFx.gold(), ElfFx.moon());
            }
         } else if (this.t == this.impactAt) {
            ElfSkills.this.sendNear(this.impact, 200.0, new ModNetwork.SilenceS2C(this.silence));
            ElfSkills.this.sendNear(ElfSkills.this.elf.position(), 128.0, new ModNetwork.SilenceS2C(this.silence));
            ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
         } else if (this.t < this.impactAt + this.silence) {
            ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
            if (this.t % 5 == 0) {
               ElfFx.p(var1, ElfFx.star(), this.impact.x, this.impact.y + 0.5, this.impact.z, 1, 0.5, 0.5, 0.5, 0.0);
            }
         } else if (!this.detonated) {
            this.detonate(var1);
         } else {
            this.landT++;
            if (this.landT == 1) {
               ElfSkills.this.elf.setNoGravity(false);
               ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 600, 0, false, false));
               ElfSkills.this.fallGuard = 900;
            }

            if (ElfSkills.this.elf.onGround() || this.landT > 500) {
               return true;
            }
         }

         return false;
      }

      void detonate(ServerLevel var1) {
         this.detonated = true;
         double var2 = ((Integer)ECConfig.annihilationRadius.get()).intValue();
         ArrayList var4 = new ArrayList(
            var1.getEntitiesOfClass(LivingEntity.class, new AABB(this.impact, this.impact).inflate(var2), ElfSkills.this.elf::isHostile)
         );
         var4.removeIf(var3 -> var3.distanceToSqr(this.impact) > var2 * var2);
         if (var4.size() > (Integer)ECConfig.annihilationMaxTargets.get()) {
            var4.sort(Comparator.comparingDouble(var1x -> var1x.distanceToSqr(this.impact)));
            var4 = new ArrayList(var4.subList(0, (Integer)ECConfig.annihilationMaxTargets.get()));
         }

         double var5 = (Double)ECConfig.annihilationDamage.get() * ElfLevel.lerp(1.0, 1.0, ElfSkills.this.lv());

         for (LivingEntity var8 : var4) {
            double var9 = Math.sqrt(var8.distanceToSqr(this.impact));
            ElfSkills.this.hurt(var8, (float)(var5 * Mth.lerp(var9 / var2, 1.0, (Double)ECConfig.annihilationMinFraction.get())));
            double var11 = (Double)ECConfig.annihilationKnockback.get() * (1.0 - var9 / var2);
            if (var11 > 0.02) {
               var8.knockback(Math.min(0.8, var11), this.impact.x - var8.getX(), this.impact.z - var8.getZ());
            }
         }

         ElfFx.p(var1, ParticleTypes.FLASH, this.impact.x, this.impact.y + 1.0, this.impact.z, 1, 0.0, 0.0, 0.0, 0.0);
         ElfFx.burst(var1, ElfFx.gold(), this.impact.x, this.impact.y + 1.0, this.impact.z, 120, 1.2);
         ElfFx.burst(var1, ElfFx.star(), this.impact.x, this.impact.y + 1.0, this.impact.z, 80, 1.4);
         ElfSkills.this.fx.add(ElfFx.shockwave(var1, this.impact, var2, 50, ElfFx.gold(), ElfFx.green()));
         ElfSkills.this.fx.add(ElfFx.shockwave(var1, this.impact, var2 * 0.6, 34, ElfFx.star(), ElfFx.gold()));
         ElfSkills.this.fx.add(ElfFx.shockwave(var1, this.impact, var2 * 0.3, 24, ElfFx.moon(), ElfFx.star()));
         int[] var13 = new int[]{0};
         ElfSkills.this.fx.add(() -> {
            var13[0]++;
            double var3 = this.impact.y + 140.0;
            double var5x = var3 - (var3 - this.impact.y) * Math.min(1.0, var13[0] / 8.0);

            for (double var7 = var5x; var7 <= var3; var7 += 5.0) {
               ElfFx.p(var1, ElfFx.gold(), this.impact.x, var7, this.impact.z, 2, 1.6, 0.0, 1.6, 0.0);
               if (((int)(var7 / 5.0) + var13[0]) % 2 == 0) {
                  ElfFx.p(var1, ElfFx.star(), this.impact.x, var7, this.impact.z, 1, 2.4, 0.0, 2.4, 0.0);
               }
            }

            return var13[0] >= 30;
         });
         int[] var14 = new int[]{0};
         ElfSkills.this.fx.add(() -> {
            var14[0]++;
            if (var14[0] % 4 == 0) {
               ElfSkills.this.magicCircle(this.impact, 14.0, var14[0] * 0.03, ElfFx.gold(), ElfFx.green());
               ElfSkills.this.magicCircle(this.impact, 26.0, -var14[0] * 0.02, ElfFx.moon(), ElfFx.star());
            }

            return var14[0] >= 80;
         });
         int[] var15 = new int[]{0};
         ElfSkills.this.fx
            .add(
               () -> {
                  var15[0]++;

                  for (int var3 = 0; var3 < 3; var3++) {
                     double var4x = var1.random.nextDouble() * Math.PI * 2.0;
                     double var6 = Math.sqrt(var1.random.nextDouble()) * 36.0;
                     ElfFx.vel(
                        var1,
                        var1.random.nextBoolean() ? ElfFx.gold() : ElfFx.star(),
                        this.impact.x + Math.cos(var4x) * var6,
                        this.impact.y + var1.random.nextDouble() * 4.0,
                        this.impact.z + Math.sin(var4x) * var6,
                        0.0,
                        0.06 + var1.random.nextDouble() * 0.08,
                        0.0
                     );
                  }

                  return var15[0] >= 120;
               }
            );
         int[] var10 = new int[]{0};
         ElfSkills.this.fx
            .add(
               () -> {
                  var10[0]++;
                  double var3 = 30.0 * Math.min(1.0, var10[0] / 50.0);

                  for (int var5x = 0; var5x < 5; var5x++) {
                     double var6 = var1.random.nextDouble() * var3;
                     double var8x = var1.random.nextDouble() * Math.PI * 2.0;
                     double var10x = 2.2 + 0.8 * Math.sin(var6 * 0.3) + var1.random.nextDouble() * 1.2;
                     ElfFx.vel(
                        var1,
                        ElfFx.fire(),
                        this.impact.x + Math.cos(var8x) * var10x,
                        this.impact.y + var6,
                        this.impact.z + Math.sin(var8x) * var10x,
                        0.0,
                        0.04,
                        0.0
                     );
                  }

                  if (var10[0] > 25) {
                     double var18 = 15.0 * Math.min(1.0, (var10[0] - 25) / 45.0);
                     double var7 = 4.5;

                     for (int var9x = 0; var9x < 14; var9x++) {
                        double var19 = var1.random.nextDouble() * Math.PI * 2.0;
                        double var12 = var1.random.nextDouble() * Math.PI * 2.0;
                        double var14x = var18 + Math.cos(var12) * var7;
                        double var16 = 31.0 + Math.sin(var12) * var7 * 0.8;
                        ElfFx.vel(
                           var1,
                           var9x % 3 == 0 ? ElfFx.gold() : (var9x % 3 == 1 ? ElfFx.fire() : ElfFx.star()),
                           this.impact.x + Math.cos(var19) * var14x,
                           this.impact.y + var16,
                           this.impact.z + Math.sin(var19) * var14x,
                           Math.cos(var19) * 0.05,
                           0.03,
                           Math.sin(var19) * 0.05
                        );
                     }
                  }

                  return var10[0] >= 110;
               }
            );
         var1.playSound(null, this.impact.x, this.impact.y, this.impact.z, (SoundEvent)ModRegistry.SND_ULT_IMPACT.get(), SoundSource.NEUTRAL, 16.0F, 0.6F);
         var1.playSound(null, this.impact.x, this.impact.y, this.impact.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 16.0F, 0.5F);
         var1.playSound(null, this.impact.x, this.impact.y, this.impact.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.NEUTRAL, 12.0F, 0.5F);
         ElfSkills.this.sendNear(this.impact, 160.0, new ModNetwork.CinematicS2C(2, 90));
         ElfSkills.this.sendNear(this.impact, 160.0, new ModNetwork.ImpactS2C());
      }

      @Override
      void finish() {
         if (this.t >= this.impactAt && !this.detonated) {
            ElfSkills.this.sendNear(this.impact, 200.0, new ModNetwork.SilenceS2C(0));
            ElfSkills.this.sendNear(ElfSkills.this.elf.position(), 128.0, new ModNetwork.SilenceS2C(0));
         }

         ElfSkills.this.elf.setNoGravity(false);
         if (!this.detonated || !ElfSkills.this.elf.onGround()) {
            ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 600, 0, false, false));
            ElfSkills.this.fallGuard = 900;
         }

         ElfSkills.this.cinematic = null;
      }
   }

   private abstract class Cast {
      int anim;

      abstract boolean tick();

      void start() {
      }

      void finish() {
      }

      boolean holds() {
         return false;
      }
   }

   private final class ChronoLock extends ElfSkills.Cast {
      static final int FREEZE = 40;
      static final int REWIND = 12;
      final LivingEntity target;
      final List<ElfArrow> arrows = new ArrayList<>();
      final List<Vec3> dirs = new ArrayList<>();
      final List<LivingEntity> victims = new ArrayList<>();
      final Map<Integer, Boolean> prevNoAi = new HashMap<>();
      final ElfArrow.HitTracker tracker = new ElfArrow.HitTracker(ElfSkills.this.dmg(1.7), 64);
      Vec3 center;
      int t;
      boolean released;
      boolean thawed;

      ChronoLock(LivingEntity nullx) {
         this.target = nullx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ServerLevel var1 = ElfSkills.this.sl();
         ElfSkills.this.elf.getNavigation().stop();
         this.center = this.target.position().add(0.0, this.target.getBbHeight() * 0.5, 0.0);
         this.victims.add(this.target);

         for (LivingEntity var3 : var1.getEntitiesOfClass(
            LivingEntity.class,
            new AABB(this.center, this.center).inflate(4.5),
            var1x -> var1x != this.target && var1x.isAlive() && ElfSkills.this.elf.isHostile(var1x)
         )) {
            if (this.victims.size() < 8) {
               this.victims.add(var3);
            }
         }

         for (LivingEntity var6 : this.victims) {
            if (var6 instanceof Mob var4) {
               this.prevNoAi.put(var6.getId(), var4.isNoAi());
               var4.setNoAi(true);
            }

            var6.addEffect(new MobEffectInstance(MobEffects.GLOWING, 90, 0, false, false));
            var6.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 90, 9, false, false));
         }

         var1.playSound(null, this.center.x, this.center.y, this.center.z, SoundEvents.BEACON_ACTIVATE, SoundSource.NEUTRAL, 1.4F, 0.6F);
         var1.playSound(null, this.center.x, this.center.y, this.center.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.6F, 0.5F);
         ElfFx.ring(var1, ElfFx.moon(), this.center.x, this.center.y, this.center.z, 1.0, 36, 0.35, 0.0);
         ElfFx.burst(var1, ElfFx.star(), this.center.x, this.center.y, this.center.z, 30, 0.25);
      }

      private void holdVictims() {
         for (LivingEntity var2 : this.victims) {
            if (var2.isAlive()) {
               var2.setDeltaMovement(0.0, 0.0, 0.0);
               var2.fallDistance = 0.0F;
            }
         }
      }

      private void thaw() {
         if (!this.thawed) {
            this.thawed = true;

            for (LivingEntity var2 : this.victims) {
               if (var2 instanceof Mob var3 && this.prevNoAi.containsKey(var2.getId())) {
                  var3.setNoAi(this.prevNoAi.get(var2.getId()));
               }
            }
         }
      }

      private void spawnArrow(int var1) {
         ServerLevel var2 = ElfSkills.this.sl();
         double var3 = var1 * (Math.PI / 5);
         double var5 = Math.sin(var1 * 0.85) * 1.1;
         double var7 = 3.4 * (var1 / 39.0 + 1.0);
         Vec3 var9 = this.center.add(Math.cos(var3) * var7, var5, Math.sin(var3) * var7);
         Vec3 var10 = this.center.subtract(var9).normalize();
         ElfArrow var11 = new ElfArrow((EntityType<? extends ElfArrow>)ModRegistry.ELF_ARROW.get(), var2);
         var11.setOwner(ElfSkills.this.elf);
         var11.setPos(var9.x, var9.y, var9.z);
         var11.pickup = Pickup.DISALLOWED;
         var11.setTracker(this.tracker);
         var11.setNoGravity(true);
         var11.shoot(var10.x, var10.y, var10.z, 0.001F, 0.0F);
         var2.addFreshEntity(var11);
         this.arrows.add(var11);
         this.dirs.add(var10);
         ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
         if (var1 % 2 == 0) {
            var2.playSound(null, var9.x, var9.y, var9.z, SoundEvents.ARROW_SHOOT, SoundSource.NEUTRAL, 0.8F, 1.0F + var1 * 0.015F);
         }

         ElfFx.p(var2, ElfFx.star(), var9.x, var9.y, var9.z, 3, 0.1, 0.1, 0.1, 0.02);
         ElfFx.p(var2, ElfFx.moon(), var9.x, var9.y, var9.z, 2, 0.05, 0.05, 0.05, 0.0);
      }

      @Override
      boolean tick() {
         ServerLevel var1 = ElfSkills.this.sl();
         this.t++;
         ElfSkills.this.elf.getNavigation().stop();
         ElfSkills.this.elf.getLookControl().setLookAt(this.center.x, this.center.y, this.center.z);
         this.holdVictims();
         ElfBuffs.chronoGrow(ElfSkills.this.elf, this.victims, this.prevNoAi, this.target, this.center, this.t);
         if (this.t <= 40) {
            this.spawnArrow(this.t - 1);
            if (this.t % 4 == 0) {
               ElfFx.ring(
                  var1, ElfFx.moon(), this.center.x, this.center.y - 0.4 + this.t * 0.03, this.center.z, 3.4 * ((this.t - 1) / 39.0 + 1.0), 30, 0.0, 0.0
               );
            }
         } else if (this.t <= 52) {
            if (this.t == 41) {
               var1.playSound(null, this.center.x, this.center.y, this.center.z, SoundEvents.BEACON_DEACTIVATE, SoundSource.NEUTRAL, 1.6F, 1.7F);
            }

            double var2 = (this.t - 40) / 12.0;

            for (int var4 = 0; var4 < this.arrows.size(); var4++) {
               ElfArrow var5 = this.arrows.get(var4);
               if (var5.isAlive()) {
                  Vec3 var6 = this.dirs.get(var4);
                  var5.setPos(var5.getX() - var6.x * 0.14, var5.getY() - var6.y * 0.14, var5.getZ() - var6.z * 0.14);
                  var5.setDeltaMovement(var6.x * 0.001, var6.y * 0.001, var6.z * 0.001);
                  var5.hasImpulse = true;
               }
            }

            ElfFx.ring(var1, ElfFx.moon(), this.center.x, this.center.y, this.center.z, 7.6 * (1.0 - var2) + 0.8, 24, 0.0, 0.0);
            ElfFx.converge(var1, ElfFx.star(), this.center, 5.0, 8, 0.25);
         } else {
            if (!this.released) {
               this.released = true;
               Vec3 var21 = this.target.isAlive() ? this.target.position().add(0.0, this.target.getBbHeight() * 0.5, 0.0) : this.center;
               var1.playSound(null, var21.x, var21.y, var21.z, SoundEvents.CROSSBOW_SHOOT, SoundSource.NEUTRAL, 1.6F, 0.6F);
               var1.playSound(null, var21.x, var21.y, var21.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.NEUTRAL, 0.7F, 1.8F);
               ElfFx.burst(var1, ElfFx.gold(), var21.x, var21.y, var21.z, 30, 0.35);

               for (ElfArrow var22 : this.arrows) {
                  Vec3 var20 = ElfBuffs.aim(var22, var21);
                  if (var22.isAlive()) {
                     var22.shoot(var20.x - var22.getX(), var20.y - var22.getY(), var20.z - var22.getZ(), 3.4F, 0.0F);
                     var22.hasImpulse = true;
                  }
               }
            }

            if (this.t >= 56) {
               this.thaw();
            }
         }

         return this.t >= 64;
      }

      @Override
      void finish() {
         this.thaw();
         if (!this.released) {
            for (ElfArrow var2 : this.arrows) {
               var2.discard();
            }
         }
      }
   }

   private final class Hunt extends ElfSkills.Cast {
      LivingEntity target;
      int t;
      SpectralStagEntity stag;
      final float dmg = (float)((Double)ECConfig.huntDamage.get() * ElfLevel.lerp(1.0, 1.6, ElfSkills.this.lv()) * ElfSkills.this.tMul());
      final float pathDmg = (float)((Double)ECConfig.huntPathDamage.get() * ElfLevel.lerp(1.0, 1.6, ElfSkills.this.lv()) * ElfSkills.this.tMul());

      Hunt(LivingEntity nullx) {
         this.target = nullx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.elf.getNavigation().stop();
      }

      @Override
      boolean tick() {
         ServerLevel var1 = ElfSkills.this.sl();
         if ((this.target == null || !this.target.isAlive()) && this.stag == null) {
            this.target = ElfSkills.this.pickHuntTarget();
            if (this.target == null) {
               return true;
            }
         }

         this.t++;
         ElfSkills.this.elf.getNavigation().stop();
         if (this.target != null) {
            ElfSkills.this.elf.getLookControl().setLookAt(this.target, 60.0F, 60.0F);
         }

         if (this.t <= 30) {
            if (this.t == 1) {
               var1.playSound(
                  null,
                  ElfSkills.this.elf.getX(),
                  ElfSkills.this.elf.getY(),
                  ElfSkills.this.elf.getZ(),
                  SoundEvents.RAVAGER_ROAR,
                  SoundSource.NEUTRAL,
                  1.6F,
                  0.8F
               );
               var1.playSound(
                  null,
                  ElfSkills.this.elf.getX(),
                  ElfSkills.this.elf.getY(),
                  ElfSkills.this.elf.getZ(),
                  SoundEvents.BEACON_ACTIVATE,
                  SoundSource.NEUTRAL,
                  1.4F,
                  1.2F
               );
            }

            double var2 = this.t * 0.25;

            for (int var4 = 0; var4 < 12; var4++) {
               double var5 = var2 + var4 * Math.PI / 6.0;
               ElfFx.p(
                  var1,
                  ElfFx.gold(),
                  ElfSkills.this.elf.getX() + Math.cos(var5) * 1.4,
                  ElfSkills.this.elf.getY() + 0.15,
                  ElfSkills.this.elf.getZ() + Math.sin(var5) * 1.4,
                  1,
                  0.0,
                  0.02,
                  0.0,
                  0.0
               );
            }

            for (byte var13 = -1; var13 <= 1; var13 += 2) {
               for (double var16 = 0.0; var16 < 1.0; var16 += 0.1) {
                  double var7 = var13 * (0.2 + var16 * 0.45);
                  double var9 = 2.2 + var16 * 0.9;
                  ElfFx.p(
                     var1,
                     ElfFx.gold(),
                     ElfSkills.this.elf.getX() + var7 * Math.cos(Math.toRadians(ElfSkills.this.elf.yBodyRot)),
                     ElfSkills.this.elf.getY() + var9,
                     ElfSkills.this.elf.getZ() + var7 * Math.sin(Math.toRadians(ElfSkills.this.elf.yBodyRot)),
                     1,
                     0.01,
                     0.01,
                     0.01,
                     0.0
                  );
               }
            }

            ElfFx.converge(var1, ElfFx.green(), ElfSkills.this.elf.position().add(0.0, 1.3, 0.0), 3.5, 4, 0.1);
            ElfFx.p(var1, ElfFx.leaf(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 2.4, ElfSkills.this.elf.getZ(), 1, 0.8, 0.5, 0.8, 0.0);
         } else if (this.t == 31) {
            Vec3 var11 = ElfFx.handPos(ElfSkills.this.elf);
            Vec3 var3 = this.target.position().add(0.0, this.target.getBbHeight() * 0.5, 0.0);
            Vec3 var14 = var3.subtract(var11);
            int var17 = (int)Math.min(60.0, var14.length() * 2.0);

            for (int var6 = 0; var6 <= var17; var6++) {
               Vec3 var20 = var11.add(var14.scale((double)var6 / Math.max(1, var17)));
               ElfFx.p(var1, ElfFx.gold(), var20.x, var20.y, var20.z, 1, 0.05, 0.05, 0.05, 0.0);
               if (var6 % 3 == 0) {
                  ElfFx.p(var1, ElfFx.star(), var20.x, var20.y, var20.z, 1, 0.1, 0.1, 0.1, 0.02);
               }
            }

            ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
            this.stag = (SpectralStagEntity)((EntityType)ModRegistry.SPECTRAL_STAG.get()).create(var1);
            if (this.stag == null) {
               return true;
            }

            Vec3 var19 = ElfSkills.this.elf.position().subtract(var14.normalize().multiply(1.0, 0.0, 1.0).scale(2.5));
            this.stag.moveTo(var19.x, var19.y + 0.2, var19.z, ElfSkills.this.elf.getYRot(), 0.0F);
            this.stag.setup(ElfSkills.this.elf, this.target, (Double)ECConfig.huntSpeed.get(), this.dmg, this.pathDmg);
            var1.addFreshEntity(this.stag);
            ElfFx.burst(var1, ElfFx.green(), var19.x, var19.y + 1.2, var19.z, 50, 0.5);
            ElfFx.burst(var1, ElfFx.gold(), var19.x, var19.y + 1.2, var19.z, 30, 0.4);
            ElfFx.burst(var1, ElfFx.leaf(), var19.x, var19.y + 1.5, var19.z, 25, 0.35);
            ElfSkills.this.fx.add(ElfFx.shockwave(var1, var19, 4.0, 8, ElfFx.green(), ElfFx.gold()));
            var1.playSound(null, var19.x, var19.y, var19.z, SoundEvents.RAVAGER_ROAR, SoundSource.NEUTRAL, 2.0F, 0.6F);
         } else {
            if (this.stag == null || this.stag.isRemoved()) {
               return true;
            }

            if (this.t % 4 == 0 && this.target != null && this.target.isAlive()) {
               double var12 = this.t * 0.3;

               for (int var15 = 0; var15 < 8; var15++) {
                  double var18 = var12 + var15 * Math.PI / 4.0;
                  ElfFx.p(
                     var1,
                     ElfFx.gold(),
                     this.target.getX() + Math.cos(var18) * 0.9,
                     this.target.getY() + this.target.getBbHeight() + 0.5,
                     this.target.getZ() + Math.sin(var18) * 0.9,
                     1,
                     0.0,
                     0.0,
                     0.0,
                     0.0
                  );
               }

               ElfFx.p(var1, ElfFx.star(), this.target.getX(), this.target.getY() + this.target.getBbHeight() + 0.5, this.target.getZ(), 1, 0.1, 0.1, 0.1, 0.0);
            }

            if (this.t > (Integer)ECConfig.huntMaxTicks.get() + 60) {
               return true;
            }
         }

         return false;
      }

      @Override
      void finish() {
         if (this.stag != null && !this.stag.isRemoved()) {
            this.stag.dissolve();
         }
      }
   }

   public static enum ManualResult {
      OK,
      COOLDOWN,
      LOCKED,
      INVALID,
      BUSY,
      NO_TARGET;
   }

   private final class Moonfall extends ElfSkills.Cast {
      final Vec3 center;
      int age;
      final double radius = (Double)ECConfig.moonDiameter.get() * ElfSkills.this.area() / 2.0;
      final int interval = Math.max(2, (int)Math.round(((Integer)ECConfig.moonIntervalTicks.get()).intValue() * ElfLevel.lerp(1.0, 0.6, ElfSkills.this.lv())));
      final ElfArrow.HitTracker tracker = new ElfArrow.HitTracker(ElfSkills.this.dmg((Double)ECConfig.moonDamage.get()), (Integer)ECConfig.moonMaxHits.get());
      final List<double[]> falling = new ArrayList<>();

      Moonfall(Vec3 nullx) {
         this.center = nullx;
      }

      @Override
      boolean tick() {
         this.age++;
         ServerLevel var1 = ElfSkills.this.sl();
         double var2 = this.radius;
         byte var4 = 20;
         if (this.age <= var4 && this.age % 4 == 1) {
            for (int var5 = 0; var5 < 4; var5++) {
               ElfFx.vel(
                  var1,
                  ElfFx.star(),
                  ElfSkills.this.elf.getX() + (var5 - 1.5) * 0.25,
                  ElfSkills.this.elf.getY() + 1.4,
                  ElfSkills.this.elf.getZ(),
                  0.0,
                  0.9 + var5 * 0.05,
                  0.0
               );
            }

            ElfFx.p(var1, ElfFx.moon(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 1.4, ElfSkills.this.elf.getZ(), 6, 0.3, 0.2, 0.3, 0.0);
            ElfSkills.this.elf.playSound(SoundEvents.ARROW_SHOOT, 1.0F, 1.3F);
         }

         if (this.age % 2 == 0) {
            double var12 = this.age * 0.07;

            for (int var7 = 0; var7 < 28; var7++) {
               double var8 = var12 + var7 * Math.PI * 2.0 / 28.0;
               ElfFx.p(
                  var1,
                  ElfFx.moon(),
                  this.center.x + Math.cos(var8) * var2,
                  this.center.y + 0.12,
                  this.center.z + Math.sin(var8) * var2,
                  1,
                  0.0,
                  0.02,
                  0.0,
                  0.0
               );
            }

            for (int var17 = 0; var17 < 16; var17++) {
               double var20 = -var12 * 1.4 + var17 * Math.PI * 2.0 / 16.0;
               ElfFx.p(
                  var1,
                  ElfFx.star(),
                  this.center.x + Math.cos(var20) * var2 * 0.62,
                  this.center.y + 0.15,
                  this.center.z + Math.sin(var20) * var2 * 0.62,
                  1,
                  0.0,
                  0.02,
                  0.0,
                  0.0
               );
            }

            for (int var18 = 0; var18 < 8; var18++) {
               double var21 = var12 * 0.6 + var18 * Math.PI / 4.0;

               for (double var10 = 0.3; var10 < 1.0; var10 += 0.35) {
                  ElfFx.p(
                     var1,
                     ElfFx.moon(),
                     this.center.x + Math.cos(var21) * var2 * var10,
                     this.center.y + 0.1,
                     this.center.z + Math.sin(var21) * var2 * var10,
                     1,
                     0.0,
                     0.01,
                     0.0,
                     0.0
                  );
               }
            }

            ElfFx.p(var1, ElfFx.star(), this.center.x, this.center.y + 0.3, this.center.z, 1, 0.2, 0.1, 0.2, 0.0);
         }

         if (this.age > var4) {
            int var13 = this.age - var4;
            if (var13 % this.interval == 0 && var13 <= (Integer)ECConfig.moonDurationTicks.get()) {
               double var6 = ElfSkills.this.elf.getRandom().nextDouble() * Math.PI * 2.0;
               double var22 = Math.sqrt(ElfSkills.this.elf.getRandom().nextDouble()) * var2;
               this.falling.add(new double[]{this.center.x + Math.cos(var6) * var22, this.center.y, this.center.z + Math.sin(var6) * var22, 5.0});
            }

            if (var13 % 10 == 0) {
               this.slowHostiles(var2);
            }

            if (var13 % 4 == 0) {
               double var15 = ElfSkills.this.elf.getRandom().nextDouble() * Math.PI * 2.0;
               double var23 = Math.sqrt(ElfSkills.this.elf.getRandom().nextDouble()) * var2;
               ElfFx.vel(
                  var1, ElfFx.moon(), this.center.x + Math.cos(var15) * var23, this.center.y + 0.1, this.center.z + Math.sin(var15) * var23, 0.0, 0.05, 0.0
               );
            }
         }

         Iterator var14 = this.falling.iterator();

         while (var14.hasNext()) {
            double[] var16 = (double[])var14.next();
            var16[3]--;
            double var19 = var16[3] * 2.0;
            ElfFx.vel(var1, ElfFx.star(), var16[0], var16[1] + var19 + 1.0, var16[2], 0.0, -0.5, 0.0);
            ElfFx.p(var1, ElfFx.moon(), var16[0], var16[1] + var19, var16[2], 3, 0.04, 0.5, 0.04, 0.0);
            if (var16[3] <= 0.0) {
               this.impact(var16[0], var16[1], var16[2]);
               var14.remove();
            }
         }

         return this.age > var4 + (Integer)ECConfig.moonDurationTicks.get() && this.falling.isEmpty();
      }

      void slowHostiles(double var1) {
         for (LivingEntity var4 : ElfSkills.this.sl()
            .getEntitiesOfClass(LivingEntity.class, new AABB(this.center, this.center).inflate(var1, 4.0, var1), ElfSkills.this.elf::isHostile)) {
            double var5 = var4.getX() - this.center.x;
            double var7 = var4.getZ() - this.center.z;
            if (var5 * var5 + var7 * var7 <= var1 * var1) {
               var4.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 25, (Integer)ECConfig.moonSlowAmplifier.get(), false, true));
            }
         }
      }

      void impact(double var1, double var3, double var5) {
         ServerLevel var7 = ElfSkills.this.sl();
         var7.playSound(null, var1, var3, var5, SoundEvents.ARROW_HIT, SoundSource.NEUTRAL, 0.8F, 1.2F);
         ElfFx.ring(var7, ElfFx.moon(), var1, var3 + 0.15, var5, 1.6, 14, 0.14, 0.03);
         ElfFx.burst(var7, ElfFx.star(), var1, var3 + 0.2, var5, 6, 0.2);

         for (LivingEntity var9 : var7.getEntitiesOfClass(
            LivingEntity.class, new AABB(var1 - 2.4, var3 - 2.0, var5 - 2.4, var1 + 2.4, var3 + 4.0, var5 + 2.4), ElfSkills.this.elf::isHostile
         )) {
            if (this.tracker.tryHit(var9)) {
               ElfSkills.this.hurt(var9, this.tracker.damage);
            }
         }
      }
   }

   private final class Piercer extends ElfSkills.Cast {
      final boolean fire;
      Vec3 pos;
      final Vec3 dir;
      int age;
      boolean flying = true;
      final double width = (Double)ECConfig.piercerWidth.get() * ElfSkills.this.area();
      final Set<Integer> hit = new HashSet<>();
      final Map<LivingEntity, Integer> burns = new LinkedHashMap<>();

      Piercer(boolean nullx, Vec3 nullxx, Vec3 nullxxx) {
         this.fire = nullx;
         this.pos = nullxx;
         this.dir = nullxxx;
      }

      @Override
      void start() {
         ElfSkills.this.elf.getLookControl().setLookAt(this.pos.add(this.dir.scale(8.0)));
         ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
         ServerLevel var1 = ElfSkills.this.sl();
         ElfFx.disc(var1, this.fire ? ElfFx.fire() : ElfFx.green(), this.pos.add(this.dir.scale(0.6)), this.dir, this.width * 0.45, 20);
         ElfFx.disc(var1, ElfFx.star(), this.pos.add(this.dir.scale(1.2)), this.dir, this.width * 0.3, 12);
         ElfFx.burst(var1, this.fire ? ElfFx.fire() : ElfFx.green(), this.pos.x, this.pos.y, this.pos.z, 16, 0.25);
      }

      @Override
      boolean tick() {
         this.age++;
         if (this.flying) {
            this.step();
            if (this.age >= (Integer)ECConfig.piercerLifeTicks.get()) {
               this.flying = false;
            }
         }

         if (!this.burns.isEmpty()) {
            if (this.age % 3 == 0) {
               for (LivingEntity var2 : this.burns.keySet()) {
                  ElfFx.p(ElfSkills.this.sl(), ElfFx.fire(), var2.getX(), var2.getY() + var2.getBbHeight() * 0.5, var2.getZ(), 4, 0.25, 0.4, 0.25, 0.01);
                  ElfFx.p(ElfSkills.this.sl(), ElfFx.gold(), var2.getX(), var2.getY() + var2.getBbHeight(), var2.getZ(), 1, 0.2, 0.2, 0.2, 0.02);
               }
            }

            if (this.age % 20 == 0) {
               Iterator var4 = this.burns.entrySet().iterator();

               while (var4.hasNext()) {
                  Entry var5 = (Entry)var4.next();
                  LivingEntity var3 = (LivingEntity)var5.getKey();
                  if (!var3.isAlive()) {
                     var4.remove();
                  } else {
                     ElfSkills.this.hurt(var3, ElfSkills.this.dmg((Double)ECConfig.wildfireBurnPerSecond.get()));
                     var5.setValue((Integer)var5.getValue() - 1);
                     if ((Integer)var5.getValue() <= 0) {
                        var4.remove();
                     }
                  }
               }
            }
         }

         return !this.flying && this.burns.isEmpty();
      }

      void step() {
         ServerLevel var1 = ElfSkills.this.sl();
         Vec3 var2 = this.pos.add(this.dir.scale((Double)ECConfig.piercerSpeed.get()));
         BlockHitResult var3 = var1.clip(new ClipContext(this.pos, var2, Block.COLLIDER, Fluid.NONE, ElfSkills.this.elf));
         boolean var4 = var3.getType() != Type.MISS;
         if (var4) {
            var2 = var3.getLocation();
         }

         AABB var5 = new AABB(this.pos, var2).inflate(this.width / 2.0);

         for (LivingEntity var7 : var1.getEntitiesOfClass(LivingEntity.class, var5, ElfSkills.this.elf::isHostile)) {
            if (this.hit.add(var7.getId())) {
               if (this.fire) {
                  ElfSkills.this.hurt(var7, ElfSkills.this.dmg((Double)ECConfig.wildfireDamage.get()));
                  int var8 = (Integer)ECConfig.wildfireBurnSeconds.get();
                  if (var8 > 0) {
                     this.burns.put(var7, var8 + (int)Math.round(3.0 * ElfLevel.t(ElfSkills.this.lv())));
                  }
               } else {
                  ElfSkills.this.hurt(var7, ElfSkills.this.dmg((Double)ECConfig.verdantDamage.get()));
               }

               ElfFx.burst(var1, this.fire ? ElfFx.fire() : ElfFx.green(), var7.getX(), var7.getY() + var7.getBbHeight() * 0.5, var7.getZ(), 18, 0.3);
               ElfFx.burst(var1, ElfFx.star(), var7.getX(), var7.getY() + var7.getBbHeight() * 0.5, var7.getZ(), 8, 0.35);
            }
         }

         ParticleOptions var10 = this.fire ? ElfFx.fire() : ElfFx.green();
         ParticleOptions var11 = this.fire ? ElfFx.gold() : ElfFx.star();

         for (int var12 = 0; var12 < 3; var12++) {
            Vec3 var9 = this.pos.lerp(var2, var12 / 3.0);
            ElfFx.p(var1, var10, var9.x, var9.y, var9.z, 5, this.width * 0.2, this.width * 0.2, this.width * 0.2, 0.0);
            if (var12 == 0) {
               ElfFx.disc(var1, var10, var9, this.dir, this.width * 0.5, 14);
            }
         }

         if (this.age % 2 == 0) {
            ElfFx.disc(var1, var11, var2, this.dir, this.width * 0.28, 8);
            ElfFx.p(var1, var11, var2.x, var2.y, var2.z, 2, 0.15, 0.15, 0.15, 0.05);
            ElfFx.p(var1, this.fire ? ElfFx.fire() : ElfFx.leaf(), var2.x, var2.y, var2.z, 2, this.width * 0.4, this.width * 0.4, this.width * 0.4, 0.0);
         }

         this.pos = var2;
         if (var4) {
            this.flying = false;
            ElfFx.burst(var1, var10, var2.x, var2.y, var2.z, 22, 0.3);
            ElfFx.burst(var1, ElfFx.star(), var2.x, var2.y, var2.z, 10, 0.3);
         }
      }
   }

   private final class Ricochet extends ElfSkills.Cast {
      LivingEntity cur;
      Vec3 from;
      int t;
      int hits;
      final Map<Integer, Integer> count = new HashMap<>();

      Ricochet(LivingEntity nullx) {
         this.cur = nullx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.elf.getNavigation().stop();
         this.from = ElfFx.handPos(ElfSkills.this.elf);
         ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
         ElfSkills.this.elf.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.4F);
      }

      private LivingEntity next(Vec3 var1) {
         LivingEntity var2 = null;
         int var3 = 99;
         double var4 = 1.0E9;

         for (LivingEntity var7 : ElfSkills.this.sl()
            .getEntitiesOfClass(LivingEntity.class, new AABB(var1, var1).inflate(18.0), var1x -> var1x.isAlive() && ElfSkills.this.elf.isHostile(var1x))) {
            int var8 = this.count.getOrDefault(var7.getId(), 0);
            if (var8 < 4 && (var7 != this.cur || var8 < 6)) {
               double var9 = var7.distanceToSqr(var1.x, var1.y, var1.z);
               boolean var11 = var7 == this.cur;
               if (!var11 && (var8 < var3 || var8 == var3 && var9 < var4)) {
                  var2 = var7;
                  var3 = var8;
                  var4 = var9;
               }
            }
         }

         if (var2 == null && this.cur != null && this.cur.isAlive() && this.count.getOrDefault(this.cur.getId(), 0) < 6) {
            var2 = this.cur;
         }

         return var2;
      }

      @Override
      boolean tick() {
         ServerLevel var1 = ElfSkills.this.sl();
         this.t++;
         ElfSkills.this.elf.getNavigation().stop();
         if (this.cur != null) {
            ElfSkills.this.elf.getLookControl().setLookAt(this.cur, 60.0F, 60.0F);
         }

         if (this.t < 5) {
            Vec3 var6 = ElfFx.handPos(ElfSkills.this.elf);
            ElfFx.p(var1, ElfFx.star(), var6.x, var6.y, var6.z, 2, 0.15, 0.15, 0.15, 0.02);
            return false;
         } else if ((this.t - 5) % 3 != 0) {
            return false;
         } else {
            if (this.cur == null || !this.cur.isAlive()) {
               this.cur = this.next(this.from);
               if (this.cur == null) {
                  return true;
               }
            }

            LivingEntity var2 = this.cur;
            Vec3 var3 = var2.position().add(0.0, var2.getBbHeight() * 0.6, 0.0);
            int var4 = this.count.getOrDefault(var2.getId(), 0);
            if (var4 > 0) {
               Vec3 var5 = var3.add((var1.random.nextDouble() - 0.5) * 6.0, 1.5 + var1.random.nextDouble() * 2.0, (var1.random.nextDouble() - 0.5) * 6.0);
               ElfSkills.beam(var1, this.from, var5, ElfFx.moon());
               this.from = var5;
            }

            ElfSkills.beam(var1, this.from, var3, ElfFx.moon());
            ElfSkills.beam(var1, this.from, var3, ElfFx.star());
            float var7 = ElfSkills.this.dmg(7.0) * Math.max(0.35F, 1.0F - 0.04F * this.hits);
            ElfSkills.this.hurt(var2, var7);
            var2.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
            ElfFx.burst(var1, ElfFx.gold(), var3.x, var3.y, var3.z, 14, 0.25);
            ElfFx.ring(var1, ElfFx.moon(), var3.x, var3.y, var3.z, 0.8, 14, 0.12, 0.02);
            ElfVfx.send(var1, 15, -1, var3, null, 8, 1.0F);
            var1.playSound(null, var3.x, var3.y, var3.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 1.4F, 0.8F + this.hits * 0.09F);
            this.count.merge(var2.getId(), 1, Integer::sum);
            this.hits++;
            this.from = var3;
            if (this.hits >= 16) {
               return true;
            } else {
               this.cur = this.next(var3);
               return this.cur == null;
            }
         }
      }
   }

   private final class Skyfall extends ElfSkills.Cast {
      LivingEntity target;
      final double targetY;
      int phase;
      int t;
      Vec3 arrow;
      Vec3 arrowDir;
      int flight;

      Skyfall(LivingEntity nullx, double nullxx) {
         this.target = nullx;
         this.targetY = nullxx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.elf.setNoGravity(true);
         ElfSkills.this.explosionImmune = (Integer)ECConfig.skyfallImmunityTicks.get();
         ElfSkills.this.elf.getNavigation().stop();
         ElfFx.ring(
            ElfSkills.this.sl(), ElfFx.gold(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 0.15, ElfSkills.this.elf.getZ(), 0.5, 28, 0.25, 0.03
         );
         ElfFx.burst(ElfSkills.this.sl(), ElfFx.star(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 0.5, ElfSkills.this.elf.getZ(), 14, 0.25);
      }

      @Override
      boolean tick() {
         if (this.target == null || !this.target.isAlive()) {
            this.target = ElfSkills.this.elf.nearestHostile(((Integer)ECConfig.attackRange.get()).intValue());
         }

         if (this.target == null) {
            return true;
         } else {
            this.t++;
            ServerLevel var1 = ElfSkills.this.sl();
            if (this.phase == 0) {
               double var9 = this.targetY - ElfSkills.this.elf.getY();
               ElfFx.p(var1, ElfFx.gold(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 0.1, ElfSkills.this.elf.getZ(), 3, 0.25, 0.05, 0.25, 0.0);
               if (!(var9 <= 0.25)
                  && this.t <= 40
                  && ElfSkills.this.elf.level().noCollision(ElfSkills.this.elf, ElfSkills.this.elf.getBoundingBox().move(0.0, 0.3, 0.0))) {
                  ElfSkills.this.elf.setDeltaMovement(0.0, Math.min(0.6, var9 * 0.5 + 0.1), 0.0);
               } else {
                  this.phase = 1;
                  this.t = 0;
                  ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
               }
            } else if (this.phase == 1) {
               ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
               ElfSkills.this.elf.getLookControl().setLookAt(this.target, 60.0F, 60.0F);
               ElfFx.converge(var1, ElfFx.gold(), ElfSkills.this.elf.position().add(0.0, 1.2, 0.0), 2.4, 4, 0.13);
               ElfFx.disc(var1, ElfFx.gold(), ElfSkills.this.elf.position().add(0.0, -0.2, 0.0), new Vec3(0.0, 1.0, 0.0), 1.0 + this.t * 0.06, 14);
               if (this.t >= 8) {
                  this.phase = 2;
                  this.arrow = ElfSkills.this.elf.getEyePosition();
                  this.arrowDir = this.target.position().add(0.0, this.target.getBbHeight() * 0.5, 0.0).subtract(this.arrow).normalize();
                  ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
                  ElfSkills.this.elf.playSound(SoundEvents.SKELETON_SHOOT, 1.2F, 0.7F);
                  ElfFx.muzzle(var1, ElfSkills.this.elf, this.arrowDir);
               }
            } else {
               ElfSkills.this.elf.setDeltaMovement(Vec3.ZERO);
               Vec3 var2 = this.arrow.add(this.arrowDir.scale(2.0));
               BlockHitResult var3 = var1.clip(new ClipContext(this.arrow, var2, Block.COLLIDER, Fluid.NONE, ElfSkills.this.elf));
               if (var3.getType() != Type.MISS) {
                  var2 = var3.getLocation();
               }

               AABB var4 = new AABB(this.arrow, var2).inflate(0.6);
               LivingEntity var5 = null;
               Iterator var6 = var1.getEntitiesOfClass(LivingEntity.class, var4, ElfSkills.this.elf::isHostile).iterator();
               if (var6.hasNext()) {
                  LivingEntity var7 = (LivingEntity)var6.next();
                  var5 = var7;
               }

               for (int var10 = 0; var10 < 4; var10++) {
                  Vec3 var8 = this.arrow.lerp(var2, var10 / 4.0);
                  ElfFx.p(var1, ElfFx.gold(), var8.x, var8.y, var8.z, 2, 0.12, 0.12, 0.12, 0.0);
                  ElfFx.p(var1, ElfFx.fire(), var8.x, var8.y, var8.z, 1, 0.08, 0.08, 0.08, 0.0);
               }

               ElfFx.p(var1, ElfFx.star(), var2.x, var2.y, var2.z, 2, 0.15, 0.15, 0.15, 0.03);
               this.arrow = var2;
               if (var5 != null || var3.getType() != Type.MISS || ++this.flight > 40) {
                  this.explode(this.arrow, var5);
                  return true;
               }
            }

            return false;
         }
      }

      void explode(Vec3 var1, LivingEntity var2) {
         ServerLevel var3 = ElfSkills.this.sl();
         double var4 = (Double)ECConfig.skyfallRadius.get() * ElfSkills.this.area();
         ElfFx.p(var3, ParticleTypes.FLASH, var1.x, var1.y, var1.z, 1, 0.0, 0.0, 0.0, 0.0);
         ElfFx.burst(var3, ElfFx.gold(), var1.x, var1.y, var1.z, 50, 0.55);
         ElfFx.burst(var3, ElfFx.fire(), var1.x, var1.y, var1.z, 30, 0.4);
         ElfFx.burst(var3, ElfFx.star(), var1.x, var1.y, var1.z, 24, 0.6);
         ElfSkills.this.fx.add(ElfFx.shockwave(var3, var1, var4, 10, ElfFx.gold(), ElfFx.fire()));
         var3.playSound(null, var1.x, var1.y, var1.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 2.0F, 1.1F);

         for (LivingEntity var7 : var3.getEntitiesOfClass(LivingEntity.class, new AABB(var1, var1).inflate(var4), ElfSkills.this.elf::isHostile)) {
            if (!(var7.getBoundingBox().distanceToSqr(var1) > var4 * var4)) {
               ElfSkills.this.hurt(var7, ElfSkills.this.dmg(var7 == var2 ? (Double)ECConfig.skyfallDirect.get() : (Double)ECConfig.skyfallSplash.get()));
            }
         }
      }

      @Override
      void finish() {
         ElfSkills.this.elf.setNoGravity(false);
         if (ElfSkills.this.elf.getRandom().nextDouble() < (Double)ECConfig.stompChance.get()
            && ElfSkills.this.elf.isAlive()
            && !ElfSkills.this.elf.isMounted()) {
            ElfSkills.this.pending.add(ElfSkills.this.new Stomp());
         } else {
            ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, (Integer)ECConfig.skyfallSlowFallTicks.get(), 0, false, false));
            ElfSkills.this.fallGuard = (Integer)ECConfig.skyfallSlowFallTicks.get() + 60;
         }
      }
   }

   private final class Stomp extends ElfSkills.Cast {
      int t;

      Stomp() {
         this.anim = 7;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.explosionImmune = 80;
         ElfSkills.this.fallGuard = 220;
         ElfSkills.this.elf.setDashDir(3);
         ElfSkills.this.elf.playSound(SoundEvents.PHANTOM_SWOOP, 1.2F, 0.8F);
      }

      @Override
      boolean tick() {
         this.t++;
         ServerLevel var1 = ElfSkills.this.sl();
         if ((!ElfSkills.this.elf.onGround() || this.t <= 1) && this.t <= 80) {
            Vec3 var2 = ElfSkills.this.elf.getDeltaMovement();
            ElfSkills.this.elf.setDeltaMovement(0.0, Math.min(var2.y, -1.4), 0.0);
            ElfFx.p(var1, ElfFx.gold(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 1.4, ElfSkills.this.elf.getZ(), 4, 0.25, 0.8, 0.25, 0.0);
            ElfFx.p(var1, ElfFx.star(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 2.0, ElfSkills.this.elf.getZ(), 2, 0.2, 0.8, 0.2, 0.0);
            return false;
         } else {
            this.impact(var1);
            return true;
         }
      }

      void impact(ServerLevel var1) {
         Vec3 var2 = ElfSkills.this.elf.position();
         double var3 = (Double)ECConfig.stompRadius.get() * ElfSkills.this.area();
         ElfFx.p(var1, ParticleTypes.FLASH, var2.x, var2.y + 0.3, var2.z, 1, 0.0, 0.0, 0.0, 0.0);
         ElfSkills.this.fx.add(ElfFx.shockwave(var1, var2, var3, 9, ElfFx.gold(), ElfFx.green()));
         ElfFx.burst(var1, ElfFx.gold(), var2.x, var2.y + 0.3, var2.z, 40, 0.5);
         ElfFx.burst(var1, ElfFx.star(), var2.x, var2.y + 0.3, var2.z, 20, 0.5);
         if ((Boolean)ECConfig.particles.get()) {
            var1.sendParticles(
               new BlockParticleOption(ParticleTypes.BLOCK, var1.getBlockState(BlockPos.containing(var2).below())),
               var2.x,
               var2.y + 0.2,
               var2.z,
               60,
               var3 * 0.4,
               0.15,
               var3 * 0.4,
               0.25
            );
         }

         var1.playSound(null, var2.x, var2.y, var2.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 1.4F, 1.4F);
         var1.playSound(null, var2.x, var2.y, var2.z, SoundEvents.ANVIL_LAND, SoundSource.NEUTRAL, 1.0F, 0.7F);

         for (LivingEntity var6 : var1.getEntitiesOfClass(LivingEntity.class, new AABB(var2, var2).inflate(var3, 2.5, var3), ElfSkills.this.elf::isHostile)) {
            if (!(var6.distanceToSqr(var2) > var3 * var3)) {
               ElfSkills.this.hurt(var6, ElfSkills.this.dmg((Double)ECConfig.stompDamage.get()));
               var6.knockback(1.0, ElfSkills.this.elf.getX() - var6.getX(), ElfSkills.this.elf.getZ() - var6.getZ());
               var6.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, true));
            }
         }
      }

      @Override
      void finish() {
         ElfSkills.this.elf.setDashDir(0);
      }
   }

   private final class Thorn extends ElfSkills.Cast {
      final LivingEntity target;
      Vec3 pos;
      Vec3 dir;
      Vec3 root;
      int age;
      int fieldAge;
      boolean rooted;
      final double radius = (Double)ECConfig.thornRadius.get() * ElfSkills.this.area();
      final int duration = (int)Math.round(((Integer)ECConfig.thornDurationTicks.get()).intValue() * ElfLevel.lerp(1.0, 1.5, ElfSkills.this.lv()));
      final Set<Integer> hit = new HashSet<>();

      Thorn(LivingEntity nullx) {
         this.target = nullx;
      }

      @Override
      void start() {
         this.pos = ElfFx.handPos(ElfSkills.this.elf);
         this.dir = this.target.position().add(0.0, this.target.getBbHeight() * 0.4, 0.0).subtract(this.pos).normalize();
         ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
         ElfSkills.this.elf.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 0.8F);
         ElfFx.muzzle(ElfSkills.this.sl(), ElfSkills.this.elf, this.dir);
      }

      @Override
      boolean tick() {
         ServerLevel var1 = ElfSkills.this.sl();
         if (!this.rooted) {
            this.age++;
            Vec3 var13 = this.pos.add(this.dir.scale(2.0));
            BlockHitResult var3 = var1.clip(new ClipContext(this.pos, var13, Block.COLLIDER, Fluid.NONE, ElfSkills.this.elf));
            if (var3.getType() != Type.MISS) {
               var13 = var3.getLocation();
            }

            LivingEntity var15 = null;
            Iterator var17 = var1.getEntitiesOfClass(LivingEntity.class, new AABB(this.pos, var13).inflate(0.6), ElfSkills.this.elf::isHostile).iterator();
            if (var17.hasNext()) {
               LivingEntity var18 = (LivingEntity)var17.next();
               var15 = var18;
            }

            for (int var19 = 0; var19 < 3; var19++) {
               Vec3 var21 = this.pos.lerp(var13, var19 / 3.0);
               ElfFx.p(var1, ElfFx.green(), var21.x, var21.y, var21.z, 2, 0.08, 0.08, 0.08, 0.0);
               ElfFx.p(var1, ElfFx.leaf(), var21.x, var21.y, var21.z, 1, 0.1, 0.1, 0.1, 0.0);
            }

            this.pos = var13;
            if (var15 != null || var3.getType() != Type.MISS || this.age > 25) {
               this.rooted = true;
               this.root = var15 != null ? var15.position() : new Vec3(var13.x, var13.y, var13.z);
               var1.playSound(null, this.root.x, this.root.y, this.root.z, SoundEvents.ROOTED_DIRT_BREAK, SoundSource.NEUTRAL, 1.4F, 0.7F);
               var1.playSound(null, this.root.x, this.root.y, this.root.z, SoundEvents.MOSS_BREAK, SoundSource.NEUTRAL, 1.2F, 0.8F);
               ElfFx.burst(var1, ElfFx.green(), this.root.x, this.root.y + 0.3, this.root.z, 24, 0.3);

               for (LivingEntity var22 : var1.getEntitiesOfClass(
                  LivingEntity.class, new AABB(this.root, this.root).inflate(this.radius, 2.5, this.radius), ElfSkills.this.elf::isHostile
               )) {
                  double var23 = var22.getX() - this.root.x;
                  double var24 = var22.getZ() - this.root.z;
                  if (!(var23 * var23 + var24 * var24 > this.radius * this.radius) && this.hit.add(var22.getId())) {
                     ElfSkills.this.hurt(var22, ElfSkills.this.dmg((Double)ECConfig.thornDamage.get()));
                  }
               }
            }

            return false;
         } else {
            this.fieldAge++;
            double var2 = Math.min(1.0, this.fieldAge / 8.0);
            if (this.fieldAge % 2 == 0) {
               for (int var4 = 0; var4 < 8; var4++) {
                  double var5 = var4 * Math.PI / 4.0 + Math.sin(this.fieldAge * 0.15 + var4) * 0.25;

                  for (double var7 = 0.4; var7 <= this.radius * var2; var7 += 0.7) {
                     ElfFx.vel(var1, ElfFx.green(), this.root.x + Math.cos(var5) * var7, this.root.y + 0.1, this.root.z + Math.sin(var5) * var7, 0.0, 0.03, 0.0);
                  }
               }

               ElfFx.p(var1, ElfFx.leaf(), this.root.x, this.root.y + 0.4, this.root.z, 2, this.radius * 0.5, 0.2, this.radius * 0.5, 0.0);
            }

            if (this.fieldAge % 5 == 0) {
               for (LivingEntity var16 : var1.getEntitiesOfClass(
                  LivingEntity.class, new AABB(this.root, this.root).inflate(this.radius, 2.5, this.radius), ElfSkills.this.elf::isHostile
               )) {
                  double var6 = var16.getX() - this.root.x;
                  double var8 = var16.getZ() - this.root.z;
                  if (!(var6 * var6 + var8 * var8 > this.radius * this.radius)) {
                     boolean var10 = var16.getMaxHealth() >= ((Integer)ECConfig.thornBossHealth.get()).intValue();
                     var16.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, var10 ? 16 : 12, var10 ? 2 : 6, false, true));

                     for (double var11 = 0.0; var11 < var16.getBbHeight(); var11 += 0.45) {
                        ElfFx.p(var1, ElfFx.green(), var16.getX(), var16.getY() + var11, var16.getZ(), 1, 0.3, 0.0, 0.3, 0.0);
                     }

                     ElfFx.p(var1, ElfFx.star(), var16.getX(), var16.getY() + var16.getBbHeight() * 0.5, var16.getZ(), 1, 0.3, 0.3, 0.3, 0.0);
                  }
               }
            }

            return this.fieldAge >= this.duration;
         }
      }
   }

   private final class Transcend extends ElfSkills.Cast {
      int t;
      double y0;
      final int total = 200;
      final int morph = 190;

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.cinematic = this;
         this.y0 = ElfSkills.this.elf.getY();
         ElfSkills.this.elf.setNoGravity(true);
         ElfSkills.this.elf.getNavigation().stop();
         ElfSkills.this.explosionImmune = 260;
         ElfSkills.this.sendNear(ElfSkills.this.elf.position(), 96.0, new ModNetwork.CinematicS2C(0, 200));
         ElfSkills.this.snd(SoundEvents.BEACON_ACTIVATE, 2.0F, 0.8F);
      }

      @Override
      boolean tick() {
         this.t++;
         ServerLevel var1 = ElfSkills.this.sl();
         Vec3 var2 = ElfSkills.this.elf.position();
         double var3 = this.y0 + 3.5 * Math.min(1.0, this.t / 100.0);
         ElfSkills.this.elf.setDeltaMovement(0.0, Mth.clamp((var3 - ElfSkills.this.elf.getY()) * 0.3, -0.2, 0.4), 0.0);
         ElfSkills.this.elf.getNavigation().stop();
         if (this.t % 3 == 0) {
            ElfSkills.this.magicCircle(
               new Vec3(var2.x, this.y0 + 0.05, var2.z), 1.0 + 5.5 * Math.min(1.0, this.t / 40.0), this.t * 0.04, ElfFx.gold(), ElfFx.green()
            );
         }

         if (this.t >= 30 && this.t % 2 == 0) {
            for (int var5 = 0; var5 < 4; var5++) {
               double var6 = this.t * 0.15 + var5 * Math.PI / 2.0;
               double var8 = this.t % 40 * 0.12 + var5 * 0.9;
               ElfFx.p(var1, ElfFx.star(), var2.x + Math.cos(var6) * 1.7, this.y0 + var8, var2.z + Math.sin(var6) * 1.7, 1, 0.0, 0.0, 0.0, 0.0);
            }

            for (int var10 = 0; var10 < 2; var10++) {
               double var13 = this.t * 0.3 + var10 * Math.PI;
               double var14 = this.t % 50 * 0.1;
               ElfFx.p(var1, ElfFx.gold(), var2.x + Math.cos(var13) * 0.9, var2.y + var14 - 0.5, var2.z + Math.sin(var13) * 0.9, 1, 0.0, 0.0, 0.0, 0.0);
               ElfFx.p(
                  var1,
                  ElfFx.green(),
                  var2.x + Math.cos(var13 + 1.1) * 1.2,
                  var2.y + var14 * 1.3 - 0.5,
                  var2.z + Math.sin(var13 + 1.1) * 1.2,
                  1,
                  0.0,
                  0.0,
                  0.0,
                  0.0
               );
            }
         }

         if (this.t >= 100 && this.t % 2 == 0) {
            for (double var11 = 0.0; var11 < 72.0; var11 += 3.0) {
               ElfFx.p(var1, ElfFx.gold(), var2.x, ElfSkills.this.elf.getY() + var11, var2.z, 1, 0.45, 0.0, 0.45, 0.0);
               if (((int)(var11 / 3.0) + this.t) % 2 == 0) {
                  ElfFx.p(var1, ElfFx.green(), var2.x, ElfSkills.this.elf.getY() + var11, var2.z, 1, 0.9, 0.0, 0.9, 0.0);
               }
            }
         }

         if (this.t >= 60 && this.t % 5 == 0) {
            double var12 = var2.x + (var1.random.nextDouble() - 0.5) * 6.0;
            double var7 = var2.z + (var1.random.nextDouble() - 0.5) * 6.0;
            ElfFx.vel(var1, ElfFx.star(), var12, ElfSkills.this.elf.getY() + var1.random.nextDouble() * 3.0, var7, 0.0, 0.06, 0.0);
            ElfFx.burst(var1, ElfFx.gold(), var12, ElfSkills.this.elf.getY() + 1.5, var7, 3, 0.1);
         }

         if (this.t % 20 == 0 && this.t < 180) {
            ElfSkills.this.snd(SoundEvents.AMETHYST_BLOCK_CHIME, 1.6F, 0.7F + this.t / 200.0F * 1.2F);
         }

         if (this.t == 1 || this.t == 70 || this.t == 140) {
            ElfSkills.this.bar(Component.translatable("transcend.elven_companions.line" + (this.t == 1 ? 1 : (this.t == 70 ? 2 : 3))), 64.0);
         }

         if (this.t == 60) {
            ElfSkills.this.snd(SoundEvents.ENCHANTMENT_TABLE_USE, 2.0F, 0.8F);
         }

         if (this.t == 100) {
            ElfSkills.this.snd(SoundEvents.BEACON_POWER_SELECT, 2.0F, 0.9F);
         }

         if (this.t == 150) {
            ElfSkills.this.snd(SoundEvents.END_PORTAL_SPAWN, 0.6F, 1.4F);
         }

         if (this.t == 190) {
            ElfSkills.this.elf.setTranscended(true);
            ElfFx.p(var1, ParticleTypes.FLASH, var2.x, var2.y + 1.0, var2.z, 1, 0.0, 0.0, 0.0, 0.0);
            ElfFx.burst(var1, ElfFx.gold(), var2.x, var2.y + 1.2, var2.z, 80, 0.8);
            ElfFx.burst(var1, ElfFx.star(), var2.x, var2.y + 1.2, var2.z, 60, 0.9);
            ElfSkills.this.fx.add(ElfFx.shockwave(var1, new Vec3(var2.x, this.y0, var2.z), 14.0, 18, ElfFx.gold(), ElfFx.green()));
            ElfSkills.this.snd(SoundEvents.LIGHTNING_BOLT_THUNDER, 2.0F, 0.6F);
            ElfSkills.this.snd(SoundEvents.PLAYER_LEVELUP, 1.5F, 0.7F);
            ElfSkills.this.bar(Component.translatable("transcend.elven_companions.done", new Object[]{ElfSkills.this.elf.getDisplayName()}), 64.0);
         }

         return this.t >= 200;
      }

      @Override
      void finish() {
         ElfSkills.this.elf.setNoGravity(false);
         ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 120, 0, false, false));
         ElfSkills.this.fallGuard = 200;
         if (this.t >= 30000 && ElfSkills.this.elf.isTranscended() && ElfSkills.this.elf.level() instanceof ServerLevel var1) {
            var1.playSound(
               null,
               ElfSkills.this.elf.getX(),
               ElfSkills.this.elf.getY(),
               ElfSkills.this.elf.getZ(),
               (SoundEvent)ModRegistry.SND_TRANSCEND_MUSIC.get(),
               SoundSource.MUSIC,
               ((Double)ECConfig.musicVolume.get()).floatValue(),
               1.0F
            );
         }

         ElfSkills.this.cinematic = null;
      }
   }

   private final class Ultimate extends ElfSkills.Cast {
      int t;
      int landing;
      boolean fired;
      double startY;
      double apexY;
      final int dur = (Integer)ECConfig.ultDurationTicks.get();

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.elf.getNavigation().stop();
         ElfSkills.this.elf.setNoGravity(true);
         this.startY = ElfSkills.this.elf.getY();
         double var1 = ((Integer)ECConfig.ultHeight.get()).intValue();
         double var3 = ElfSkills.this.sl().getMaxBuildHeight() - 3 - this.startY;
         var1 = Math.min(var1, var3);

         for (double var5 = 1.0; var5 <= var1; var5++) {
            if (!ElfSkills.this.elf.level().noCollision(ElfSkills.this.elf, ElfSkills.this.elf.getBoundingBox().move(0.0, var5, 0.0))) {
               var1 = Math.max(1.0, var5 - 2.0);
               break;
            }
         }

         this.apexY = this.startY + Math.max(1.0, var1);
         ElfFx.ring(
            ElfSkills.this.sl(), ElfFx.gold(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 0.15, ElfSkills.this.elf.getZ(), 0.8, 36, 0.3, 0.03
         );
      }

      @Override
      boolean tick() {
         this.t++;
         if (!this.fired) {
            double var1 = Math.min(1.0, (double)this.t / this.dur);
            double var3 = 1.0 - Math.pow(1.0 - var1, 2.0);
            double var5 = this.startY + (this.apexY - this.startY) * var3;
            double var7 = Math.max(0.0, Math.min(0.5, var5 - ElfSkills.this.elf.getY()));
            if (!ElfSkills.this.elf.level().noCollision(ElfSkills.this.elf, ElfSkills.this.elf.getBoundingBox().move(0.0, 0.3, 0.0))) {
               var7 = 0.0;
            }

            ElfSkills.this.elf.setDeltaMovement(0.0, var7, 0.0);
            ElfSkills.this.elf.getNavigation().stop();
            if (this.t % 2 == 0) {
               this.aura(var1);
            }

            if (this.t % 30 == 1 || this.t == 1) {
               ElfSkills.this.bar(
                  Component.translatable("ultimate.elven_companions.line" + (var1 < 0.3 ? 1 : (var1 < 0.6 ? 2 : 3))),
                  (double)((Integer)ECConfig.ultAnnounceRadius.get()).intValue()
               );
            }

            if (this.t >= this.dur) {
               this.fire();
            }
         } else {
            this.landing++;
            if (ElfSkills.this.elf.onGround() || this.landing > 300) {
               return true;
            }
         }

         return false;
      }

      void aura(double var1) {
         ServerLevel var3 = ElfSkills.this.sl();
         double var4 = this.t * 0.35;

         for (int var6 = 0; var6 < 3; var6++) {
            double var7 = var4 + var6 * Math.PI * 2.0 / 3.0;
            double var9 = this.t % 40 * 0.05;
            ElfFx.p(
               var3,
               ElfFx.gold(),
               ElfSkills.this.elf.getX() + Math.cos(var7) * 0.9,
               ElfSkills.this.elf.getY() + 0.2 + var9,
               ElfSkills.this.elf.getZ() + Math.sin(var7) * 0.9,
               1,
               0.0,
               0.05,
               0.0,
               0.0
            );
            ElfFx.p(
               var3,
               ElfFx.star(),
               ElfSkills.this.elf.getX() + Math.cos(-var7) * 1.3,
               ElfSkills.this.elf.getY() + 1.8 - var9,
               ElfSkills.this.elf.getZ() + Math.sin(-var7) * 1.3,
               1,
               0.0,
               0.05,
               0.0,
               0.0
            );
         }

         for (double var11 = 0.0; var11 < 4.5; var11 += 0.9) {
            ElfFx.p(var3, ElfFx.green(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + var11, ElfSkills.this.elf.getZ(), 1, 0.45, 0.1, 0.45, 0.0);
         }

         ElfFx.p(var3, ElfFx.leaf(), ElfSkills.this.elf.getX(), ElfSkills.this.elf.getY() + 2.2, ElfSkills.this.elf.getZ(), 1, 1.2, 1.0, 1.2, 0.0);
         if (var1 > 0.5) {
            ElfFx.converge(var3, ElfFx.star(), ElfSkills.this.elf.position().add(0.0, 1.2, 0.0), 6.0, 3, 0.08);
         }
      }

      void fire() {
         this.fired = true;
         ServerLevel var1 = ElfSkills.this.sl();
         double var2 = ElfSkills.this.ultScale(ElfSkills.this.area());
         double var4 = ElfSkills.this.ultScale(ElfLevel.skillDamage(ElfSkills.this.lv()) * ElfSkills.this.tMul());
         Vec3 var6 = ElfSkills.this.elf.position();
         Vec3 var7 = new Vec3(var6.x, var1.getMinBuildHeight(), var6.z);
         BlockHitResult var8 = var1.clip(new ClipContext(var6, var7, Block.COLLIDER, Fluid.NONE, ElfSkills.this.elf));
         Vec3 var9 = var8.getType() == Type.MISS ? var7 : var8.getLocation();
         double var10 = (Double)ECConfig.ultBeamWidth.get() * var2;
         double var12 = Math.max(1.0, var6.y - var9.y);

         for (double var14 = var6.y; var14 > var9.y; var14 -= 0.6) {
            double var16 = var10 * 0.5 * Math.min(1.0, 0.15 + (var6.y - var14) / var12);
            ElfFx.p(var1, ElfFx.gold(), var6.x, var14, var6.z, 3, var16 * 0.35, 0.0, var16 * 0.35, 0.0);
            ElfFx.p(var1, ElfFx.green(), var6.x, var14, var6.z, 2, var16 * 0.5, 0.0, var16 * 0.5, 0.0);
            ElfFx.p(var1, ElfFx.star(), var6.x, var14, var6.z, 1, var16 * 0.2, 0.0, var16 * 0.2, 0.0);
         }

         ElfFx.p(var1, ParticleTypes.FLASH, var9.x, var9.y + 0.5, var9.z, 1, 0.0, 0.0, 0.0, 0.0);
         ElfFx.burst(var1, ElfFx.gold(), var9.x, var9.y + 0.6, var9.z, 90, 0.9);
         ElfFx.burst(var1, ElfFx.star(), var9.x, var9.y + 0.6, var9.z, 60, 1.0);

         for (int var22 = 0; var22 < 40; var22++) {
            double var15 = var1.random.nextDouble() * Math.PI * 2.0;
            double var17 = var1.random.nextDouble() * var10 * 0.35;
            ElfFx.vel(
               var1,
               ElfFx.gold(),
               var9.x + Math.cos(var15) * var17,
               var9.y + 0.2,
               var9.z + Math.sin(var15) * var17,
               0.0,
               0.5 + var1.random.nextDouble() * 0.7,
               0.0
            );
         }

         ElfSkills.this.fx.add(ElfFx.shockwave(var1, var9, var10 * 1.3, 16, ElfFx.gold(), ElfFx.green()));
         ElfSkills.this.fx.add(ElfFx.shockwave(var1, var9, var10 * 0.8, 10, ElfFx.star(), ElfFx.gold()));
         if ((Boolean)ECConfig.particles.get()) {
            var1.sendParticles(
               new BlockParticleOption(ParticleTypes.BLOCK, var1.getBlockState(BlockPos.containing(var9).below())),
               var9.x,
               var9.y + 0.3,
               var9.z,
               120,
               var10 * 0.4,
               0.2,
               var10 * 0.4,
               0.35
            );
         }

         var1.playSound(null, var9.x, var9.y, var9.z, (SoundEvent)ModRegistry.SND_ULT_IMPACT.get(), SoundSource.NEUTRAL, 8.0F, 1.0F);
         var1.playSound(null, var9.x, var9.y, var9.z, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.NEUTRAL, 6.0F, 0.7F);
         double var23 = Math.min(96.0, ((Integer)ECConfig.ultFarRadius.get()).intValue() * var2);
         double var24 = ((Integer)ECConfig.ultNearRadius.get()).intValue() * var2;

         for (LivingEntity var19 : var1.getEntitiesOfClass(LivingEntity.class, new AABB(var9, var9).inflate(var23), ElfSkills.this.elf::isHostile)) {
            double var20 = Math.sqrt(var19.distanceToSqr(var9));
            if (!(var20 > var23)) {
               ElfSkills.this.hurt(var19, (float)(var20 <= var24 ? (Double)ECConfig.ultNearDamage.get() : (Double)ECConfig.ultFarDamage.get() * var4));
            }
         }

         PacketDistributor.sendToPlayersNear(var1, null, var9.x, var9.y, var9.z, 96.0, new ModNetwork.ImpactS2C(), new CustomPacketPayload[0]);
         ElfSkills.this.elf.setNoGravity(false);
         ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 240, 0, false, false));
         ElfSkills.this.fallGuard = 300;
      }

      @Override
      void finish() {
         ElfSkills.this.elf.setNoGravity(false);
         if (!this.fired) {
            ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, false, false));
            ElfSkills.this.fallGuard = 300;
         }

         ElfSkills.this.ult = null;
      }
   }

   private final class Volley extends ElfSkills.Cast {
      LivingEntity target;
      int fired;
      int timer;
      final int total = (Integer)ECConfig.volleyArrows.get() + (int)Math.round(10.0 * ElfLevel.t(ElfSkills.this.lv()));
      final int interval = Math.max(2, (int)Math.round(((Integer)ECConfig.volleyIntervalTicks.get()).intValue() * ElfLevel.lerp(1.0, 0.6, ElfSkills.this.lv())));
      final ElfArrow.HitTracker tracker = new ElfArrow.HitTracker(
         ElfSkills.this.dmg((Double)ECConfig.volleyDamage.get()), (Integer)ECConfig.volleyMaxHits.get()
      );

      Volley(LivingEntity nullx) {
         this.target = nullx;
      }

      @Override
      boolean holds() {
         return true;
      }

      @Override
      boolean tick() {
         if (this.target == null || !this.target.isAlive()) {
            this.target = ElfSkills.this.elf.nearestHostile(32.0);
         }

         if (this.target == null) {
            return true;
         } else {
            ElfSkills.this.elf.getNavigation().stop();
            ElfSkills.this.elf.getLookControl().setLookAt(this.target, 60.0F, 60.0F);
            if (this.timer-- <= 0) {
               this.fire();
               this.fired++;
               this.timer = this.interval;
            }

            return this.fired >= this.total;
         }
      }

      void fire() {
         ElfArrow var1 = new ElfArrow((EntityType<? extends ElfArrow>)ModRegistry.ELF_ARROW.get(), ElfSkills.this.sl());
         var1.setOwner(ElfSkills.this.elf);
         var1.setPos(ElfSkills.this.elf.getX(), ElfSkills.this.elf.getEyeY() - 0.1, ElfSkills.this.elf.getZ());
         var1.pickup = Pickup.DISALLOWED;
         var1.setTracker(this.tracker);
         double var2 = ElfSkills.this.elf.distanceTo(this.target);
         Vec3 var4 = this.target
            .position()
            .add(0.0, this.target.getBbHeight() * 0.5, 0.0)
            .add(this.target.getDeltaMovement().scale(var2 / 2.0 * ElfLevel.aimLead(ElfSkills.this.lv())));
         double var5 = var4.x - var1.getX();
         double var7 = var4.y - var1.getY();
         double var9 = var4.z - var1.getZ();
         var1.shoot(var5, var7 + Math.sqrt(var5 * var5 + var9 * var9) * 0.08, var9, 2.0F, 6.0F - (float)(4.0 * ElfLevel.t(ElfSkills.this.lv())));
         ElfSkills.this.sl().addFreshEntity(var1);
         ElfSkills.this.elf.swing(InteractionHand.MAIN_HAND);
         ElfSkills.this.elf.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.2F);
         ElfFx.muzzle(ElfSkills.this.sl(), ElfSkills.this.elf, new Vec3(var5, var7, var9).normalize());
      }
   }

   private final class WorldWrath extends ElfSkills.Cast {
      static final int CHARGE = 30;
      static final int PULSES = 10;
      static final int PULSE_EVERY = 8;
      static final int FINALE = 116;
      static final int END = 150;
      final double radius = 16.0;
      Vec3 c;
      int t;
      boolean finale;
      final ElfArrow.HitTracker rain = new ElfArrow.HitTracker(ElfSkills.this.dmg(3.5), 6);

      @Override
      boolean holds() {
         return true;
      }

      @Override
      void start() {
         ElfSkills.this.elf.getNavigation().stop();
         this.c = ElfSkills.this.elf.position();
         ElfSkills.this.elf.setNoGravity(true);
         ElfSkills.this.sl().playSound(null, this.c.x, this.c.y, this.c.z, SoundEvents.BEACON_ACTIVATE, SoundSource.NEUTRAL, 2.0F, 0.5F);
      }

      private List<LivingEntity> foes() {
         return ElfSkills.this.sl()
            .getEntitiesOfClass(
               LivingEntity.class,
               new AABB(this.c, this.c).inflate(16.0, 8.0, 16.0),
               var1 -> var1.isAlive() && ElfSkills.this.elf.isHostile(var1) && var1.distanceToSqr(this.c.x, var1.getY(), this.c.z) <= 16.0 * 16.0
            );
      }

      private void tree(ServerLevel var1) {
         double var2 = Math.min(1.0, this.t / 36.0) * 13.0;

         for (double var4 = 0.0; var4 < var2; var4 += 0.8) {
            double var6 = 0.25 + 0.5 * (1.0 - var4 / 13.0);
            ElfFx.p(var1, ElfFx.green(), this.c.x, this.c.y + var4, this.c.z, 2, var6, 0.1, var6, 0.0);
         }

         if (var2 > 6.0) {
            double var13 = this.c.y + var2;
            double var14 = 5.5 * Math.min(1.0, (var2 - 6.0) / 7.0);

            for (int var8 = 0; var8 < 18; var8++) {
               double var9 = Math.random() * Math.PI * 2.0;
               double var11 = Math.sqrt(Math.random()) * var14;
               ElfFx.p(
                  var1,
                  var8 % 3 == 0 ? ElfFx.gold() : ElfFx.leaf(),
                  this.c.x + Math.cos(var9) * var11,
                  var13 - Math.random() * 1.6,
                  this.c.z + Math.sin(var9) * var11,
                  1,
                  0.1,
                  0.1,
                  0.1,
                  0.0
               );
            }
         }
      }

      private void pulse(ServerLevel var1, int var2) {
         var1.playSound(null, this.c.x, this.c.y, this.c.z, SoundEvents.ROOTED_DIRT_BREAK, SoundSource.NEUTRAL, 1.8F, 0.6F + var2 * 0.04F);
         ElfFx.ring(var1, ElfFx.green(), this.c.x, this.c.y + 0.3, this.c.z, 2.0 + var2 * 1.4, 36, 0.25, 0.05);
         List var3 = this.foes();
         int var4 = 0;

         for (LivingEntity var6 : var3) {
            ElfSkills.this.hurt(var6, ElfSkills.this.dmg(5.0));
            var6.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 24, 5, false, false));
            var6.push(0.0, 0.3, 0.0);

            for (double var7 = 0.0; var7 < 3.2; var7 += 0.5) {
               ElfFx.vel(var1, ElfFx.green(), var6.getX(), var6.getY() + var7, var6.getZ(), 0.0, 0.12, 0.0);
               ElfFx.p(var1, ElfFx.leaf(), var6.getX(), var6.getY() + var7, var6.getZ(), 1, 0.4, 0.0, 0.4, 0.0);
            }

            if (var4 < 6) {
               var4++;
               ElfArrow var9 = new ElfArrow((EntityType<? extends ElfArrow>)ModRegistry.ELF_ARROW.get(), var1);
               var9.setOwner(ElfSkills.this.elf);
               var9.setPos(var6.getX() + (var1.random.nextDouble() - 0.5) * 2.0, var6.getY() + 12.0, var6.getZ() + (var1.random.nextDouble() - 0.5) * 2.0);
               var9.pickup = Pickup.DISALLOWED;
               var9.setTracker(this.rain);
               var9.shoot(0.0, -1.0, 0.0, 2.6F, 0.0F);
               var1.addFreshEntity(var9);
            }
         }
      }

      @Override
      boolean tick() {
         ServerLevel var1 = ElfSkills.this.sl();
         this.t++;
         ElfSkills.this.elf.getNavigation().stop();
         Vec3 var2 = ElfSkills.this.elf.getDeltaMovement();
         double var3 = this.t < 30 ? 0.05 : (this.t < 144 ? 0.0 : -0.02);
         ElfSkills.this.elf.setDeltaMovement(var2.x * 0.5, var3, var2.z * 0.5);
         ElfSkills.this.elf.hasImpulse = true;
         this.tree(var1);
         if (this.t <= 30) {
            double var5 = 16.0 * this.t / 30.0;
            if (this.t % 2 == 0) {
               ElfFx.ring(var1, ElfFx.gold(), this.c.x, this.c.y + 0.1, this.c.z, var5, 40, 0.0, 0.02);
               ElfFx.ring(var1, ElfFx.green(), this.c.x, this.c.y + 0.1, this.c.z, var5 * 0.6, 28, 0.0, 0.02);
            }

            if (this.t % 6 == 0) {
               for (LivingEntity var8 : this.foes()) {
                  var8.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false));
                  var8.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 4, false, false));
               }
            }
         } else if (this.t < 116) {
            int var14 = this.t - 30;
            if (var14 % 8 == 0) {
               this.pulse(var1, var14 / 8);
            }
         } else if (!this.finale) {
            this.finale = true;
            var1.playSound(null, this.c.x, this.c.y, this.c.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.NEUTRAL, 3.0F, 1.2F);
            var1.playSound(null, this.c.x, this.c.y, this.c.z, SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 1.6F, 0.7F);
            ElfFx.ring(var1, ElfFx.gold(), this.c.x, this.c.y + 0.4, this.c.z, 3.0, 40, 0.5, 0.05);
            ElfFx.ring(var1, ElfFx.green(), this.c.x, this.c.y + 0.4, this.c.z, 6.0, 60, 0.6, 0.05);
            ElfFx.ring(var1, ElfFx.moon(), this.c.x, this.c.y + 0.4, this.c.z, 9.0, 80, 0.7, 0.05);
            ElfFx.burst(var1, ElfFx.gold(), this.c.x, this.c.y + 4.0, this.c.z, 60, 0.9);
            ElfFx.sparkle(var1, this.c.x, this.c.y + 6.0, this.c.z, 8.0, 60);

            for (LivingEntity var6 : this.foes()) {
               double var18 = var6.getX() - this.c.x;
               double var9 = var6.getZ() - this.c.z;
               double var11 = Math.sqrt(var18 * var18 + var9 * var9);
               float var13 = (float)Math.max(0.45, 1.0 - var11 / 16.0 * 0.55);
               ElfSkills.this.hurt(var6, ElfSkills.this.dmg(40.0) * var13);
               if (var11 > 0.01) {
                  var6.push(var18 / var11 * 0.9, 0.5, var9 / var11 * 0.9);
               }
            }

            float var16 = ElfSkills.this.elf.getMaxHealth() * 0.2F;
            ElfSkills.this.elf.heal(var16);
            Player var17 = ElfSkills.this.elf.getOwnerPlayer();
            if (var17 != null && var17.level() == ElfSkills.this.elf.level() && var17.distanceToSqr(ElfSkills.this.elf) <= 16.0 * 16.0 * 4.0) {
               var17.heal(var17.getMaxHealth() * 0.2F);
               ElfFx.burst(var1, ElfFx.green(), var17.getX(), var17.getY() + 1.0, var17.getZ(), 20, 0.2);
            }
         }

         return this.t >= 150;
      }

      @Override
      void finish() {
         ElfSkills.this.elf.setNoGravity(false);
         ElfSkills.this.elf.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0, false, false));
         ElfSkills.this.grantFallGuard(120);
      }
   }
}
