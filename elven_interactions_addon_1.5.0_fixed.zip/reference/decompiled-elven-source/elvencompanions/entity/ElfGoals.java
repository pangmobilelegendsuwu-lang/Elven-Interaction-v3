package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import java.util.EnumSet;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.Goal.Flag;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class ElfGoals {
   private ElfGoals() {
   }

   public static class AggressiveTargetGoal extends NearestAttackableTargetGoal<LivingEntity> {
      private final ElfEntity elf;

      public AggressiveTargetGoal(ElfEntity var1) {
         super(var1, LivingEntity.class, 10, true, false, var1x -> var1.isHostileInLeash(var1x));
         this.elf = var1;
      }

      public boolean canUse() {
         return this.elf.getCombat() == 2 && this.elf.canFight() && super.canUse();
      }

      public boolean canContinueToUse() {
         return this.elf.canFight() && super.canContinueToUse();
      }
   }

   public static class AvoidOwnerGoal extends Goal {
      private final ElfEntity elf;
      private int cooldown;

      public AvoidOwnerGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE));
      }

      public boolean canUse() {
         if (--this.cooldown <= 0 && this.elf.getStance() == 0 && !this.elf.isBusyForMovement() && this.elf.getTarget() == null) {
            Player var1 = this.elf.getOwnerPlayer();
            return var1 != null && var1.level() == this.elf.level() && this.elf.distanceToSqr(var1) < 2.5600000000000005;
         } else {
            return false;
         }
      }

      public void start() {
         this.cooldown = 30;
         Player var1 = this.elf.getOwnerPlayer();
         if (var1 != null) {
            Vec3 var2 = DefaultRandomPos.getPosAway(this.elf, 4, 2, var1.position());
            if (var2 != null) {
               this.elf.getNavigation().moveTo(var2.x, var2.y, var2.z, 0.9);
            }
         }
      }

      public boolean canContinueToUse() {
         return false;
      }
   }

   public static class BowGoal extends Goal {
      private final ElfEntity elf;
      private int attackTime;
      private int seeTime;
      private int strafeTime;
      private boolean clockwise = true;

      public BowGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
      }

      public boolean canUse() {
         LivingEntity var1 = this.elf.getTarget();
         return var1 != null && var1.isAlive() && this.elf.canFight() && !this.elf.defense.isDrinking() && !this.elf.skills.isBusy();
      }

      public boolean canContinueToUse() {
         return this.canUse();
      }

      public void start() {
         this.elf.setAggressive(true);
         this.attackTime = Math.max(this.attackTime, 10);
         this.strafeTime = 0;
         this.clockwise = this.elf.getRandom().nextBoolean();
      }

      public void stop() {
         this.elf.setAggressive(false);
         this.seeTime = 0;
         this.elf.getNavigation().stop();
      }

      public boolean requiresUpdateEveryTick() {
         return true;
      }

      public void tick() {
         LivingEntity var1 = this.elf.getTarget();
         if (var1 != null) {
            double var2 = ((Integer)ECConfig.attackRange.get()).intValue() + (this.elf.skills.isFlying() ? 12.0 : 0.0);
            double var4 = this.elf.distanceToSqr(var1);
            double var6 = Math.sqrt(var4);
            boolean var8 = this.elf.getSensing().hasLineOfSight(var1);
            if (var8) {
               if (this.seeTime < 0) {
                  this.seeTime = 0;
               }

               this.seeTime++;
            } else {
               if (this.seeTime > 0) {
                  this.seeTime = 0;
               }

               this.seeTime--;
            }

            if (this.seeTime < -100) {
               this.elf.setTarget(null);
            } else {
               boolean var9 = this.elf.getStance() != 1 && !this.elf.isMounted();
               if (var9) {
                  BlockPos var10 = this.elf.getGuardPos();
                  boolean var11 = this.elf.getStance() == 2 && var10 != null;
                  if (var11
                     && this.elf.blockPosition().distSqr(var10)
                        > (double)((Integer)ECConfig.guardRadius.get()).intValue() * ((Integer)ECConfig.guardRadius.get()).intValue()) {
                     this.elf.getNavigation().moveTo(var10.getX() + 0.5, var10.getY(), var10.getZ() + 0.5, 1.0);
                  } else if (var4 <= var2 * var2 && this.seeTime >= 10) {
                     this.elf.getNavigation().stop();
                     if (++this.strafeTime >= 20) {
                        this.strafeTime = 0;
                        if (this.elf.getRandom().nextFloat() < 0.35F) {
                           this.clockwise = !this.clockwise;
                        }
                     }

                     float var12 = var6 > var2 * 0.75 ? 0.5F : (var6 < var2 * 0.3 ? -0.5F : 0.0F);
                     this.elf.getMoveControl().strafe(var12, this.clockwise ? 0.5F : -0.5F);
                     this.elf.lookAt(var1, 30.0F, 30.0F);
                  } else {
                     this.strafeTime = 0;
                     this.elf.getNavigation().moveTo(var1, 1.0);
                  }
               }

               this.elf.getLookControl().setLookAt(var1, 30.0F, 30.0F);
               if (this.attackTime > 0) {
                  this.attackTime--;
               }

               if (this.attackTime <= 0 && var8 && var4 <= var2 * var2 && this.seeTime >= 3) {
                  this.elf.shoot(var1);
                  this.attackTime = this.elf.fireInterval();
               }
            }
         }
      }
   }

   public static class EscapeGoal extends Goal {
      private final ElfEntity elf;
      private int recalc;

      public EscapeGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE));
      }

      public boolean canUse() {
         return this.elf.defense.isEscaping() && !this.elf.isMounted() && !this.elf.skills.isUltimate() && !this.elf.skills.isBusy();
      }

      public boolean canContinueToUse() {
         return this.canUse();
      }

      public void tick() {
         Player var1 = this.elf.getOwnerPlayer();
         if (var1 != null && var1.level() == this.elf.level()) {
            this.elf.getLookControl().setLookAt(var1, 30.0F, 30.0F);
            double var4 = this.elf.distanceToSqr(var1);
            if (var4 > 9.0) {
               if (--this.recalc <= 0) {
                  this.recalc = 6;
                  this.elf.getNavigation().moveTo(var1, 1.45);
               }
            } else {
               this.elf.getNavigation().stop();
            }
         } else if (--this.recalc <= 0) {
            this.recalc = 10;
            LivingEntity var2 = this.elf.nearestHostile(16.0);
            if (var2 != null) {
               Vec3 var3 = DefaultRandomPos.getPosAway(this.elf, 12, 5, var2.position());
               if (var3 != null) {
                  this.elf.getNavigation().moveTo(var3.x, var3.y, var3.z, 1.4);
               }
            }
         }
      }
   }

   public static class FollowGoal extends Goal {
      private final ElfEntity elf;
      private int recalc;

      public FollowGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE));
      }

      private Player owner() {
         return this.elf.getOwnerPlayer();
      }

      public boolean canUse() {
         if (this.elf.getStance() == 0 && !this.elf.isBusyForMovement() && !this.elf.isGoingHome()) {
            Player var1 = this.owner();
            if (var1 != null && var1.level() == this.elf.level() && !var1.isSpectator()) {
               double var2 = ((Integer)ECConfig.followStartDistance.get()).intValue();
               return this.elf.distanceToSqr(var1) > var2 * var2;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }

      public boolean canContinueToUse() {
         Player var1 = this.owner();
         if (var1 != null && var1.level() == this.elf.level() && this.elf.getStance() == 0 && !this.elf.isBusyForMovement()) {
            double var2 = ((Integer)ECConfig.followStopDistance.get()).intValue();
            return this.elf.distanceToSqr(var1) > var2 * var2;
         } else {
            return false;
         }
      }

      public void start() {
         this.recalc = 0;
      }

      public void stop() {
         this.elf.getNavigation().stop();
      }

      public void tick() {
         Player var1 = this.owner();
         if (var1 != null) {
            this.elf.getLookControl().setLookAt(var1, 10.0F, this.elf.getMaxHeadXRot());
            double var2 = this.elf.distanceToSqr(var1);
            double var4 = ((Integer)ECConfig.teleportDistance.get()).intValue();
            if (var2 > var4 * var4) {
               this.elf.teleportNearOwner(var1);
            } else if (--this.recalc <= 0) {
               this.recalc = 8;
               this.elf.getNavigation().moveTo(var1, var2 > 144.0 ? 1.35 : 1.05);
            }
         }
      }
   }

   public static class GoHomeGoal extends Goal {
      private final ElfEntity elf;
      private int recalc;
      private int stuck;

      public GoHomeGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE));
      }

      public boolean canUse() {
         return this.elf.isGoingHome() && this.elf.getHomePos() != null && !this.elf.isBusyForMovement();
      }

      public boolean canContinueToUse() {
         return this.canUse();
      }

      public void start() {
         this.recalc = 0;
         this.stuck = 0;
      }

      public void tick() {
         BlockPos var1 = this.elf.getHomePos();
         if (var1 == null) {
            this.elf.cancelGoHome();
         } else {
            double var2 = this.elf.distanceToSqr(var1.getX() + 0.5, var1.getY(), var1.getZ() + 0.5);
            if (var2 <= 4.0) {
               this.elf.cancelGoHome();
               this.elf.getNavigation().stop();
            } else {
               if (--this.recalc <= 0) {
                  this.recalc = 10;
                  if (!this.elf.getNavigation().moveTo(var1.getX() + 0.5, var1.getY(), var1.getZ() + 0.5, 1.1)) {
                     this.stuck += 10;
                  }

                  if (!this.elf.getNavigation().isStuck() && !this.elf.getNavigation().isDone()) {
                     this.stuck = Math.max(0, this.stuck - 5);
                  } else {
                     this.stuck += 10;
                  }
               }

               if (this.stuck > 200 && this.elf.level() instanceof ServerLevel var4) {
                  this.elf.teleportHome(var4);
                  this.elf.cancelGoHome();
               }
            }
         }
      }
   }

   public static class GuardReturnGoal extends Goal {
      private final ElfEntity elf;

      public GuardReturnGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE));
      }

      public boolean canUse() {
         BlockPos var1 = this.elf.getGuardPos();
         return this.elf.getStance() == 2
            && var1 != null
            && !this.elf.isBusyForMovement()
            && !this.elf.isGoingHome()
            && this.elf.getTarget() == null
            && this.elf.blockPosition().distSqr(var1) > 9.0;
      }

      public boolean canContinueToUse() {
         BlockPos var1 = this.elf.getGuardPos();
         return var1 != null && !this.elf.getNavigation().isDone() && this.elf.getStance() == 2 && this.elf.getTarget() == null && !this.elf.isGoingHome();
      }

      public void start() {
         BlockPos var1 = this.elf.getGuardPos();
         this.elf.getNavigation().moveTo(var1.getX() + 0.5, var1.getY(), var1.getZ() + 0.5, 1.0);
      }
   }

   public static class HoldGoal extends Goal {
      private final ElfEntity elf;

      public HoldGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP));
      }

      public boolean canUse() {
         return this.elf.skills.isUltimate() || this.elf.getRestState() >= 2 || this.elf.getStance() == 1 && !this.elf.isMounted() || this.elf.skills.isBusy();
      }

      public boolean canContinueToUse() {
         return this.canUse();
      }

      public void start() {
         this.elf.getNavigation().stop();
      }
   }

   public static class OwnerHurtByGoal extends TargetGoal {
      private final ElfEntity elf;
      private LivingEntity attacker;
      private int timestamp;

      public OwnerHurtByGoal(ElfEntity var1) {
         super(var1, false);
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.TARGET));
      }

      public boolean canUse() {
         if (!this.elf.canFight()) {
            return false;
         } else {
            Player var1 = this.elf.getOwnerPlayer();
            if (var1 == null) {
               return false;
            } else {
               this.attacker = var1.getLastHurtByMob();
               int var2 = var1.getLastHurtByMobTimestamp();
               return var2 != this.timestamp && this.elf.isValidTarget(this.attacker);
            }
         }
      }

      public void start() {
         this.elf.setTarget(this.attacker);
         Player var1 = this.elf.getOwnerPlayer();
         if (var1 != null) {
            this.timestamp = var1.getLastHurtByMobTimestamp();
         }

         super.start();
      }

      public boolean canContinueToUse() {
         return this.elf.canFight() && super.canContinueToUse();
      }
   }

   public static class OwnerHurtGoal extends TargetGoal {
      private final ElfEntity elf;
      private LivingEntity victim;
      private int timestamp;

      public OwnerHurtGoal(ElfEntity var1) {
         super(var1, false);
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.TARGET));
      }

      public boolean canUse() {
         if (!this.elf.canFight()) {
            return false;
         } else {
            Player var1 = this.elf.getOwnerPlayer();
            if (var1 == null) {
               return false;
            } else {
               this.victim = var1.getLastHurtMob();
               int var2 = var1.getLastHurtMobTimestamp();
               return var2 != this.timestamp && this.elf.isValidTarget(this.victim);
            }
         }
      }

      public void start() {
         this.elf.setTarget(this.victim);
         Player var1 = this.elf.getOwnerPlayer();
         if (var1 != null) {
            this.timestamp = var1.getLastHurtMobTimestamp();
         }

         super.start();
      }

      public boolean canContinueToUse() {
         return this.elf.canFight() && super.canContinueToUse();
      }
   }

   public static class RetaliateGoal extends HurtByTargetGoal {
      private final ElfEntity elf;

      public RetaliateGoal(ElfEntity var1) {
         super(var1, new Class[0]);
         this.elf = var1;
      }

      public boolean canUse() {
         return this.elf.canFight() && super.canUse();
      }

      public boolean canContinueToUse() {
         return this.elf.canFight() && super.canContinueToUse();
      }
   }

   public static class WanderGoal extends Goal {
      private final ElfEntity elf;
      private int wait;

      public WanderGoal(ElfEntity var1) {
         this.elf = var1;
         this.setFlags(EnumSet.of(Flag.MOVE));
      }

      public boolean canUse() {
         if (this.elf.getStance() == 3
            && this.elf.getWanderAnchor() != null
            && !this.elf.isBusyForMovement()
            && !this.elf.isGoingHome()
            && this.elf.getTarget() == null) {
            if (--this.wait > 0) {
               return false;
            } else {
               this.wait = 30 + this.elf.getRandom().nextInt(90);
               return true;
            }
         } else {
            return false;
         }
      }

      public boolean canContinueToUse() {
         return this.elf.getStance() == 3
            && !this.elf.getNavigation().isDone()
            && !this.elf.isBusyForMovement()
            && this.elf.getTarget() == null
            && !this.elf.isGoingHome();
      }

      public void start() {
         BlockPos var1 = this.elf.getWanderAnchor();
         Vec3 var2 = Vec3.atBottomCenterOf(var1);
         double var3 = ((Integer)ECConfig.wanderRadius.get()).intValue();
         if (this.elf.distanceToSqr(var2) > var3 * var3 * 0.81) {
            this.elf.getNavigation().moveTo(var2.x, var2.y, var2.z, 1.0);
         } else {
            Vec3 var5 = LandRandomPos.getPosTowards(this.elf, 6, 3, var2);
            if (var5 != null && var5.distanceToSqr(var2) <= var3 * var3) {
               this.elf.getNavigation().moveTo(var5.x, var5.y, var5.z, 0.8);
            }
         }
      }
   }
}
