package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ModRegistry;
import com.elvencompanions.data.ElfManager;
import com.elvencompanions.data.ElfRegistry;
import com.elvencompanions.item.SoulItem;
import com.elvencompanions.logic.CarryLayout;
import com.elvencompanions.logic.RestSchedule;
import com.elvencompanions.logic.TranscendMath;
import com.elvencompanions.voice.ElfVoice;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Component.Serializer;
import net.minecraft.network.protocol.game.ClientboundTakeItemEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Strider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow.Pickup;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class ElfEntity extends PathfinderMob implements OwnableEntity {
   public static final int STANCE_FOLLOW = 0;
   public static final int STANCE_SIT = 1;
   public static final int STANCE_GUARD = 2;
   public static final int STANCE_WANDER = 3;
   public static final int STANCE_COUNT = 4;
   public static final int REASON_MANUAL = 0;
   public static final int REASON_SCHEDULED = 1;
   public static final int COMBAT_NEUTRAL = 0;
   public static final int COMBAT_PASSIVE = 1;
   public static final int COMBAT_AGGRESSIVE = 2;
   public static final int REST_NONE = 0;
   public static final int REST_SEARCH = 1;
   public static final int REST_BED = 2;
   public static final int REST_GROUND = 3;
   public static final int ANIM_NONE = 0;
   public static final int ANIM_VERDANT = 1;
   public static final int ANIM_SKYFALL = 2;
   public static final int ANIM_VOLLEY = 3;
   public static final int ANIM_WILDFIRE = 4;
   public static final int ANIM_MOONFALL = 5;
   public static final int ANIM_ULT = 6;
   public static final int ANIM_DASH = 7;
   public static final int ANIM_RAGE = 8;
   public static final int ANIM_TRANSCEND = 9;
   public static final int ANIM_ANNIHILATE = 10;
   public static final int SKIN_COUNT = 6;
   private static final String[] NAMES = new String[]{
      "Lyralei",
      "Aeloria",
      "Sylwen",
      "Thalindra",
      "Elowen",
      "Faelwen",
      "Isilmë",
      "Naerith",
      "Caelynn",
      "Miriel",
      "Galadwen",
      "Ithilwen",
      "Arwenna",
      "Vaelis",
      "Liriel",
      "Elenril"
   };
   private static final EntityDataAccessor<Integer> DATA_SKIN = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_STANCE = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_COMBAT = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_REST = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_WAKE = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_ANIM = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Boolean> DATA_PICKUP = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Boolean> DATA_DRINK = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Boolean> DATA_CARRIED = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Optional<UUID>> DATA_OWNER = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.OPTIONAL_UUID);
   private static final EntityDataAccessor<Integer> DATA_LEVEL = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_DASHDIR = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_CARRY_INDEX = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Integer> DATA_SCHEDULE = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Boolean> DATA_TRANSCENDED = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Integer> DATA_RAGE = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Boolean> DATA_HAS_HOME = SynchedEntityData.defineId(ElfEntity.class, EntityDataSerializers.BOOLEAN);
   private UUID ownerUUID;
   private UUID companionId;
   private int combatBeforeSit = 0;
   private BlockPos guardPos;
   private BlockPos bedTarget;
   private int restTicks;
   private int restHealTimer;
   private boolean deathHandled;
   private Vec3 lastSafePos;
   private int xp;
   private float restYaw;
   private final Map<UUID, Long> recentHits = new HashMap<>();
   private BlockPos wanderAnchor;
   private BlockPos homePos;
   private String homeDim = "";
   private boolean goingHome;
   private int goHomeTicks;
   private int restReason = 0;
   private long suppressedOccurrence = Long.MIN_VALUE;
   private long carryStamp;
   private boolean permanentlyDeleted;
   private static final AtomicLong CARRY_SEQ = new AtomicLong();
   public final ElfInventory inventory = new ElfInventory(this);
   public final ElfSkills skills = new ElfSkills(this);
   public final ElfDefense defense = new ElfDefense(this);
   public final ElfVoice voice = new ElfVoice(this);
   private int horseRecalc;
   public float wingAmt;
   public float wingAmtO;
   public float rageAmt;
   public float rageAmtO;

   public ElfEntity(EntityType<? extends ElfEntity> type, Level level) {
      super(type, level);
      this.xpReward = 0;
      this.setPersistenceRequired();
   }

   public static Builder createAttributes() {
      return Mob.createMobAttributes()
         .add(Attributes.MAX_HEALTH, 80.0)
         .add(Attributes.MOVEMENT_SPEED, 0.3)
         .add(Attributes.FOLLOW_RANGE, 32.0)
         .add(Attributes.ATTACK_DAMAGE, 2.0)
         .add(Attributes.STEP_HEIGHT, 1.0);
   }

   protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder b) {
      super.defineSynchedData(b);
      b.define(DATA_SKIN, 0);
      b.define(DATA_STANCE, 0);
      b.define(DATA_COMBAT, 0);
      b.define(DATA_REST, 0);
      b.define(DATA_WAKE, 0);
      b.define(DATA_ANIM, 0);
      b.define(DATA_PICKUP, false);
      b.define(DATA_DRINK, false);
      b.define(DATA_CARRIED, false);
      b.define(DATA_OWNER, Optional.empty());
      b.define(DATA_LEVEL, 1);
      b.define(DATA_DASHDIR, 0);
      b.define(DATA_CARRY_INDEX, 0);
      b.define(DATA_SCHEDULE, 0);
      b.define(DATA_HAS_HOME, false);
      b.define(DATA_TRANSCENDED, false);
      b.define(DATA_RAGE, 0);
   }

   protected void registerGoals() {
      this.goalSelector.addGoal(0, new FloatGoal(this));
      this.goalSelector.addGoal(1, new ElfGoals.HoldGoal(this));
      this.goalSelector.addGoal(2, new ElfGoals.EscapeGoal(this));
      this.goalSelector.addGoal(4, new ElfGoals.BowGoal(this));
      this.goalSelector.addGoal(5, new ElfGoals.FollowGoal(this));
      this.goalSelector.addGoal(5, new ElfGoals.GoHomeGoal(this));
      this.goalSelector.addGoal(6, new ElfGoals.WanderGoal(this));
      this.goalSelector.addGoal(6, new ElfGoals.GuardReturnGoal(this));
      this.goalSelector.addGoal(7, new ElfGoals.AvoidOwnerGoal(this));
      this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
      this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
      this.targetSelector.addGoal(1, new ElfGoals.OwnerHurtByGoal(this));
      this.targetSelector.addGoal(2, new ElfGoals.OwnerHurtGoal(this));
      this.targetSelector.addGoal(3, new ElfGoals.RetaliateGoal(this));
      this.targetSelector.addGoal(4, new ElfGoals.AggressiveTargetGoal(this));
   }

   @Nullable
   public UUID getOwnerUUID() {
      return this.ownerUUID != null ? this.ownerUUID : (UUID)((Optional)this.entityData.get(DATA_OWNER)).orElse(null);
   }

   private void setOwnerUUID(UUID u) {
      this.ownerUUID = u;
      this.entityData.set(DATA_OWNER, Optional.ofNullable(u));
   }

   public boolean isCarried() {
      return (Boolean)this.entityData.get(DATA_CARRIED);
   }

   public boolean isMounted() {
      return this.isPassenger() || this.isCarried();
   }

   public int getElfLevel() {
      return Math.max(1, Math.min(50, (Integer)this.entityData.get(DATA_LEVEL)));
   }

   public int getXp() {
      return this.xp;
   }

   public int getDashDir() {
      return (Integer)this.entityData.get(DATA_DASHDIR);
   }

   public void setDashDir(int d) {
      this.entityData.set(DATA_DASHDIR, d);
   }

   public void setSkin(int s) {
      this.entityData.set(DATA_SKIN, Math.floorMod(s, 6));
   }

   public UUID getCompanionId() {
      return this.companionId;
   }

   public int getSkin() {
      return (Integer)this.entityData.get(DATA_SKIN);
   }

   public int getStance() {
      return (Integer)this.entityData.get(DATA_STANCE);
   }

   public int getCombat() {
      return (Integer)this.entityData.get(DATA_COMBAT);
   }

   public int getRestState() {
      return (Integer)this.entityData.get(DATA_REST);
   }

   public int getWakeAnim() {
      return (Integer)this.entityData.get(DATA_WAKE);
   }

   public int getAnim() {
      return (Integer)this.entityData.get(DATA_ANIM);
   }

   public boolean isPickup() {
      return (Boolean)this.entityData.get(DATA_PICKUP);
   }

   public boolean isDrinking() {
      return (Boolean)this.entityData.get(DATA_DRINK);
   }

   public void setDrinking(boolean v) {
      this.entityData.set(DATA_DRINK, v);
   }

   public void setPickup(boolean v) {
      this.entityData.set(DATA_PICKUP, v);
   }

   public BlockPos getGuardPos() {
      return this.guardPos;
   }

   public BlockPos getWanderAnchor() {
      return this.wanderAnchor;
   }

   public BlockPos getHomePos() {
      return this.homePos;
   }

   public boolean hasHome() {
      return (Boolean)this.entityData.get(DATA_HAS_HOME);
   }

   public boolean isGoingHome() {
      return this.goingHome;
   }

   public void cancelGoHome() {
      this.goingHome = false;
   }

   public int getCarryIndex() {
      return (Integer)this.entityData.get(DATA_CARRY_INDEX);
   }

   public boolean isTranscended() {
      return (Boolean)this.entityData.get(DATA_TRANSCENDED);
   }

   public void setTranscended(boolean v) {
      this.entityData.set(DATA_TRANSCENDED, v);
      if (!this.level().isClientSide && this.getItemBySlot(EquipmentSlot.MAINHAND).getItem() != this.bowStack().getItem() && !this.defense.isDrinking()) {
         this.setItemSlot(EquipmentSlot.MAINHAND, this.bowStack());
      }

      if (this.level() instanceof ServerLevel sl && this.getOwnerUUID() != null) {
         ElfRegistry.get(sl.getServer()).update(this);
      }
   }

   public int getRageTicks() {
      return (Integer)this.entityData.get(DATA_RAGE);
   }

   public boolean isRaging() {
      return this.getRageTicks() > 0;
   }

   public void setRageTicksSync(int t) {
      if ((Integer)this.entityData.get(DATA_RAGE) != t) {
         this.entityData.set(DATA_RAGE, t);
      }
   }

   public ItemStack bowStack() {
      return new ItemStack(this.isTranscended() ? (ItemLike)ModRegistry.CELESTIAL_BOW.get() : (ItemLike)ModRegistry.ELF_BOW.get());
   }

   public boolean hasBowInHand() {
      return this.getMainHandItem().is((Item)ModRegistry.ELF_BOW.get()) || this.getMainHandItem().is((Item)ModRegistry.CELESTIAL_BOW.get());
   }

   public double effectiveArrowMult() {
      double mult = ElfLevel.arrowMult(this.getElfLevel());
      if (this.defense.isStealth()) {
         mult *= ECConfig.stealthArrowMultiplier.get() / Math.max(0.01, (Double)ECConfig.arrowDamageMultiplier.get());
      }

      return ElfNew.scaleMult(
         TranscendMath.rageArrow(mult, this.isRaging(), (Double)ECConfig.ragingMultiplier.get(), (Double)ECConfig.ragingArrowCap.get()), this
      );
   }

   public RestSchedule getSchedule() {
      return RestSchedule.byId((Integer)this.entityData.get(DATA_SCHEDULE));
   }

   public boolean isPermanentlyDeleted() {
      return this.permanentlyDeleted;
   }

   public boolean isOwnedBy(Entity e) {
      UUID o = this.getOwnerUUID();
      return o != null && e != null && o.equals(e.getUUID());
   }

   @Nullable
   public Player getOwnerPlayer() {
      UUID o = this.getOwnerUUID();
      return o == null ? null : this.level().getPlayerByUUID(o);
   }

   public boolean canInteract(Player p) {
      if (!this.isAlive() || !this.isOwnedBy(p)) {
         return false;
      } else if (this.isCarried()) {
         return true;
      } else if (p.level() != this.level()) {
         return false;
      } else {
         double max = ((Integer)ECConfig.interactionDistance.get()).intValue();
         return this.getBoundingBox().distanceToSqr(p.getEyePosition()) <= max * max;
      }
   }

   public boolean canUseInventory(Player p) {
      return this.canInteract(p) && !this.skills.isUltimate();
   }

   public boolean isBusyForMovement() {
      return this.getRestState() != 0
         || this.isMounted()
         || this.defense.isDrinking()
         || this.defense.isEscaping()
         || this.skills.isUltimate()
         || this.skills.isBusy();
   }

   public static ElfEntity summon(ServerLevel level, ServerPlayer owner) {
      ElfEntity elf = (ElfEntity)((EntityType)ModRegistry.ELF.get()).create(level);
      if (elf == null) {
         return null;
      } else {
         Vec3 look = owner.getLookAngle();
         Vec3 fwd = new Vec3(look.x, 0.0, look.z);
         fwd = fwd.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 0.0, 1.0) : fwd.normalize();
         Vec3 p = owner.position();
         Vec3[] cand = new Vec3[]{
            p.add(fwd.scale(1.8)),
            p.add(fwd.scale(1.0)),
            p.add(-fwd.z * 1.5, 0.0, fwd.x * 1.5),
            p.add(fwd.z * 1.5, 0.0, -fwd.x * 1.5),
            p.add(fwd.scale(-1.5)),
            p
         };
         boolean placed = false;

         for (Vec3 c : cand) {
            elf.moveTo(c.x, c.y, c.z, owner.getYRot() + 180.0F, 0.0F);
            if (level.noCollision(elf)) {
               placed = true;
               break;
            }
         }

         if (!placed) {
            return null;
         } else {
            elf.initNew(owner);
            if (!level.addFreshEntity(elf)) {
               return null;
            } else {
               level.playSound(null, elf.blockPosition(), (SoundEvent)ModRegistry.SND_SUMMON.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
               level.sendParticles(ParticleTypes.HAPPY_VILLAGER, elf.getX(), elf.getY() + 1.0, elf.getZ(), 25, 0.4, 0.8, 0.4, 0.05);
               level.sendParticles(ParticleTypes.END_ROD, elf.getX(), elf.getY() + 1.0, elf.getZ(), 15, 0.4, 0.8, 0.4, 0.05);
               return elf;
            }
         }
      }
   }

   private void initNew(ServerPlayer owner) {
      this.setOwnerUUID(owner.getUUID());
      this.companionId = this.getUUID();
      this.entityData.set(DATA_SKIN, this.random.nextInt(6));
      if ((Boolean)ECConfig.randomNames.get()) {
         this.setCustomName(Component.literal(NAMES[this.random.nextInt(NAMES.length)]));
      }

      this.setCustomNameVisible(true);
      this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack((ItemLike)ModRegistry.ELF_BOW.get()));
      this.applyConfigHealth(true);
      ElfRegistry.get(owner.server).update(this);
   }

   private void applyConfigHealth(boolean fill) {
      int lv = this.getElfLevel();
      AttributeInstance hp = this.getAttribute(Attributes.MAX_HEALTH);
      double max = ElfLevel.maxHealth(lv);
      if (hp != null && hp.getBaseValue() != max) {
         hp.setBaseValue(max);
      }

      AttributeInstance sp = this.getAttribute(Attributes.MOVEMENT_SPEED);
      double speed = 0.3 * ElfLevel.walkSpeed(lv);
      if (sp != null && Math.abs(sp.getBaseValue() - speed) > 1.0E-6) {
         sp.setBaseValue(speed);
      }

      AttributeInstance step = this.getAttribute(Attributes.STEP_HEIGHT);
      if (step != null && Math.abs(step.getBaseValue() - (Double)ECConfig.stepHeight.get()) > 1.0E-6) {
         step.setBaseValue((Double)ECConfig.stepHeight.get());
      }

      if (fill) {
         this.setHealth(this.getMaxHealth());
      } else if (this.getHealth() > this.getMaxHealth()) {
         this.setHealth(this.getMaxHealth());
      }
   }

   public void onServerJoin(ServerLevel level) {
      ElfNew.onJoin(this);
      if (this.companionId == null) {
         this.companionId = this.getUUID();
      }

      this.applyConfigHealth(false);
      this.lastSafePos = this.position();
      ElfRegistry reg = ElfRegistry.get(level.getServer());
      if (reg.isDeleted(this.companionId)) {
         this.permanentlyDeleted = true;
         this.deathHandled = true;
         level.getServer().execute(this::discard);
      } else {
         for (int id : reg.drainPending(this.companionId)) {
            ElfAction a = ElfAction.byId(id);
            if (a != null) {
               this.applyQueued(a);
            }
         }

         if (this.ownerUUID != null) {
            reg.update(this);
         }
      }
   }

   private void applyQueued(ElfAction a) {
      switch (a) {
         case NEUTRAL:
            this.setCombatMode(0);
            break;
         case PASSIVE:
            this.setCombatMode(1);
            break;
         case AGGRESSIVE:
            this.setCombatMode(2);
            break;
         case PICKUP:
            this.setPickup(!this.isPickup());
            break;
         case REST_SCHEDULE:
            this.setSchedule(this.getSchedule().next());
      }
   }

   public boolean removeWhenFarAway(double d) {
      return false;
   }

   protected void customServerAiStep() {
      if (!ElfNew.guard(this)) {
         super.customServerAiStep();
         if (this.level() instanceof ServerLevel sl) {
            if (!this.defense.isDrinking() && !this.getMainHandItem().is(this.bowStack().getItem())) {
               this.setItemSlot(EquipmentSlot.MAINHAND, this.bowStack());
            }

            if (this.tickCount % 20 == 0) {
               this.skills.tryStartTranscend();
            }

            this.tickHorseControl();
            this.skills.tick();
            this.defense.tick();
            this.voice.tick();
            this.tickSchedule(sl);
            this.tickRest(sl);
            this.tickPickup(sl);
            if (this.tickCount % 100 == 0) {
               this.recentHits.values().removeIf(t -> sl.getGameTime() - t > 400L);
            }

            if (this.getStance() == 1 && !this.isMounted() && this.getRestState() == 0 && this.onGround()) {
               Vec3 dm = this.getDeltaMovement();
               this.setDeltaMovement(0.0, dm.y, 0.0);
            }

            int w = this.getWakeAnim();
            if (w > 0) {
               this.entityData.set(DATA_WAKE, w - 1);
            }

            int anim = this.skills.currentAnim();
            if (anim == 0 && this.defense.isDashing()) {
               anim = 7;
            }

            if (anim != this.getAnim()) {
               this.entityData.set(DATA_ANIM, anim);
            }

            if (this.onGround() && !this.isInLava() && !this.isInWater() && this.tickCount % 20 == 0) {
               this.lastSafePos = this.position();
            }

            if (this.tickCount % 20 == 0 && this.ownerUUID != null) {
               ElfRegistry.get(sl.getServer()).update(this);
            }
         }
      }
   }

   private void tickHorseControl() {
      if (this.getVehicle() instanceof AbstractHorse horse && !horse.isRemoved() && !this.level().isClientSide) {
         for (Entity p : horse.getPassengers()) {
            if (p instanceof Player) {
               return;
            }
         }

         if (this.skills.isUltimate() || this.getRestState() != 0) {
            horse.getNavigation().stop();
         } else if (--this.horseRecalc <= 0) {
            this.horseRecalc = 6;
            Vec3 dest = null;
            double stopAt = 3.0;
            LivingEntity t = this.getTarget();
            Player owner = this.getOwnerPlayer();
            if (this.canFight() && t != null && t.isAlive()) {
               double range = ((Integer)ECConfig.attackRange.get()).intValue();
               if (this.distanceTo(t) > range * 0.7) {
                  dest = t.position();
                  stopAt = range * 0.5;
               }
            } else if (this.goingHome && this.homePos != null) {
               dest = Vec3.atBottomCenterOf(this.homePos);
               if (horse.distanceToSqr(dest) <= 9.0) {
                  this.goingHome = false;
               }
            } else {
               switch (this.getStance()) {
                  case 0:
                     if (owner != null && owner.level() == this.level()) {
                        double d2 = horse.distanceToSqr(owner);
                        double start = ((Integer)ECConfig.followStartDistance.get()).intValue();
                        if (d2 > start * start) {
                           dest = owner.position();
                           stopAt = ((Integer)ECConfig.followStopDistance.get()).intValue();
                        }
                     }
                  case 1:
                  default:
                     break;
                  case 2:
                     if (this.guardPos != null && horse.blockPosition().distSqr(this.guardPos) > 9.0) {
                        dest = Vec3.atBottomCenterOf(this.guardPos);
                        stopAt = 2.0;
                     }
                     break;
                  case 3:
                     if (this.wanderAnchor != null) {
                        double r = ((Integer)ECConfig.wanderRadius.get()).intValue();
                        if (horse.blockPosition().distSqr(this.wanderAnchor) > r * r * 0.8) {
                           dest = Vec3.atBottomCenterOf(this.wanderAnchor);
                           stopAt = 3.0;
                        }
                     }
               }
            }

            if (dest != null && horse.distanceToSqr(dest) > stopAt * stopAt) {
               horse.getNavigation().moveTo(dest.x, dest.y, dest.z, 1.35);
            } else {
               horse.getNavigation().stop();
            }
         }
      }
   }

   public void tick() {
      super.tick();
      if (this.isCarried()) {
         this.tickCarried();
      }

      if (this.level().isClientSide) {
         this.clientFx();
      }
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
      super.onSyncedDataUpdated(key);
      if (key == DATA_CARRIED) {
         this.noPhysics = this.isCarried();
      }
   }

   public void setCarried(boolean c) {
      if (this.isCarried() != c) {
         if (c && !this.level().isClientSide) {
            this.carryStamp = CARRY_SEQ.incrementAndGet();
         }

         this.entityData.set(DATA_CARRIED, c);
         this.noPhysics = c;
         this.getNavigation().stop();
         if (!c) {
            this.setDeltaMovement(Vec3.ZERO);
            this.fallDistance = 0.0F;
         }

         if (!this.level().isClientSide) {
            reindexCarried(this.getOwnerUUID());
         }
      }
   }

   public static void reindexCarried(@Nullable UUID owner) {
      if (owner != null) {
         List<ElfEntity> list = new ArrayList<>();

         for (ElfEntity e : ElfManager.LOADED.values()) {
            if (e.isCarried() && owner.equals(e.getOwnerUUID()) && !e.isRemoved()) {
               list.add(e);
            }
         }

         list.sort(Comparator.<ElfEntity>comparingLong(ex -> ex.carryStamp).thenComparing(ex -> ex.getUUID()));

         for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getCarryIndex() != i) {
               list.get(i).entityData.set(DATA_CARRY_INDEX, i);
            }
         }
      }
   }

   public void dismount() {
      if (this.getVehicle() instanceof Mob m) {
         m.getNavigation().stop();
      }

      this.stopRiding();
      this.setCarried(false);
   }

   public static boolean carrierLying(Player o) {
      return o.isVisuallySwimming() || o.isFallFlying() || o.getPose() == Pose.SWIMMING || o.getPose() == Pose.FALL_FLYING;
   }

   private void tickCarried() {
      Player o = this.getOwnerPlayer();
      if (o != null && o.level() == this.level() && o.isAlive() && !o.isSpectator() && !this.isPassenger()) {
         boolean lying = carrierLying(o);
         double[] off = CarryLayout.offset(this.getCarryIndex(), o.yBodyRot, lying, Math.max(0.4, o.getBbHeight() / 1.8));
         this.xo = this.xOld = this.getX();
         this.yo = this.yOld = this.getY();
         this.zo = this.zOld = this.getZ();
         this.setPos(o.getX() + off[0], o.getY() + off[1], o.getZ() + off[2]);
         this.setDeltaMovement(Vec3.ZERO);
         this.fallDistance = 0.0F;
         this.yRotO = this.getYRot();
         this.yBodyRotO = this.yBodyRot;
         this.yHeadRotO = this.yHeadRot;
         this.setYRot(o.yBodyRot);
         this.yBodyRot = o.yBodyRot;
         this.yHeadRot = o.yHeadRot;
         this.getNavigation().stop();
      } else {
         if (!this.level().isClientSide) {
            this.setCarried(false);
         }
      }
   }

   private void easeCelestial() {
      this.wingAmtO = this.wingAmt;
      this.rageAmtO = this.rageAmt;
      boolean combat = this.isAggressive() || this.getAnim() != 0 || this.isRaging();
      this.wingAmt = this.wingAmt + ((this.isTranscended() && combat ? 1.0F : 0.0F) - this.wingAmt) * 0.15F;
      this.rageAmt = this.rageAmt + ((this.isRaging() ? 1.0F : 0.0F) - this.rageAmt) * 0.2F;
   }

   private void clientFx() {
      this.easeCelestial();
      int lv = this.getElfLevel();
      if (this.isAggressive() && !this.isDrinking() && this.tickCount % 3 == 0) {
         Vec3 h = ElfFx.handPos(this);
         this.level()
            .addParticle(
               lv >= 30 ? (ParticleOptions)ModRegistry.GLOW_GOLD.get() : (ParticleOptions)ModRegistry.GLOW_GREEN.get(),
               h.x,
               h.y + this.random.nextDouble() * 0.6 - 0.3,
               h.z,
               0.0,
               0.01,
               0.0
            );
         if (this.random.nextInt(3) == 0) {
            this.level()
               .addParticle(
                  (ParticleOptions)ModRegistry.STAR.get(),
                  h.x,
                  h.y,
                  h.z,
                  (this.random.nextDouble() - 0.5) * 0.04,
                  0.02,
                  (this.random.nextDouble() - 0.5) * 0.04
               );
         }
      }

      int tier = ElfLevel.tier(lv);
      if (tier > 0 && !this.isInvisible() && this.tickCount % 6 == 0) {
         for (int i = 0; i < tier; i++) {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            this.level()
               .addParticle(
                  tier >= 3 && this.random.nextBoolean() ? (ParticleOptions)ModRegistry.GLOW_GOLD.get() : (ParticleOptions)ModRegistry.GLOW_GREEN.get(),
                  this.getX() + Math.cos(a) * 0.55,
                  this.getY() + 0.2 + this.random.nextDouble() * 1.6,
                  this.getZ() + Math.sin(a) * 0.55,
                  0.0,
                  0.02 + tier * 0.004,
                  0.0
               );
         }

         if (tier >= 5 && this.tickCount % 12 == 0) {
            this.level().addParticle((ParticleOptions)ModRegistry.STAR.get(), this.getX(), this.getY() + 2.1, this.getZ(), 0.0, 0.01, 0.0);
         }
      }
   }

   public boolean canFight() {
      return this.getCombat() != 1 && this.getStance() != 1 && this.getRestState() == 0 && !this.skills.isUltimate() && !this.defense.isEscaping();
   }

   public boolean isValidTarget(@Nullable LivingEntity t) {
      if (t == null || !t.isAlive() || t == this || t instanceof Player || t instanceof ElfEntity || t instanceof ArmorStand) {
         return false;
      } else {
         return !this.isOwnedBy(t) && !this.isAlliedTo(t)
            ? !(t instanceof OwnableEntity o && this.ownerUUID != null && this.ownerUUID.equals(o.getOwnerUUID()))
            : false;
      }
   }

   public boolean isHostile(@Nullable LivingEntity t) {
      return this.isValidTarget(t) && t instanceof Enemy;
   }

   public boolean isHostileInLeash(LivingEntity t) {
      if (!this.isHostile(t)) {
         return false;
      } else if (this.getStance() == 2 && this.guardPos != null) {
         double r = ((Integer)ECConfig.guardRadius.get()).intValue() + 6.0;
         return t.distanceToSqr(this.guardPos.getX() + 0.5, this.guardPos.getY(), this.guardPos.getZ() + 0.5) <= r * r;
      } else {
         return true;
      }
   }

   @Nullable
   public LivingEntity nearestHostile(double range) {
      LivingEntity best = null;
      double bd = Double.MAX_VALUE;

      for (LivingEntity e : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(range), this::isHostile)) {
         double d = e.distanceToSqr(this);
         if (d < bd && d <= range * range) {
            bd = d;
            best = e;
         }
      }

      return best;
   }

   public boolean canAttack(LivingEntity t) {
      return this.isValidTarget(t) && super.canAttack(t);
   }

   public void setTarget(@Nullable LivingEntity t) {
      if (t != null && (!this.canFight() || !this.isValidTarget(t))) {
         t = null;
      }

      boolean fresh = t != null && t != this.getTarget() && !this.level().isClientSide;
      super.setTarget(t);
      if (fresh) {
         this.voice.onTarget(t);
      }
   }

   public boolean isAlliedTo(Entity other) {
      if (other == this) {
         return true;
      } else {
         if (this.ownerUUID != null) {
            if (other.getUUID().equals(this.ownerUUID)) {
               return true;
            }

            if (other instanceof OwnableEntity o && this.ownerUUID.equals(o.getOwnerUUID())) {
               return true;
            }
         }

         return super.isAlliedTo(other);
      }
   }

   public int fireInterval() {
      return ElfNew.scaleInterval(
         TranscendMath.rageInterval(
            ElfLevel.fireInterval(this.getElfLevel(), this.level().getDifficulty()),
            this.isRaging(),
            (Double)ECConfig.ragingMultiplier.get(),
            (Integer)ECConfig.ragingMinInterval.get()
         ),
         this
      );
   }

   public void shoot(LivingEntity target) {
      if (!this.level().isClientSide) {
         int n = this.random.nextDouble() < ECConfig.doubleShotChance.get() ? 2 : 1;

         for (int i = 0; i < n; i++) {
            this.spawnArrow(target, i == 0 ? 0.0F : 3.0F);
         }

         this.swing(InteractionHand.MAIN_HAND);
         this.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.0F / (this.random.nextFloat() * 0.4F + 0.8F));
         if (this.level() instanceof ServerLevel sl) {
            Vec3 aim = target.getEyePosition().subtract(this.getEyePosition()).normalize();
            ElfFx.muzzle(sl, this, aim);
         }

         this.voice.onBasicShot();
         this.skills.onBasicShot(target);
      }
   }

   private void spawnArrow(LivingEntity target, float extraSpread) {
      int lv = this.getElfLevel();
      ElfArrow a = new ElfArrow((EntityType<? extends ElfArrow>)ModRegistry.ELF_ARROW.get(), this.level());
      a.setOwner(this);
      Vec3 muzzle = ElfFx.handPos(this);
      a.setPos(muzzle.x, muzzle.y, muzzle.z);
      a.pickup = Pickup.DISALLOWED;
      a.setBaseDamage(2.0 * this.effectiveArrowMult());
      double dist = this.distanceTo(target);
      double flight = dist / 1.6 * ElfLevel.aimLead(lv);
      Vec3 v = target.getDeltaMovement();
      double tx = target.getX() + v.x * flight;
      double tz = target.getZ() + v.z * flight;
      double ty = target.getY(0.3333333333333333) + (target.onGround() ? 0.0 : v.y * flight * 0.5);
      double dx = tx - muzzle.x;
      double dz = tz - muzzle.z;
      double dy = ty - muzzle.y;
      double hd = Math.sqrt(dx * dx + dz * dz);
      a.shoot(dx, dy + hd * 0.2, dz, 1.6F, (float)(ElfLevel.inaccuracy(lv) + extraSpread));
      this.level().addFreshEntity(a);
   }

   public boolean hurt(DamageSource src, float amount) {
      if (ElfExtras.blocksDamage(this, src)) {
         return false;
      } else if (this.level().isClientSide) {
         return super.hurt(src, amount);
      } else if (src.getEntity() != null && this.isOwnedBy(src.getEntity())) {
         return false;
      } else if (src.getDirectEntity() instanceof ElfArrow arrow && arrow.getOwner() instanceof ElfEntity) {
         return false;
      } else {
         if (this.getRestState() != 0) {
            this.wakeUp();
         }

         if (!src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount *= (float)(1.0 - ElfLevel.damageReduction(this.getElfLevel()));
         }

         boolean r = super.hurt(src, amount);
         if (r) {
            this.defense.onDamaged(src, amount);
            this.voice.onHurt(amount);
         }

         return r;
      }
   }

   public boolean isPickable() {
      return !this.isCarried() && super.isPickable();
   }

   public boolean isInvulnerableTo(DamageSource src) {
      if (super.isInvulnerableTo(src)) {
         return true;
      } else {
         return this.skills.explosionImmune() && src.is(DamageTypeTags.IS_EXPLOSION)
            ? true
            : this.skills.isUltimate() && (Boolean)ECConfig.ultInvulnerable.get() && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
      }
   }

   public boolean causeFallDamage(float dist, float mult, DamageSource src) {
      return !this.skills.fallGuard() && super.causeFallDamage(dist, mult, src);
   }

   public InteractionResult mobInteract(Player player, InteractionHand hand) {
      if (!this.isOwnedBy(player)) {
         return InteractionResult.PASS;
      } else {
         ItemStack held = player.getItemInHand(hand);
         if (hand != InteractionHand.MAIN_HAND || !held.isEmpty()) {
            return InteractionResult.PASS;
         } else if (!this.level().isClientSide && player instanceof ServerPlayer sp) {
            if (this.skills.isUltimate()) {
               sp.displayClientMessage(Component.translatable("message.elven_companions.ult_locked", new Object[]{this.getName()}), true);
               return InteractionResult.CONSUME;
            } else if (this.getRestState() != 0) {
               this.wakeUp();
               ElfDialogue.say(this, "wake");
               return InteractionResult.CONSUME;
            } else {
               this.setStance((this.getStance() + 1) % 4);
               String key = stanceKey(this.getStance());
               sp.displayClientMessage(
                  Component.translatable("message.elven_companions.stance", new Object[]{Component.translatable("stance.elven_companions." + key)}), true
               );
               ElfDialogue.say(this, key);
               return InteractionResult.CONSUME;
            }
         } else {
            return InteractionResult.sidedSuccess(this.level().isClientSide);
         }
      }
   }

   private static String stanceKey(int s) {
      return s == 1 ? "sit" : (s == 2 ? "guard" : (s == 3 ? "wander" : "follow"));
   }

   public void setStance(int s) {
      int old = this.getStance();
      if (old != s) {
         if (old == 1) {
            this.entityData.set(DATA_COMBAT, this.combatBeforeSit);
         }

         if (s == 1) {
            this.combatBeforeSit = this.getCombat();
            this.entityData.set(DATA_COMBAT, 1);
            this.setTarget(null);
            this.getNavigation().stop();
         }

         if (s == 2) {
            this.guardPos = this.blockPosition();
         }

         if (s == 3) {
            this.wanderAnchor = this.blockPosition();
         }

         this.entityData.set(DATA_STANCE, s);
      }
   }

   public void setCombatMode(int c) {
      if (this.getStance() == 1) {
         this.combatBeforeSit = c;
      } else {
         this.entityData.set(DATA_COMBAT, c);
      }

      if (this.getCombat() == 1) {
         this.setTarget(null);
      }
   }

   public boolean executeCommand(ServerPlayer p, ElfAction a) {
      return this.executeCommand(p, a, false);
   }

   public boolean executeCommand(ServerPlayer p, ElfAction a, boolean quiet) {
      if (ElfExtras.command(this, p, a)) {
         return true;
      } else if (!this.isOwnedBy(p) || !this.isAlive()) {
         return false;
      } else if (this.skills.isUltimate()) {
         if (!quiet) {
            p.displayClientMessage(Component.translatable("message.elven_companions.ult_locked", new Object[]{this.getName()}), true);
         }

         return false;
      } else {
         boolean ok = false;
         switch (a) {
            case NEUTRAL:
            case PASSIVE:
            case AGGRESSIVE:
               int c = a == ElfAction.NEUTRAL ? 0 : (a == ElfAction.PASSIVE ? 1 : 2);
               this.setCombatMode(c);
               String key = a.name().toLowerCase(Locale.ROOT);
               if (!quiet) {
                  p.displayClientMessage(
                     Component.translatable(
                        this.getStance() == 1 && c != 1 ? "message.elven_companions.combat_queued" : "message.elven_companions.combat",
                        new Object[]{Component.translatable("combat.elven_companions." + key)}
                     ),
                     true
                  );
               }

               ElfDialogue.say(this, key);
               ok = true;
               break;
            case PICKUP:
               this.setPickup(!this.isPickup());
               ElfDialogue.say(this, this.isPickup() ? "pickup_on" : "pickup_off");
               ok = true;
               break;
            case REST_SCHEDULE:
               this.setSchedule(this.getSchedule().next());
               if (!quiet) {
                  p.displayClientMessage(
                     Component.translatable(
                        "message.elven_companions.schedule", new Object[]{Component.translatable("gui.elven_companions.schedule." + this.getSchedule().id())}
                     ),
                     true
                  );
               }

               ok = true;
               break;
            case RIDE_PLAYER:
               if (this.near(p, quiet)) {
                  this.wakeUp();
                  this.dismount();
                  this.setCarried(true);
                  ElfDialogue.say(this, "ride_player");
                  ok = true;
               }
               break;
            case RIDE_MOUNT:
               if (this.near(p, quiet)) {
                  ok = this.rideNearbyMount(p);
                  if (!ok) {
                     this.msg(p, quiet, "no_mount");
                  } else {
                     ElfDialogue.say(this, "ride_mount");
                  }
               }
               break;
            case UNMOUNT:
               if (!this.isMounted()) {
                  this.msg(p, quiet, "not_riding");
               } else {
                  this.wakeUp();
                  this.dismount();
                  ElfDialogue.say(this, "unmount");
                  ok = true;
               }
               break;
            case INVENTORY:
               if (this.near(p, quiet)) {
                  this.openInventory(p);
                  ElfDialogue.say(this, "inventory");
                  ok = true;
               }
               break;
            case REST:
               if (this.getRestState() != 0) {
                  this.wakeUp();
                  ElfDialogue.say(this, "wake");
                  ok = true;
               } else if (this.startRest(false)) {
                  ElfDialogue.say(this, "rest");
                  ok = true;
               }
               break;
            case TELEPORT:
               ok = this.teleportToOwner(p, quiet);
               break;
            case STANCE:
               this.wakeUp();
               this.cancelGoHome();
               this.setStance((this.getStance() + 1) % 4);
               String stanceName = stanceKey(this.getStance());
               if (!quiet) {
                  p.displayClientMessage(
                     Component.translatable("message.elven_companions.stance", new Object[]{Component.translatable("stance.elven_companions." + stanceName)}), true
                  );
               }

               ElfDialogue.say(this, stanceName);
               ok = true;
               break;
            case HOME_TOGGLE:
               ok = this.toggleHome(p, quiet);
               break;
            case GO_HOME:
               ok = this.goHome(p, quiet);
               break;
            default:
               if (!(Boolean)ECConfig.allowManualSkills.get()) {
                  this.msg(p, quiet, "manual_disabled");
               } else {
                  this.wakeUp();
                  ok = this.skills.manual(a.ordinal() - ElfAction.SKILL_0.ordinal());
                  if (ok) {
                     ElfDialogue.say(this, "skill");
                  } else {
                     this.msg(p, quiet, "skill_failed");
                  }
               }
         }

         if (ok && this.ownerUUID != null) {
            ElfRegistry.get(p.server).update(this);
         }

         return ok;
      }
   }

   private void msg(ServerPlayer p, boolean quiet, String key) {
      if (!quiet) {
         p.displayClientMessage(Component.translatable("message.elven_companions." + key), true);
      }
   }

   private boolean near(ServerPlayer p, boolean quiet) {
      if (this.canInteract(p)) {
         return true;
      } else {
         if (!quiet) {
            if (p.level() != this.level()) {
               p.displayClientMessage(Component.translatable("message.elven_companions.other_dimension", new Object[]{this.getName()}), true);
            } else {
               p.displayClientMessage(
                  Component.translatable(
                     "message.elven_companions.too_far_dist",
                     new Object[]{
                        this.getName(),
                        String.format(Locale.ROOT, "%.0f", Math.sqrt(this.getBoundingBox().distanceToSqr(p.getEyePosition()))),
                        ECConfig.interactionDistance.get()
                     }
                  ),
                  true
               );
            }
         }

         return false;
      }
   }

   public void openInventory(ServerPlayer p) {
      p.openMenu(new SimpleMenuProvider((id, inv, pl) -> new ElfInventoryMenu(id, inv, this), this.getDisplayName()), buf -> buf.writeVarInt(this.getId()));
   }

   private boolean isCompatibleMount(Entity e, ServerPlayer owner) {
      if (e != this && e != owner && !(e instanceof ElfEntity) && !e.isRemoved()) {
         if (!(e instanceof AbstractHorse) && !(e instanceof Boat) && !(e instanceof AbstractMinecart) && !(e instanceof Pig) && !(e instanceof Strider)) {
            return false;
         } else {
            for (Entity passenger : e.getPassengers()) {
               if (passenger instanceof Player pl && pl != owner) {
                  return false;
               }
            }

            return !(e instanceof OwnableEntity o && o.getOwnerUUID() != null && !o.getOwnerUUID().equals(owner.getUUID()));
         }
      } else {
         return false;
      }
   }

   private boolean rideNearbyMount(ServerPlayer owner) {
      double r = (Double)ECConfig.mountRadius.get();
      List<Entity> list = new ArrayList<>(this.level().getEntities(this, this.getBoundingBox().inflate(r), e -> this.isCompatibleMount(e, owner)));
      list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(this)));

      for (Entity m : list) {
         if (!(m.distanceToSqr(this) > r * r)) {
            this.wakeUp();
            this.dismount();
            if (this.startRiding(m)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean teleportToOwner(ServerPlayer p, boolean quiet) {
      this.wakeUp();
      this.dismount();
      Vec3 spot = this.findSafeSpotNear(p);
      if (spot == null) {
         this.msg(p, quiet, "teleport_failed");
         return false;
      } else {
         ServerLevel target = p.serverLevel();
         this.getNavigation().stop();
         if (target != this.level()) {
            if (!this.teleportTo(target, spot.x, spot.y, spot.z, Set.of(), p.getYRot() + 180.0F, 0.0F)) {
               this.msg(p, quiet, "teleport_failed");
               return false;
            }
         } else {
            this.moveTo(spot.x, spot.y, spot.z, p.getYRot() + 180.0F, 0.0F);
         }

         this.setDeltaMovement(Vec3.ZERO);
         this.fallDistance = 0.0F;
         if (this.getStance() == 2) {
            this.guardPos = this.blockPosition();
         }

         target.sendParticles(ParticleTypes.PORTAL, spot.x, spot.y + 1.0, spot.z, 25, 0.4, 0.8, 0.4, 0.2);
         target.playSound(null, spot.x, spot.y, spot.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.NEUTRAL, 0.8F, 1.3F);
         if (!quiet) {
            p.displayClientMessage(Component.translatable("message.elven_companions.teleported", new Object[]{this.getName()}), true);
         }

         ElfDialogue.say(this, "teleport");
         return true;
      }
   }

   @Nullable
   private Vec3 findSafeSpotNear(Player owner) {
      Level lv = owner.level();
      AABB box = this.getType().getDimensions().makeBoundingBox(0.0, 0.0, 0.0);
      double[][] offs = new double[][]{{1.2, 0.0}, {-1.2, 0.0}, {0.0, 1.2}, {0.0, -1.2}, {1.6, 1.6}, {-1.6, 1.6}, {1.6, -1.6}, {-1.6, -1.6}, {0.0, 0.0}};

      for (double[] o : offs) {
         double x = owner.getX() + o[0];
         double z = owner.getZ() + o[1];

         for (int dy = 0; dy <= 2; dy++) {
            double y = owner.getY() + dy;
            BlockPos below = BlockPos.containing(x, y - 0.1, z);
            if (lv.noCollision(box.move(x, y, z)) && lv.getBlockState(below).isFaceSturdy(lv, below, Direction.UP)) {
               return new Vec3(x, y, z);
            }
         }
      }

      return null;
   }

   public void teleportNearOwner(Player o) {
      for (int i = 0; i < 12; i++) {
         double x = o.getX() + (this.random.nextDouble() - 0.5) * 6.0;
         double z = o.getZ() + (this.random.nextDouble() - 0.5) * 6.0;
         double y = o.getY();
         BlockPos below = BlockPos.containing(x, y - 0.1, z);
         if (this.level().noCollision(this, this.getBoundingBox().move(x - this.getX(), y - this.getY(), z - this.getZ()))
            && this.level().getBlockState(below).isFaceSturdy(this.level(), below, Direction.UP)) {
            this.moveTo(x, y, z, this.getYRot(), this.getXRot());
            this.getNavigation().stop();
            return;
         }
      }
   }

   public boolean startRest(boolean scheduled) {
      if (this.getRestState() != 0) {
         return false;
      } else {
         this.restReason = scheduled ? 1 : 0;
         this.goingHome = false;
         this.dismount();
         this.getNavigation().stop();
         this.entityData.set(DATA_REST, 1);
         this.restTicks = 0;
         this.bedTarget = this.level() instanceof ServerLevel sl ? this.findBed(sl) : null;
         return true;
      }
   }

   private boolean bedClaimed(BlockPos p) {
      for (ElfEntity e : ElfManager.LOADED.values()) {
         if (e != this) {
            if (e.bedTarget != null && e.bedTarget.equals(p)) {
               return true;
            }

            if (e.getSleepingPos().filter(p::equals).isPresent()) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean bedUsable(ServerLevel sl, BlockPos p) {
      BlockState s = sl.getBlockState(p);
      return s.getBlock() instanceof BedBlock
         && s.getValue(BedBlock.PART) == BedPart.HEAD
         && (!(Boolean)s.getValue(BedBlock.OCCUPIED) || this.getSleepingPos().filter(p::equals).isPresent())
         && !this.bedClaimed(p);
   }

   @Nullable
   private BlockPos findBed(ServerLevel sl) {
      int r = (Integer)ECConfig.bedRadius.get();
      BlockPos c = this.blockPosition();
      BlockPos best = null;
      double bd = Double.MAX_VALUE;

      for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -3, -r), c.offset(r, 3, r))) {
         if (this.bedUsable(sl, p)) {
            double d = p.distSqr(c);
            if (d < bd && this.getNavigation().createPath(p, 1) != null) {
               bd = d;
               best = p.immutable();
            }
         }
      }

      return best;
   }

   private void tickRest(ServerLevel sl) {
      int rs = this.getRestState();
      if (rs != 0) {
         if (rs == 1) {
            this.restTicks++;
            if (this.bedTarget != null && !this.bedUsable(sl, this.bedTarget)) {
               this.bedTarget = null;
            }

            if (this.bedTarget == null && this.restTicks % 40 == 0) {
               this.bedTarget = this.findBed(sl);
            }

            if (this.bedTarget != null) {
               double dx = this.bedTarget.getX() + 0.5 - this.getX();
               double dz = this.bedTarget.getZ() + 0.5 - this.getZ();
               double dy = this.bedTarget.getY() - this.getY();
               if (dx * dx + dz * dz <= 6.25 && Math.abs(dy) <= 2.0) {
                  this.startSleeping(this.bedTarget);
                  this.entityData.set(DATA_REST, 2);
                  this.restHealTimer = 0;
                  sl.playSound(null, this.blockPosition(), (SoundEvent)ModRegistry.SND_REST.get(), SoundSource.NEUTRAL, 0.8F, 1.0F);
                  return;
               }

               if (this.getNavigation().isDone()) {
                  this.getNavigation().moveTo(this.bedTarget.getX() + 0.5, this.bedTarget.getY(), this.bedTarget.getZ() + 0.5, 1.0);
               }
            }

            int limit = (Integer)ECConfig.bedSearchSeconds.get() * 20;
            if (this.bedTarget == null && this.restTicks >= limit || this.restTicks >= limit * 3) {
               this.lieOnGround();
            }
         } else {
            this.setDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
            if (rs == 3) {
               this.setYRot(this.restYaw);
               this.yBodyRot = this.restYaw;
               this.yHeadRot = this.restYaw;
            }

            if (rs == 2 && !(sl.getBlockState(this.getSleepingPos().orElse(this.blockPosition())).getBlock() instanceof BedBlock)) {
               this.wakeUp();
            } else {
               if (++this.restHealTimer >= (Integer)ECConfig.restHealIntervalTicks.get()) {
                  this.restHealTimer = 0;
                  this.heal(((Double)ECConfig.restHealAmount.get()).floatValue());
                  sl.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.5, this.getZ(), 1, 0.2, 0.1, 0.2, 0.0);
               }

               if (this.tickCount % 10 == 0 && this.danger(sl)) {
                  this.wakeUp();
               }
            }
         }
      }
   }

   private boolean danger(ServerLevel sl) {
      if (!this.isOnFire() && !this.isInLava() && this.getAirSupply() >= 100) {
         for (Mob m : sl.getEntitiesOfClass(Mob.class, this.getBoundingBox().inflate(7.0), mx -> mx instanceof Enemy && mx.isAlive() && this.isValidTarget(mx))) {
            if (m.getTarget() != null || m.distanceToSqr(this) < 25.0) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private void lieOnGround() {
      this.restYaw = this.getYRot();
      this.entityData.set(DATA_REST, 3);
      this.restHealTimer = 0;
      this.getNavigation().stop();
      this.setDeltaMovement(Vec3.ZERO);
      if (this.level() instanceof ServerLevel sl) {
         sl.playSound(null, this.blockPosition(), (SoundEvent)ModRegistry.SND_REST.get(), SoundSource.NEUTRAL, 0.8F, 1.0F);
      }
   }

   public void wakeUp() {
      this.wakeUp(true);
   }

   public void wakeUp(boolean suppress) {
      if (suppress && this.level() instanceof ServerLevel sl0) {
         this.suppressCurrentWindow(sl0);
      }

      if (this.getRestState() != 0) {
         if (this.isSleeping()) {
            this.stopSleeping();
         }

         this.entityData.set(DATA_REST, 0);
         this.entityData.set(DATA_WAKE, 20);
         this.bedTarget = null;
         this.getNavigation().stop();
      }
   }

   public void setSchedule(RestSchedule sch) {
      this.entityData.set(DATA_SCHEDULE, sch.ordinal());
      this.suppressedOccurrence = Long.MIN_VALUE;
      if (sch == RestSchedule.OFF && this.restReason == 1 && this.getRestState() != 0) {
         this.wakeUp(false);
      }
   }

   private int[] windowFor(RestSchedule sch) {
      return switch (sch) {
         case DAY -> new int[]{(Integer)ECConfig.restDayStart.get(), (Integer)ECConfig.restDayEnd.get()};
         case NOON -> new int[]{(Integer)ECConfig.restNoonStart.get(), (Integer)ECConfig.restNoonEnd.get()};
         case EVENING -> new int[]{(Integer)ECConfig.restEveningStart.get(), (Integer)ECConfig.restEveningEnd.get()};
         case NIGHT -> new int[]{(Integer)ECConfig.restNightStart.get(), (Integer)ECConfig.restNightEnd.get()};
         default -> null;
      };
   }

   private void suppressCurrentWindow(ServerLevel sl) {
      int[] w = this.windowFor(this.getSchedule());
      if (w != null && RestSchedule.inWindow(sl.getDayTime(), w[0], w[1])) {
         this.suppressedOccurrence = RestSchedule.occurrenceId(sl.getDayTime(), w[0], w[1]);
      }
   }

   private void tickSchedule(ServerLevel sl) {
      RestSchedule sch = this.getSchedule();
      if (sch != RestSchedule.OFF) {
         int[] w = this.windowFor(sch);
         long t = sl.getDayTime();
         if (!RestSchedule.inWindow(t, w[0], w[1])) {
            this.suppressedOccurrence = Long.MIN_VALUE;
            if (this.restReason == 1 && this.getRestState() != 0) {
               this.wakeUp(false);
               ElfDialogue.say(this, "wake");
            }
         } else if (this.getRestState() == 0 && this.tickCount % 20 == 0) {
            if (this.suppressedOccurrence != RestSchedule.occurrenceId(t, w[0], w[1])) {
               if (!this.isMounted()
                  && !this.defense.isEscaping()
                  && !this.defense.isDrinking()
                  && !this.skills.isUltimate()
                  && !this.skills.hasCast()
                  && this.getTarget() == null
                  && !this.isInWater()
                  && !this.isOnFire()
                  && this.onGround()
                  && this.nearestHostile(12.0) == null) {
                  this.startRest(true);
               }
            }
         }
      }
   }

   private boolean isSafeStand(Level lv, BlockPos feet) {
      BlockPos below = feet.below();
      if (!lv.getBlockState(below).isFaceSturdy(lv, below, Direction.UP)) {
         return false;
      } else if (lv.getFluidState(feet).isEmpty() && lv.getFluidState(feet.above()).isEmpty()) {
         BlockState b0 = lv.getBlockState(feet);
         BlockState b1 = lv.getBlockState(below);
         return !b0.is(BlockTags.FIRE) && !b0.is(Blocks.CACTUS) && !b1.is(Blocks.MAGMA_BLOCK) && !b1.is(BlockTags.CAMPFIRES) && !b0.is(Blocks.SWEET_BERRY_BUSH)
            ? lv.noCollision(this.getType().getDimensions().makeBoundingBox(feet.getX() + 0.5, feet.getY(), feet.getZ() + 0.5))
            : false;
      } else {
         return false;
      }
   }

   @Nullable
   private BlockPos findSafeStand(Level lv, BlockPos around) {
      BlockPos best = null;
      double bd = Double.MAX_VALUE;

      for (int dx = -3; dx <= 3; dx++) {
         for (int dz = -3; dz <= 3; dz++) {
            for (int dy = -3; dy <= 3; dy++) {
               BlockPos c = around.offset(dx, dy, dz);
               if (lv.isLoaded(c)) {
                  double d = c.distSqr(around);
                  if (d < bd && this.isSafeStand(lv, c)) {
                     bd = d;
                     best = c;
                  }
               }
            }
         }
      }

      return best;
   }

   private boolean toggleHome(ServerPlayer p, boolean quiet) {
      if (this.hasHome()) {
         this.homePos = null;
         this.homeDim = "";
         this.goingHome = false;
         this.entityData.set(DATA_HAS_HOME, false);
         this.msg(p, quiet, "home_removed");
         return true;
      } else {
         BlockPos safe = this.findSafeStand(this.level(), this.blockPosition());
         if (safe == null) {
            this.msg(p, quiet, "home_unsafe");
            return false;
         } else {
            this.homePos = safe.immutable();
            this.homeDim = this.level().dimension().location().toString();
            this.entityData.set(DATA_HAS_HOME, true);
            this.msg(p, quiet, "home_set");
            return true;
         }
      }
   }

   private void adoptHomeAsPost() {
      if (this.homePos != null) {
         if (this.getStance() == 0) {
            this.setStance(2);
         }

         if (this.getStance() == 2) {
            this.guardPos = this.homePos;
         }

         if (this.getStance() == 3) {
            this.wanderAnchor = this.homePos;
         }
      }
   }

   private boolean goHome(ServerPlayer p, boolean quiet) {
      if (this.hasHome() && this.homePos != null) {
         ResourceLocation rl = ResourceLocation.tryParse(this.homeDim);
         ServerLevel target = rl == null ? null : p.server.getLevel(ResourceKey.create(Registries.DIMENSION, rl));
         if (target == null) {
            this.msg(p, quiet, "home_unavailable");
            return false;
         } else {
            this.wakeUp();
            this.dismount();
            this.cancelGoHome();
            Vec3 center = Vec3.atBottomCenterOf(this.homePos);
            if (target == this.level()
               && this.distanceToSqr(center)
                  <= (double)((Integer)ECConfig.goHomeTeleportDistance.get()).intValue() * ((Integer)ECConfig.goHomeTeleportDistance.get()).intValue()) {
               this.goingHome = true;
               this.goHomeTicks = 0;
               this.adoptHomeAsPost();
               this.msg(p, quiet, "going_home");
               ElfDialogue.say(this, "go_home");
               return true;
            } else if (!this.teleportHome(target)) {
               this.msg(p, quiet, "home_unsafe");
               return false;
            } else {
               this.adoptHomeAsPost();
               this.msg(p, quiet, "going_home");
               ElfDialogue.say(this, "go_home");
               return true;
            }
         }
      } else {
         this.msg(p, quiet, "no_home");
         return false;
      }
   }

   public boolean teleportHome(ServerLevel target) {
      if (this.homePos == null) {
         return false;
      } else {
         target.getChunk(this.homePos);
         BlockPos safe = this.findSafeStand(target, this.homePos);
         if (safe == null) {
            return false;
         } else {
            this.getNavigation().stop();
            if (target != this.level()) {
               if (!this.teleportTo(target, safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, Set.of(), this.getYRot(), 0.0F)) {
                  return false;
               }
            } else {
               this.moveTo(safe.getX() + 0.5, safe.getY(), safe.getZ() + 0.5, this.getYRot(), 0.0F);
            }

            this.setDeltaMovement(Vec3.ZERO);
            this.fallDistance = 0.0F;
            this.goingHome = false;
            target.sendParticles(ParticleTypes.PORTAL, safe.getX() + 0.5, safe.getY() + 1, safe.getZ() + 0.5, 20, 0.4, 0.8, 0.4, 0.2);
            return true;
         }
      }
   }

   public void deletePermanently() {
      this.permanentlyDeleted = true;
      this.deathHandled = true;
      this.setCarried(false);
      this.wakeUp(false);
      this.skills.cancelAll();
      this.defense.endAll();
      if (!this.level().isClientSide) {
         if ((Boolean)ECConfig.deleteDropsInventory.get()) {
            for (int i = 0; i < 41; i++) {
               ItemStack st = this.inventory.getItem(i);
               if (!st.isEmpty()) {
                  this.spawnAtLocation(st.copy());
               }
            }
         }

         this.inventory.clearContent();
      }

      this.discard();
   }

   public void setLevelQuiet(int newLevel) {
      int lv = Math.max(1, Math.min(50, newLevel));
      if (lv != this.getElfLevel()) {
         float frac = this.getMaxHealth() <= 0.0F ? 1.0F : this.getHealth() / this.getMaxHealth();
         this.entityData.set(DATA_LEVEL, lv);
         this.xp = 0;
         this.applyConfigHealth(false);
         if (this.isAlive()) {
            this.setHealth(Math.max(1.0F, Math.min(this.getMaxHealth(), frac * this.getMaxHealth())));
         }

         if (this.level() instanceof ServerLevel sl && this.getOwnerUUID() != null) {
            ElfRegistry.get(sl.getServer()).update(this);
         }
      }
   }

   private void tickPickup(ServerLevel sl) {
      if (this.isPickup() && this.tickCount % (Integer)ECConfig.pickupIntervalTicks.get() == 0 && this.getRestState() < 2 && !this.skills.isUltimate()) {
         double r = (Double)ECConfig.pickupRadius.get();
         List<ItemEntity> items = sl.getEntitiesOfClass(
            ItemEntity.class, this.getBoundingBox().inflate(r), i -> i.isAlive() && !i.hasPickUpDelay() && i.distanceToSqr(this) <= r * r
         );
         int handled = 0;

         for (ItemEntity item : items) {
            if (handled++ >= (Integer)ECConfig.pickupMaxPerScan.get()) {
               break;
            }

            ItemStack stack = item.getItem();
            int before = stack.getCount();
            ItemStack rest = this.inventory.addToMain(stack);
            int taken = before - rest.getCount();
            if (taken > 0) {
               sl.getChunkSource().broadcast(item, new ClientboundTakeItemEntityPacket(item.getId(), this.getId(), taken));
               this.playSound(SoundEvents.ITEM_PICKUP, 0.2F, 1.0F + this.random.nextFloat());
               if (rest.isEmpty()) {
                  item.discard();
               } else {
                  item.setItem(rest);
               }
            }
         }
      }
   }

   public void writeElfData(CompoundTag t) {
      if (this.ownerUUID != null) {
         t.putUUID("Owner", this.ownerUUID);
      }

      if (this.companionId != null) {
         t.putUUID("CompanionId", this.companionId);
      }

      t.putInt("Skin", this.getSkin());
      t.putInt("Stance", this.getStance());
      t.putInt("Combat", this.getCombat());
      t.putInt("Level", this.getElfLevel());
      t.putInt("Xp", this.xp);
      t.putBoolean("Transcended", this.isTranscended());
      t.putInt("Schedule", this.getSchedule().ordinal());
      t.putLong("SuppressedWindow", this.suppressedOccurrence);
      if (this.wanderAnchor != null) {
         t.putLong("WanderAnchor", this.wanderAnchor.asLong());
      }

      if (this.homePos != null) {
         t.putLong("Home", this.homePos.asLong());
         t.putString("HomeDim", this.homeDim);
      }

      t.putInt("CombatBeforeSit", this.combatBeforeSit);
      t.putBoolean("Pickup", this.isPickup());
      if (this.guardPos != null) {
         t.putLong("GuardPos", this.guardPos.asLong());
      }

      t.putInt("RestState", this.getRestState());
      t.put("ElfInv", this.inventory.save(this.registryAccess()));
      t.putFloat("SavedHealth", this.getHealth());
      t.putFloat("SavedMaxHealth", this.getMaxHealth());
      if (this.hasCustomName()) {
         t.putString("CustomNameJson", Serializer.toJson(this.getCustomName(), this.registryAccess()));
         t.putString("NameText", this.getCustomName().getString());
      }

      this.skills.save(t);
      this.defense.save(t);
   }

   public void readElfData(CompoundTag t) {
      if (t.hasUUID("Owner")) {
         this.setOwnerUUID(t.getUUID("Owner"));
      }

      this.entityData.set(DATA_LEVEL, t.contains("Level") ? Math.max(1, Math.min(50, t.getInt("Level"))) : 1);
      this.xp = Math.max(0, t.getInt("Xp"));
      this.entityData.set(DATA_TRANSCENDED, t.getBoolean("Transcended"));
      this.entityData.set(DATA_RAGE, Math.max(0, t.getInt("RageTicks")));
      if (t.hasUUID("CompanionId")) {
         this.companionId = t.getUUID("CompanionId");
      }

      this.entityData.set(DATA_SKIN, Math.floorMod(t.getInt("Skin"), 6));
      this.combatBeforeSit = t.contains("CombatBeforeSit") ? t.getInt("CombatBeforeSit") : 0;
      this.entityData.set(DATA_STANCE, Math.floorMod(t.getInt("Stance"), 4));
      this.entityData.set(DATA_SCHEDULE, Math.floorMod(t.getInt("Schedule"), RestSchedule.values().length));
      this.suppressedOccurrence = t.contains("SuppressedWindow") ? t.getLong("SuppressedWindow") : Long.MIN_VALUE;
      this.wanderAnchor = t.contains("WanderAnchor") ? BlockPos.of(t.getLong("WanderAnchor")) : null;
      if (this.wanderAnchor == null && this.getStance() == 3) {
         this.wanderAnchor = this.blockPosition();
      }

      this.homePos = t.contains("Home") ? BlockPos.of(t.getLong("Home")) : null;
      this.homeDim = this.homePos != null ? t.getString("HomeDim") : "";
      this.entityData.set(DATA_HAS_HOME, this.homePos != null);
      this.goingHome = false;
      this.entityData.set(DATA_COMBAT, Math.floorMod(t.getInt("Combat"), 3));
      this.entityData.set(DATA_PICKUP, t.getBoolean("Pickup"));
      this.guardPos = t.contains("GuardPos") ? BlockPos.of(t.getLong("GuardPos")) : null;
      if (this.guardPos == null && this.getStance() == 2) {
         this.guardPos = this.blockPosition();
      }

      if (t.contains("ElfInv", 9)) {
         this.inventory.load(t.getList("ElfInv", 10), this.registryAccess());
      }

      if (t.contains("CustomNameJson")) {
         Component c = Serializer.fromJson(t.getString("CustomNameJson"), this.registryAccess());
         if (c != null) {
            this.setCustomName(c);
            this.setCustomNameVisible(true);
         }
      }

      this.skills.load(t);
      this.defense.load(t);
      this.setNoGravity(false);
      this.entityData.set(DATA_CARRIED, false);
      this.noPhysics = false;
   }

   public void addAdditionalSaveData(CompoundTag t) {
      super.addAdditionalSaveData(t);
      this.writeElfData(t);
   }

   public void readAdditionalSaveData(CompoundTag t) {
      super.readAdditionalSaveData(t);
      this.readElfData(t);
      if (this.getRestState() >= 2 && !this.isSleeping()) {
         this.entityData.set(DATA_REST, 0);
      }

      if (this.getRestState() == 1) {
         this.entityData.set(DATA_REST, 0);
      }
   }

   public void die(DamageSource source) {
      if (!this.level().isClientSide && !this.deathHandled && this.level() instanceof ServerLevel sl) {
         this.deathHandled = true;
         this.setCarried(false);
         this.voice.onDeath();
         this.skills.onDeath();
         this.skills.cancelAll();
         this.defense.endAll();
         this.wakeUp();
         if (this.ownerUUID != null && this.companionId != null) {
            this.storeSoul(sl);
         }
      }

      super.die(source);
   }

   private void storeSoul(ServerLevel sl) {
      CompoundTag data = new CompoundTag();
      this.writeElfData(data);
      ItemStack soul = SoulItem.create(data);
      ElfRegistry.get(sl.getServer()).markDead(this);
      this.inventory.clearContent();
      ServerPlayer owner = sl.getServer().getPlayerList().getPlayer(this.ownerUUID);
      if (owner != null) {
         owner.getInventory().placeItemBackInInventory(soul);
      } else {
         Vec3 at = this.lastSafePos == null || !this.isInLava() && !(this.getY() < sl.getMinBuildHeight() + 1) ? this.position() : this.lastSafePos;
         ItemEntity drop = new ItemEntity(sl, at.x, at.y + 0.3, at.z, soul);
         drop.setUnlimitedLifetime();
         drop.setInvulnerable(true);
         sl.addFreshEntity(drop);
      }

      sl.playSound(null, this.blockPosition(), (SoundEvent)ModRegistry.SND_SOUL.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
      sl.sendParticles(ParticleTypes.SOUL, this.getX(), this.getY() + 1.0, this.getZ(), 20, 0.3, 0.6, 0.3, 0.03);
   }

   protected void dropAllDeathLoot(ServerLevel level, DamageSource source) {
   }

   @Nullable
   public static ElfEntity revive(ServerLevel level, Vec3 pos, CompoundTag data) {
      if (data.hasUUID("CompanionId") && data.hasUUID("Owner")) {
         UUID cid = data.getUUID("CompanionId");
         if (ElfManager.LOADED.containsKey(cid)) {
            return null;
         } else {
            ElfRegistry reg = ElfRegistry.get(level.getServer());
            ElfRegistry.Record rec = reg.byId(cid);
            if (reg.isDeleted(cid)) {
               return null;
            } else if (rec != null && !rec.dead) {
               return null;
            } else {
               ElfEntity elf = (ElfEntity)((EntityType)ModRegistry.ELF.get()).create(level);
               if (elf == null) {
                  return null;
               } else {
                  elf.readElfData(data);
                  elf.moveTo(pos.x, pos.y, pos.z, level.random.nextFloat() * 360.0F, 0.0F);
                  elf.applyConfigHealth(false);
                  elf.setHealth((float)Math.max(1.0, elf.getMaxHealth() * (Double)ECConfig.reviveHealthFraction.get()));
                  elf.entityData.set(DATA_REST, 0);
                  if (!level.addFreshEntity(elf)) {
                     return null;
                  } else {
                     elf.skillsReviveCleanup();
                     reg.update(elf);
                     ElfDialogue.say(elf, "revive");
                     return elf;
                  }
               }
            }
         }
      } else {
         return null;
      }
   }

   private void skillsReviveCleanup() {
      this.setNoGravity(false);
      this.removeAllEffects();
   }

   public void remove(RemovalReason reason) {
      if (!this.level().isClientSide) {
         this.skills.cancelAll();
         this.defense.endAll();
      }

      super.remove(reason);
   }

   public void noteDamaged(LivingEntity victim) {
      if (!this.level().isClientSide && victim != null) {
         if (this.recentHits.size() > 64) {
            this.recentHits.values().removeIf(t -> this.level().getGameTime() - t > 400L);
         }

         this.recentHits.put(victim.getUUID(), this.level().getGameTime());
      }
   }

   public void onAssist(LivingEntity victim) {
      Long t = this.recentHits.get(victim.getUUID());
      boolean involved = t != null && this.level().getGameTime() - t <= 200L || this.getTarget() == victim;
      if (involved) {
         this.addXp((int)Math.round(ElfLevel.killXp(victim) * (Double)ECConfig.assistXpFraction.get()));
      }
   }

   public boolean killedEntity(ServerLevel lvl, LivingEntity victim) {
      boolean r = super.killedEntity(lvl, victim);
      if (victim instanceof Enemy) {
         this.addXp(ElfLevel.killXp(victim));
      }

      return r;
   }

   public void addXp(int amount) {
      if (!this.level().isClientSide && amount > 0 && !this.isTranscended()) {
         this.xp = this.xp + Math.max(1, (int)Math.round(amount * (Double)ECConfig.xpMultiplier.get()));
         if (this.getElfLevel() >= 50) {
            this.xp = Math.min(this.xp, ElfLevel.transcendXp());
            if (this.xp >= ElfLevel.transcendXp()) {
               this.skills.tryStartTranscend();
            }
         } else {
            int start = this.getElfLevel();

            int lv;
            for (lv = start; lv < 50 && this.xp >= ElfLevel.xpForNext(lv); lv++) {
               this.xp = this.xp - ElfLevel.xpForNext(lv);
            }

            if (lv >= 50) {
               this.xp = 0;
            }

            if (lv != start) {
               this.entityData.set(DATA_LEVEL, lv);
               this.onLevelUp(lv);
            }
         }
      }
   }

   private void onLevelUp(int newLevel) {
      this.applyConfigHealth(true);
      this.skills.addFx(ElfFx.levelBeam(this, 34));
      if (this.getOwnerPlayer() instanceof ServerPlayer sp) {
         Component name = this.getDisplayName().copy().withStyle(ChatFormatting.GREEN);
         sp.sendSystemMessage(
            Component.empty()
               .append(Component.literal("✦ ").withStyle(ChatFormatting.GOLD))
               .append(
                  Component.translatable(
                        newLevel >= 50 ? "message.elven_companions.levelup_max" : "message.elven_companions.levelup",
                        new Object[]{
                           name, Component.literal(String.valueOf(newLevel)).withStyle(new ChatFormatting[]{ChatFormatting.GOLD, ChatFormatting.BOLD})
                        }
                     )
                     .withStyle(ChatFormatting.YELLOW)
               )
         );
      }

      if (this.level() instanceof ServerLevel sl) {
         ElfRegistry.get(sl.getServer()).update(this);
      }
   }

   @Nullable
   protected SoundEvent getHurtSound(DamageSource s) {
      return null;
   }

   @Nullable
   protected SoundEvent getDeathSound() {
      return null;
   }

   @Nullable
   protected SoundEvent getAmbientSound() {
      return null;
   }
}
