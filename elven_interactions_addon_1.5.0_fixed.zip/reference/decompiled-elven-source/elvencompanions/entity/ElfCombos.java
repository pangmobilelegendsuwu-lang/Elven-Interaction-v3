package com.elvencompanions.entity;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.WeakHashMap;
import java.util.function.Supplier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;

public final class ElfCombos {
   private static final int VERDANT = 0;
   private static final int SKYFALL = 1;
   private static final int VOLLEY = 2;
   private static final int WILDFIRE = 3;
   private static final int MOONFALL = 4;
   private static final int THORN = 5;
   private static final double[][] TABLE = new double[][]{
      {5.0, 0.0, 0.4, 0.7, 18.0},
      {5.0, 3.0, 0.12, 0.25, 18.0},
      {4.0, 2.0, 0.35, 0.65, 24.0},
      {3.0, 5.0, 0.25, 0.45, 10.0},
      {0.0, 2.0, 0.15, 0.35, 10.0},
      {1.0, 4.0, 0.2, 0.4, 30.0}
   };
   private static final WeakHashMap<ElfSkills, ElfCombos.Pending> PENDING = new WeakHashMap<>();
   private static boolean ok = true;
   private static Field fElf;
   private static Field fCd;
   private static Field fCasts;
   private static Field fUlt;
   private static Field fCinematic;
   private static Field fAnims;
   private static Field fKeys;
   private static Field fAnim;
   private static Method mFactory;
   private static Method mCooldownTicks;
   private static Method mAnnounce;
   private static Method mStart;
   private static boolean inited;

   private static void init() {
      if (!inited) {
         inited = true;

         try {
            Class<ElfSkills> var0 = ElfSkills.class;
            fElf = acc(var0.getDeclaredField("elf"));
            fCd = acc(var0.getDeclaredField("cd"));
            fCasts = acc(var0.getDeclaredField("casts"));
            fUlt = acc(var0.getDeclaredField("ult"));
            fCinematic = acc(var0.getDeclaredField("cinematic"));
            fAnims = acc(var0.getDeclaredField("ANIMS"));
            fKeys = acc(var0.getDeclaredField("KEYS"));
            mFactory = acc(var0.getDeclaredMethod("factory", int.class, LivingEntity.class));
            mCooldownTicks = acc(var0.getDeclaredMethod("cooldownTicks", int.class));
            mAnnounce = acc(var0.getDeclaredMethod("announce", String.class, double.class));
            Class var1 = Class.forName("com.elvencompanions.entity.ElfSkills$Cast");
            fAnim = acc(var1.getDeclaredField("anim"));
            mStart = acc(var1.getDeclaredMethod("start"));
         } catch (Throwable var2) {
            ok = false;
         }
      }
   }

   private static <T extends AccessibleObject> T acc(T var0) {
      var0.setAccessible(true);
      return (T)var0;
   }

   public static void onActivated(ElfSkills var0, int var1, LivingEntity var2) {
      try {
         init();
         if (!ok || var2 == null) {
            return;
         }

         ElfEntity var3 = (ElfEntity)fElf.get(var0);
         ElfNew.onElfCast(var3, var1);
         int var4 = var3.getElfLevel();
         double var5 = var3.getRandom().nextDouble();
         double var7 = 0.0;

         for (double[] var12 : TABLE) {
            if ((int)var12[0] == var1) {
               var7 += ElfLevel.lerp(var12[2], var12[3], var4);
               if (var5 < var7) {
                  ElfCombos.Pending var13 = new ElfCombos.Pending();
                  var13.second = (int)var12[1];
                  var13.delay = (int)var12[4];
                  var13.target = var2;
                  PENDING.put(var0, var13);
                  return;
               }
            }
         }
      } catch (Throwable var14) {
         ok = false;
      }
   }

   public static void tick(ElfSkills var0) {
      try {
         init();
         if (!ok) {
            return;
         }

         ElfEntity var1 = (ElfEntity)fElf.get(var0);
         ElfMelee.update(var1);
         ElfNew.tick(var1);
         ElfCombos.Pending var2 = PENDING.get(var0);
         if (var2 == null) {
            return;
         }

         if (--var2.delay > 0) {
            return;
         }

         PENDING.remove(var0);
         fire(var0, var1, var2);
      } catch (Throwable var3) {
         PENDING.remove(var0);
      }
   }

   private static void fire(ElfSkills var0, ElfEntity var1, ElfCombos.Pending var2) throws Exception {
      LivingEntity var3 = var2.target;
      if (var1.isAlive() && var3 != null && var3.isAlive() && var1.level() instanceof ServerLevel) {
         if (fUlt.get(var0) == null && fCinematic.get(var0) == null) {
            int[] var4 = (int[])fCd.get(var0);
            if (var4[var2.second] <= 0) {
               Supplier var5 = (Supplier)mFactory.invoke(var0, var2.second, var3);
               Object var6 = var5.get();
               if (var6 != null) {
                  fAnim.setInt(var6, ((int[])fAnims.get(null))[var2.second]);
                  var4[var2.second] = (Integer)mCooldownTicks.invoke(var0, var2.second);
                  List var7 = (List)fCasts.get(var0);
                  var7.add(var6);

                  try {
                     String[] var8 = (String[])fKeys.get(null);
                     mAnnounce.invoke(var0, var8[var2.second], 32.0);
                  } catch (Throwable var9) {
                  }

                  mStart.invoke(var6);
               }
            }
         }
      }
   }

   private ElfCombos() {
   }

   private static final class Pending {
      int second;
      int delay;
      LivingEntity target;
   }
}
