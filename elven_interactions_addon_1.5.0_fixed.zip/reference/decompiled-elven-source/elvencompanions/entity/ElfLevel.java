package com.elvencompanions.entity;

import com.elvencompanions.ECConfig;
import com.elvencompanions.logic.TranscendMath;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.LivingEntity;

public final class ElfLevel {
   public static final int MAX = 50;

   public static double t(int level) {
      return (Mth.clamp(level, 1, 50) - 1) / 49.0;
   }

   public static double lerp(double a, double b, int level) {
      return a + (b - a) * t(level);
   }

   public static int xpForNext(int level) {
      double v = (Double)ECConfig.xpBase.get() + (Double)ECConfig.xpLinear.get() * level + (Double)ECConfig.xpQuad.get() * level * level;
      return Math.max(1, (int)Math.round(v));
   }

   public static int transcendXp() {
      return TranscendMath.transcendXp(xpForNext(50), (Double)ECConfig.transcendXpMultiplier.get());
   }

   public static int killXp(LivingEntity victim) {
      return Math.min(160, (int)Math.round(Math.max(3.0, victim.getMaxHealth() * 0.7)));
   }

   public static double maxHealth(int l) {
      return lerp((Double)ECConfig.maxHealth.get(), (Double)ECConfig.maxHealthMax.get(), l);
   }

   public static double damageReduction(int l) {
      return lerp(0.0, (Double)ECConfig.maxDamageReduction.get(), l);
   }

   public static double arrowMult(int l) {
      return lerp((Double)ECConfig.arrowDamageMultiplier.get(), (Double)ECConfig.arrowDamageMultiplierMax.get(), l);
   }

   public static int fireInterval(int level, Difficulty difficulty) {
      int skeleton = difficulty == Difficulty.HARD ? 20 : 40;
      return Math.max(4, (int)Math.round(skeleton * (Double)ECConfig.fireIntervalFactor.get() / fireSpeed(level)));
   }

   public static double fireSpeed(int l) {
      return lerp(1.0, (Double)ECConfig.fireSpeedMaxMultiplier.get(), l);
   }

   public static double chanceMult(int l) {
      return lerp(1.0, (Double)ECConfig.skillChanceMaxMultiplier.get(), l);
   }

   public static double skillDamage(int l) {
      return lerp(1.0, (Double)ECConfig.skillDamageMaxMultiplier.get(), l);
   }

   public static double area(int l) {
      return lerp(1.0, (Double)ECConfig.skillAreaMaxMultiplier.get(), l);
   }

   public static double staminaMult(int l) {
      return lerp(1.0, (Double)ECConfig.staminaMaxMultiplier.get(), l);
   }

   public static double cooldownFactor(int l) {
      return lerp(1.0, (Double)ECConfig.skillCooldownMinFactor.get(), l);
   }

   public static double walkSpeed(int l) {
      return lerp(1.0, (Double)ECConfig.walkSpeedMaxMultiplier.get(), l);
   }

   public static double inaccuracy(int l) {
      return lerp((Double)ECConfig.arrowInaccuracy.get(), (Double)ECConfig.arrowInaccuracyMin.get(), l);
   }

   public static double aimLead(int l) {
      return lerp(0.25, 1.0, l);
   }

   public static int potionTicks(int l) {
      return (int)Math.round(lerp(((Integer)ECConfig.potionDrinkTicks.get()).intValue(), ((Integer)ECConfig.potionDrinkTicksMin.get()).intValue(), l));
   }

   public static int tier(int l) {
      return Mth.clamp(l / 10, 0, 5);
   }

   private ElfLevel() {
   }
}
