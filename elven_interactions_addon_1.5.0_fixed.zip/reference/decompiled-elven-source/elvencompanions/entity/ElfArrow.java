package com.elvencompanions.entity;

import com.elvencompanions.ModRegistry;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public class ElfArrow extends Arrow {
   private ElfArrow.HitTracker tracker;
   private boolean aimed;

   public ElfArrow(EntityType<? extends ElfArrow> var1, Level var2) {
      super(var1, var2);
   }

   public void setTracker(ElfArrow.HitTracker var1) {
      this.tracker = var1;
   }

   private void aimAssist(ElfEntity var1) {
      LivingEntity var2 = var1.getTarget();
      Vec3 var3 = this.getDeltaMovement();
      double var4 = var3.length();
      if (var2 != null && var2.isAlive() && !(var4 < 0.5)) {
         double var6 = var2.getX() - this.getX();
         double var8 = var2.getY() + var2.getBbHeight() * 0.6 - this.getY();
         double var10 = var2.getZ() - this.getZ();
         double var12 = Math.sqrt(var6 * var6 + var10 * var10);
         double var14 = var12 / var4;
         Vec3 var16 = var2.getDeltaMovement();
         var6 += var16.x * var14 * 0.9;
         var10 += var16.z * var14 * 0.9;
         var12 = Math.sqrt(var6 * var6 + var10 * var10);
         this.shoot(var6, var8 + var12 * 0.2, var10, (float)var4, 0.25F);
      }
   }

   public void tick() {
      if (!this.aimed) {
         this.aimed = true;
         if (!this.level().isClientSide && this.tracker == null && this.getOwner() instanceof ElfEntity var1 && var1.skills.isFlying()) {
            this.aimAssist(var1);
         }
      }

      super.tick();
      if (this.level().isClientSide && this.getDeltaMovement().lengthSqr() > 0.04) {
         boolean var4;
         if (this.tracker != null || this.getOwner() instanceof ElfEntity var5 && var5.getElfLevel() >= 30) {
            var4 = true;
         } else {
            var4 = false;
         }

         this.level()
            .addParticle(
               var4 ? (ParticleOptions)ModRegistry.GLOW_GOLD.get() : (ParticleOptions)ModRegistry.GLOW_GREEN.get(),
               this.getX(),
               this.getY(),
               this.getZ(),
               0.0,
               0.0,
               0.0
            );
         if (this.tickCount % 2 == 0) {
            this.level()
               .addParticle(
                  (ParticleOptions)ModRegistry.STAR.get(),
                  this.getX(),
                  this.getY(),
                  this.getZ(),
                  (this.random.nextDouble() - 0.5) * 0.03,
                  (this.random.nextDouble() - 0.5) * 0.03,
                  (this.random.nextDouble() - 0.5) * 0.03
               );
         }
      }
   }

   protected boolean canHitEntity(Entity var1) {
      if (!super.canHitEntity(var1)) {
         return false;
      } else {
         return this.getOwner() instanceof ElfEntity var2 && var1 instanceof LivingEntity var3 ? var2.isValidTarget(var3) : true;
      }
   }

   protected void onHitEntity(EntityHitResult var1) {
      if (this.getOwner() instanceof ElfEntity var2 && var1.getEntity() instanceof LivingEntity var3 && !this.level().isClientSide) {
         var2.noteDamaged(var3);
      }

      if (var1.getEntity() instanceof WitherBoss var7 && var7.isPowered()) {
         if (!this.level().isClientSide) {
            float var10;
            if (this.tracker != null) {
               var10 = this.tracker.tryHit(var7) ? this.tracker.damage : 0.0F;
            } else {
               var10 = Mth.ceil(Mth.clamp(this.getDeltaMovement().length() * this.getBaseDamage(), 0.0, 2.147483647E9));
            }

            if (var10 > 0.0F) {
               DamageSource var14 = this.getOwner() instanceof LivingEntity var15 ? this.damageSources().mobAttack(var15) : this.damageSources().generic();
               var7.invulnerableTime = 0;
               var7.hurt(var14, var10);
            }
         }

         this.discard();
      } else if (this.tracker == null) {
         super.onHitEntity(var1);
      } else {
         Entity var9 = var1.getEntity();
         if (!this.level().isClientSide && this.tracker.tryHit(var9)) {
            Entity var12 = this.getOwner();
            DamageSource var5 = this.damageSources().arrow(this, (Entity)(var12 == null ? this : var12));
            if (var9 instanceof LivingEntity var6) {
               var6.invulnerableTime = 0;
            }

            var9.hurt(var5, this.tracker.damage);
         }

         this.discard();
      }
   }

   public static class HitTracker {
      public final float damage;
      public final int maxHits;
      private final Map<Integer, Integer> hits = new HashMap<>();

      public HitTracker(float var1, int var2) {
         this.damage = var1;
         this.maxHits = var2;
      }

      public boolean tryHit(Entity var1) {
         int var2 = this.hits.getOrDefault(var1.getId(), 0);
         if (var2 >= this.maxHits) {
            return false;
         } else {
            this.hits.put(var1.getId(), var2 + 1);
            return true;
         }
      }
   }
}
