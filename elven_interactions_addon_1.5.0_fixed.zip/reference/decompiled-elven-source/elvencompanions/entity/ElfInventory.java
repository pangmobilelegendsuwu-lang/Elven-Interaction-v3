package com.elvencompanions.entity;

import net.minecraft.core.NonNullList;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class ElfInventory implements Container {
   public static final int MAIN_SIZE = 36;
   public static final int SIZE = 41;
   private static final EquipmentSlot[] EQ = new EquipmentSlot[]{
      EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD, EquipmentSlot.OFFHAND
   };
   private final ElfEntity elf;
   private final NonNullList<ItemStack> main = NonNullList.withSize(36, ItemStack.EMPTY);
   private final NonNullList<ItemStack> fallback = NonNullList.withSize(5, ItemStack.EMPTY);

   public ElfInventory(ElfEntity elf) {
      this.elf = elf;
   }

   public int getContainerSize() {
      return 41;
   }

   public boolean isEmpty() {
      for (int i = 0; i < 41; i++) {
         if (!this.getItem(i).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public int usedSlots() {
      int n = 0;

      for (int i = 0; i < 41; i++) {
         if (!this.getItem(i).isEmpty()) {
            n++;
         }
      }

      return n;
   }

   public ItemStack getItem(int i) {
      if (i < 0 || i >= 41) {
         return ItemStack.EMPTY;
      } else if (i < 36) {
         return (ItemStack)this.main.get(i);
      } else {
         return this.elf != null ? this.elf.getItemBySlot(EQ[i - 36]) : (ItemStack)this.fallback.get(i - 36);
      }
   }

   public void setItem(int i, ItemStack stack) {
      if (i >= 0 && i < 41) {
         if (!stack.isEmpty() && stack.getCount() > this.getMaxStackSize()) {
            stack.setCount(this.getMaxStackSize());
         }

         if (i < 36) {
            this.main.set(i, stack);
         } else if (this.elf != null) {
            this.elf.setItemSlot(EQ[i - 36], stack);
         } else {
            this.fallback.set(i - 36, stack);
         }

         this.setChanged();
      }
   }

   public ItemStack removeItem(int i, int amount) {
      ItemStack s = this.getItem(i);
      if (!s.isEmpty() && amount > 0) {
         ItemStack out = s.split(amount);
         if (s.isEmpty() && i >= 36) {
            this.setItem(i, ItemStack.EMPTY);
         }

         this.setChanged();
         return out;
      } else {
         return ItemStack.EMPTY;
      }
   }

   public ItemStack removeItemNoUpdate(int i) {
      ItemStack s = this.getItem(i);
      if (s.isEmpty()) {
         return ItemStack.EMPTY;
      } else {
         if (i < 36) {
            this.main.set(i, ItemStack.EMPTY);
         } else {
            this.setItem(i, ItemStack.EMPTY);
         }

         return s;
      }
   }

   public void setChanged() {
   }

   public boolean stillValid(Player player) {
      return this.elf == null || this.elf.canUseInventory(player);
   }

   public void clearContent() {
      for (int i = 0; i < 41; i++) {
         if (i < 36) {
            this.main.set(i, ItemStack.EMPTY);
         } else {
            this.setItem(i, ItemStack.EMPTY);
         }
      }
   }

   public ItemStack addToMain(ItemStack stack) {
      ItemStack rem = stack.copy();

      for (int i = 0; i < 36 && !rem.isEmpty(); i++) {
         ItemStack t = (ItemStack)this.main.get(i);
         if (!t.isEmpty() && ItemStack.isSameItemSameComponents(t, rem) && t.getCount() < t.getMaxStackSize()) {
            int mv = Math.min(rem.getCount(), t.getMaxStackSize() - t.getCount());
            t.grow(mv);
            rem.shrink(mv);
         }
      }

      for (int ix = 0; ix < 36 && !rem.isEmpty(); ix++) {
         if (((ItemStack)this.main.get(ix)).isEmpty()) {
            this.main.set(ix, rem.split(Math.min(rem.getCount(), rem.getMaxStackSize())));
         }
      }

      return rem;
   }

   public ListTag save(Provider prov) {
      ListTag list = new ListTag();

      for (int i = 0; i < 41; i++) {
         ItemStack s = this.getItem(i);
         if (!s.isEmpty()) {
            CompoundTag t = new CompoundTag();
            t.putByte("Slot", (byte)i);
            list.add(s.save(prov, t));
         }
      }

      return list;
   }

   public void load(ListTag list, Provider prov) {
      this.clearContent();

      for (int i = 0; i < list.size(); i++) {
         CompoundTag t = list.getCompound(i);
         int slot = t.getByte("Slot") & 255;
         ItemStack s = ItemStack.parse(prov, t).orElse(ItemStack.EMPTY);
         if (slot < 41 && !s.isEmpty()) {
            this.setItem(slot, s);
         }
      }
   }
}
