package com.elvencompanions.entity;

import com.elvencompanions.ModRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.ItemStack;

public class ElfInventoryMenu extends AbstractContainerMenu {
   private static final int ELF_SLOTS = 41;
   private final ElfEntity elf;
   private final Container container;

   public ElfInventoryMenu(int id, Inventory playerInv, ElfEntity elf) {
      super((MenuType)ModRegistry.ELF_MENU.get(), id);
      this.elf = elf;
      this.container = elf.inventory;
      this.layout(playerInv);
   }

   public ElfInventoryMenu(int id, Inventory playerInv, RegistryFriendlyByteBuf buf) {
      super((MenuType)ModRegistry.ELF_MENU.get(), id);
      this.elf = playerInv.player.level().getEntity(buf.readVarInt()) instanceof ElfEntity ee ? ee : null;
      this.container = this.elf != null ? this.elf.inventory : new ElfInventory(null);
      this.layout(playerInv);
   }

   private void layout(Inventory pi) {
      this.addSlot(new ElfInventoryMenu.ArmorSlot(this.container, 39, 8, 18, EquipmentSlot.HEAD));
      this.addSlot(new ElfInventoryMenu.ArmorSlot(this.container, 38, 26, 18, EquipmentSlot.CHEST));
      this.addSlot(new ElfInventoryMenu.ArmorSlot(this.container, 37, 44, 18, EquipmentSlot.LEGS));
      this.addSlot(new ElfInventoryMenu.ArmorSlot(this.container, 36, 62, 18, EquipmentSlot.FEET));
      this.addSlot(new Slot(this.container, 40, 98, 18).setBackground(InventoryMenu.BLOCK_ATLAS, InventoryMenu.EMPTY_ARMOR_SLOT_SHIELD));

      for (int r = 0; r < 3; r++) {
         for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(this.container, 9 + r * 9 + c, 8 + c * 18, 40 + r * 18));
         }
      }

      for (int c = 0; c < 9; c++) {
         this.addSlot(new Slot(this.container, c, 8 + c * 18, 98));
      }

      for (int r = 0; r < 3; r++) {
         for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(pi, 9 + r * 9 + c, 8 + c * 18, 132 + r * 18));
         }
      }

      for (int c = 0; c < 9; c++) {
         this.addSlot(new Slot(pi, c, 8 + c * 18, 190));
      }
   }

   public ItemStack quickMoveStack(Player player, int index) {
      ItemStack result = ItemStack.EMPTY;
      Slot slot = (Slot)this.slots.get(index);
      if (slot != null && slot.hasItem()) {
         ItemStack stack = slot.getItem();
         result = stack.copy();
         if (index < 41) {
            if (!this.moveItemStackTo(stack, 41, this.slots.size(), true)) {
               return ItemStack.EMPTY;
            }
         } else {
            boolean moved = false;

            for (int i = 0; i < 4 && !moved; i++) {
               if (((Slot)this.slots.get(i)).mayPlace(stack) && !((Slot)this.slots.get(i)).hasItem()) {
                  moved = this.moveItemStackTo(stack, i, i + 1, false);
               }
            }

            if (!moved && !this.moveItemStackTo(stack, 5, 41, false)) {
               return ItemStack.EMPTY;
            }
         }

         if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
         } else {
            slot.setChanged();
         }

         if (stack.getCount() == result.getCount()) {
            return ItemStack.EMPTY;
         } else {
            slot.onTake(player, stack);
            return result;
         }
      } else {
         return result;
      }
   }

   public boolean stillValid(Player player) {
      return this.elf == null || this.elf.canUseInventory(player);
   }

   private static class ArmorSlot extends Slot {
      private final EquipmentSlot es;

      ArmorSlot(Container c, int idx, int x, int y, EquipmentSlot es) {
         super(c, idx, x, y);
         this.es = es;

         ResourceLocation icon = switch (es) {
            case HEAD -> InventoryMenu.EMPTY_ARMOR_SLOT_HELMET;
            case CHEST -> InventoryMenu.EMPTY_ARMOR_SLOT_CHESTPLATE;
            case LEGS -> InventoryMenu.EMPTY_ARMOR_SLOT_LEGGINGS;
            default -> InventoryMenu.EMPTY_ARMOR_SLOT_BOOTS;
         };
         this.setBackground(InventoryMenu.BLOCK_ATLAS, icon);
      }

      public boolean mayPlace(ItemStack s) {
         Equipable eq = Equipable.get(s);
         return eq != null && eq.getEquipmentSlot() == this.es;
      }

      public int getMaxStackSize() {
         return 1;
      }
   }
}
