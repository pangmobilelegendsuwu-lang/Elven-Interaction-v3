package com.elvencompanions.entity;

public final class FalconPath {
   public static final int OUT = 10;
   public static final int LOOP = 9;
   public static final double R = 3.2;
   private static final double GOLDEN = 2.399963;

   public static int total(int var0) {
      return 10 + var0 * 9;
   }

   public static int pass(double var0) {
      return var0 < 10.0 ? 0 : 1 + (int)((var0 - 10.0) / 9.0);
   }

   public static void pos(double var0, double var2, double var4, double var6, double var8, double var10, double var12, double[] var14) {
      if (var12 <= 10.0) {
         double var36 = Math.max(0.0, var12) / 10.0;
         var14[0] = var0 + (var6 - var0) * var36;
         var14[1] = var2 + (var8 - var2) * var36 + Math.sin(Math.PI * var36) * 0.7;
         var14[2] = var4 + (var10 - var4) * var36;
      } else {
         int var15 = (int)((var12 - 10.0) / 9.0);
         double var16 = (var12 - 10.0 - var15 * 9) / 9.0;
         double var18 = var15 * 2.399963;
         double var20 = (var15 % 3 - 1) * 0.55;
         double var22 = Math.cos(var18) * Math.cos(var20);
         double var24 = Math.sin(var20);
         double var26 = Math.sin(var18) * Math.cos(var20);
         double var28 = -Math.sin(var18);
         double var30 = Math.cos(var18);
         double var32 = (var15 % 2 == 0 ? 1 : -1) * 3.2 * 0.75 * Math.sin((Math.PI * 2) * var16);
         double var34 = 3.2 * Math.sin(Math.PI * var16);
         var14[0] = var6 + var22 * var34 + var28 * var32;
         var14[1] = var8 + var24 * var34 + 0.35 * Math.sin(Math.PI * var16);
         var14[2] = var10 + var26 * var34 + var30 * var32;
      }
   }

   private FalconPath() {
   }
}
