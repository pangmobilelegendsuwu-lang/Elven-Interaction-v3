package com.elvencompanions.block;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ModRegistry;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.item.SoulItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class SoulwoodTreeBlockEntity extends BlockEntity {
   private ItemStack soul = ItemStack.EMPTY;
   private boolean apple;
   private int ritualTicks = -1;

   public SoulwoodTreeBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModRegistry.TREE_BE.get(), pos, state);
   }

   public ItemStack getSoul() {
      return this.soul;
   }

   public boolean hasApple() {
      return this.apple;
   }

   public void insertSoul(ItemStack s) {
      this.soul = s;
      this.ritualTicks = -1;
      this.setChanged();
      if (this.level instanceof ServerLevel sl) {
         sl.playSound(null, this.worldPosition, (SoundEvent)ModRegistry.SND_SOUL.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
      }
   }

   public void insertApple() {
      this.apple = true;
      this.ritualTicks = -1;
      this.setChanged();
   }

   public ItemStack takeSoul() {
      ItemStack s = this.soul;
      this.soul = ItemStack.EMPTY;
      this.ritualTicks = -1;
      this.setChanged();
      return s;
   }

   public boolean takeApple() {
      boolean had = this.apple;
      this.apple = false;
      this.ritualTicks = -1;
      this.setChanged();
      return had;
   }

   public static void serverTick(Level level, BlockPos pos, BlockState state, SoulwoodTreeBlockEntity be) {
      if (level instanceof ServerLevel sl) {
         if (!be.soul.isEmpty() && be.apple) {
            if (be.ritualTicks < 0) {
               be.ritualTicks = 0;
               sl.playSound(null, pos, (SoundEvent)ModRegistry.SND_REVIVE.get(), SoundSource.BLOCKS, 1.5F, 1.0F);
            }

            be.ritualTicks++;
            double h = 1.0 + be.ritualTicks * 0.02;
            sl.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + h, pos.getZ() + 0.5, 2, 0.4, 0.1, 0.4, 0.01);
            if (be.ritualTicks % 4 == 0) {
               sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 4, 0.6, 0.6, 0.6, 0.0);
            }

            if (be.ritualTicks >= (Integer)ECConfig.reviveTicks.get()) {
               be.finish(sl, pos);
            }
         } else {
            be.ritualTicks = -1;
         }
      }
   }

   private void finish(ServerLevel sl, BlockPos pos) {
      CompoundTag data = SoulItem.read(this.soul);
      ElfEntity elf = data == null ? null : ElfEntity.revive(sl, pos.above().getCenter().add(0.0, -0.5, 0.0), data);
      if (elf == null) {
         ItemStack s = this.takeSoul();
         if (!s.isEmpty()) {
            sl.addFreshEntity(new ItemEntity(sl, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, s));
         }

         if (this.takeApple()) {
            sl.addFreshEntity(new ItemEntity(sl, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, new ItemStack(Items.GOLDEN_APPLE)));
         }

         for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(pos.getX(), pos.getY(), pos.getZ()) < 144.0) {
               p.displayClientMessage(Component.translatable("message.elven_companions.revive_failed"), true);
            }
         }
      } else {
         this.soul = ItemStack.EMPTY;
         this.apple = false;
         this.ritualTicks = -1;
         this.setChanged();
         sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5, 40, 0.5, 0.8, 0.5, 0.3);
         sl.playSound(null, pos, (SoundEvent)ModRegistry.SND_REVIVE.get(), SoundSource.BLOCKS, 2.0F, 1.3F);
      }
   }

   protected void saveAdditional(CompoundTag tag, Provider reg) {
      super.saveAdditional(tag, reg);
      if (!this.soul.isEmpty()) {
         tag.put("Soul", this.soul.save(reg));
      }

      tag.putBoolean("Apple", this.apple);
   }

   protected void loadAdditional(CompoundTag tag, Provider reg) {
      super.loadAdditional(tag, reg);
      this.soul = tag.contains("Soul") ? ItemStack.parse(reg, tag.getCompound("Soul")).orElse(ItemStack.EMPTY) : ItemStack.EMPTY;
      this.apple = tag.getBoolean("Apple");
      this.ritualTicks = -1;
   }
}
