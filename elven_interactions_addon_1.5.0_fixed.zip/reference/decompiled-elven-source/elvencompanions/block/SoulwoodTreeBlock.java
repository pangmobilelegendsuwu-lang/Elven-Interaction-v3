package com.elvencompanions.block;

import com.elvencompanions.ModRegistry;
import com.elvencompanions.item.SoulItem;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class SoulwoodTreeBlock extends BaseEntityBlock {
   public static final MapCodec<SoulwoodTreeBlock> CODEC = simpleCodec(SoulwoodTreeBlock::new);
   private static final VoxelShape SHAPE = Block.box(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);

   public SoulwoodTreeBlock(Properties props) {
      super(props);
   }

   protected MapCodec<? extends BaseEntityBlock> codec() {
      return CODEC;
   }

   protected RenderShape getRenderShape(BlockState state) {
      return RenderShape.MODEL;
   }

   protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
      return SHAPE;
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new SoulwoodTreeBlockEntity(pos, state);
   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
      return level.isClientSide ? null : createTickerHelper(type, (BlockEntityType)ModRegistry.TREE_BE.get(), SoulwoodTreeBlockEntity::serverTick);
   }

   protected ItemInteractionResult useItemOn(
      ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit
   ) {
      if (level.getBlockEntity(pos) instanceof SoulwoodTreeBlockEntity be) {
         if (stack.getItem() instanceof SoulItem) {
            if (level.isClientSide) {
               return ItemInteractionResult.SUCCESS;
            } else if (be.getSoul().isEmpty() && SoulItem.read(stack) != null) {
               be.insertSoul(stack.copyWithCount(1));
               if (!player.getAbilities().instabuild) {
                  stack.shrink(1);
               }

               player.displayClientMessage(Component.translatable("message.elven_companions.soul_inserted"), true);
               return ItemInteractionResult.CONSUME;
            } else {
               return ItemInteractionResult.FAIL;
            }
         } else if (stack.is(Items.GOLDEN_APPLE)) {
            if (level.isClientSide) {
               return ItemInteractionResult.SUCCESS;
            } else if (be.hasApple()) {
               return ItemInteractionResult.FAIL;
            } else {
               be.insertApple();
               if (!player.getAbilities().instabuild) {
                  stack.shrink(1);
               }

               player.displayClientMessage(Component.translatable("message.elven_companions.apple_inserted"), true);
               return ItemInteractionResult.CONSUME;
            }
         } else {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
         }
      } else {
         return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
      }
   }

   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
      if (level.getBlockEntity(pos) instanceof SoulwoodTreeBlockEntity be) {
         if (level.isClientSide) {
            return InteractionResult.SUCCESS;
         } else if (player.isShiftKeyDown()) {
            ItemStack soul = be.takeSoul();
            if (!soul.isEmpty()) {
               player.getInventory().placeItemBackInInventory(soul);
               player.displayClientMessage(Component.translatable("message.elven_companions.soul_returned"), true);
            } else if (be.takeApple()) {
               player.getInventory().placeItemBackInInventory(new ItemStack(Items.GOLDEN_APPLE));
               player.displayClientMessage(Component.translatable("message.elven_companions.apple_returned"), true);
            } else {
               player.displayClientMessage(Component.translatable("message.elven_companions.tree_empty"), true);
            }

            return InteractionResult.CONSUME;
         } else {
            String contents = (be.getSoul().isEmpty() ? "" : "Elf Soul")
               + (!be.getSoul().isEmpty() && be.hasApple() ? " + " : "")
               + (be.hasApple() ? "Golden Apple" : "");
            player.displayClientMessage(
               contents.isEmpty()
                  ? Component.translatable("message.elven_companions.tree_empty")
                  : Component.translatable("message.elven_companions.tree_contents", new Object[]{contents}),
               true
            );
            return InteractionResult.CONSUME;
         }
      } else {
         return InteractionResult.PASS;
      }
   }

   protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
      if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof SoulwoodTreeBlockEntity be) {
         ItemStack soul = be.takeSoul();
         if (!soul.isEmpty()) {
            Block.popResource(level, pos, soul);
         }

         if (be.takeApple()) {
            Block.popResource(level, pos, new ItemStack(Items.GOLDEN_APPLE));
         }
      }

      super.onRemove(state, level, pos, newState, movedByPiston);
   }
}
