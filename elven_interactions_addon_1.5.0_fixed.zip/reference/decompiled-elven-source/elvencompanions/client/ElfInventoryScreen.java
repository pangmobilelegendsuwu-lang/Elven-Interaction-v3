package com.elvencompanions.client;

import com.elvencompanions.entity.ElfInventoryMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class ElfInventoryScreen extends AbstractContainerScreen<ElfInventoryMenu> {
   public ElfInventoryScreen(ElfInventoryMenu menu, Inventory inv, Component title) {
      super(menu, inv, title);
      this.imageWidth = 176;
      this.imageHeight = 214;
      this.inventoryLabelY = 120;
      this.titleLabelY = 6;
   }

   protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
      int x = this.leftPos;
      int y = this.topPos;
      g.fill(x, y, x + this.imageWidth, y + this.imageHeight, -3750202);
      g.renderOutline(x, y, this.imageWidth, this.imageHeight, -16777216);

      for (Slot s : ((ElfInventoryMenu)this.menu).slots) {
         g.fill(x + s.x - 1, y + s.y - 1, x + s.x + 17, y + s.y + 17, -13158601);
         g.fill(x + s.x, y + s.y, x + s.x + 16, y + s.y + 16, -7631989);
      }
   }

   public void render(GuiGraphics g, int mx, int my, float pt) {
      super.render(g, mx, my, pt);
      this.renderTooltip(g, mx, my);
   }
}
