package com.elvencompanions.client;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

public final class TranscendCinematic {
   private static final int MAX_LINES = 8;
   private static final int FALLBACK_TICKS = 90;
   private static final int MIN_TICKS = 24;
   private static final int GAP_TICKS = 10;
   private static final int BAR_IN = 14;
   private static final int BAR_OUT = 16;
   private static boolean active;
   private static int total;
   private static int age;
   private static int line = -1;
   private static int lineAge;
   private static int gap;
   private static boolean sawActive;
   private static boolean voiceDone;
   private static int linger;
   private static SoundInstance sound;
   private static String subtitle = "";
   private static int flashAge = 9999;
   private static int flashLen = 1;
   private static int flashHold;
   private static float flashPeak;
   private static float burst;

   public static void start(int var0) {
      reset();
      active = true;
      total = Math.max(40, var0);
      nextLine(0);
   }

   public static void reset() {
      Minecraft var0 = Minecraft.getInstance();
      if (sound != null && var0 != null) {
         var0.getSoundManager().stop(sound);
      }

      active = false;
      total = 0;
      age = 0;
      line = -1;
      lineAge = 0;
      gap = 0;
      sawActive = false;
      voiceDone = true;
      linger = 0;
      sound = null;
      subtitle = "";
      flashAge = 9999;
      burst = 0.0F;
   }

   private static int at(int var0) {
      return Math.round((float)var0 * total / 200.0F);
   }

   private static void pulse(int var0, int var1, float var2, float var3) {
      flashAge = 0;
      flashLen = var0;
      flashHold = var1;
      flashPeak = var2;
      burst = Math.max(burst, var3);
   }

   private static void nextLine(int var0) {
      Minecraft var1 = Minecraft.getInstance();
      String var2 = "transcend.elven_companions.voice." + (var0 + 1);
      if (var0 < 8 && I18n.exists(var2)) {
         voiceDone = false;
         line = var0;
         lineAge = 0;
         sawActive = false;
         subtitle = I18n.get(var2, new Object[0]);
         sound = null;
         if ((Boolean)ECConfig.voiceEnabled.get()) {
            ResourceLocation var3 = ElvenCompanions.rl("transcend_voice_" + (var0 + 1));
            float var4 = Mth.clamp(((Double)ECConfig.voiceVolume.get()).floatValue(), 0.05F, 2.0F);
            sound = new SimpleSoundInstance(var3, SoundSource.VOICE, var4, 1.0F, RandomSource.create(), false, 0, Attenuation.NONE, 0.0, 0.0, 0.0, true);
            var1.getSoundManager().play(sound);
         }
      } else {
         voiceDone = true;
         linger = 36;
         subtitle = "";
         sound = null;
         line = -1;
      }
   }

   public static void tick(Minecraft var0) {
      if (flashAge < 9999) {
         flashAge++;
      }

      if (burst > 0.0F) {
         burst = Math.max(0.0F, burst - 0.12F);
      }

      if (active) {
         if (var0.level != null && var0.player != null) {
            age++;
            if (age == at(60)) {
               pulse(10, 0, 110.0F, 1.6F);
            } else if (age == at(100)) {
               pulse(12, 0, 150.0F, 2.2F);
            } else if (age == at(150)) {
               pulse(14, 0, 190.0F, 2.8F);
            } else if (age == at(188)) {
               pulse(70, 12, 255.0F, 7.0F);
            }

            if (!voiceDone && line >= 0) {
               lineAge++;
               boolean var1 = sound != null && var0.getSoundManager().isActive(sound);
               if (var1) {
                  sawActive = true;
               }

               boolean var2;
               if (sound != null && sawActive) {
                  var2 = !var1 && lineAge >= 24;
               } else if (sound != null && lineAge <= 12) {
                  var2 = false;
               } else {
                  var2 = lineAge >= 90;
               }

               if (var2) {
                  subtitle = "";
                  gap = 10;
                  line = -2 - line;
               }
            } else if (!voiceDone && line < -1) {
               if (--gap <= 0) {
                  nextLine(-2 - line + 1);
               }
            } else if (voiceDone && linger > 0) {
               linger--;
            }

            if (age >= total && voiceDone && linger <= 0) {
               active = false;
               sound = null;
            }
         } else {
            reset();
         }
      }
   }

   public static float extraShake() {
      if (!active && burst <= 0.0F) {
         return 0.0F;
      } else {
         float var0 = total > 0 ? Mth.clamp((float)age / total, 0.0F, 1.0F) : 0.0F;
         return burst + (active ? var0 * var0 * var0 * 1.6F : 0.0F);
      }
   }

   private static float barAmount() {
      if (!active) {
         return 0.0F;
      } else {
         float var0 = Mth.clamp(age / 14.0F, 0.0F, 1.0F);
         float var1 = 1.0F;
         if (age >= total && voiceDone) {
            var1 = Mth.clamp(linger / 16.0F, 0.0F, 1.0F);
         }

         float var2 = Math.min(var0, var1);
         return var2 * var2 * (3.0F - 2.0F * var2);
      }
   }

   public static void render(GuiGraphics var0) {
      Minecraft var1 = Minecraft.getInstance();
      int var2 = var0.guiWidth();
      int var3 = var0.guiHeight();
      float var4 = barAmount();
      if (var4 > 0.0F) {
         int var5 = Math.round(var3 * 0.125F * var4);
         var0.fill(0, 0, var2, var5, -16777216);
         var0.fill(0, var3 - var5, var2, var3, -16777216);
         if (!subtitle.isEmpty()) {
            drawSubtitle(var0, var1.font, var2, var3, var5);
         }
      }

      if (flashAge < 9999) {
         float var7;
         if (flashAge <= flashHold) {
            var7 = flashPeak;
         } else {
            float var6 = (float)(flashAge - flashHold) / Math.max(1, flashLen - flashHold);
            var7 = flashPeak * (1.0F - Mth.clamp(var6, 0.0F, 1.0F));
         }

         int var8 = Mth.clamp((int)var7, 0, 255);
         if (var8 >= 6) {
            var0.fill(0, 0, var2, var3, var8 << 24 | 16777215);
         }
      }
   }

   private static void drawSubtitle(GuiGraphics var0, Font var1, int var2, int var3, int var4) {
      int var5 = Mth.clamp(lineAge * 40, 0, 255);
      if (var5 >= 8) {
         float var6 = 1.25F;
         int var7 = (int)(var2 * 0.7F / var6);
         ArrayList var8 = new ArrayList();
         StringBuilder var9 = new StringBuilder();

         for (String var13 : subtitle.split(" ")) {
            String var14 = var9.length() == 0 ? var13 : var9 + " " + var13;
            if (var1.width(var14) > var7 && var9.length() > 0) {
               var8.add(var9.toString());
               var9 = new StringBuilder(var13);
            } else {
               var9 = new StringBuilder(var14);
            }
         }

         if (var9.length() > 0) {
            var8.add(var9.toString());
         }

         float var15 = 11.0F * var6;
         float var16 = var3 - var4 + (var4 - var15 * var8.size()) / 2.0F;

         for (int var17 = 0; var17 < var8.size(); var17++) {
            String var18 = (String)var8.get(var17);
            float var19 = (var2 - var1.width(var18) * var6) / 2.0F;
            var0.pose().pushPose();
            var0.pose().translate(var19, var16 + var15 * var17, 0.0F);
            var0.pose().scale(var6, var6, 1.0F);
            var0.drawString(var1, var18, 0, 0, var5 << 24 | 16777215);
            var0.pose().popPose();
         }
      }
   }

   private TranscendCinematic() {
   }
}
