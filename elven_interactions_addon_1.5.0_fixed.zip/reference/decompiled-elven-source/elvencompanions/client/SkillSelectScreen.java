package com.elvencompanions.client;

import com.elvencompanions.logic.ElfRank;
import com.elvencompanions.net.ElfStatus;
import com.elvencompanions.net.ModNetwork;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.PacketDistributor;

public class SkillSelectScreen extends Screen {
   private final List<ElfStatus> list;
   private int index;

   public SkillSelectScreen(List<ElfStatus> list) {
      super(Component.translatable("gui.elven_companions.skillselect.title"));
      this.list = list;
      if (SkillHud.selected != null) {
         for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id().equals(SkillHud.selected)) {
               this.index = i;
            }
         }
      }
   }

   protected void init() {
      int cx = this.width / 2;
      int y = this.height / 2 + 40;
      this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.previous"), b -> this.step(-1)).bounds(cx - 130, y, 60, 20).build());
      this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.select"), b -> {
         if (!this.list.isEmpty()) {
            PacketDistributor.sendToServer(new ModNetwork.SkillPickC2S(this.list.get(this.index).id()), new CustomPacketPayload[0]);
            this.onClose();
         }
      }).bounds(cx - 65, y, 60, 20).build());
      this.addRenderableWidget(
         Button.builder(Component.translatable("gui.elven_companions.delete.cancel"), b -> this.onClose()).bounds(cx + 5, y, 60, 20).build()
      );
      this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.next"), b -> this.step(1)).bounds(cx + 70, y, 60, 20).build());
   }

   private void step(int d) {
      if (!this.list.isEmpty()) {
         this.index = Math.floorMod(this.index + d, this.list.size());
      }
   }

   public void render(GuiGraphics g, int mx, int my, float pt) {
      super.render(g, mx, my, pt);
      int cx = this.width / 2;
      int top = this.height / 2 - 60;
      g.fill(cx - 140, top - 6, cx + 140, this.height / 2 + 66, -1072689136);
      g.drawCenteredString(this.font, this.title, cx, top, 16777215);
      if (this.list.isEmpty()) {
         g.drawCenteredString(this.font, Component.translatable("gui.elven_companions.roster.empty"), cx, top + 40, 11184810);
      } else {
         ElfStatus s = this.list.get(this.index);
         boolean current = s.id().equals(SkillHud.selected);
         g.drawCenteredString(
            this.font,
            Component.literal(s.name() + "  Lv." + s.level() + (s.transcended() ? " ✦" : "") + "  (" + (this.index + 1) + "/" + this.list.size() + ")"),
            cx,
            top + 20,
            5635925
         );
         g.drawCenteredString(
            this.font, Component.literal("[").append(Component.translatable(ElfRank.key(s.level(), s.transcended()))).append("]"), cx, top + 32, 16765773
         );
         g.drawCenteredString(
            this.font,
            Component.translatable(s.loaded() ? "gui.elven_companions.status.loaded" : "gui.elven_companions.status.unloaded"),
            cx,
            top + 46,
            s.loaded() ? 8978312 : 16755285
         );
         if (current) {
            g.drawCenteredString(this.font, Component.translatable("gui.elven_companions.skillselect.current"), cx, top + 58, 16769162);
         }
      }
   }
}
