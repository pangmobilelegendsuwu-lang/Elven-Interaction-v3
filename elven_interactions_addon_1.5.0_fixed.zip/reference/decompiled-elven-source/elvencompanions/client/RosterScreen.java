package com.elvencompanions.client;

import com.elvencompanions.logic.ElfRank;
import com.elvencompanions.net.ElfStatus;
import com.elvencompanions.net.ModNetwork;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.PacketDistributor;

public class RosterScreen extends Screen {
   private List<ElfStatus> list;
   private int index;
   private Button select;
   private Button delete;

   public RosterScreen(List<ElfStatus> list) {
      super(Component.translatable("gui.elven_companions.roster.title"));
      this.list = list;
   }

   public void setList(List<ElfStatus> l) {
      this.list = l;
      if (this.index >= l.size()) {
         this.index = Math.max(0, l.size() - 1);
      }

      this.refreshButtons();
   }

   protected void init() {
      int cx = this.width / 2;
      int y = this.height / 2 + 62;
      int w = 50;
      this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.previous"), b -> this.step(-1)).bounds(cx - 133, y, w, 20).build());
      this.select = (Button)this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.select"), b -> {
         if (!this.list.isEmpty()) {
            PacketDistributor.sendToServer(new ModNetwork.SelectC2S(this.list.get(this.index).id()), new CustomPacketPayload[0]);
         }
      }).bounds(cx - 79, y, w, 20).build());
      this.delete = (Button)this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.delete").withStyle(ChatFormatting.RED), b -> {
         if (!this.list.isEmpty()) {
            this.minecraft.setScreen(new DeleteConfirmScreen(this, this.list.get(this.index)));
         }
      }).bounds(cx - 25, y, w, 20).build());
      this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.back"), b -> this.onClose()).bounds(cx + 29, y, w, 20).build());
      this.addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.next"), b -> this.step(1)).bounds(cx + 83, y, w, 20).build());
      this.refreshButtons();
   }

   private void step(int d) {
      if (!this.list.isEmpty()) {
         this.index = Math.floorMod(this.index + d, this.list.size());
         this.refreshButtons();
      }
   }

   private void refreshButtons() {
      if (this.select != null) {
         ElfStatus s = this.list.isEmpty() ? null : this.list.get(this.index);
         this.select.active = s != null && s.loaded() && !s.dead() && !s.ultimate();
         this.select
            .setTooltip(
               Tooltip.create(
                  Component.translatable(
                     this.select.active
                        ? "gui.elven_companions.select"
                        : (s != null && s.dead() ? "gui.elven_companions.status.dead" : "gui.elven_companions.status.unloaded")
                  )
               )
            );
         this.delete.active = s != null;
         this.delete.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.delete")));
      }
   }

   public void render(GuiGraphics g, int mx, int my, float pt) {
      super.render(g, mx, my, pt);
      int cx = this.width / 2;
      int top = this.height / 2 - 80;
      g.fill(cx - 140, top - 6, cx + 140, this.height / 2 + 90, -1072689136);
      g.drawCenteredString(this.font, this.title, cx, top, 16777215);
      if (this.list.isEmpty()) {
         g.drawCenteredString(this.font, Component.translatable("gui.elven_companions.roster.empty"), cx, top + 40, 11184810);
      } else {
         ElfStatus s = this.list.get(this.index);
         g.drawCenteredString(
            this.font, Component.literal(s.name() + "  Lv." + s.level() + "  (" + (this.index + 1) + "/" + this.list.size() + ")"), cx, top + 18, 5635925
         );
         g.drawCenteredString(
            this.font, Component.literal("[").append(Component.translatable(ElfRank.key(s.level(), s.transcended()))).append("]"), cx, top + 29, 16765773
         );
         int y = top + 44;
         g.drawString(this.font, Component.translatable("gui.elven_companions.status.skin", new Object[]{s.skin() + 1}), cx - 120, y, 13421772);
         y += 11;
         g.drawString(
            this.font,
            Component.translatable(
               "gui.elven_companions.status.stance",
               new Object[]{
                  Component.translatable("stance.elven_companions." + new String[]{"follow", "sit", "guard", "wander"}[Math.floorMod(s.stance(), 4)])
               }
            ),
            cx - 120,
            y,
            13421772
         );
         y += 11;
         g.drawString(
            this.font,
            Component.translatable(
               "gui.elven_companions.status.combat",
               new Object[]{
                  Component.translatable("combat.elven_companions." + new String[]{"neutral", "passive", "aggressive"}[Math.floorMod(s.combat(), 3)])
               }
            ),
            cx - 120,
            y,
            13421772
         );
         y += 11;
         g.drawString(
            this.font,
            Component.translatable("gui.elven_companions.status.health", new Object[]{Math.round(s.health()), Math.round(s.maxHealth())}),
            cx - 120,
            y,
            16746632
         );
         y += 11;
         Component state = s.dead()
            ? Component.translatable("gui.elven_companions.status.dead")
            : (
               s.ultimate()
                  ? Component.translatable("gui.elven_companions.status.ultimate")
                  : (
                     !s.loaded()
                        ? Component.translatable("gui.elven_companions.status.unloaded")
                        : (
                           s.rest() == 1
                              ? Component.translatable("gui.elven_companions.status.searching")
                              : (
                                 s.rest() >= 2
                                    ? Component.translatable("gui.elven_companions.status.resting")
                                    : Component.translatable("gui.elven_companions.status.loaded")
                              )
                        )
                  )
            );
         g.drawString(this.font, state, cx - 120, y, s.loaded() && !s.dead() ? 8978312 : 16755285);
      }
   }
}
