package com.elvencompanions.client;

import com.elvencompanions.entity.ElfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;

public class TranscendedLayer extends RenderLayer<ElfEntity, ElfModel> {
   private static final Map<Integer, float[]> FLY = new HashMap<>();

   public TranscendedLayer(RenderLayerParent<ElfEntity, ElfModel> var1) {
      super(var1);
   }

   public void render(PoseStack var1, MultiBufferSource var2, int var3, ElfEntity var4, float var5, float var6, float var7, float var8, float var9, float var10) {
      if (var4.isTranscended() && !var4.isInvisible()) {
         float var11 = Mth.lerp(var7, var4.wingAmtO, var4.wingAmt);
         float[] var12 = FLY.computeIfAbsent(var4.getId(), var0 -> new float[]{0.0F});
         var12[0] += ((var4.isNoGravity() && !var4.onGround() ? 1.0F : 0.0F) - var12[0]) * 0.06F;
         var11 = Math.max(var11, var12[0]);
         float var13 = Mth.lerp(var7, var4.rageAmtO, var4.rageAmt);
         ((ElfModel)this.getParentModel()).renderCelestial(var1, var2, var3, var8, var11, var13, var4.isRaging());
      }
   }
}
