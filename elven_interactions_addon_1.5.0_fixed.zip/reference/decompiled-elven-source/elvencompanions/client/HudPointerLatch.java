package com.elvencompanions.client;

import net.minecraft.client.Minecraft;

public final class HudPointerLatch {
   static final int DOUBLE_TAP_TICKS = 10;
   static final long DEBOUNCE_NANOS = 250000000L;
   private static boolean latched;
   private static long tick;
   private static long lastPressTick = -4611686018427387904L;
   private static int lastButton = -1;
   private static long lastButtonNanos;

   private HudPointerLatch() {
   }

   public static boolean wanted(boolean var0) {
      Minecraft var1 = Minecraft.getInstance();
      boolean var2 = SkillHud.active() && var1.screen == null;
      int var3 = 0;

      while (var3 < 8 && ClientSetup.SKILL_POINTER.consumeClick()) {
         var3++;
      }

      return step(var0, var3, var2);
   }

   static boolean step(boolean var0, int var1, boolean var2) {
      tick++;
      if (!var2) {
         latched = false;
         lastPressTick = -4611686018427387904L;
         return var0;
      } else {
         for (int var3 = 0; var3 < var1; var3++) {
            if (latched) {
               latched = false;
               lastPressTick = -4611686018427387904L;
            } else if (tick - lastPressTick <= 10L) {
               latched = true;
               lastPressTick = -4611686018427387904L;
            } else {
               lastPressTick = tick;
            }
         }

         return var0 || latched;
      }
   }

   public static boolean debounce(int var0) {
      return debounce(var0, System.nanoTime());
   }

   static boolean debounce(int var0, long var1) {
      if (var0 == lastButton && var1 - lastButtonNanos < 250000000L) {
         return false;
      } else {
         lastButton = var0;
         lastButtonNanos = var1;
         return true;
      }
   }

   static void reset() {
      latched = false;
      tick = 0L;
      lastPressTick = -4611686018427387904L;
      lastButton = -1;
      lastButtonNanos = 0L;
   }
}
