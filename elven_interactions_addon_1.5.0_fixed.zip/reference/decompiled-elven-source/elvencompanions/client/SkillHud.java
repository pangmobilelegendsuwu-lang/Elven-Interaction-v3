package com.elvencompanions.client;

import com.elvencompanions.logic.HudLayout;
import com.elvencompanions.net.ElfStatus;
import com.elvencompanions.net.ModNetwork;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.network.PacketDistributor;

public final class SkillHud {
   private static final SkillHud.Btn[] BUTTONS = new SkillHud.Btn[]{
      new SkillHud.Btn(0, "piercer"),
      new SkillHud.Btn(1, "skyfall"),
      new SkillHud.Btn(2, "volley"),
      new SkillHud.Btn(3, "wildfire"),
      new SkillHud.Btn(4, "moonfall"),
      new SkillHud.Btn(5, "thorn"),
      new SkillHud.Btn(6, "ascendance"),
      new SkillHud.Btn(7, "hunt"),
      new SkillHud.Btn(10, "annihilation"),
      new SkillHud.Btn(8, "guardian"),
      new SkillHud.Btn(9, "seed"),
      new SkillHud.Btn(11, "raging"),
      new SkillHud.Btn(12, "stealth"),
      new SkillHud.Btn(13, "chrono"),
      new SkillHud.Btn(14, "ricochet"),
      new SkillHud.Btn(15, "worldtree"),
      new SkillHud.Btn(18, "mirrorleaf"),
      new SkillHud.Btn(19, "falcon"),
      new SkillHud.Btn(20, "sunder"),
      new SkillHud.Btn(22, "stagger")
   };
   static UUID selected;
   static boolean visible;
   static boolean bypass;
   static boolean pointerMode;
   static boolean dragging;
   static ElfStatus status;
   private static int hudX = Integer.MIN_VALUE;
   private static int hudY = Integer.MIN_VALUE;
   private static double dragDX;
   private static double dragDY;
   private static final long[] flashUntil = new long[BUTTONS.length];
   private static long clientTick;

   public static boolean active() {
      return visible && selected != null;
   }

   public static void setState(UUID var0, boolean var1, boolean var2) {
      if (var0 == null || !var0.equals(selected)) {
         status = null;
      }

      selected = var0;
      visible = var1;
      bypass = var2;
      if (!active()) {
         pointerMode = false;
         dragging = false;
      }
   }

   public static void setStatus(ElfStatus var0) {
      if (selected != null && var0.id().equals(selected)) {
         status = var0;
      }
   }

   private static Path file() {
      return FMLPaths.CONFIGDIR.get().resolve("elven_companions_hud.properties");
   }

   private static void loadPos() {
      try (BufferedReader var0 = Files.newBufferedReader(file())) {
         Properties var1 = new Properties();
         var1.load(var0);
         hudX = Integer.parseInt(var1.getProperty("x", "-2147483648"));
         hudY = Integer.parseInt(var1.getProperty("y", "-2147483648"));
      } catch (IOException | RuntimeException var5) {
      }
   }

   private static void savePos() {
      try (BufferedWriter var0 = Files.newBufferedWriter(file())) {
         Properties var1 = new Properties();
         var1.setProperty("x", Integer.toString(hudX));
         var1.setProperty("y", Integer.toString(hudY));
         var1.store(var0, "Elven Companions skill HUD position");
      } catch (IOException var5) {
      }
   }

   private static void ensurePos(int var0, int var1) {
      if (hudX == Integer.MIN_VALUE) {
         loadPos();
      }

      if (hudX == Integer.MIN_VALUE || hudY == Integer.MIN_VALUE) {
         hudX = HudLayout.defaultX(var0);
         hudY = HudLayout.defaultY(var1, BUTTONS.length);
      }

      hudX = HudLayout.clampX(hudX, var0);
      hudY = HudLayout.clampY(hudY, var1, BUTTONS.length);
   }

   private static boolean creative() {
      Minecraft var0 = Minecraft.getInstance();
      return var0.player != null && var0.player.isCreative();
   }

   private static boolean locked(int var0) {
      ElfStatus var1 = status;
      if (var1 == null) {
         return false;
      } else if (var0 != 10 && var0 != 11 && var0 != 15) {
         return var0 == 7 ? var1.level() < 20 : false;
      } else {
         return !var1.transcended();
      }
   }

   private static int cooldown(int var0) {
      ElfStatus var1 = status;
      return var1 != null && var0 < var1.cooldownSecs().length ? var1.cooldownSecs()[var0] : 0;
   }

   private static double guiX(Minecraft var0) {
      return var0.mouseHandler.xpos() * var0.getWindow().getGuiScaledWidth() / var0.getWindow().getScreenWidth();
   }

   private static double guiY(Minecraft var0) {
      return var0.mouseHandler.ypos() * var0.getWindow().getGuiScaledHeight() / var0.getWindow().getScreenHeight();
   }

   public static void render(GuiGraphics var0) {
      Minecraft var1 = Minecraft.getInstance();
      if (active() && var1.screen == null && !var1.options.hideGui) {
         clientTick++;
         Font var2 = var1.font;
         int var3 = var0.guiWidth();
         int var4 = var0.guiHeight();
         ensurePos(var3, var4);
         if (dragging) {
            hudX = HudLayout.clampX((int)(guiX(var1) - dragDX), var3);
            hudY = HudLayout.clampY((int)(guiY(var1) - dragDY), var4, BUTTONS.length);
         }

         int var5 = hudX;
         int var6 = hudY;
         byte var7 = 124;
         int var8 = HudLayout.height(BUTTONS.length);
         var0.fill(var5 - 1, var6 - 1, var5 + var7 + 1, var6 + var8 + 1, -1442840576);
         var0.fill(var5, var6, var5 + var7, var6 + var8, -1072424424);
         var0.fill(var5, var6, var5 + var7, var6 + 13, pointerMode ? -532647856 : -802664392);
         String var9 = status != null ? status.name() : "...";
         if (var9.length() > 14) {
            var9 = var9.substring(0, 13) + "…";
         }

         var0.drawString(var2, var9 + (status != null ? "  Lv." + status.level() + (status.transcended() ? "✦" : "") : ""), var5 + 3, var6 + 3, 16777215, true);
         int var10 = (var7 - 6) / 2;

         for (int var11 = 0; var11 < BUTTONS.length; var11++) {
            SkillHud.Btn var12 = BUTTONS[var11];
            int var13 = var5 + 3 + var11 % 2 * var10;
            int var14 = var6 + 13 + 3 + var11 / 2 * 15;
            boolean var15 = locked(var12.action());
            boolean var16 = flashUntil[var11] > clientTick;
            int var17 = cooldown(var12.action());
            int var18 = var16 ? -7544672 : (var15 ? -12966876 : (var17 > 0 ? -14012360 : (var12.action() >= 6 ? -11908576 : -13870534)));
            var0.fill(var13, var14, var13 + var10 - 1, var14 + 15 - 1, var18);
            MutableComponent var19 = Component.translatable("gui.elven_companions.hud." + var12.key());
            var0.drawString(var2, var19, var13 + 2, var14 + 3, var15 ? 8939110 : (var17 > 0 ? 11184810 : 16777215), false);
            if (var15) {
               int var20 = var13 + var10 - 9;
               int var21 = var14 + 4;
               var0.fill(var20, var21 + 3, var20 + 6, var21 + 8, -2276284);
               var0.fill(var20 + 1, var21, var20 + 2, var21 + 3, -2276284);
               var0.fill(var20 + 4, var21, var20 + 5, var21 + 3, -2276284);
               var0.fill(var20 + 1, var21, var20 + 5, var21 + 1, -2276284);
            } else if (var17 > 0) {
               String var23 = var17 + "s";
               var0.drawString(var2, var23, var13 + var10 - 3 - var2.width(var23), var14 + 3, 16768341, false);
            }
         }

         int var22 = var6 + 13 + 3 + HudLayout.rows(BUTTONS.length) * 15 + 2;
         var0.fill(var5 + 3, var22, var5 + var7 / 2 - 1, var22 + 17 - 3, -13614998);
         var0.drawString(var2, Component.translatable("gui.elven_companions.hud.switch"), var5 + 3 + 3, var22 + 3, 16777215, false);
         if (creative()) {
            var0.fill(var5 + var7 / 2, var22, var5 + var7 - 3, var22 + 17 - 3, bypass ? -8758760 : -12961222);
            var0.drawString(
               var2,
               Component.translatable(bypass ? "gui.elven_companions.hud.cd_on" : "gui.elven_companions.hud.cd_off"),
               var5 + var7 / 2 + 3,
               var22 + 3,
               bypass ? 16769162 : 12303291,
               false
            );
         }

         if (!pointerMode) {
            var0.drawString(var2, Component.translatable("gui.elven_companions.hud.hint"), var5, var6 + var8 + 3, -2002081110, false);
         }
      }
   }

   public static boolean onMouse(int var0, int var1) {
      Minecraft var2 = Minecraft.getInstance();
      if (!active() || !pointerMode || var2.screen != null) {
         return false;
      } else if (var0 != 0) {
         return true;
      } else {
         double var3 = guiX(var2);
         double var5 = guiY(var2);
         int var7 = hudX;
         int var8 = hudY;
         if (var1 == 0) {
            if (dragging) {
               dragging = false;
               savePos();
            }

            return true;
         } else if (HudLayout.inHeader(var3, var5, var7, var8)) {
            dragging = true;
            dragDX = var3 - var7;
            dragDY = var5 - var8;
            return true;
         } else {
            int var9 = HudLayout.buttonAt(var3, var5, var7, var8, BUTTONS.length);
            if (var9 >= 0) {
               if (selected != null && HudPointerLatch.debounce(var9)) {
                  PacketDistributor.sendToServer(new ModNetwork.SkillActionC2S(selected, BUTTONS[var9].action()), new CustomPacketPayload[0]);
                  flashUntil[var9] = clientTick + 8L;
               }

               return true;
            } else {
               int var10 = HudLayout.footerAt(var3, var5, var7, var8, BUTTONS.length);
               if (var10 == 0) {
                  PacketDistributor.sendToServer(new ModNetwork.SkillSwitchC2S(), new CustomPacketPayload[0]);
               } else if (var10 == 1 && creative()) {
                  PacketDistributor.sendToServer(new ModNetwork.SkillBypassC2S(!bypass), new CustomPacketPayload[0]);
               }

               return true;
            }
         }
      }
   }

   public static void tick(boolean var0) {
      var0 = HudPointerLatch.wanted(var0);
      Minecraft var1 = Minecraft.getInstance();
      boolean var2 = active() && var1.screen == null && var0;
      if (var2 && !pointerMode) {
         var1.mouseHandler.releaseMouse();
         pointerMode = true;
      } else if (!var2 && pointerMode) {
         pointerMode = false;
         dragging = false;
         if (var1.screen == null) {
            var1.mouseHandler.grabMouse();
         }
      }

      if (active() && var1.player != null && var1.player.tickCount % 20 == 0 && selected != null) {
         PacketDistributor.sendToServer(new ModNetwork.StatusRequestC2S(selected), new CustomPacketPayload[0]);
      }
   }

   private SkillHud() {
   }

   private record Btn(int action, String key) {
   }
}
