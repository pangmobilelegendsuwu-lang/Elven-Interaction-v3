package com.elvencompanions.client;

import com.elvencompanions.net.ElfStatus;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.Minecraft;

public final class ClientHooks {
   public static void roster(List<ElfStatus> list) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.screen instanceof RosterScreen rs) {
         rs.setList(list);
      } else {
         mc.setScreen(new RosterScreen(list));
      }
   }

   public static void status(ElfStatus s, boolean open) {
      Minecraft mc = Minecraft.getInstance();
      SkillHud.setStatus(s);
      if (open) {
         mc.setScreen(new CommandScreen(s));
      } else if (mc.screen instanceof CommandScreen cs && cs.elfId().equals(s.id())) {
         cs.updateStatus(s);
      }
   }

   public static void impact() {
      ClientEvents.triggerImpact();
   }

   public static void skillSelect(List<ElfStatus> list) {
      Minecraft.getInstance().setScreen(new SkillSelectScreen(list));
   }

   public static void skillState(UUID selected, boolean visible, boolean bypass) {
      SkillHud.setState(selected, visible, bypass);
   }

   public static void cinematic(int type, int ticks) {
      ClientEvents.startCinematic(type, ticks);
   }

   public static void silence(int ticks) {
      ClientEvents.startSilence(ticks);
   }

   public static void celestialArrow(double x, double y, double z, int ticks, double startY) {
      CelestialArrowRenderer.spawn(x, y, z, ticks, startY);
   }

   private ClientHooks() {
   }
}
