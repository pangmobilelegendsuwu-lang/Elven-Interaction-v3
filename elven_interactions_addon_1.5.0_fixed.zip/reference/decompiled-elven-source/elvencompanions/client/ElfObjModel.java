package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

public final class ElfObjModel {
   public static final ResourceLocation LOCATION = ElvenCompanions.rl("models/entity/elf.obj");
   private static ElfObjModel instance;
   public final List<ElfObjModel.Part> parts;

   private ElfObjModel(List<ElfObjModel.Part> parts) {
      this.parts = parts;
   }

   public static ElfObjModel get() {
      if (instance == null) {
         instance = load();
      }

      return instance;
   }

   public static void invalidate() {
      instance = null;
   }

   static ElfObjModel.Bone boneFor(String raw) {
      String n = raw.toLowerCase(Locale.ROOT);
      if (n.equals("head") || n.equals("hat")) {
         return ElfObjModel.Bone.HEAD;
      } else if (n.contains("left arm")) {
         return ElfObjModel.Bone.L_ARM;
      } else if (n.contains("right arm")) {
         return ElfObjModel.Bone.R_ARM;
      } else if (n.contains("left leg") || n.equals("leggings_left")) {
         return ElfObjModel.Bone.L_LEG;
      } else {
         return !n.contains("right leg") && !n.equals("leggings_right") ? ElfObjModel.Bone.BODY : ElfObjModel.Bone.R_LEG;
      }
   }

   private static ElfObjModel load() {
      List<float[]> v = new ArrayList<>();
      List<float[]> vt = new ArrayList<>();
      List<float[]> vn = new ArrayList<>();
      List<ElfObjModel.Obj> objs = new ArrayList<>();
      ElfObjModel.Obj cur = null;

      String line;
      try (BufferedReader r = Minecraft.getInstance().getResourceManager().openAsReader(LOCATION)) {
         while ((line = r.readLine()) != null) {
            line = line.trim();
            if (!line.isEmpty() && !line.startsWith("#")) {
               String[] p = line.split("\\s+");
               String o = p[0];
               switch (o) {
                  case "v":
                     v.add(new float[]{f(p[1]), f(p[2]), f(p[3])});
                     break;
                  case "vt":
                     vt.add(new float[]{f(p[1]), f(p[2])});
                     break;
                  case "vn":
                     vn.add(new float[]{f(p[1]), f(p[2]), f(p[3])});
                     break;
                  case "o":
                  case "g":
                     cur = new ElfObjModel.Obj();
                     cur.name = line.substring(2).trim();
                     objs.add(cur);
                     break;
                  case "usemtl":
                     if (cur != null) {
                        cur.material = line.substring(7).trim();
                     }
                     break;
                  case "f":
                     if (cur == null) {
                        cur = new ElfObjModel.Obj();
                        cur.name = "default";
                        objs.add(cur);
                     }

                     int[][] face = new int[p.length - 1][3];

                     for (int i = 1; i < p.length; i++) {
                        String[] s = p[i].split("/", -1);
                        face[i - 1][0] = idx(s[0], v.size());
                        face[i - 1][1] = s.length > 1 && !s[1].isEmpty() ? idx(s[1], vt.size()) : -1;
                        face[i - 1][2] = s.length > 2 && !s[2].isEmpty() ? idx(s[2], vn.size()) : -1;
                     }

                     cur.faces.add(face);
               }
            }
         }
      } catch (RuntimeException | IOException var24) {
         ElvenCompanions.LOGGER.error("Could not load elf OBJ model {}", LOCATION, var24);
         return new ElfObjModel(List.of());
      }

      String skinMat = null;

      for (ElfObjModel.Obj o : objs) {
         if (o.name.equalsIgnoreCase("head")) {
            skinMat = o.material;
         }
      }

      List<ElfObjModel.Part> parts = new ArrayList<>();

      for (ElfObjModel.Obj ox : objs) {
         List<Float> out = new ArrayList<>();

         for (int[][] face : ox.faces) {
            for (int start = 1; start + 1 < face.length || start == 1; start += 2) {
               int[][] q = face.length == 3
                  ? new int[][]{face[0], face[1], face[2], face[2]}
                  : (
                     face.length == 4
                        ? face
                        : new int[][]{face[0], face[start], face[Math.min(start + 1, face.length - 1)], face[Math.min(start + 1, face.length - 1)]}
                  );
               float[] n0 = faceNormal(v, q);

               for (int[] c : q) {
                  float[] pos = v.get(c[0]);
                  float[] uv = c[1] >= 0 ? vt.get(c[1]) : new float[]{0.0F, 0.0F};
                  float[] nrm = c[2] >= 0 ? vn.get(c[2]) : n0;
                  out.add(pos[0]);
                  out.add(pos[1]);
                  out.add(pos[2]);
                  out.add(uv[0]);
                  out.add(1.0F - uv[1]);
                  out.add(nrm[0]);
                  out.add(nrm[1]);
                  out.add(nrm[2]);
               }

               if (face.length <= 4) {
                  break;
               }
            }
         }

         float[] data = new float[out.size()];

         for (int i = 0; i < data.length; i++) {
            data[i] = out.get(i);
         }

         boolean equipment = skinMat != null && !ox.material.equals(skinMat);
         parts.add(new ElfObjModel.Part(ox.name, boneFor(ox.name), equipment, data));
      }

      ElvenCompanions.LOGGER.info("Loaded elf OBJ: {} parts", parts.size());
      return new ElfObjModel(parts);
   }

   private static float f(String s) {
      return Float.parseFloat(s);
   }

   private static int idx(String s, int size) {
      int i = Integer.parseInt(s);
      return i > 0 ? i - 1 : size + i;
   }

   private static float[] faceNormal(List<float[]> v, int[][] q) {
      float[] a = v.get(q[0][0]);
      float[] b = v.get(q[1][0]);
      float[] c = v.get(q[2][0]);
      float ux = b[0] - a[0];
      float uy = b[1] - a[1];
      float uz = b[2] - a[2];
      float wx = c[0] - a[0];
      float wy = c[1] - a[1];
      float wz = c[2] - a[2];
      float nx = uy * wz - uz * wy;
      float ny = uz * wx - ux * wz;
      float nz = ux * wy - uy * wx;
      float len = (float)Math.sqrt(nx * nx + ny * ny + nz * nz);
      return len < 1.0E-6F ? new float[]{0.0F, 1.0F, 0.0F} : new float[]{nx / len, ny / len, nz / len};
   }

   public static enum Bone {
      HEAD,
      BODY,
      L_ARM,
      R_ARM,
      L_LEG,
      R_LEG;
   }

   private static final class Obj {
      String name;
      String material = "";
      final List<int[][]> faces = new ArrayList<>();
   }

   public static final class Part {
      public final String name;
      public final ElfObjModel.Bone bone;
      public final boolean equipment;
      final float[] data;

      Part(String name, ElfObjModel.Bone bone, boolean equipment, float[] data) {
         this.name = name;
         this.bone = bone;
         this.equipment = equipment;
         this.data = data;
      }

      public void render(Pose pose, VertexConsumer vc, int light, int overlay, int color) {
         for (int i = 0; i < this.data.length; i += 8) {
            vc.addVertex(pose.pose(), this.data[i], this.data[i + 1], this.data[i + 2])
               .setColor(color)
               .setUv(this.data[i + 3], this.data[i + 4])
               .setOverlay(overlay)
               .setLight(light)
               .setNormal(pose, this.data[i + 5], this.data[i + 6], this.data[i + 7]);
         }
      }
   }
}
