package com.elvencompanions.client;

import com.elvencompanions.client.fx.FxManager;
import com.elvencompanions.entity.ElfEntity;
import java.util.List;
import net.minecraft.client.Minecraft;

public final class Aura {
   public static final int OFF = 0;
   public static final int ALWAYS = 1;
   public static final int DEFAULT = 2;

   public static void tick(Minecraft var0) {
      int var1 = ClientPrefs.auraMode();
      if (var1 != 0 && var0.level != null && var0.player != null && Vfx.enabled()) {
         List var2 = var0.level
            .getEntitiesOfClass(ElfEntity.class, var0.player.getBoundingBox().inflate(32.0), var0x -> var0x.isAlive() && !var0x.isInvisible());
         var2.sort((var1x, var2x) -> Double.compare(var1x.distanceToSqr(var0.player), var2x.distanceToSqr(var0.player)));
         int var3 = 0;

         for (ElfEntity var5 : var2) {
            if (var3 >= 3) {
               break;
            }

            boolean var6 = var5.isAggressive() || var5.isRaging();
            if (var1 == 1 || var6) {
               var3++;
               int var7 = var5.isRaging() ? 1 : (var5.isTranscended() ? 2 : 0);
               FxManager.touchAura(var5.getId(), var7, var5.getX(), var5.getY(), var5.getZ());
               accents(var5, var7);
            }
         }
      }
   }

   private static void accents(ElfEntity var0, int var1) {
      if (ElfGlowParticle.GLOW != null) {
         double var2 = var0.getX();
         double var4 = var0.getY();
         double var6 = var0.getZ();
         if (var1 == 0) {
            if (Vfx.ok(0.12F)) {
               Vfx.leaf(
                  var2 + (Vfx.R.nextDouble() - 0.5) * 2.0,
                  var4 + 0.8 + Vfx.R.nextDouble() * 1.6,
                  var6 + (Vfx.R.nextDouble() - 0.5) * 2.0,
                  0.0,
                  0.02,
                  0.0,
                  12124002,
                  0.26F,
                  28
               );
            }
         } else if (var1 == 1) {
            if (Vfx.ok(0.35F)) {
               Vfx.spark(
                  var2 + (Vfx.R.nextDouble() - 0.5) * 1.6, var4 + 0.2, var6 + (Vfx.R.nextDouble() - 0.5) * 1.6, 0.0, 0.08, 0.0, 16734736, 0.14F, 16, -0.002F
               );
            }
         } else if (Vfx.ok(0.15F)) {
            double var8 = Vfx.R.nextDouble() * Math.PI * 2.0;
            double var10 = 0.8 + Vfx.R.nextDouble() * 1.5;
            Vfx.star(var2 + Math.cos(var8) * var10, var4 + 0.3 + Vfx.R.nextDouble() * 2.6, var6 + Math.sin(var8) * var10, 0.0, 0.02, 0.0, 16777215, 0.4F, 10);
         }
      }
   }

   private Aura() {
   }
}
