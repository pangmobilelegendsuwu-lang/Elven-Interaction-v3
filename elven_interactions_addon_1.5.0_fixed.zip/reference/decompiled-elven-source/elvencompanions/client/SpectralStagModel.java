package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

public class SpectralStagModel {
   public static final ModelLayerLocation LAYER = new ModelLayerLocation(ElvenCompanions.rl("spectral_stag"), "main");
   public final ModelPart root;
   public final ModelPart body;
   public final ModelPart neck;
   public final ModelPart legFL;
   public final ModelPart legFR;
   public final ModelPart legBL;
   public final ModelPart legBR;
   public final ModelPart tail;

   public SpectralStagModel(ModelPart root) {
      this.root = root;
      this.body = root.getChild("body");
      this.neck = root.getChild("neck");
      this.legFL = root.getChild("leg_fl");
      this.legFR = root.getChild("leg_fr");
      this.legBL = root.getChild("leg_bl");
      this.legBR = root.getChild("leg_br");
      this.tail = root.getChild("tail");
   }

   public static LayerDefinition create() {
      MeshDefinition mesh = new MeshDefinition();
      PartDefinition r = mesh.getRoot();
      r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, 6.0F, -14.0F, 10.0F, 12.0F, 28.0F), PartPose.ZERO);
      PartDefinition neck = r.addOrReplaceChild(
         "neck",
         CubeListBuilder.create().texOffs(0, 40).addBox(-2.5F, -18.0F, -2.5F, 5.0F, 18.0F, 5.0F),
         PartPose.offsetAndRotation(0.0F, 9.0F, -12.0F, 0.7F, 0.0F, 0.0F)
      );
      PartDefinition head = neck.addOrReplaceChild(
         "head",
         CubeListBuilder.create()
            .texOffs(40, 40)
            .addBox(-3.5F, -4.0F, -10.0F, 7.0F, 7.0F, 11.0F)
            .texOffs(60, 0)
            .addBox(-4.5F, -5.0F, -1.0F, 2.0F, 3.0F, 1.0F)
            .texOffs(60, 4)
            .addBox(2.5F, -5.0F, -1.0F, 2.0F, 3.0F, 1.0F),
         PartPose.offsetAndRotation(0.0F, -18.0F, 0.0F, -0.35F, 0.0F, 0.0F)
      );

      for (int side = -1; side <= 1; side += 2) {
         String n = side < 0 ? "l" : "r";
         PartDefinition beam = head.addOrReplaceChild(
            "beam_" + n,
            CubeListBuilder.create().texOffs(80, 0).addBox(-0.5F, -13.0F, -0.5F, 1.0F, 13.0F, 1.0F),
            PartPose.offsetAndRotation(side * 2.5F, -3.5F, -1.0F, -0.35F, 0.0F, side * 0.45F)
         );
         beam.addOrReplaceChild(
            "tine1_" + n,
            CubeListBuilder.create().texOffs(84, 0).addBox(-0.5F, -7.0F, -0.5F, 1.0F, 7.0F, 1.0F),
            PartPose.offsetAndRotation(0.0F, -4.0F, 0.0F, -0.6F, 0.0F, side * 0.6F)
         );
         beam.addOrReplaceChild(
            "tine2_" + n,
            CubeListBuilder.create().texOffs(88, 0).addBox(-0.5F, -7.0F, -0.5F, 1.0F, 7.0F, 1.0F),
            PartPose.offsetAndRotation(0.0F, -7.5F, 0.0F, 0.5F, 0.0F, side * 0.5F)
         );
         beam.addOrReplaceChild(
            "tine3_" + n,
            CubeListBuilder.create().texOffs(92, 0).addBox(-0.5F, -6.0F, -0.5F, 1.0F, 6.0F, 1.0F),
            PartPose.offsetAndRotation(0.0F, -11.0F, 0.0F, -0.3F, 0.0F, side * 0.9F)
         );
      }

      CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 20).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 14.0F, 4.0F);
      r.addOrReplaceChild("leg_fl", leg, PartPose.offset(-3.5F, 18.0F, -10.0F));
      r.addOrReplaceChild("leg_fr", leg, PartPose.offset(3.5F, 18.0F, -10.0F));
      r.addOrReplaceChild("leg_bl", leg, PartPose.offset(-3.5F, 18.0F, 10.0F));
      r.addOrReplaceChild("leg_br", leg, PartPose.offset(3.5F, 18.0F, 10.0F));
      r.addOrReplaceChild(
         "tail",
         CubeListBuilder.create().texOffs(20, 20).addBox(-1.5F, 0.0F, 0.0F, 3.0F, 6.0F, 3.0F),
         PartPose.offsetAndRotation(0.0F, 7.0F, 14.0F, 0.7F, 0.0F, 0.0F)
      );
      return LayerDefinition.create(mesh, 128, 64);
   }

   public void animate(float ticks) {
      float t = ticks * 0.9F;
      float a = Mth.cos(t) * 0.95F;
      this.legFL.xRot = a;
      this.legBR.xRot = a;
      this.legFR.xRot = -a;
      this.legBL.xRot = -a;
      this.neck.xRot = 0.7F + Mth.sin(t) * 0.07F;
      this.tail.xRot = 0.7F + Mth.sin(t * 1.3F) * 0.2F;
      this.body.y = Mth.sin(t * 2.0F) * 0.8F;
   }
}
