package com.elvencompanions.client;

import com.elvencompanions.client.fx.FxManager;
import com.elvencompanions.net.VfxS2C;

public final class ClientHooksVfx {
   public static void play(VfxS2C var0) {
      Vfx.add(var0.kind(), var0.entity(), var0.x(), var0.y(), var0.z(), var0.x2(), var0.y2(), var0.z2(), var0.ticks(), var0.scale());
      if (Vfx.enabled()) {
         FxManager.addSkill(var0.kind(), var0.entity(), var0.x(), var0.y(), var0.z(), var0.x2(), var0.y2(), var0.z2(), var0.ticks(), var0.scale());
      }
   }

   private ClientHooksVfx() {
   }
}
