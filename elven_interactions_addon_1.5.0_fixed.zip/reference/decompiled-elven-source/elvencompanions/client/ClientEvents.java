package com.elvencompanions.client;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.net.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;
import net.neoforged.neoforge.client.event.InputEvent.MouseButton.Pre;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent.Stage;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeCameraAngles;
import net.neoforged.neoforge.client.event.ViewportEvent.ComputeFov;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(
   modid = "elven_companions",
   value = {Dist.CLIENT}
)
public final class ClientEvents {
   private static int flash;
   private static int jolt;
   private static int cinType = -1;
   private static int cinTicks;
   private static int cinTotal;
   private static int silenceTicks;

   public static void triggerImpact() {
      flash = 10;
      jolt = 12;
   }

   public static void startCinematic(int var0, int var1) {
      ElfEarly.onCinematic(var0);
      cinType = var0;
      cinTotal = Math.max(1, var1);
      cinTicks = cinTotal;
      if (var0 == 2) {
         flash = 16;
         jolt = 20;
      }

      if (var0 == 0) {
         TranscendCinematic.start(cinTotal);
      }
   }

   public static void startSilence(int var0) {
      Minecraft var1 = Minecraft.getInstance();
      silenceTicks = Math.max(0, var0);
      if (var0 > 0) {
         var1.getSoundManager().stop();
         var1.getMusicManager().stopPlaying();
      }
   }

   @SubscribeEvent
   public static void tick(Post var0) {
      Minecraft var1 = Minecraft.getInstance();
      if (flash > 0) {
         flash--;
      }

      if (jolt > 0) {
         jolt--;
      }

      if (cinTicks > 0) {
         cinTicks--;
      }

      if (silenceTicks > 0) {
         silenceTicks--;
      }

      TranscendCinematic.tick(var1);
      TranscendMusic.tick(var1);
      CelestialArrowRenderer.clientTick();
      Vfx.tick(var1);
      Aura.tick(var1);
      SkillHud.tick(ClientSetup.SKILL_POINTER.isDown());

      while (ClientSetup.UNMOUNT_KEY.consumeClick()) {
         if (var1.player != null
            && var1.level != null
            && !var1.level
               .getEntitiesOfClass(
                  ElfEntity.class, var1.player.getBoundingBox().inflate(4.0), var1x -> var1x.isCarried() && var1.player.getUUID().equals(var1x.getOwnerUUID())
               )
               .isEmpty()) {
            PacketDistributor.sendToServer(new ModNetwork.UnmountC2S(), new CustomPacketPayload[0]);
         }
      }
   }

   @SubscribeEvent
   public static void overlay(net.neoforged.neoforge.client.event.RenderGuiEvent.Post var0) {
      if (flash > 0) {
         int var1 = (int)(210.0F * (flash / 12.0F));
         var0.getGuiGraphics().fill(0, 0, var0.getGuiGraphics().guiWidth(), var0.getGuiGraphics().guiHeight(), Mth.clamp(var1, 0, 255) << 24 | 15269864);
      }

      TranscendCinematic.render(var0.getGuiGraphics());
      SkillHud.render(var0.getGuiGraphics());
   }

   private static float cinIntensity() {
      if (cinTicks <= 0) {
         return 0.0F;
      } else {
         float var0 = 1.0F - (float)cinTicks / cinTotal;

         return switch (cinType) {
            case 0 -> 0.3F + 1.4F * var0;
            case 1 -> 0.25F + 0.9F * var0;
            case 2 -> 5.0F * (1.0F - var0);
            case 3 -> 1.8F * (1.0F - var0);
            default -> 0.0F;
         };
      }
   }

   @SubscribeEvent
   public static void camera(ComputeCameraAngles var0) {
      float var1 = jolt > 0 ? jolt / 12.0F : 0.0F;
      float var2 = cinIntensity() + TranscendCinematic.extraShake();
      if (!(var1 <= 0.0F) || !(var2 <= 0.0F)) {
         float var3 = Minecraft.getInstance().player == null ? 0.0F : Minecraft.getInstance().player.tickCount;
         var0.setPitch(var0.getPitch() + Mth.sin(jolt * 2.3F) * 2.5F * var1 + Mth.sin(var3 * 1.7F) * var2 * 0.8F);
         var0.setYaw(var0.getYaw() + Mth.cos(var3 * 2.1F) * var2 * 0.6F);
         var0.setRoll(var0.getRoll() + Mth.cos(jolt * 1.9F) * 1.5F * var1 + Mth.sin(var3 * 1.3F) * var2 * 0.5F);
      }
   }

   @SubscribeEvent
   public static void fov(ComputeFov var0) {
      if (cinTicks > 0) {
         float var1 = 1.0F - (float)cinTicks / cinTotal;

         float var2 = switch (cinType) {
            case 0 -> 10.0F * Mth.sin(var1 * (float) Math.PI);
            default -> 0.0F;
            case 2 -> 25.0F * (1.0F - var1);
            case 3 -> 8.0F * (1.0F - var1);
         };
         if (var2 != 0.0F) {
            var0.setFOV(var0.getFOV() + var2);
         }
      }
   }

   @SubscribeEvent
   public static void sound(PlaySoundEvent var0) {
      if (silenceTicks > 0) {
         var0.setSound(null);
      } else if (var0.getSound() != null && "elven_companions:transcend_music".equals(var0.getSound().getLocation().toString())) {
         var0.setSound(null);
      }
   }

   @SubscribeEvent
   public static void worldRender(RenderLevelStageEvent var0) {
      if (var0.getStage() == Stage.AFTER_PARTICLES && CelestialArrowRenderer.any()) {
         CelestialArrowRenderer.render(var0.getPoseStack(), var0.getCamera(), var0.getPartialTick().getGameTimeDeltaPartialTick(false));
      }
   }

   @SubscribeEvent
   public static void mouse(Pre var0) {
      if (SkillHud.onMouse(var0.getButton(), var0.getAction())) {
         var0.setCanceled(true);
      }
   }

   private ClientEvents() {
   }
}
