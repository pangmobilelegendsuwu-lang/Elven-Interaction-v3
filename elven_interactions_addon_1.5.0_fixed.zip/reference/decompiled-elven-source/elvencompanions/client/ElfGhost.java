package com.elvencompanions.client;

import com.elvencompanions.client.fx.FxManager;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

public final class ElfGhost {
   private static float cur = -1.0F;

   public static RenderType type(RenderType var0, LivingEntity var1, ResourceLocation var2) {
      float var3;
      try {
         var3 = FxManager.ghostAlpha(var1.getId());
      } catch (Throwable var5) {
         var3 = -1.0F;
      }

      cur = var3;
      return var3 < 0.0F ? var0 : RenderType.entityTranslucent(var2);
   }

   public static int tint(int var0) {
      if (cur < 0.0F) {
         return var0;
      } else {
         int var1 = Math.max(0, Math.min(255, (int)(cur * 255.0F)));
         return var1 << 24 | 12124108;
      }
   }

   private ElfGhost() {
   }
}
