package com.elvencompanions.client;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.entity.ElfEntity;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.neoforged.fml.loading.FMLPaths;

public final class TranscendMusic {
   private static final double RANGE = 48.0;
   private static final double FULL_RANGE = 16.0;
   private static boolean enabled = true;
   private static boolean loaded;
   private static TranscendMusic.Loop loop;
   private static int ticks;

   private static Path file() {
      return FMLPaths.CONFIGDIR.get().resolve("elven_companions_client.properties");
   }

   private static void load() {
      if (!loaded) {
         loaded = true;

         try {
            Path var0 = file();
            if (Files.exists(var0)) {
               Properties var1 = new Properties();

               try (BufferedReader var2 = Files.newBufferedReader(var0)) {
                  var1.load(var2);
               }

               enabled = Boolean.parseBoolean(var1.getProperty("music", "true"));
            }
         } catch (Throwable var7) {
         }
      }
   }

   public static boolean isEnabled() {
      load();
      return enabled;
   }

   public static void setEnabled(boolean var0) {
      load();
      enabled = var0;

      try {
         Properties var1 = new Properties();
         Path var2 = file();
         if (Files.exists(var2)) {
            try (BufferedReader var3 = Files.newBufferedReader(var2)) {
               var1.load(var3);
            }
         }

         var1.setProperty("music", Boolean.toString(var0));

         try (BufferedWriter var11 = Files.newBufferedWriter(var2)) {
            var1.store(var11, "Elven Companions (client)");
         }
      } catch (Throwable var10) {
      }

      if (!var0 && loop != null) {
         loop.fadeOut();
      }
   }

   public static void stopNow() {
      if (loop != null) {
         Minecraft.getInstance().getSoundManager().stop(loop);
         loop = null;
      }
   }

   public static void tick(Minecraft var0) {
      load();
      if (loop != null && loop.isStopped()) {
         loop = null;
      }

      if (var0.level != null && var0.player != null) {
         if (++ticks % 10 == 0) {
            if (!enabled) {
               if (loop != null) {
                  loop.fadeOut();
               }
            } else if (loop != null) {
               if (ticks % 40 == 0) {
                  var0.getMusicManager().stopPlaying();
               }
            } else {
               List var1 = var0.level
                  .getEntitiesOfClass(ElfEntity.class, var0.player.getBoundingBox().inflate(48.0), var0x -> ElfEarly.isT(var0x) && var0x.isAlive());
               ElfEntity var2 = null;
               double var3 = Double.MAX_VALUE;

               for (ElfEntity var6 : var1) {
                  double var7 = var6.distanceToSqr(var0.player);
                  if (var7 < var3) {
                     var3 = var7;
                     var2 = var6;
                  }
               }

               if (var2 != null) {
                  loop = new TranscendMusic.Loop(var2);
                  var0.getSoundManager().play(loop);
                  var0.getMusicManager().stopPlaying();
               }
            }
         }
      } else {
         if (loop != null) {
            stopNow();
         }
      }
   }

   private TranscendMusic() {
   }

   private static final class Loop extends AbstractTickableSoundInstance {
      private final ElfEntity elf;
      private float fade;
      private boolean fadingOut;

      Loop(ElfEntity var1) {
         super(SoundEvent.createVariableRangeEvent(ElvenCompanions.rl("transcend_music_loop")), SoundSource.MUSIC, RandomSource.create());
         this.elf = var1;
         this.looping = true;
         this.delay = 0;
         this.volume = 1.0E-4F;
         this.relative = true;
         this.attenuation = Attenuation.NONE;
      }

      void fadeOut() {
         this.fadingOut = true;
      }

      public void tick() {
         Minecraft var1 = Minecraft.getInstance();
         if (var1.player != null && var1.level != null) {
            double var2 = Math.sqrt(this.elf.distanceToSqr(var1.player));
            if (this.elf.isRemoved() || !this.elf.isAlive() || !ElfEarly.isT(this.elf) || !TranscendMusic.enabled || var2 > 48.0) {
               this.fadingOut = true;
            }

            this.fade = Mth.clamp(this.fade + (this.fadingOut ? -0.025F : 0.02F), 0.0F, 1.0F);
            if (this.fadingOut && this.fade <= 0.0F) {
               this.stop();
            } else {
               float var4 = (float)Mth.clamp(1.0 - (var2 - 16.0) / 32.0, 0.0, 1.0);
               var4 = var4 * var4 * (3.0F - 2.0F * var4);
               float var5 = ((Double)ECConfig.musicVolume.get()).floatValue();
               this.volume = Math.max(1.0E-4F, var5 * var4 * this.fade);
            }
         } else {
            this.stop();
         }
      }
   }
}
