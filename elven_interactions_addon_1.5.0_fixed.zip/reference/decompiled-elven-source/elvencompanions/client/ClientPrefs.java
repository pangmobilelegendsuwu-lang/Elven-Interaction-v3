package com.elvencompanions.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.neoforged.fml.loading.FMLPaths;

public final class ClientPrefs {
   private static boolean healthBar = true;
   private static boolean loaded;
   private static int auraMode = 2;
   private static boolean auraLoaded;

   private static Path file() {
      return FMLPaths.CONFIGDIR.get().resolve("elven_companions_client.properties");
   }

   private static Properties read() {
      Properties var0 = new Properties();

      try {
         Path var1 = file();
         if (Files.exists(var1)) {
            try (BufferedReader var2 = Files.newBufferedReader(var1)) {
               var0.load(var2);
            }
         }
      } catch (Throwable var7) {
      }

      return var0;
   }

   public static int auraMode() {
      if (!auraLoaded) {
         auraLoaded = true;
         String var0 = read().getProperty("aura", "default");
         auraMode = var0.equalsIgnoreCase("off") ? 0 : (var0.equalsIgnoreCase("always") ? 1 : 2);
      }

      return auraMode;
   }

   public static int cycleAura() {
      int var0 = (auraMode() + 1) % 3;
      auraMode = var0;

      try {
         Properties var1 = read();
         var1.setProperty("aura", var0 == 0 ? "off" : (var0 == 1 ? "always" : "default"));

         try (BufferedWriter var2 = Files.newBufferedWriter(file())) {
            var1.store(var2, "Elven Companions (client)");
         }
      } catch (Throwable var7) {
      }

      return var0;
   }

   public static boolean healthBar() {
      if (!loaded) {
         loaded = true;
         healthBar = Boolean.parseBoolean(read().getProperty("healthbar", "true"));
      }

      return healthBar;
   }

   public static void setHealthBar(boolean var0) {
      healthBar();
      healthBar = var0;

      try {
         Properties var1 = read();
         var1.setProperty("healthbar", Boolean.toString(var0));

         try (BufferedWriter var2 = Files.newBufferedWriter(file())) {
            var1.store(var2, "Elven Companions (client)");
         }
      } catch (Throwable var7) {
      }
   }

   private ClientPrefs() {
   }
}
