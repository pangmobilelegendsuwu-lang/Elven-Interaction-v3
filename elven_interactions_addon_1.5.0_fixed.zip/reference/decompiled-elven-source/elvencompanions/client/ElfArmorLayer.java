package com.elvencompanions.client;

import com.elvencompanions.entity.ElfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorMaterial.Layer;
import net.minecraft.world.item.component.DyedItemColor;

public class ElfArmorLayer extends RenderLayer<ElfEntity, ElfModel> {
   private final HumanoidModel<LivingEntity> inner;
   private final HumanoidModel<LivingEntity> outer;

   public ElfArmorLayer(RenderLayerParent<ElfEntity, ElfModel> parent, EntityModelSet models) {
      super(parent);
      this.inner = new HumanoidModel(models.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR));
      this.outer = new HumanoidModel(models.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR));
   }

   public void render(
      PoseStack ps,
      MultiBufferSource buffers,
      int light,
      ElfEntity e,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float age,
      float netHeadYaw,
      float headPitch
   ) {
      if (!e.isInvisible()) {
         ElfModel m = (ElfModel)this.getParentModel();

         for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.HEAD}) {
            ItemStack stack = e.getItemBySlot(slot);
            if (stack.getItem() instanceof ArmorItem armor && armor.getEquipmentSlot() == slot) {
               boolean innerModel = slot == EquipmentSlot.LEGS;
               HumanoidModel<LivingEntity> hm = innerModel ? this.inner : this.outer;
               m.poseArmor(hm);

               for (Layer layer : ((ArmorMaterial)armor.getMaterial().value()).layers()) {
                  int color = layer.dyeable() ? ARGB32.opaque(DyedItemColor.getOrDefault(stack, -6265536)) : -1;
                  ResourceLocation tex = layer.texture(innerModel);
                  VertexConsumer vc = ItemRenderer.getArmorFoilBuffer(buffers, RenderType.armorCutoutNoCull(tex), stack.hasFoil());
                  this.draw(ps, vc, hm, slot, light, color, m);
               }
            }
         }
      }
   }

   private void draw(PoseStack ps, VertexConsumer vc, HumanoidModel<LivingEntity> hm, EquipmentSlot slot, int light, int color, ElfModel m) {
      ps.pushPose();
      ps.translate(0.0F, m.armorDrop(), 0.0F);
      if (slot == EquipmentSlot.LEGS || slot == EquipmentSlot.FEET) {
         hm.setAllVisible(false);
         hm.rightLeg.visible = true;
         hm.leftLeg.visible = true;
         hm.renderToBuffer(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
      }

      hm.setAllVisible(false);
      switch (slot) {
         case HEAD:
            hm.head.visible = true;
            hm.hat.visible = true;
            break;
         case CHEST:
            hm.body.visible = true;
            hm.rightArm.visible = true;
            hm.leftArm.visible = true;
            break;
         case LEGS:
            hm.body.visible = true;
            break;
         default:
            return_(ps);
            return;
      }

      ps.pushPose();
      ps.translate(0.0F, 0.75F, 0.0F);
      ps.mulPose(Axis.ZP.rotation(m.torsoZ()));
      ps.mulPose(Axis.XP.rotation(-m.torsoX()));
      ps.translate(0.0F, -0.75F, 0.0F);
      hm.renderToBuffer(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
      ps.popPose();
      ps.popPose();
   }

   private static void return_(PoseStack ps) {
      ps.popPose();
   }
}
