package com.elvencompanions.client;

import com.elvencompanions.ECConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;

public final class Vfx {
   public static final int GREEN = 6750059;
   public static final int LIME = 12124002;
   public static final int PALE = 14155728;
   public static final int GOLD = 16765514;
   public static final int AMBER = 16754736;
   public static final int MOON = 10274047;
   public static final int VIOLET = 9140223;
   public static final int DEEPV = 5913855;
   public static final int WHITE = 16777215;
   public static final int RED = 16722490;
   public static final int DRED = 8002072;
   public static final int FIRE = 16734736;
   public static final int CYAN = 7333119;
   static final RandomSource R = RandomSource.create();
   private static final List<Vfx.Fx> ACTIVE = new ArrayList<>();
   private static float dens = 1.0F;

   public static void add(int var0, int var1, double var2, double var4, double var6, double var8, double var10, double var12, int var14, float var15) {
      if (ACTIVE.size() < 64) {
         ACTIVE.add(new Vfx.Fx(var0, var1, var2, var4, var6, var8, var10, var12, var14, var15));
      }
   }

   public static void clear() {
      ACTIVE.clear();
   }

   static boolean enabled() {
      return (Boolean)ECConfig.particles.get();
   }

   static float density() {
      return Math.max(0.15F, ((Double)ECConfig.particleDensity.get()).floatValue());
   }

   static boolean ok(float var0) {
      return R.nextFloat() < var0 * dens;
   }

   private static void emit(
      SpriteSet var0,
      double var1,
      double var3,
      double var5,
      double var7,
      double var9,
      double var11,
      int var13,
      float var14,
      int var15,
      float var16,
      float var17,
      float var18,
      float var19
   ) {
      Minecraft var20 = Minecraft.getInstance();
      if (var0 != null && var20.level != null) {
         float var21 = (var13 >> 16 & 0xFF) / 255.0F;
         float var22 = (var13 >> 8 & 0xFF) / 255.0F;
         float var23 = (var13 & 0xFF) / 255.0F;
         var20.particleEngine
            .add(ElfGlowParticle.make(var20.level, var1, var3, var5, var7, var9, var11, var0, var21, var22, var23, var14, var15, var16, var19, var17, var18));
      }
   }

   static void glow(double var0, double var2, double var4, double var6, double var8, double var10, int var12, float var13, int var14) {
      emit(ElfGlowParticle.GLOW, var0, var2, var4, var6, var8, var10, var12, var13, var14, 0.0F, 0.9F, 0.35F, 0.0F);
   }

   static void spark(double var0, double var2, double var4, double var6, double var8, double var10, int var12, float var13, int var14, float var15) {
      emit(ElfGlowParticle.GLOW, var0, var2, var4, var6, var8, var10, var12, var13, var14, var15, 0.94F, 0.5F, 0.0F);
   }

   static void shard(double var0, double var2, double var4, double var6, double var8, double var10, int var12, float var13, int var14, float var15) {
      emit(ElfGlowParticle.GLOW, var0, var2, var4, var6, var8, var10, var12, var13, var14, var15, 0.92F, 0.0F, 0.0F);
   }

   static void star(double var0, double var2, double var4, double var6, double var8, double var10, int var12, float var13, int var14) {
      emit(ElfGlowParticle.STAR, var0, var2, var4, var6, var8, var10, var12, var13, var14, 0.0F, 0.9F, 0.3F, 0.05F);
   }

   static void leaf(double var0, double var2, double var4, double var6, double var8, double var10, int var12, float var13, int var14) {
      emit(ElfGlowParticle.LEAF, var0, var2, var4, var6, var8, var10, var12, var13, var14, 0.004F, 0.96F, 0.2F, 0.08F);
   }

   static void ring(double var0, double var2, double var4, double var6, int var8, double var9, int var11, float var12, int var13, double var14) {
      int var16 = Math.max(4, Math.round(var8 * dens));

      for (int var17 = 0; var17 < var16; var17++) {
         double var18 = var9 + var17 * (Math.PI * 2) / var16;
         glow(var0 + Math.cos(var18) * var6, var2, var4 + Math.sin(var18) * var6, 0.0, var14, 0.0, var11, var12, var13);
      }
   }

   static void orbit(double var0, double var2, double var4, double var6, int var8, double var9, double var11, double var13, int var15, float var16, int var17) {
      int var18 = Math.max(4, Math.round(var8 * dens));
      double var19 = Math.cos(var11);
      double var21 = Math.sin(var11);
      double var23 = Math.cos(var13);
      double var25 = Math.sin(var13);

      for (int var27 = 0; var27 < var18; var27++) {
         double var28 = var9 + var27 * (Math.PI * 2) / var18;
         double var30 = Math.cos(var28) * var6;
         double var32 = Math.sin(var28) * var6 * var21;
         double var34 = Math.sin(var28) * var6 * var19;
         glow(var0 + var30 * var23 - var34 * var25, var2 + var32, var4 + var30 * var25 + var34 * var23, 0.0, 0.0, 0.0, var15, var16, var17);
      }
   }

   static void rune(double var0, double var2, double var4, double var6, double var8, int var10, int var11, float var12, int var13) {
      ring(var0, var2, var4, var6, (int)(var6 * 14.0), var8 * 0.3, var10, var12, var13, 0.0);
      ring(var0, var2, var4, var6 * 0.82, (int)(var6 * 10.0), -var8 * 0.5, var11, var12 * 0.8F, var13, 0.0);
      byte var14 = 8;

      for (int var15 = 0; var15 < var14; var15++) {
         double var16 = var8 + var15 * Math.PI * 2.0 / var14;

         for (double var18 = var6 * 0.3; var18 < var6 * 0.82; var18 += 0.55) {
            if (ok(0.9F)) {
               glow(var0 + Math.cos(var16) * var18, var2, var4 + Math.sin(var16) * var18, 0.0, 0.0, 0.0, var11, var12 * 0.7F, var13);
            }
         }
      }

      for (int var26 = 0; var26 < 6; var26++) {
         double var27 = -var8 * 0.7 + var26 * Math.PI / 3.0;
         double var28 = var27 + (Math.PI * 2.0 / 3.0);

         for (double var20 = 0.0; var20 < 1.0; var20 += 0.12) {
            if (ok(0.8F)) {
               double var22 = Math.cos(var27) * var6 * 0.6 * (1.0 - var20) + Math.cos(var28) * var6 * 0.6 * var20;
               double var24 = Math.sin(var27) * var6 * 0.6 * (1.0 - var20) + Math.sin(var28) * var6 * 0.6 * var20;
               glow(var0 + var22, var2, var4 + var24, 0.0, 0.0, 0.0, var10, var12 * 0.75F, var13);
            }
         }
      }
   }

   static void pillars(double var0, double var2, double var4, double var6, int var8, double var9, int var11, float var12, int var13) {
      int var14 = Math.max(1, Math.round(var8 * dens));

      for (int var15 = 0; var15 < var14; var15++) {
         double var16 = R.nextDouble() * Math.PI * 2.0;
         double var18 = Math.sqrt(R.nextDouble()) * var6;
         glow(
            var0 + Math.cos(var16) * var18,
            var2 + R.nextDouble() * 0.6,
            var4 + Math.sin(var16) * var18,
            0.0,
            var9 * (0.7 + R.nextDouble() * 0.6),
            0.0,
            var11,
            var12,
            var13
         );
      }
   }

   static void helix(
      double var0,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      int var16,
      int var17,
      int var18,
      float var19,
      int var20
   ) {
      int var21 = Math.max(1, Math.round(var17 * dens));

      for (int var22 = 0; var22 < var16; var22++) {
         for (int var23 = 0; var23 < var21; var23++) {
            double var24 = R.nextDouble();
            double var26 = var14 + var24 * var12 * Math.PI * 2.0 + var22 * Math.PI * 2.0 / var16;
            double var28 = var6 + (var8 - var6) * var24;
            glow(
               var0 + Math.cos(var26) * var28,
               var2 + var24 * var10,
               var4 + Math.sin(var26) * var28,
               -Math.sin(var26) * 0.02,
               0.02,
               Math.cos(var26) * 0.02,
               var18,
               var19,
               var20
            );
         }
      }
   }

   static void starBurst(double var0, double var2, double var4, double var6, int var8, int var9) {
      star(var0, var2, var4, 0.0, 0.0, 0.0, 16777215, (float)var6 * 0.9F, var9);

      for (int var10 = 0; var10 < 4; var10++) {
         double var11 = var10 * Math.PI / 2.0;

         for (double var13 = 0.15; var13 < var6; var13 += 0.22) {
            glow(var0 + Math.cos(var11) * var13, var2, var4 + Math.sin(var11) * var13, 0.0, 0.0, 0.0, var8, 0.16F * (float)(1.0 - var13 / var6 * 0.7), var9);
            glow(
               var0, var2 + Math.sin(var11) * var13, var4 + Math.cos(var11) * var13 * 0.0, 0.0, 0.0, 0.0, var8, 0.16F * (float)(1.0 - var13 / var6 * 0.7), var9
            );
         }
      }
   }

   static void burst(double var0, double var2, double var4, int var6, double var7, int var9, float var10, int var11) {
      int var12 = Math.max(2, Math.round(var6 * dens));

      for (int var13 = 0; var13 < var12; var13++) {
         double var14 = R.nextDouble() * Math.PI * 2.0;
         double var16 = R.nextDouble() * Math.PI - (Math.PI / 2);
         double var18 = var7 * (0.4 + R.nextDouble() * 0.6);
         spark(
            var0,
            var2,
            var4,
            Math.cos(var14) * Math.cos(var16) * var18,
            Math.sin(var16) * var18,
            Math.sin(var14) * Math.cos(var16) * var18,
            var9,
            var10,
            var11,
            0.0F
         );
      }
   }

   static void line(double var0, double var2, double var4, double var6, double var8, double var10, double var12, int var14, float var15, int var16) {
      double var17 = var6 - var0;
      double var19 = var8 - var2;
      double var21 = var10 - var4;
      double var23 = Math.sqrt(var17 * var17 + var19 * var19 + var21 * var21);
      int var25 = Math.max(2, (int)(var23 / var12));

      for (int var26 = 0; var26 <= var25; var26++) {
         double var27 = (double)var26 / var25;
         glow(var0 + var17 * var27, var2 + var19 * var27, var4 + var21 * var27, 0.0, 0.0, 0.0, var14, var15, var16);
      }
   }

   public static void tick(Minecraft var0) {
      if (var0.level == null) {
         ACTIVE.clear();
      } else if (enabled() && ElfGlowParticle.GLOW != null) {
         dens = density();

         for (int var1 = ACTIVE.size() - 1; var1 >= 0; var1--) {
            Vfx.Fx var2 = ACTIVE.get(var1);
            var2.age++;

            try {
               VfxRecipes.play(var2);
            } catch (RuntimeException var4) {
            }

            if (var2.age >= var2.ticks) {
               ACTIVE.remove(var1);
            }
         }
      } else {
         ACTIVE.clear();
      }
   }

   static double[] centre(Vfx.Fx var0) {
      Minecraft var1 = Minecraft.getInstance();
      if (var0.ent >= 0 && var1.level != null) {
         Entity var2 = var1.level.getEntity(var0.ent);
         if (var2 != null) {
            return new double[]{var2.getX(), var2.getY(), var2.getZ(), var2.getYRot()};
         }
      }

      return new double[]{var0.x, var0.y, var0.z, 0.0};
   }

   private Vfx() {
   }

   public static final class Fx {
      final int kind;
      final int ent;
      final double x;
      final double y;
      final double z;
      final double x2;
      final double y2;
      final double z2;
      final int ticks;
      final float sc;
      int age;

      Fx(int var1, int var2, double var3, double var5, double var7, double var9, double var11, double var13, int var15, float var16) {
         this.kind = var1;
         this.ent = var2;
         this.x = var3;
         this.y = var5;
         this.z = var7;
         this.x2 = var9;
         this.y2 = var11;
         this.z2 = var13;
         this.ticks = Math.max(1, var15);
         this.sc = var16 <= 0.0F ? 1.0F : var16;
      }
   }
}
