package com.elvencompanions.client;

import com.elvencompanions.ModRegistry;
import com.elvencompanions.entity.ElfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class ElfHeldItemLayer extends RenderLayer<ElfEntity, ElfModel> {
   public static final float BOW_SCALE = 1.3F;
   private final ItemInHandRenderer renderer;

   public ElfHeldItemLayer(RenderLayerParent<ElfEntity, ElfModel> parent, ItemInHandRenderer renderer) {
      super(parent);
      this.renderer = renderer;
   }

   public void render(
      PoseStack ps,
      MultiBufferSource buffers,
      int light,
      ElfEntity e,
      float limbSwing,
      float limbSwingAmount,
      float partialTick,
      float age,
      float netHeadYaw,
      float headPitch
   ) {
      this.renderHand(e, e.getMainHandItem(), HumanoidArm.RIGHT, ps, buffers, light);
      this.renderHand(e, e.getOffhandItem(), HumanoidArm.LEFT, ps, buffers, light);
   }

   private void renderHand(ElfEntity e, ItemStack stack, HumanoidArm arm, PoseStack ps, MultiBufferSource buffers, int light) {
      if (!stack.isEmpty()) {
         ps.pushPose();
         boolean celestial = stack.is((Item)ModRegistry.CELESTIAL_BOW.get());
         if (arm == HumanoidArm.RIGHT && (celestial || stack.is((Item)ModRegistry.ELF_BOW.get()))) {
            ((ElfModel)this.getParentModel()).transformToBow(ps, celestial ? 1.625F : 1.3F);
            this.renderer.renderItem(e, stack, ItemDisplayContext.NONE, false, ps, buffers, light);
         } else {
            ((ElfModel)this.getParentModel()).translateToHand(arm, ps);
            ps.mulPose(Axis.XP.rotationDegrees(-90.0F));
            ps.mulPose(Axis.YP.rotationDegrees(180.0F));
            boolean left = arm == HumanoidArm.LEFT;
            ps.translate((left ? -1 : 1) / 16.0F, 0.125F, -0.625F);
            this.renderer
               .renderItem(e, stack, left ? ItemDisplayContext.THIRD_PERSON_LEFT_HAND : ItemDisplayContext.THIRD_PERSON_RIGHT_HAND, left, ps, buffers, light);
         }

         ps.popPose();
      }
   }
}
