package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.phys.Vec3;

public final class CelestialArrowRenderer {
   private static final ResourceLocation TEX = ElvenCompanions.rl("textures/entity/celestial_arrow.png");
   private static final float[] UV = new float[]{0.0F, 0.0F, 1.0F, 1.0F};
   private static final List<CelestialArrowRenderer.Arrow> ARROWS = new ArrayList<>();
   private static long tick;

   public static void spawn(double x, double y, double z, int ticks, double startY) {
      CelestialArrowRenderer.Arrow a = new CelestialArrowRenderer.Arrow();
      a.x = x;
      a.y = y;
      a.z = z;
      a.ticks = Math.max(10, ticks);
      a.startY = startY;
      a.startTick = tick;
      if (ARROWS.size() > 4) {
         ARROWS.remove(0);
      }

      ARROWS.add(a);
   }

   public static void clientTick() {
      tick++;
      ARROWS.removeIf(a -> tick - a.startTick > a.ticks + 8);
   }

   public static boolean any() {
      return !ARROWS.isEmpty();
   }

   public static void render(PoseStack ps, Camera cam, float partial) {
      if (!ARROWS.isEmpty()) {
         Minecraft mc = Minecraft.getInstance();
         BufferSource bs = mc.renderBuffers().bufferSource();
         RenderType rt = RenderType.eyes(TEX);
         VertexConsumer vc = bs.getBuffer(rt);
         Vec3 c = cam.getPosition();

         for (CelestialArrowRenderer.Arrow a : ARROWS) {
            double p = Mth.clamp(((float)tick + partial - (float)a.startTick) / a.ticks, 0.0, 1.0);
            double ease = p * p * (3.0 - 2.0 * p) * 0.35 + p * 0.65;
            double tipY = Mth.lerp(ease, a.startY, a.y);
            float alpha = (float)Mth.clamp(p * 12.0, 0.0, 1.0) * (float)Mth.clamp((1.04 - p) * 25.0, 0.0, 1.0);
            if (!(alpha <= 0.01F)) {
               ps.pushPose();
               ps.translate(a.x - c.x, tipY - c.y, a.z - c.z);
               draw(ps, vc, ((float)tick + partial) * 0.02F, ARGB32.color((int)(235.0F * alpha), 255, 255, 255));
               ps.popPose();
            }
         }

         bs.endBatch(rt);
      }
   }

   private static void draw(PoseStack ps, VertexConsumer vc, float spin, int color) {
      Pose pose = ps.last();
      float head = 16.0F;
      float shaft = 52.0F;
      float hw = 5.5F;
      float sw = 1.4F;

      for (int i = 0; i < 4; i++) {
         float a0 = spin + i * (float) (Math.PI / 2);
         float a1 = a0 + (float) (Math.PI / 2);
         float x0 = Mth.cos(a0) * hw;
         float z0 = Mth.sin(a0) * hw;
         float x1 = Mth.cos(a1) * hw;
         float z1 = Mth.sin(a1) * hw;
         tri(pose, vc, color, 0.0F, 0.0F, 0.0F, x0, head, z0, x1, head, z1);
      }

      for (int i = 0; i < 4; i++) {
         float a0 = spin + (float) (Math.PI / 4) + i * (float) (Math.PI / 2);
         float a1 = a0 + (float) (Math.PI / 2);
         float x0 = Mth.cos(a0) * sw;
         float z0 = Mth.sin(a0) * sw;
         float x1 = Mth.cos(a1) * sw;
         float z1 = Mth.sin(a1) * sw;
         quadD(pose, vc, color, x0, head, z0, x1, head, z1, x1, head + shaft, z1, x0, head + shaft, z0);
      }

      for (int i = 0; i < 3; i++) {
         float a = spin * 0.5F + i * (float) (Math.PI * 2) / 3.0F;
         float cx = Mth.cos(a);
         float cz = Mth.sin(a);
         quadD(
            pose,
            vc,
            color,
            0.0F,
            head + shaft - 14.0F,
            0.0F,
            cx * 7.0F,
            head + shaft - 20.0F,
            cz * 7.0F,
            cx * 7.0F,
            head + shaft + 2.0F,
            cz * 7.0F,
            0.0F,
            head + shaft,
            0.0F
         );
      }

      for (int k = 0; k < 2; k++) {
         float r = 9 + k * 5;
         float y = head + 2.0F + k * 8;

         for (int i = 0; i < 24; i++) {
            float a0 = -spin * 3.0F + i * (float) (Math.PI * 2) / 24.0F;
            float a1 = a0 + (float) (Math.PI / 15);
            quadD(
               pose,
               vc,
               ARGB32.color(150, 255, 255, 255),
               Mth.cos(a0) * r,
               y - 0.5F,
               Mth.sin(a0) * r,
               Mth.cos(a1) * r,
               y - 0.5F,
               Mth.sin(a1) * r,
               Mth.cos(a1) * r,
               y + 0.5F,
               Mth.sin(a1) * r,
               Mth.cos(a0) * r,
               y + 0.5F,
               Mth.sin(a0) * r
            );
         }
      }
   }

   private static void v(Pose p, VertexConsumer vc, int color, float x, float y, float z, float u, float w) {
      vc.addVertex(p.pose(), x, y, z).setColor(color).setUv(u, w).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(p, 0.0F, 1.0F, 0.0F);
   }

   private static void tri(Pose p, VertexConsumer vc, int color, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz) {
      v(p, vc, color, ax, ay, az, 0.5F, 0.0F);
      v(p, vc, color, bx, by, bz, 0.0F, 1.0F);
      v(p, vc, color, cx, cy, cz, 1.0F, 1.0F);
      v(p, vc, color, cx, cy, cz, 1.0F, 1.0F);
      v(p, vc, color, cx, cy, cz, 1.0F, 1.0F);
      v(p, vc, color, bx, by, bz, 0.0F, 1.0F);
      v(p, vc, color, ax, ay, az, 0.5F, 0.0F);
      v(p, vc, color, ax, ay, az, 0.5F, 0.0F);
   }

   private static void quadD(
      Pose p,
      VertexConsumer vc,
      int color,
      float ax,
      float ay,
      float az,
      float bx,
      float by,
      float bz,
      float cx,
      float cy,
      float cz,
      float dx,
      float dy,
      float dz
   ) {
      v(p, vc, color, ax, ay, az, UV[0], UV[1]);
      v(p, vc, color, bx, by, bz, UV[2], UV[1]);
      v(p, vc, color, cx, cy, cz, UV[2], UV[3]);
      v(p, vc, color, dx, dy, dz, UV[0], UV[3]);
      v(p, vc, color, dx, dy, dz, UV[0], UV[3]);
      v(p, vc, color, cx, cy, cz, UV[2], UV[3]);
      v(p, vc, color, bx, by, bz, UV[2], UV[1]);
      v(p, vc, color, ax, ay, az, UV[0], UV[1]);
   }

   private CelestialArrowRenderer() {
   }

   private static final class Arrow {
      double x;
      double y;
      double z;
      double startY;
      long startTick;
      int ticks;
   }
}
