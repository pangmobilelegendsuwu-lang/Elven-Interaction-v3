package com.elvencompanions.client.fx;

import com.mojang.blaze3d.platform.GlStateManager.DestFactor;
import com.mojang.blaze3d.platform.GlStateManager.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureManager;

final class FxType implements ParticleRenderType {
   final Tex tex;
   final int mode;

   FxType(Tex var1, int var2) {
      this.tex = var1;
      this.mode = var2;
   }

   public BufferBuilder begin(Tesselator var1, TextureManager var2) {
      if (this.mode == 0) {
         RenderSystem.depthMask(false);
         RenderSystem.setShaderTexture(0, FxManager.loc(this.tex));
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE);
      } else {
         RenderSystem.depthMask(true);
         RenderSystem.setShaderTexture(0, this.mode == 1 ? FxManager.loc(this.tex) : TextureAtlas.LOCATION_PARTICLES);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
      }

      return var1.begin(Mode.QUADS, DefaultVertexFormat.PARTICLE);
   }

   @Override
   public String toString() {
      return "ELVEN_FX_" + this.tex + "_" + this.mode;
   }
}
