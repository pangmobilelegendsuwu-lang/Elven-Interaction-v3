package com.elvencompanions.client.fx;

public final class SkillMeshes {
   public static void render(Ctx var0, FxInst var1, double var2) {
      double var4 = var1.age + var2;
      var0.time = var4;
      double var6 = var1.ix(var2);
      double var8 = var1.iy(var2);
      double var10 = var1.iz(var2);
      switch (var1.kind) {
         case 1:
            piercer(var0, var1, var4, false);
            break;
         case 2:
            skyfall(var0, var1, var4, var6, var8, var10);
            break;
         case 3:
            volley(var0, var1, var4);
            break;
         case 4:
            piercer(var0, var1, var4, true);
            break;
         case 5:
            moonfall(var0, var1, var4, var6, var8, var10);
            break;
         case 6:
            thorn(var0, var1, var4, var6, var8, var10);
            break;
         case 7:
            hunt(var0, var1, var4, var6, var8, var10);
            break;
         case 8:
            guardian(var0, var1, var4, var6, var8, var10);
            break;
         case 9:
            seed(var0, var1, var4, var6, var8, var10);
            break;
         case 10:
            rage(var0, var1, var4, var6, var8, var10);
            break;
         case 11:
            stealth(var0, var1, var4, var6, var8, var10);
            break;
         case 12:
            ascend(var0, var1, var4, var6, var8, var10);
            break;
         case 13:
            annihilation(var0, var1, var4, var6, var8, var10);
            break;
         case 14:
            chrono(var0, var1, var4, var6, var8, var10);
            break;
         case 15:
            ricochet(var0, var1, var4);
            break;
         case 16:
            world(var0, var1, var4, var6, var8, var10);
            break;
         case 17:
         case 18:
         case 19:
         default:
            if (NewMeshes.handles(var1.kind)) {
               NewMeshes.render(var0, var1, var2, var4, var6, var8, var10);
            }
            break;
         case 20:
            transcend(var0, var1, var4, var6, var8, var10);
      }
   }

   public static boolean handles(int var0) {
      return var0 >= 1 && var0 <= 16 || var0 == 20 || NewMeshes.handles(var0);
   }

   private static void piercer(Ctx var0, FxInst var1, double var2, boolean var4) {
      double var5 = var1.x2 - var1.x;
      double var7 = var1.y2 - var1.y;
      double var9 = var1.z2 - var1.z;
      double var11 = Math.sqrt(var5 * var5 + var7 * var7 + var9 * var9);
      if (!(var11 < 0.5)) {
         var5 /= var11;
         var7 /= var11;
         var9 /= var11;
         double var13 = var11 + 3.0;
         double var15 = var2 / var1.ticks;
         double var17 = var15 * var13;
         double var19 = var13 / var1.ticks;
         double var21 = Math.min(var17, 11.0);
         int var23 = var4 ? 16738832 : 6750059;
         int var24 = var4 ? 16752688 : 12124002;
         double[] var25 = new double[3];
         double[] var26 = new double[3];
         Geo.basis(var5, var7, var9, var25, var26);
         int var27 = var0.n(30, 12);
         double var28 = 1.0 - Geo.sstep(0.9, 1.0, var15);
         double[] var30 = new double[var27];
         double[] var31 = new double[var27];
         double[] var32 = new double[var27];
         double[] var33 = new double[var27];
         int[] var34 = new int[var27];

         for (int var35 = 0; var35 < var27; var35++) {
            double var36 = (double)var35 / (var27 - 1);
            double var38 = Math.max(0.0, var17 - var21 * (1.0 - var36));
            var30[var35] = var1.x + var5 * var38;
            var31[var35] = var1.y + var7 * var38;
            var32[var35] = var1.z + var9 * var38;
            var33[var35] = 0.62 * Math.pow(var36, 0.8) + 0.02;
            var34[var35] = Col.mul(Col.mix(var23, 16777215, Math.pow(var36, 2.5)), (0.1 + 0.9 * var36) * var28);
         }

         Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var30, var31, var32, var33, var34, var27, -var2 * 0.12, -var2 * 0.12 + 2.5);

         for (int var52 = 0; var52 < 2; var52++) {
            var31 = new double[var27];
            var32 = new double[var27];
            var33 = new double[var27];
            double[] var65 = new double[var27];
            int[] var67 = new int[var27];

            for (int var69 = 0; var69 < var27; var69++) {
               double var37 = (double)var69 / (var27 - 1);
               double var39 = Math.max(0.0, var17 - var21 * (1.0 - var37));
               double var41 = var39 * 1.3 + var2 * 0.55 + var52 * Math.PI;
               double var43 = 0.12 + 0.55 * Math.pow(var37, 0.7);
               double var45 = Math.cos(var41) * var43;
               double var47 = Math.sin(var41) * var43;
               var31[var69] = var1.x + var5 * var39 + var25[0] * var45 + var26[0] * var47;
               var32[var69] = var1.y + var7 * var39 + var25[1] * var45 + var26[1] * var47;
               var33[var69] = var1.z + var9 * var39 + var25[2] * var45 + var26[2] * var47;
               var65[var69] = 0.42 * Math.pow(var37, 0.6) + 0.01;
               var67[var69] = Col.mul(var52 == 0 ? var23 : var24, (0.05 + 0.95 * var37) * var28 * 0.95);
            }

            Geo.ribbon(var0.q, var4 ? Tex.RIBBON_WISP : Tex.RIBBON_SOFT, var31, var32, var33, var65, var67, var27, var2 * 0.1, var2 * 0.1 + 3.0);
         }

         if (var17 < var13) {
            double var53 = var1.x + var5 * var17;
            double var61 = var1.y + var7 * var17;
            double var66 = var1.z + var9 * var17;
            if (!var4) {
               Geo.oriented(
                  var0.q,
                  Tex.ARROW,
                  var53 - var5 * 1.6,
                  var61 - var7 * 1.6,
                  var66 - var9 * 1.6,
                  var5,
                  var7,
                  var9,
                  1.9,
                  0.26,
                  2,
                  var2 * 0.2,
                  Col.mul(var23, 0.35),
                  Col.mul(16777215, 1.0)
               );
            }

            Parts.flare(var0, var53, var61, var66, 1.05, var2 * 0.25, var4 ? 16752688 : 14221264, var28, false);
            Parts.spark(var0, var53, var61, var66, 0.9, var23, var28);
         }

         if (var4) {
            for (int var54 = 0; var54 < 6; var54++) {
               double var58 = var17 - 0.4 - var54 * 1.55;
               if (!(var58 < 0.0) && !(var58 > var11 + 1.0)) {
                  double var63 = 1.0 - var54 / 6.0;
                  Geo.flameSprite(
                     var0.q,
                     var1.x + var5 * var58,
                     var1.y + var7 * var58 - 0.3,
                     var1.z + var9 * var58,
                     0.55 * (0.5 + 0.5 * var63),
                     1.25 * (0.55 + 0.45 * var63),
                     (int)(var2 * 0.9) + var54 * 3,
                     Col.mul(16777215, var63 * var28)
                  );
               }
            }
         } else {
            for (int var55 = 0; var55 < 9; var55++) {
               double var59 = (var55 + 0.4) * var11 / 9.0;
               double var64 = var2 - var59 / var19;
               if (!(var64 < 0.0) && !(var64 > 24.0)) {
                  double var68 = 1.0 - Geo.sstep(10.0, 24.0, var64);
                  double var70 = var1.x + var5 * var59 + Math.sin(var55 * 2.1 + var64 * 0.25) * 0.5;
                  double var71 = var1.y + var7 * var59 + 0.3 - var64 * 0.02 + Math.sin(var64 * 0.2 + var55) * 0.1;
                  double var72 = var1.z + var9 * var59 + Math.cos(var55 * 1.7 + var64 * 0.25) * 0.5;
                  Parts.leaf(var0, var55 & 3, var70, var71, var72, 0.26, var2 * 0.3 + var55, 12124002, var68 * var28);
               }
            }
         }

         if (var2 < 10.0) {
            double var56 = var2 / 10.0;
            Geo.discN(
               var0.q,
               Tex.RUNE_NATURE,
               var1.x + var5 * 0.6,
               var1.y + var7 * 0.6,
               var1.z + var9 * 0.6,
               1.2 + var56 * 0.5,
               var5,
               var7,
               var9,
               var2 * 0.25,
               Col.mul(var4 ? 16747040 : 6750059, 1.0 - var56)
            );
         }
      }
   }

   private static void volley(Ctx var0, FxInst var1, double var2) {
      double var4 = var1.x2 - var1.x;
      double var6 = var1.z2 - var1.z;
      double var8 = Math.atan2(var6, var4);
      if (var2 < 12.0) {
         double var10 = var2 / 12.0;
         Geo.discN(
            var0.q,
            Tex.RUNE_NATURE,
            var1.x + Math.cos(var8) * 0.9,
            var1.y,
            var1.z + Math.sin(var8) * 0.9,
            1.7 + var10 * 0.6,
            Math.cos(var8),
            0.0,
            Math.sin(var8),
            var2 * 0.3,
            Col.mul(12124002, 1.0 - var10)
         );
         Parts.flare(
            var0, var1.x + Math.cos(var8) * 0.7, var1.y, var1.z + Math.sin(var8) * 0.7, 1.4 * (1.0 - var10) + 0.3, var2 * 0.2, 14221264, 1.0 - var10, false
         );
      }
   }

   private static void skyfall(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = 1.0 + var10 * 8.0 * var1.sc;
      double var14 = 1.0 - Geo.sstep(0.75, 1.0, var10);
      Parts.ring(var0, var4, var6 + 0.06, var8, var12, 10276863, (1.0 - var10) * 0.95);
      Parts.ring(var0, var4, var6 + 0.07, var8, var12 * 0.62, 16777215, (1.0 - var10) * 0.7);
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.05, var8, Math.max(0.5, var12 * 0.9), var2 * 0.07, 10276863, var14 * 0.7 * Geo.sstep(0.0, 0.12, var10));
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var12 * 1.15, 9141759, var14 * 0.25);
      double var16 = Geo.fadeIO(var10, 0.06, 0.55);
      Parts.column(var0, var4, var6, var8, 0.85, 10.0, 10276863, var16 * 0.8, var2 * 0.08, 16777215, var16 * 0.8);
      if (var2 < 14.0) {
         double var18 = var2 / 14.0;
         Parts.flare(var0, var4, var6 + 1.3, var8, 3.4 * (1.0 - var18) + 0.8, var2 * 0.15, 16777215, 1.0 - var18, true);
         Parts.flare(var0, var4, var6 + 1.3, var8, 4.2 * (1.0 - var18) + 0.8, var2 * 0.15 + 0.78, 10276863, (1.0 - var18) * 0.8, false);
      }

      int var60 = var0.n(14, 7);

      for (int var19 = 0; var19 < var60; var19++) {
         double var20 = 1.4 + Math.sqrt(Geo.hash(var19, 1)) * 6.0 * var1.sc;
         double var22 = Geo.hash(var19, 2) * (Math.PI * 2);
         double var24 = 1.5 + Geo.hash(var19, 3) * 15.0;
         double var26 = var2 - var24;
         double var28 = 5.0;
         double var30 = 16.0;
         if (!(var26 < 0.0) && !(var26 > var28 + var30)) {
            double var32 = Math.min(1.0, var26 / var28);
            double var34 = var26 < var28 ? 1.0 : 1.0 - Geo.sstep(var28 + 4.0, var28 + var30, var26);
            double var36 = var4 + Math.cos(var22) * var20;
            double var38 = var8 + Math.sin(var22) * var20;
            double var40 = 0.2;
            double var42 = Math.cos(var22 + 1.3) * var40;
            double var44 = Math.sin(var22 + 1.3) * var40;
            double var46 = var6 + 0.15 + (1.0 - var32 * var32) * 17.0;
            double var48 = Math.sqrt(var42 * var42 + 1.0 + var44 * var44);
            double var50 = var42 / var48;
            double var52 = -1.0 / var48;
            double var54 = var44 / var48;
            double var56 = 3.6;
            Geo.oriented(
               var0.q,
               Tex.ARROW,
               var36 - var50 * var56,
               var46 - var52 * var56,
               var38 - var54 * var56,
               var50,
               var52,
               var54,
               var56,
               0.34,
               2,
               var22,
               Col.mul(10276863, 0.5 * var34),
               Col.mul(16777215, var34)
            );
            Geo.standing(
               var0.q,
               Tex.BEAM_CORE,
               var36 - var50 * var56,
               var46 - var52 * var56,
               var38 - var54 * var56,
               var22,
               0.22,
               9.0,
               2,
               Col.mul(10276863, 0.8 * var34 * (1.0 - var32 * 0.4)),
               Col.mul(10276863, 0.0)
            );
            if (var26 >= var28 && var26 < var28 + 5.0) {
               double var58 = (var26 - var28) / 5.0;
               Parts.flare(var0, var36, var6 + 0.5, var38, 1.5 * (1.0 - var58) + 0.3, var22, 16777215, 1.0 - var58, false);
               Parts.ring(var0, var36, var6 + 0.08, var38, 0.3 + var58 * 1.5, 10276863, 1.0 - var58);
            }
         }
      }
   }

   private static void moonfall(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = 5.5 * var1.sc;
      double var14 = Geo.fadeIO(var10, 0.08, 0.14);
      double var16 = 6.6;
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.05, var8, var12, var2 * 0.045, 10276863, var14 * 0.95);
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.07, var8, var12 * 0.6, -var2 * 0.07, 9141759, var14 * 0.8);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var12 * 1.05, 5913855, var14 * 0.35);
      int var18 = var0.n(28, 12);
      Geo.cylinder(
         var0.q,
         Tex.DOME,
         var4,
         var6,
         var8,
         var12 * 0.97,
         var12 * 0.97,
         var16,
         var18,
         0.0,
         Col.mul(10276863, 0.55 * var14),
         Col.mul(9141759, 0.08 * var14),
         12.0,
         var2 * 0.004,
         0.0,
         1.0
      );
      double var19 = var6 + var16 + 0.3;
      Parts.rune(var0, Tex.RUNE_MOON, var4, var19, var8, var12 * 0.92, -var2 * 0.03, 13625087, var14 * 0.55);
      Parts.ring(var0, var4, var19 + 0.02, var8, var12 * 0.97, 10276863, var14 * 0.8);
      Parts.column(var0, var4, var6, var8, 0.7, var16 + 1.0, 10276863, var14 * 0.35, var2 * 0.06, 16777215, var14 * 0.3);
      Parts.spark(var0, var4, var6 + var16 + 2.6, var8, 3.4, 9141759, var14 * (0.55 + 0.1 * Math.sin(var2 * 0.2)));
      Geo.billboard(var0.q, Tex.MOON, var4, var6 + var16 + 2.6, var8, 1.7, 0.4, Col.mul(13625087, var14 * (0.85 + 0.15 * Math.sin(var2 * 0.2))));
      int var21 = var0.n(16, 8);

      for (int var22 = 0; var22 < var21; var22++) {
         double var23 = (Math.PI * 2) * var22 / var21 + 0.15;
         double var25 = var12 * 0.8;
         double var27 = 6.0 + var22 * (22.0 / var21);
         double var29 = 5.0;
         double var31 = var2 - var27;
         if (!(var31 < 0.0)) {
            double var33 = Math.min(1.0, var31 / var29);
            double var35 = var33 * var33;
            double var37 = var4 + Math.cos(var23) * var25;
            double var39 = var8 + Math.sin(var23) * var25;
            double var41 = var6 + 0.1 + (1.0 - var35) * 15.0;
            double var43 = var14 * (0.75 + 0.25 * Math.sin(var2 * 0.25 + var22));
            Geo.oriented(
               var0.q, Tex.ARROW, var37, var41 + 4.2, var39, 0.0, -1.0, 0.0, 4.2, 0.36, 2, var23, Col.mul(9141759, 0.5 * var43), Col.mul(16777215, var43)
            );
            if (var33 >= 1.0) {
               Parts.shaft(var0, var37, var6 + 3.5, var39, 0.28, 6.0, 10276863, var43 * 0.7, var23);
               double var45 = Math.min(1.0, (var31 - var29) / 6.0);
               if (var45 < 1.0) {
                  Parts.ring(var0, var37, var6 + 0.08, var39, 0.3 + var45 * 1.4, 13625087, 1.0 - var45);
               }
            }
         }
      }

      int var47 = (int)Math.floor(var2 / 2.5);

      for (int var48 = var47 - 3; var48 <= var47; var48++) {
         if (var48 >= 3) {
            double var24 = var48 * 2.5;
            double var26 = var2 - var24;
            double var28 = 4.0;
            if (!(var26 < 0.0) && !(var26 > var28 + 6.0)) {
               double var30 = Math.sqrt(Geo.hash(var48, 5)) * var12 * 0.85;
               double var32 = Geo.hash(var48, 6) * (Math.PI * 2);
               double var34 = var4 + Math.cos(var32) * var30;
               double var36 = var8 + Math.sin(var32) * var30;
               double var38 = Math.min(1.0, var26 / var28);
               double var40 = var6 + 0.1 + (1.0 - var38 * var38) * 14.0;
               double var42 = var14 * (var26 < var28 ? 1.0 : 1.0 - (var26 - var28) / 6.0);
               Geo.oriented(
                  var0.q, Tex.ARROW, var34, var40 + 3.0, var36, 0.0, -1.0, 0.0, 3.0, 0.28, 2, var32, Col.mul(10276863, 0.4 * var42), Col.mul(16777215, var42)
               );
               if (var26 >= var28) {
                  Parts.flare(var0, var34, var6 + 0.4, var36, 1.0, 0.0, 13625087, var42, false);
               }
            }
         }
      }

      for (int var49 = 0; var49 < 9; var49++) {
         double var50 = Geo.hash(var49, 8) * (Math.PI * 2) + var2 * 0.01;
         double var51 = var12 * (0.3 + 0.6 * Geo.hash(var49, 9));
         Parts.flare(
            var0,
            var4 + Math.cos(var50) * var51,
            var6 + 1.0 + Geo.hash(var49, 10) * 5.5,
            var8 + Math.sin(var50) * var51,
            0.5 + 0.35 * Geo.hash(var49, 11),
            var2 * 0.05,
            16777215,
            var14 * (0.45 + 0.55 * Math.abs(Math.sin(var2 * 0.12 + var49 * 1.7))),
            false
         );
      }
   }

   private static void thorn(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = var1.sc;
      double var14 = 4.0 * var12;
      double var16 = 3.0 * var12;
      double var18 = Geo.sstep(0.0, 0.3, var10);
      double var20 = Geo.sstep(0.1, 0.55, var10);
      double var22 = 1.0 - Geo.sstep(0.86, 1.0, var10);
      double var24 = 3.6 * Math.max(0.8, Math.min(1.6, var12));
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, var14, var2 * 0.03, 6750059, var22 * Geo.sstep(0.0, 0.1, var10));
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var14 * 0.9, 3137648, var22 * 0.3);
      if (var2 < 10.0) {
         Parts.ring(var0, var4, var6 + 0.07, var8, var14 * (var2 / 10.0), 12124002, 1.0 - var2 / 10.0);
      }

      byte var26 = 7;
      int var27 = var0.n(11, 6);
      int var28 = var0.n(5, 4);

      for (int var29 = 0; var29 < var26; var29++) {
         double var30 = (Math.PI * 2) * var29 / var26 + 0.4;
         double var32 = (var29 & 1) == 0 ? 1.0 : -1.0;
         double[] var34 = new double[var27];
         double[] var35 = new double[var27];
         double[] var36 = new double[var27];
         double[] var37 = new double[var27];
         int[] var38 = new int[var27];

         for (int var39 = 0; var39 < var27; var39++) {
            double var40 = (double)var39 / (var27 - 1);
            double var42 = var40 * var18;
            double var44 = var30 + var32 * var40 * 2.4 * var18;
            double var46 = var16 * (1.0 - 0.55 * var40 * var20) + Math.sin(var40 * 9.0 + var29) * 0.12;
            var34[var39] = var4 + Math.cos(var44) * var46;
            var35[var39] = var6 + var42 * var24 + 0.02;
            var36[var39] = var8 + Math.sin(var44) * var46;
            var37[var39] = Math.max(0.01, 0.13 * (1.0 - var40 * 0.75) * (0.3 + 0.7 * var18));
            var38[var39] = Col.mul(Col.mix(6750059, 12124002, var40), var22 * (0.55 + 0.45 * Math.sin(var2 * 0.2 + var29 + var40 * 4.0) * 0.5 + 0.2));
         }

         Geo.tube(var0.q, Tex.VINE, var34, var35, var36, var37, var38, var27, var28, 1.0, 0.0, 3.0);

         for (int var52 = 1; var52 <= 4; var52++) {
            int var54 = Math.min(var27 - 1, (int)(var52 * (var27 - 1) / 4.5));
            double var41 = Math.atan2(var36[var54] - var8, var34[var54] - var4);
            double var43 = 0.42 * var18 * (1.0 - (double)var54 / var27 * 0.5);
            if (var43 > 0.05) {
               Geo.oriented(
                  var0.q,
                  Tex.SPIKE,
                  var34[var54],
                  var35[var54],
                  var36[var54],
                  Math.cos(var41 + var52) * 0.8,
                  0.5,
                  Math.sin(var41 + var52) * 0.8,
                  var43,
                  0.11,
                  2,
                  var52,
                  Col.mul(6750059, var22 * 0.7),
                  Col.mul(14221264, var22)
               );
            }
         }

         int var53 = var27 - 1;
         Parts.leaf(var0, var29 & 3, var34[var53], var35[var53] + 0.1, var36[var53], 0.28 * var18, var2 * 0.2 + var29, 12124002, var22);
         Parts.leaf(var0, var29 + 1 & 3, var34[var27 / 2], var35[var27 / 2], var36[var27 / 2], 0.22 * var18, -var2 * 0.15 + var29, 6750059, var22 * 0.85);
      }

      for (int var48 = 0; var48 < 8; var48++) {
         double var49 = (var2 * 0.03 + Geo.hash(var48, 4)) % 1.0;
         double var50 = Geo.hash(var48, 5) * (Math.PI * 2);
         double var51 = Geo.hash(var48, 6) * var14 * 0.7;
         Parts.spark(
            var0, var4 + Math.cos(var50) * var51, var6 + 0.3 + var49 * 3.0, var8 + Math.sin(var50) * var51, 0.35, 12124002, var22 * (1.0 - var49) * 0.9
         );
      }
   }

   private static void hunt(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = 4.5 * var1.sc;
      double var14 = Geo.fadeIO(var10, 0.08, 0.2);
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, var12, var2 * 0.035, 6750059, var14);
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.06, var8, var12 * 0.55, -var2 * 0.06, 14221264, var14 * 0.7);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var12, 3137648, var14 * 0.3);
      Parts.ring(var0, var4, var6 + 0.07, var8, var12 * (0.4 + 1.1 * var10), 12124002, (1.0 - var10) * 0.7);
      Parts.Centre var16 = (var6x, var8x) -> {
         var8x[0] = var4;
         var8x[1] = var6;
         var8x[2] = var8;
      };
      int[] var17 = new int[]{14221264, 12124002, 6750059};

      for (int var18 = 0; var18 < 3; var18++) {
         Parts.orbit(
            var0,
            Tex.RIBBON_SOFT,
            var16,
            1.3 + 0.1 * var18,
            4.8 * var1.sc * (1.0 - 0.14 * var18),
            4.8 * var1.sc * (1.0 - 0.14 * var18) * 0.9,
            0.35 + 0.42 * var18,
            var18 * 2.1,
            var2 * (0.2 + 0.03 * var18) * (var18 == 1 ? -1 : 1) + var18 * 2,
            var18 == 1 ? -1.0 : 1.0,
            2.6,
            4.5,
            0.62 - 0.08 * var18,
            var17[var18],
            16777215,
            var14 * 0.95,
            28,
            0.25,
            var2 * 0.08
         );
      }

      for (int var25 = 0; var25 < 2; var25++) {
         Parts.helix(
            var0,
            Tex.RIBBON_WISP,
            var4,
            var6,
            var8,
            3.4 * var1.sc,
            1.5 * var1.sc,
            4.2,
            1.6,
            var2 * 0.16 + var25 * Math.PI,
            0.42,
            var25 == 0 ? 12124002 : 6750059,
            var14 * 0.9,
            20,
            0.0,
            1.0,
            -var2 * 0.1
         );
      }

      for (int var26 = 0; var26 < 5; var26++) {
         double var19 = var2 * 0.04 + (Math.PI * 2) * var26 / 5.0;
         Parts.shaft(var0, var4 + Math.cos(var19) * var12 * 0.7, var6, var8 + Math.sin(var19) * var12 * 0.7, 0.3, 5.5, 14221264, var14 * 0.7, var19);
      }

      for (int var27 = 0; var27 < 9; var27++) {
         double var28 = (var2 * 0.045 + Geo.hash(var27, 1)) % 1.0;
         double var21 = Geo.hash(var27, 2) * (Math.PI * 2) + var2 * 0.1;
         double var23 = var12 * (0.3 + 0.7 * Geo.hash(var27, 3));
         Parts.leaf(
            var0,
            var27 & 3,
            var4 + Math.cos(var21) * var23,
            var6 + 0.3 + var28 * 4.5,
            var8 + Math.sin(var21) * var23,
            0.3,
            var2 * 0.2 + var27,
            12124002,
            var14 * Math.sin(var28 * Math.PI)
         );
      }
   }

   private static void guardian(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = 6.0 * var1.sc;
      double var14 = Geo.sstep(0.0, 0.33, var10);
      double var16 = Geo.fadeIO(var10, 0.06, 0.2);
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, var12, var2 * 0.025, 12124002, var16);
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var6 + 0.07, var8, var12 * 0.5, -var2 * 0.05, 16767050, var16 * 0.55);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var12 * 1.05, 3137648, var16 * 0.28);
      Parts.ring(var0, var4, var6 + 0.08, var8, var12 * 0.97, 14221264, var16 * 0.8);
      double var18 = 7.2 * var14 * Math.max(0.85, Math.min(1.5, (double)var1.sc));
      double var20 = 3.7 * var14 * Math.max(0.85, Math.min(1.5, (double)var1.sc));
      Geo.standing(
         var0.q,
         Tex.GUARDIAN,
         var4,
         var6 - 0.2,
         var8,
         var2 * 0.012,
         var20,
         var18,
         0.0,
         0.0,
         2,
         Col.mul(12124002, var16 * (0.5 + 0.1 * Math.sin(var2 * 0.15))),
         Col.mul(12124002, var16 * 0.6),
         0.0,
         0.0,
         1.0,
         1.0
      );
      Parts.column(var0, var4, var6, var8, 1.0, 8.0 * var14, 6750059, var16 * 0.28, var2 * 0.04, 14221264, var16 * 0.0);
      Geo.dome(
         var0.q,
         Tex.DOME,
         var4,
         var6,
         var8,
         var12 * 0.97,
         0.75,
         var0.n(6, 3),
         var0.n(20, 10),
         var2 * 0.004,
         Col.mul(12124002, 0.45 * var16),
         Col.mul(14221264, 0.08 * var16),
         10.0,
         2.0,
         var14
      );
      byte var22 = 6;
      int var23 = var0.n(14, 7);

      for (int var24 = 0; var24 < var22; var24++) {
         double var25 = (Math.PI * 2) * var24 / var22 + var2 * 0.004;
         double[] var27 = new double[var23];
         double[] var28 = new double[var23];
         double[] var29 = new double[var23];
         double[] var30 = new double[var23];
         int[] var31 = new int[var23];

         for (int var32 = 0; var32 < var23; var32++) {
            double var33 = (double)var32 / (var23 - 1) * var14;
            double var35 = var12 * 0.97 * Math.cos(var33 * Math.PI / 2.0);
            double var37 = 5.6 * Math.sin(var33 * Math.PI / 2.0) + Math.sin(var32 * 1.3 + var24) * 0.1;
            var27[var32] = var4 + Math.cos(var25 + var33 * 0.5) * var35;
            var28[var32] = var6 + var37;
            var29[var32] = var8 + Math.sin(var25 + var33 * 0.5) * var35;
            var30[var32] = 0.4 - 0.15 * var33;
            var31[var32] = Col.mul(Col.mix(12124002, 14221264, var33), var16 * 0.9);
         }

         Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var27, var28, var29, var30, var31, var23, 0.0, 4.0);
         Parts.leaf(var0, var24 & 3, var27[var23 / 2], var28[var23 / 2], var29[var23 / 2], 0.34, var2 * 0.1 + var24, 12124002, var16 * var14);
         Parts.leaf(var0, var24 + 2 & 3, var27[var23 * 3 / 4], var28[var23 * 3 / 4], var29[var23 * 3 / 4], 0.28, -var2 * 0.1 + var24, 14221264, var16 * var14);
      }

      for (int var39 = 0; var39 < 12; var39++) {
         double var40 = (var2 * 0.025 + Geo.hash(var39, 1)) % 1.0;
         double var41 = Geo.hash(var39, 2) * (Math.PI * 2);
         double var42 = Geo.hash(var39, 3) * var12 * 0.8;
         Parts.spark(
            var0,
            var4 + Math.cos(var41) * var42,
            var6 + 0.3 + var40 * 6.0,
            var8 + Math.sin(var41) * var42,
            0.4,
            var39 % 3 == 0 ? 16767050 : 12124002,
            var16 * Math.sin(var40 * Math.PI)
         );
      }
   }

   private static void seed(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = Geo.fadeIO(var10, 0.1, 0.25);
      double var14 = var1.sc;
      double var16 = Geo.sstep(0.0, 0.3, var10);
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, 2.4 * var14 * Math.max(0.2, var16), var2 * 0.06, 12124002, var12 * 0.9);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, 3.2 * var14, 3137648, var12 * 0.35);
      Parts.ring(var0, var4, var6 + 0.07, var8, 0.5 + var10 * 5.5 * var14, 12124002, (1.0 - var10) * 0.95);
      Parts.ring(var0, var4, var6 + 0.08, var8, 0.4 + Math.max(0.0, var10 - 0.18) * 5.0 * var14, 16767050, Math.max(0.0, (1.0 - var10) * 0.7));
      double var18 = 0.35 + 0.65 * var16 + 0.05 * Math.sin(var2 * 0.3);
      Geo.billboard(var0.q, Tex.SPROUT, var4, var6 + 0.2 + var18 * 0.9, var8, var18 * 0.95, 0.0, Col.mul(12124002, var12 * 0.85));
      Parts.spark(var0, var4, var6 + 0.9 + var18 * 0.2, var8, 1.6 * var18, 3137648, var12 * 0.35);
      Parts.column(var0, var4, var6, var8, 0.6, 3.8 * var16, 12124002, var12 * 0.3, var2 * 0.05, 14221264, var12 * 0.15);

      for (int var20 = 0; var20 < 2; var20++) {
         Parts.helix(
            var0,
            Tex.RIBBON_SOFT,
            var4,
            var6,
            var8,
            1.3 * var14,
            0.45 * var14,
            3.6 * var16,
            2.0,
            var2 * 0.22 + var20 * Math.PI,
            0.3,
            var20 == 0 ? 12124002 : 16767050,
            var12,
            16,
            0.0,
            1.0,
            -var2 * 0.08
         );
      }

      for (int var27 = 0; var27 < 9; var27++) {
         double var21 = (var2 * 0.04 + Geo.hash(var27, 1)) % 1.0;
         double var23 = Geo.hash(var27, 2) * (Math.PI * 2) + var2 * 0.08;
         double var25 = (0.5 + Geo.hash(var27, 3) * 2.2) * var14;
         Parts.leaf(
            var0,
            var27 & 3,
            var4 + Math.cos(var23) * var25,
            var6 + 0.2 + var21 * 3.4,
            var8 + Math.sin(var23) * var25,
            0.24,
            var2 * 0.25 + var27,
            var27 % 3 == 0 ? 16767050 : 12124002,
            var12 * Math.sin(var21 * Math.PI)
         );
      }
   }

   private static void rage(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = var1.sc;
      double var14 = Geo.fadeIO(var10, 0.07, 0.2);
      double var16 = 3.6 * var12;
      Parts.rune(var0, Tex.RUNE_RAGE, var4, var6 + 0.05, var8, var16, var2 * 0.1, 16722490, var14);
      Parts.rune(var0, Tex.CRACK, var4, var6 + 0.06, var8, var16 * 0.95, 0.4, 14684208, var14 * 0.85);
      Parts.rune(var0, Tex.CRACK, var4, var6 + 0.065, var8, var16 * 0.8, 2.1, 16747040, var14 * 0.55);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var16 * 1.1, 8000024, var14 * 0.7);
      Parts.ring(var0, var4, var6 + 0.08, var8, var16 * (0.5 + 1.2 * Math.min(1.0, var2 / 25.0)), 16722490, (1.0 - Math.min(1.0, var2 / 25.0)) * 0.9);
      Parts.column(var0, var4, var6, var8, 1.1, 5.2, 16722490, var14 * 0.7, var2 * 0.14, 16747040, var14 * 0.5);

      for (int var18 = 0; var18 < 12; var18++) {
         double var19 = (Math.PI * 2) * var18 / 12.0 + Geo.hash(var18, 1) * 0.4;
         double var21 = (1.2 + Geo.hash(var18, 2) * 2.0) * var12;
         double var23 = (1.8 + Geo.hash(var18, 3) * 1.8) * (0.75 + 0.25 * Math.sin(var2 * 0.4 + var18 * 2.1)) * (0.4 + 0.6 * Geo.sstep(0.0, 0.15, var10));
         double var25 = Math.cos(var19) * 0.35;
         double var27 = Math.sin(var19) * 0.35;
         Geo.standing(
            var0.q,
            Tex.SPIKE,
            var4 + Math.cos(var19) * var21,
            var6,
            var8 + Math.sin(var19) * var21,
            var19 + 0.7,
            0.34,
            var23,
            var25,
            var27,
            2,
            Col.mul(16747040, var14),
            Col.mul(14684208, var14 * 0.6),
            0.0,
            0.0,
            1.0,
            1.0
         );
      }

      for (int var29 = 0; var29 < 3; var29++) {
         Parts.helix(
            var0,
            Tex.RIBBON_THORN,
            var4,
            var6,
            var8,
            2.1 * var12,
            0.7 * var12,
            4.6,
            1.8,
            var2 * 0.27 + var29 * (Math.PI * 2) / 3.0,
            0.5,
            var29 == 0 ? 16747040 : 16722490,
            var14,
            18,
            0.0,
            1.0,
            -var2 * 0.18
         );
      }

      for (int var30 = 0; var30 < 6; var30++) {
         double var32 = (Math.PI * 2) * var30 / 6.0 + var2 * 0.05;
         Geo.flameSprite(
            var0.q,
            var4 + Math.cos(var32) * 1.3 * var12,
            var6 + 0.05,
            var8 + Math.sin(var32) * 1.3 * var12,
            0.6,
            1.5 + 0.3 * Math.sin(var2 * 0.5 + var30),
            (int)(var2 * 0.9) + var30 * 5,
            Col.mul(Col.mix(16777215, 16722490, 0.45), var14 * 0.9)
         );
      }

      for (int var31 = 0; var31 < 7; var31++) {
         double var33 = Geo.hash(var31, 4) * (Math.PI * 2) + var2 * 0.02;
         double var34 = Geo.hash(var31, 5) * 3.5 * var12;
         Parts.flare(
            var0,
            var4 + Math.cos(var33) * var34,
            var6 + 0.8 + Geo.hash(var31, 6) * 3.0,
            var8 + Math.sin(var33) * var34,
            0.5 + 0.3 * Geo.hash(var31, 7),
            var2 * 0.1,
            16722490,
            var14 * Math.abs(Math.sin(var2 * 0.2 + var31 * 1.3)),
            false
         );
      }
   }

   private static void stealth(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = Geo.fadeIO(var10, 0.1, 0.4);
      double var14 = 2.4 * (1.0 - var10) + 0.2;
      Geo.disc(var0.q, Tex.SWIRL, var4, var6 + 0.06, var8, 2.0 * (1.1 - var10 * 0.4), var2 * 0.35, Col.mul(9141759, var12 * 0.85));
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.05, var8, 1.8, -var2 * 0.12, 5913855, var12 * 0.8);

      for (int var16 = 0; var16 < 3; var16++) {
         Parts.helix(
            var0,
            Tex.RIBBON_WISP,
            var4,
            var6,
            var8,
            var14 * 1.1,
            var14 * 0.5,
            2.5,
            1.5,
            var2 * 0.5 + var16 * (Math.PI * 2) / 3.0,
            0.5,
            var16 == 0 ? 5913855 : 9141759,
            var12,
            14,
            0.0,
            1.0,
            var2 * 0.1
         );
      }

      for (int var23 = 0; var23 < 4; var23++) {
         double var17 = (Math.PI * 2) * var23 / 4.0 + var2 * 0.2;
         double var19 = (var2 * 0.07 + var23 * 0.25) % 1.0;
         Geo.billboard(
            var0.q,
            Tex.SWIRL,
            var4 + Math.cos(var17) * (0.5 + var19 * 1.8),
            var6 + 0.6 + var19 * 1.4,
            var8 + Math.sin(var17) * (0.5 + var19 * 1.8),
            0.7 + var19 * 0.9,
            var2 * 0.1 + var23,
            Col.mul(5913855, var12 * (1.0 - var19) * 0.8)
         );
      }

      double var24 = Geo.sstep(0.0, 0.2, var10) * (1.0 - Geo.sstep(0.5, 0.85, var10));
      Geo.billboard(var0.q, Tex.EYE, var4, var6 + 2.7 + 0.15 * Math.sin(var2 * 0.3), var8, 0.55, 0.0, Col.mul(9141759, var24));
      Parts.flare(var0, var4, var6 + 2.7, var8, 1.5, var2 * 0.1, 5913855, var24 * 0.6, false);

      for (int var18 = 0; var18 < 6; var18++) {
         double var25 = Geo.hash(var18, 1) * (Math.PI * 2) + var2 * 0.1;
         double var21 = Geo.hash(var18, 2) * 1.8;
         Parts.flare(
            var0,
            var4 + Math.cos(var25) * var21,
            var6 + 0.4 + Geo.hash(var18, 3) * 2.0,
            var8 + Math.sin(var25) * var21,
            0.35,
            var2 * 0.1,
            9141759,
            var12 * Math.abs(Math.sin(var2 * 0.3 + var18 * 2)),
            false
         );
      }
   }

   private static void ascend(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = var1.sc;
      double var14 = Geo.fadeIO(var10, 0.08, 0.2);
      double var16 = Geo.sstep(0.0, 0.5, var10);
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, 6.0 * var12, var2 * 0.036, 12124002, var14);
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var6 + 0.07, var8, 3.8 * var12, -var2 * 0.06, 16767050, var14 * 0.7);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, 6.5 * var12, 3137648, var14 * 0.32);
      Parts.ring(var0, var4, var6 + 0.08, var8, 6.1 * var12, 14221264, var14 * 0.8);
      double var18 = 9.5 * var16;
      double var20 = 4.8 * var16;
      Geo.standing(
         var0.q,
         Tex.TREE,
         var4,
         var6 - 0.1,
         var8,
         var2 * 0.008,
         var20,
         var18,
         0.0,
         0.0,
         3,
         Col.mul(14221264, var14 * 0.8),
         Col.mul(12124002, var14 * 0.95),
         0.0,
         0.0,
         1.0,
         1.0
      );
      Parts.column(var0, var4, var6, var8, 1.6, 10.0 * var16, 16767050, var14 * 0.32, var2 * 0.05, 16777215, var14 * 0.25);

      for (int var22 = 0; var22 < 3; var22++) {
         Parts.helix(
            var0,
            Tex.RIBBON_SOFT,
            var4,
            var6,
            var8,
            5.6 * var12,
            1.2 * var12,
            9.5 * var16,
            2.0,
            var2 * 0.2 + var22 * (Math.PI * 2) / 3.0,
            0.55,
            var22 == 1 ? 16767050 : 12124002,
            var14,
            26,
            0.0,
            1.0,
            var2 * 0.05
         );
      }

      for (int var29 = 0; var29 < 16; var29++) {
         double var23 = (var2 * 0.03 + Geo.hash(var29, 1)) % 1.0;
         double var25 = Geo.hash(var29, 2) * (Math.PI * 2) + var2 * 0.07;
         double var27 = (1.0 + Geo.hash(var29, 3) * 5.0) * var12;
         Parts.leaf(
            var0,
            var29 & 3,
            var4 + Math.cos(var25) * var27,
            var6 + 10.0 * var16 - var23 * 10.0 * var16 + 0.2,
            var8 + Math.sin(var25) * var27,
            0.34,
            var2 * 0.2 + var29,
            var29 % 4 == 0 ? 16767050 : 12124002,
            var14 * Math.sin(var23 * Math.PI)
         );
      }

      for (int var30 = 0; var30 < 8; var30++) {
         double var31 = Geo.hash(var30, 7) * (Math.PI * 2);
         double var32 = Geo.hash(var30, 8) * 5.0;
         Parts.flare(
            var0,
            var4 + Math.cos(var31) * var32,
            var6 + 1.0 + Geo.hash(var30, 9) * 8.0,
            var8 + Math.sin(var31) * var32,
            0.5,
            var2 * 0.1,
            16767050,
            var14 * Math.abs(Math.sin(var2 * 0.15 + var30)),
            false
         );
      }
   }

   private static void annihilation(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var1.ticks;
      double var12 = var2 / var10;
      double var14 = 12.0F * var1.sc;
      double var16 = var10 - 12.0;
      double var18 = Geo.sstep(0.0, 12.0, var2) * (1.0 - Geo.sstep(var10 - 3.0, var10 + 2.0, var2) * 0.0);
      if (var2 >= var16) {
         double var10000 = Geo.sstep(var16, var16 + 2.0, var2) * (1.0 - Geo.sstep(var10 - 4.0, var10, var2)) * 0.0 + 1.0;
      } else {
         double var51 = 0.0;
      }

      Parts.rune(var0, Tex.RUNE_GOLD, var4, var6 + 0.05, var8, var14, var2 * 0.03, 16767050, var18);
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var6 + 0.07, var8, var14 * 0.62, -var2 * 0.045, 16752688, var18 * 0.85);
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.09, var8, var14 * 0.3, var2 * 0.08, 16777215, var18 * 0.7);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var14 * 1.1, 16752688, var18 * 0.3);
      Parts.ring(var0, var4, var6 + 0.1, var8, var14 * 0.97, 16767050, var18 * 0.9);
      double var22 = var6 + 9.5;
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var22, var8, var14 * 0.78, -var2 * 0.04, 16767050, var18 * 0.9);
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var22 + 0.05, var8, var14 * 0.45, var2 * 0.06, 16777215, var18 * 0.6);
      Parts.ring(var0, var4, var22 + 0.1, var8, var14 * 0.75, 16752688, var18 * 0.9);
      Parts.column(var0, var4, var6, var8, 1.4, 9.5, 16767050, var18 * (0.45 + 0.4 * Geo.sstep(var16 - 10.0, var16, var2)), var2 * 0.07, 16777215, var18 * 0.5);
      int var24 = var0.n(20, 10);

      for (int var25 = 0; var25 < var24; var25++) {
         double var26 = (Math.PI * 2) * var25 / var24;
         double var28 = var14 * 0.72 + var25 % 2 * var14 * 0.1;
         double var30 = 8.0 + (var16 - 14.0) * (0.15 + 0.85 * Geo.hash(var25, 1));
         double var32 = 6.0;
         double var34 = var2 - (var30 - var32);
         if (!(var34 < 0.0)) {
            double var36 = Math.min(1.0, var34 / var32);
            double var38 = var4 + Math.cos(var26) * var28;
            double var40 = var8 + Math.sin(var26) * var28;
            double var42 = var6 + 0.25 + (1.0 - var36 * var36) * 22.0;
            double var44 = 5.4;
            double var46 = 0.9 + 0.1 * Math.sin(var2 * 0.3 + var25);
            Geo.oriented(
               var0.q, Tex.SWORD, var38, var42 + var44, var40, 0.0, -1.0, 0.0, var44, 0.62, 2, var26, Col.mul(16767050, 0.55 * var46), Col.mul(16777215, var46)
            );
            if (var36 >= 1.0) {
               double var48 = Math.min(1.0, (var34 - var32) / 8.0);
               Parts.shaft(var0, var38, var6 + 4.5, var40, 0.35, 12.0, 16767050, var46 * 0.55, var26);
               if (var48 < 1.0) {
                  Parts.ring(var0, var38, var6 + 0.12, var40, 0.4 + var48 * 2.2, 16767050, 1.0 - var48);
                  Parts.flare(var0, var38, var6 + 0.6, var40, 2.0 * (1.0 - var48) + 0.4, var26, 16777215, 1.0 - var48, true);
               }
            } else {
               Geo.standing(var0.q, Tex.BEAM_CORE, var38, var42 + var44, var40, var26, 0.25, 12.0, 2, Col.mul(16767050, 0.7), Col.mul(16767050, 0.0));
            }
         }
      }

      if (var2 >= var16) {
         double var50 = (var2 - var16) / 12.0;
         Parts.flare(var0, var4, var6 + 2.5, var8, 14.0 * (1.0 - var50 * 0.5), var2 * 0.05, 16777215, 1.0 - var50 * 0.8, true);
         Parts.flare(var0, var4, var6 + 2.5, var8, 18.0 * (1.0 - var50 * 0.4), var2 * 0.05 + 0.4, 16767050, (1.0 - var50) * 0.9, false);
         Parts.ring(var0, var4, var6 + 0.3, var8, 2.0 + (var2 - var16) * 2.4, 16767050, 1.0 - var50);
         Parts.ring(var0, var4, var6 + 0.32, var8, 1.0 + (var2 - var16) * 1.6, 16777215, (1.0 - var50) * 0.9);
         Parts.column(var0, var4, var6, var8, 2.6 * (1.0 - var50 * 0.5), 26.0, 16777215, (1.0 - var50) * 0.9, var2 * 0.2, 16777215, 1.0 - var50);
      }
   }

   private static void chrono(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var2 / var1.ticks;
      double var12 = var1.sc;
      double var14 = Geo.fadeIO(var10, 0.1, 0.16);
      double var16 = Math.toRadians(var1.yaw);
      double var18 = -Math.sin(var16);
      double var20 = Math.cos(var16);
      double var22 = Math.cos(var16);
      double var24 = Math.sin(var16);
      double var26 = 3.0 * var12;
      double var28 = var4 - var18 * 1.4;
      double var30 = var6 + 3.2;
      double var32 = var8 - var20 * 1.4;
      double var34 = 1.0 + Math.min(1.0, var10 / 0.6);
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.05, var8, 4.5 * var12 * var34, -var2 * 0.06, 10276863, var14 * 0.9);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, 5.0 * var12 * var34, 5913855, var14 * 0.35);

      for (int var36 = 0; var36 < 2; var36++) {
         double var37 = (var2 * 0.045 + var36 * 0.5) % 1.0;
         Parts.ring(var0, var4, var6 + 0.08, var8, (1.0 + var37 * 8.0) * var34, 13625087, (1.0 - var37) * var14 * 0.9);
      }

      Geo.plane(var0.q, Tex.CLOCK, var28, var30, var32, var22 * var26, 0.0, var24 * var26, 0.0, var26, 0.0, Col.mul(10276863, var14 * 0.95), 0.0, 0.0, 1.0, 1.0);
      Geo.plane(
         var0.q,
         Tex.RUNE_MOON,
         var28 - var18 * 0.05,
         var30,
         var32 - var20 * 0.05,
         var22 * var26 * 1.4,
         0.0,
         var24 * var26 * 1.4,
         0.0,
         var26 * 1.4,
         0.0,
         Col.mul(5913855, var14 * 0.55),
         0.0,
         0.0,
         1.0,
         1.0
      );
      double var47 = var2 * 0.05;
      Geo.plane(
         var0.q,
         Tex.RUNE_MOON,
         var28 + var18 * 0.04,
         var30,
         var32 + var20 * 0.04,
         var22 * Math.cos(var47) * var26 * 0.5,
         Math.sin(var47) * var26 * 0.5,
         var24 * Math.cos(var47) * var26 * 0.5,
         -(var22 * Math.sin(var47)) * var26 * 0.5,
         Math.cos(var47) * var26 * 0.5,
         -(var24 * Math.sin(var47)) * var26 * 0.5,
         Col.mul(13625087, var14 * 0.5),
         0.0,
         0.0,
         1.0,
         1.0
      );
      double var38 = -var2 * 0.55 + 2.0;
      double var40 = -var2 * 0.07 + 1.0;
      hand(var0, var28 + var18 * 0.06, var30, var32 + var20 * 0.06, var22, var24, var38, var26 * 0.86, 0.16 * var12, Col.mul(16777215, var14));
      hand(var0, var28 + var18 * 0.07, var30, var32 + var20 * 0.07, var22, var24, var40, var26 * 0.56, 0.2 * var12, Col.mul(9141759, var14));
      Parts.flare(var0, var28, var30, var32, 1.5, var2 * 0.04, 16777215, var14 * 0.7, false);

      for (int var42 = 0; var42 < 8; var42++) {
         double var43 = Geo.hash(var42, 1) * (Math.PI * 2) + var2 * 0.03;
         double var45 = 2.5 + Geo.hash(var42, 2) * 3.5;
         Parts.flare(
            var0,
            var4 + Math.cos(var43) * var45,
            var6 + 1.0 + Geo.hash(var42, 3) * 4.5 + Math.sin(var2 * 0.1 + var42) * 0.2,
            var8 + Math.sin(var43) * var45,
            0.6,
            var43,
            10276863,
            var14 * (0.4 + 0.6 * Math.abs(Math.sin(var2 * 0.1 + var42 * 1.7))),
            true
         );
      }
   }

   private static void hand(Ctx var0, double var1, double var3, double var5, double var7, double var9, double var11, double var13, double var15, int var17) {
      double var18 = Math.sin(var11) * var7;
      double var20 = Math.cos(var11);
      double var22 = Math.sin(var11) * var9;
      double var24 = Math.cos(var11) * var7;
      double var26 = -Math.sin(var11);
      double var28 = Math.cos(var11) * var9;
      Geo.plane(
         var0.q,
         Tex.HAND,
         var1 + var18 * var13 / 2.0,
         var3 + var20 * var13 / 2.0,
         var5 + var22 * var13 / 2.0,
         var24 * var15,
         var26 * var15,
         var28 * var15,
         -var18 * var13 / 2.0,
         -var20 * var13 / 2.0,
         -var22 * var13 / 2.0,
         var17,
         0.0,
         0.0,
         1.0,
         1.0
      );
   }

   private static void ricochet(Ctx var0, FxInst var1, double var2) {
      double var4 = var2 / var1.ticks;
      double var6 = 1.0 - Geo.sstep(0.3, 1.0, var4);
      double var8 = var1.sc;
      double var10 = var1.x;
      double var12 = var1.y;
      double var14 = var1.z;
      Parts.flare(var0, var10, var12, var14, 1.9 * var8 * (1.1 - 0.4 * var4), var2 * 0.3, 16777215, var6, true);
      Parts.flare(var0, var10, var12, var14, 2.6 * var8 * (0.7 + 0.5 * var4), var2 * 0.2 + 0.785, 10276863, var6 * 0.85, false);
      Parts.ringBB(var0, var10, var12, var14, 0.3 + var4 * 2.4 * var8, 9141759, 1.0 - var4);
      Parts.spark(var0, var10, var12, var14, 2.4, 5913855, var6 * 0.7);

      for (int var16 = 0; var16 < 6; var16++) {
         double var17 = Geo.hash(var16, 1) * (Math.PI * 2);
         double var19 = (Geo.hash(var16, 2) - 0.5) * 2.4;
         double var21 = (0.9 + Geo.hash(var16, 3) * 1.1) * var8 * (0.4 + var4);
         Geo.oriented(
            var0.q,
            Tex.SPIKE,
            var10,
            var12,
            var14,
            Math.cos(var17) * Math.cos(var19),
            Math.sin(var19),
            Math.sin(var17) * Math.cos(var19),
            var21,
            0.09,
            2,
            var16,
            Col.mul(16777215, var6),
            Col.mul(10276863, 0.0)
         );
      }

      if (var1.hasLink) {
         double var41 = var10 - var1.lx;
         double var18 = var12 - var1.ly;
         double var20 = var14 - var1.lz;
         double var22 = Math.sqrt(var41 * var41 + var18 * var18 + var20 * var20);
         if (var22 > 0.5 && var22 < 40.0) {
            int var24 = var0.n(12, 6);
            double[] var25 = new double[var24];
            double[] var26 = new double[var24];
            double[] var27 = new double[var24];
            double[] var28 = new double[var24];
            int[] var29 = new int[var24];
            double[] var30 = new double[3];
            double[] var31 = new double[3];
            Geo.basis(var41, var18, var20, var30, var31);
            double var32 = Math.min(1.0, var2 / 3.0);

            for (int var34 = 0; var34 < var24; var34++) {
               double var35 = (double)var34 / (var24 - 1);
               double var37 = var35 * var32;
               double var39 = Math.sin(var35 * Math.PI) * 0.35 * (Geo.hash(var34, var1.seed) - 0.5) * 2.0 * (1.0 - var4);
               var25[var34] = var1.lx + var41 * var37 + var30[0] * var39;
               var26[var34] = var1.ly + var18 * var37 + var30[1] * var39 + var31[1] * var39 * 0.5;
               var27[var34] = var1.lz + var20 * var37 + var30[2] * var39;
               var28[var34] = 0.3 * (1.0 - var4 * 0.7) * (0.35 + 0.65 * Math.sin(var35 * Math.PI));
               var29[var34] = Col.mul(Col.mix(10276863, 16777215, var35), (1.0 - var4) * (0.6 + 0.4 * var35));
            }

            Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var25, var26, var27, var28, var29, var24, -var2 * 0.3, -var2 * 0.3 + 2.0);
         }
      }
   }

   private static void world(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var1.ticks;
      double var12 = var2 / var10;
      double var14 = var1.sc;
      double var16 = Geo.fadeIO(var12, 0.06, 0.1);
      double var18 = Geo.sstep(0.0, 0.3, var12);
      double var20 = 14.0 * var14 * Math.min(1.0, var2 / 30.0);
      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, var20, var2 * 0.02, 6750059, var16);
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var6 + 0.07, var8, var20 * 0.6, -var2 * 0.03, 16767050, var16 * 0.6);
      Parts.rune(var0, Tex.CRACK, var4, var6 + 0.06, var8, var20 * 0.95, 0.3, 7332095, var16 * 0.8);
      Parts.rune(var0, Tex.CRACK, var4, var6 + 0.065, var8, var20 * 0.9, 1.9, 12124002, var16 * 0.65);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var20 * 1.05, 3137648, var16 * 0.3);
      Parts.ring(var0, var4, var6 + 0.09, var8, var20 * 0.98, 14221264, var16 * 0.8);
      double var22 = 15.0 * var18;
      double var24 = 8.0 * var18;
      Geo.standing(
         var0.q,
         Tex.TREE,
         var4,
         var6 - 0.2,
         var8,
         var2 * 0.006,
         var24,
         var22,
         0.0,
         0.0,
         3,
         Col.mul(7332095, var16 * 0.7),
         Col.mul(12124002, var16 * 0.95),
         0.0,
         0.0,
         1.0,
         1.0
      );
      Geo.standing(
         var0.q,
         Tex.TREE,
         var4,
         var6 - 0.2,
         var8,
         var2 * 0.006 + 0.5,
         var24 * 0.7,
         var22 * 0.7,
         0.0,
         0.0,
         2,
         Col.mul(14221264, var16 * 0.4),
         Col.mul(14221264, var16 * 0.4),
         0.0,
         0.0,
         1.0,
         1.0
      );
      Parts.column(var0, var4, var6, var8, 1.8, 18.0 * var18, 7332095, var16 * 0.38, var2 * 0.06, 16777215, var16 * 0.3);
      int var26 = var0.n(14, 7);

      for (int var27 = 0; var27 < var26; var27++) {
         double var28 = (Math.PI * 2) * var27 / var26 + Geo.hash(var27, 1) * 0.4;
         double var30 = (4.0 + Geo.hash(var27, 2) * 9.0) * var14;
         double var32 = 0.35 + 0.65 * Math.abs(Math.sin(var2 * 0.07 + var27 * 1.9));
         Parts.shaft(
            var0,
            var4 + Math.cos(var28) * var30,
            var6,
            var8 + Math.sin(var28) * var30,
            0.5,
            16.0,
            var27 % 3 == 0 ? 16767050 : 7332095,
            var16 * var32 * var18,
            var28
         );
      }

      for (int var35 = 0; var35 < 24; var35++) {
         double var37 = (var2 * 0.022 + Geo.hash(var35, 1)) % 1.0;
         double var38 = Geo.hash(var35, 2) * (Math.PI * 2) + var2 * 0.04;
         double var40 = (1.0 + Geo.hash(var35, 3) * 10.0) * var14;
         Parts.leaf(
            var0,
            var35 & 3,
            var4 + Math.cos(var38) * var40,
            var6 + 13.0 * var18 - var37 * 13.0 * var18 + 0.2,
            var8 + Math.sin(var38) * var40,
            0.4,
            var2 * 0.2 + var35,
            var35 % 4 == 0 ? 16767050 : 12124002,
            var16 * Math.sin(var37 * Math.PI) * var18
         );
      }

      if (var2 >= var10 - 30.0) {
         double var36 = (var2 - (var10 - 30.0)) / 30.0;

         for (int var29 = 0; var29 < 4; var29++) {
            double var39 = ((var2 - (var10 - 30.0)) / 6.0 - var29 * 0.0) % 1.0;
            int var41 = (int)((var2 - (var10 - 30.0)) / 6.0) - var29;
            if (var41 >= 0) {
               double var33 = (var2 - (var10 - 30.0) - var41 * 6) / 24.0;
               if (!(var33 > 1.0)) {
                  Parts.ring(var0, var4, var6 + 0.3 + var29 * 0.01, var8, 3.0 + var33 * 13.0 * var14, 16767050, (1.0 - var33) * 0.95);
               }
            }
         }

         Parts.flare(var0, var4, var6 + 14.0 * var18, var8, 6.0 + 5.0 * var36, var2 * 0.05, 16767050, 0.6 * (1.0 - var36 * 0.5), true);
      }
   }

   private static void transcend(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var1.ticks;
      double var12 = var2 / var10;
      double var14 = Geo.fadeIO(var12, 0.05, 0.06);
      double var16 = 3.0 + var12 * 4.0;
      Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.05, var8, var16, var2 * 0.07, 9141759, var14);
      Parts.rune(var0, Tex.RUNE_GOLD, var4, var6 + 0.07, var8, var16 * 0.6, -var2 * 0.1, 16777215, var14 * 0.55);
      Parts.glowDisc(var0, var4, var6 + 0.04, var8, var16 * 1.1, 5913855, var14 * 0.45);
      Parts.ring(var0, var4, var6 + 0.09, var8, var16 * 0.98, 10276863, var14 * 0.8);
      Parts.column(
         var0,
         var4,
         var6,
         var8,
         0.9 + var12 * 0.7,
         7.0 + var12 * 8.0,
         10276863,
         var14 * (0.35 + 0.45 * var12),
         var2 * 0.1,
         16777215,
         var14 * (0.3 + 0.5 * var12)
      );
      Parts.Centre var18 = (var6x, var8x) -> {
         var8x[0] = var4;
         var8x[1] = var6;
         var8x[2] = var8;
      };

      for (int var19 = 0; var19 < 3; var19++) {
         double var20 = (1.6 + 2.4 * var12) * (1.0 + 0.18 * var19);
         Parts.orbit(
            var0,
            Tex.RIBBON_WISP,
            var18,
            1.2 + var19 * 0.35,
            var20,
            var20 * 0.9,
            0.35 + var19 * 0.4,
            var19 * 1.1,
            var2 * (0.13 + 0.03 * var19) * (var19 % 2 == 0 ? 1 : -1) + var19,
            var19 % 2 == 0 ? 1.0 : -1.0,
            2.4,
            7.5,
            0.55,
            var19 == 1 ? 16777215 : 9141759,
            16777215,
            var14,
            28,
            0.2,
            var2 * 0.1
         );
      }

      for (int var27 = 0; var27 < 8; var27++) {
         double var29 = (Math.PI * 2) * var27 / 8.0 + var2 * 0.02;
         double var22 = 1.8 + var12 * 1.4 + var27 % 2 * 0.9;
         Parts.shaft(
            var0,
            var4 + Math.cos(var29) * var22,
            var6,
            var8 + Math.sin(var29) * var22,
            0.22,
            6.0 + Geo.hash(var27, 1) * 6.0 * (0.4 + var12),
            var27 % 2 == 0 ? 10276863 : 16777215,
            var14 * (0.5 + 0.5 * Math.abs(Math.sin(var2 * 0.1 + var27))),
            var29
         );
      }

      int var28 = (int)(6.0 + var12 * 10.0);

      for (int var30 = 0; var30 < var28; var30++) {
         double var21 = Geo.hash(var30, 2) * (Math.PI * 2) + var2 * 0.03;
         double var23 = 0.8 + Geo.hash(var30, 3) * (2.0 + 2.0 * var12);
         double var25 = (var2 * 0.03 + Geo.hash(var30, 4)) % 1.0;
         Parts.flare(
            var0,
            var4 + Math.cos(var21) * var23,
            var6 + 0.3 + var25 * 4.5,
            var8 + Math.sin(var21) * var23,
            0.5 + 0.4 * Geo.hash(var30, 5),
            var2 * 0.08 + var30,
            16777215,
            var14 * Math.sin(var25 * Math.PI),
            false
         );
      }

      if (var2 >= var10 - 12.0) {
         double var31 = (var2 - (var10 - 12.0)) / 12.0;
         Parts.flare(var0, var4, var6 + 1.5, var8, 3.0 + var31 * 8.0, var2 * 0.1, 16777215, 1.0 - var31 * 0.7, true);
         Parts.flare(var0, var4, var6 + 1.5, var8, 5.0 + var31 * 9.0, var2 * 0.1 + 0.4, 10276863, (1.0 - var31) * 0.9, false);
         Parts.ring(var0, var4, var6 + 0.3, var8, var31 * 14.0, 16777215, 1.0 - var31);
         Parts.ring(var0, var4, var6 + 0.32, var8, var31 * 9.0, 10276863, 1.0 - var31);
      }
   }

   private SkillMeshes() {
   }
}
