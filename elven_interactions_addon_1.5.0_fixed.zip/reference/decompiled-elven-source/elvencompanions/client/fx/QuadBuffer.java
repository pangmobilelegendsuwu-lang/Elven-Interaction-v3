package com.elvencompanions.client.fx;

import java.util.Arrays;

public final class QuadBuffer {
   public static final int MAX_QUADS = 7000;
   public static final int STRIDE = 5;
   public final QuadBuffer.Batch[] batches = new QuadBuffer.Batch[Tex.COUNT];
   public double ox;
   public double oy;
   public double oz;
   public int quads;
   private QuadBuffer.Batch cur;
   private int inQuad;

   public QuadBuffer() {
      for (int var1 = 0; var1 < this.batches.length; var1++) {
         this.batches[var1] = new QuadBuffer.Batch();
      }
   }

   public void reset(double var1, double var3, double var5) {
      for (QuadBuffer.Batch var10 : this.batches) {
         var10.n = 0;
      }

      this.ox = var1;
      this.oy = var3;
      this.oz = var5;
      this.quads = 0;
      this.cur = null;
      this.inQuad = 0;
   }

   public boolean full() {
      return this.quads >= 7000;
   }

   public void begin(Tex var1) {
      this.cur = this.quads >= 7000 ? null : this.batches[var1.ordinal()];
      this.inQuad = 0;
   }

   public void v(double var1, double var3, double var5, double var7, double var9, int var11) {
      QuadBuffer.Batch var12 = this.cur;
      if (var12 != null) {
         if (var12.n + 5 > var12.d.length) {
            var12.d = Arrays.copyOf(var12.d, var12.d.length * 2);
            var12.c = Arrays.copyOf(var12.c, var12.c.length * 2);
         }

         float[] var13 = var12.d;
         int var14 = var12.n;
         var12.c[var14 / 5] = var11;
         var13[var14] = (float)(var1 - this.ox);
         var13[var14 + 1] = (float)(var3 - this.oy);
         var13[var14 + 2] = (float)(var5 - this.oz);
         var13[var14 + 3] = (float)var7;
         var13[var14 + 4] = (float)var9;
         var12.n += 5;
         if (++this.inQuad == 4) {
            this.inQuad = 0;
            this.quads++;
            if (this.quads >= 7000) {
               this.cur = null;
            }
         }
      }
   }

   public static final class Batch {
      public float[] d = new float[2560];
      public int[] c = new int[512];
      public int n;
   }
}
