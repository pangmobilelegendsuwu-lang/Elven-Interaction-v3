package com.elvencompanions.client.fx;

public final class Ctx {
   public final QuadBuffer q;
   public double time;
   public double clock;
   public double den = 1.0;

   public Ctx(QuadBuffer var1) {
      this.q = var1;
   }

   public int n(int var1, int var2) {
      return Math.max(var2, (int)Math.round(var1 * (0.45 + 0.55 * this.den)));
   }
}
