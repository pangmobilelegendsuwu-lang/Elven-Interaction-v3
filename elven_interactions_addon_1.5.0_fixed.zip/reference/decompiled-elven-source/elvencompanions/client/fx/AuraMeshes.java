package com.elvencompanions.client.fx;

public final class AuraMeshes {
   public static void render(Ctx var0, AuraState var1, double var2) {
      double var4 = var1.tick + var2;
      var0.time = var4;
      double var6 = var1.lifeAt(var2) * Geo.sstep(0.0, 10.0, var1.tick + var2);
      if (!(var6 <= 0.02)) {
         double[] var8 = new double[3];
         var1.posAt(0.0, var2, var8);
         switch (var1.kind) {
            case 1:
               rage(var0, var1, var2, var4, var8[0], var8[1], var8[2], var6);
               break;
            case 2:
               transcend(var0, var1, var2, var4, var8[0], var8[1], var8[2], var6);
               break;
            default:
               normal(var0, var1, var2, var4, var8[0], var8[1], var8[2], var6);
         }
      }
   }

   private static void orbitPt(AuraState var0, double var1, double var3, double var5, double var7, double var9, double var11, double var13, double[] var15) {
      var0.posAt(var13, var1, var15);
      double var16 = Math.cos(var11) * var5;
      double var18 = Math.sin(var11) * var5;
      double var20 = Math.cos(var7);
      double var22 = Math.sin(var7);
      double var24 = Math.cos(var9);
      double var26 = Math.sin(var9);
      double var28 = -var18 * var22;
      double var30 = var18 * var20;
      var15[0] += var16 * var24 + var30 * var26;
      var15[1] += var3 + var28;
      var15[2] += -var16 * var26 + var30 * var24;
   }

   private static void normal(Ctx var0, AuraState var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      Parts.rune(var0, Tex.RUNE_NATURE, var6, var8 + 0.04, var10, 1.9, var4 * 0.02, 6750059, var12 * 0.8);
      Parts.rune(var0, Tex.RUNE_NATURE, var6, var8 + 0.045, var10, 1.05, -var4 * 0.04, 12124002, var12 * 0.55);
      Parts.glowDisc(var0, var6, var8 + 0.03, var10, 1.7, 3137648, var12 * 0.3);
      double var14 = var4 * 0.035 % 1.0;
      Parts.ring(var0, var6, var8 + 0.06, var10, 0.8 + var14 * 1.7, 12124002, (1.0 - var14) * 0.65 * var12);
      Parts.Centre var16 = (var3, var5) -> var1.posAt(var3, var2, var5);
      double[] var17 = new double[]{0.38, -0.62, 0.95};
      double[] var18 = new double[]{0.0, 2.1, 4.2};
      double[] var19 = new double[]{0.15, -0.12, 0.1};
      int[] var20 = new int[]{12124002, 6750059, 14221264};
      double[] var21 = new double[]{1.2, 1.45, 1.0};
      double[] var22 = new double[]{1.25, 1.0, 1.55};
      double[] var23 = new double[3];

      for (int var24 = 0; var24 < 3; var24++) {
         double var25 = var4 * var19[var24] + var24 * 2.0;
         double var27 = Math.signum(var19[var24]);
         Parts.orbit(
            var0,
            Tex.RIBBON_SOFT,
            var16,
            var22[var24],
            var21[var24],
            var21[var24],
            var17[var24],
            var18[var24],
            var25,
            var27,
            3.4,
            1.0 / Math.abs(var19[var24]),
            0.52,
            var20[var24],
            14221264,
            var12,
            28,
            0.12,
            var4 * 0.05
         );

         for (int var29 = 0; var29 < 3; var29++) {
            double var30 = 0.35 + var29 * 0.9;
            double var32 = var25 - var27 * var30;
            orbitPt(var1, var2, var22[var24], var21[var24], var17[var24], var18[var24], var32, var30 / Math.abs(var19[var24]), var23);
            Parts.leaf(
               var0,
               var24 + var29 & 3,
               var23[0],
               var23[1] + 0.05,
               var23[2],
               0.2 - var29 * 0.03,
               var4 * 0.2 + var24 * 3 + var29,
               var20[var24],
               var12 * (1.0 - var29 * 0.25)
            );
         }
      }

      Parts.helix(var0, Tex.RIBBON_WISP, var6, var8, var10, 1.0, 0.55, 2.7, 1.4, var4 * 0.12, 0.28, 6750059, var12 * 0.55, 18, 0.0, 1.0, -var4 * 0.06);
      Parts.column(var0, var6, var8, var10, 0.95, 3.2, 6750059, var12 * 0.2, var4 * 0.03, 14221264, 0.0);

      for (int var34 = 0; var34 < 6; var34++) {
         double var35 = (var4 * 0.02 + Geo.hash(var34, 1)) % 1.0;
         double var36 = Geo.hash(var34, 2) * (Math.PI * 2) + var4 * 0.03;
         double var37 = 0.7 + Geo.hash(var34, 3) * 0.9;
         Parts.spark(
            var0, var6 + Math.cos(var36) * var37, var8 + 0.2 + var35 * 2.8, var10 + Math.sin(var36) * var37, 0.2, 12124002, var12 * Math.sin(var35 * Math.PI)
         );
      }
   }

   private static void rage(Ctx var0, AuraState var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      double var14 = 0.75 + 0.25 * Math.sin(var4 * 0.35);
      Parts.rune(var0, Tex.RUNE_RAGE, var6, var8 + 0.04, var10, 2.3, var4 * 0.09, 16722490, var12 * 0.9);
      Parts.rune(var0, Tex.CRACK, var6, var8 + 0.045, var10, 2.6, 0.7, 14684208, var12 * 0.7 * var14);
      Parts.glowDisc(var0, var6, var8 + 0.03, var10, 2.2, 8000024, var12 * 0.65);
      double var16 = var4 * 0.07 % 1.0;
      Parts.ring(var0, var6, var8 + 0.06, var10, 0.7 + var16 * 2.0, 16722490, (1.0 - var16) * 0.8 * var12);

      for (int var18 = 0; var18 < 9; var18++) {
         double var19 = (Math.PI * 2) * var18 / 9.0 + Geo.hash(var18, 1) * 0.5;
         double var21 = 1.2 + Geo.hash(var18, 2) * 0.9;
         double var23 = (1.3 + Geo.hash(var18, 3) * 1.1) * (0.65 + 0.35 * Math.sin(var4 * 0.45 + var18 * 2.3));
         Geo.standing(
            var0.q,
            Tex.SPIKE,
            var6 + Math.cos(var19) * var21,
            var8,
            var10 + Math.sin(var19) * var21,
            var19 + 0.8,
            0.26,
            var23,
            Math.cos(var19) * 0.3,
            Math.sin(var19) * 0.3,
            2,
            Col.mul(Col.mix(16722490, 16747040, 0.3), var12 * 0.9),
            Col.mul(14684208, var12 * 0.4),
            0.0,
            0.0,
            1.0,
            1.0
         );
      }

      for (int var25 = 0; var25 < 4; var25++) {
         Parts.helix(
            var0,
            Tex.RIBBON_THORN,
            var6,
            var8,
            var10,
            1.5,
            0.5,
            3.2,
            1.5,
            var4 * 0.26 + var25 * (Math.PI * 2) / 4.0,
            0.4,
            (var25 & 1) == 0 ? 16747040 : 16722490,
            var12 * 0.95,
            18,
            0.0,
            1.0,
            -var4 * 0.16
         );
      }

      Parts.column(var0, var6, var8, var10, 0.85, 4.0, 16722490, var12 * 0.45 * var14, var4 * 0.12, 16747040, var12 * 0.25);

      for (int var26 = 0; var26 < 4; var26++) {
         double var28 = (Math.PI * 2) * var26 / 4.0 + var4 * 0.06;
         Geo.flameSprite(
            var0.q,
            var6 + Math.cos(var28) * 1.0,
            var8 + 0.05,
            var10 + Math.sin(var28) * 1.0,
            0.5,
            1.2 + 0.25 * Math.sin(var4 * 0.5 + var26),
            (int)(var4 * 0.9) + var26 * 4,
            Col.mul(Col.mix(16777215, 16722490, 0.5), var12 * 0.9)
         );
      }

      for (int var27 = 0; var27 < 4; var27++) {
         double var29 = Geo.hash(var27, 4) * (Math.PI * 2) + var4 * 0.03;
         double var30 = 0.8 + Geo.hash(var27, 5) * 1.6;
         Parts.flare(
            var0,
            var6 + Math.cos(var29) * var30,
            var8 + 0.5 + Geo.hash(var27, 6) * 2.6,
            var10 + Math.sin(var29) * var30,
            0.45,
            var4 * 0.1,
            16722490,
            var12 * Math.abs(Math.sin(var4 * 0.22 + var27 * 1.7)),
            false
         );
      }
   }

   private static void transcend(Ctx var0, AuraState var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      Parts.rune(var0, Tex.RUNE_MOON, var6, var8 + 0.04, var10, 2.5, var4 * 0.05, 9141759, var12 * 0.9);
      Parts.rune(var0, Tex.RUNE_GOLD, var6, var8 + 0.045, var10, 1.5, -var4 * 0.08, 16777215, var12 * 0.5);
      Parts.glowDisc(var0, var6, var8 + 0.03, var10, 2.4, 5913855, var12 * 0.45);
      double var14 = var4 * 0.03 % 1.0;
      Parts.ring(var0, var6, var8 + 0.06, var10, 0.9 + var14 * 2.0, 10276863, (1.0 - var14) * 0.7 * var12);
      Parts.Centre var16 = (var3, var5) -> var1.posAt(var3, var2, var5);
      double[] var17 = new double[]{0.42, -0.72, 1.05};
      double[] var18 = new double[]{0.0, 1.9, 3.8};
      double[] var19 = new double[]{0.12, -0.15, 0.1};
      double[] var20 = new double[]{1.55, 1.95, 2.3};
      double[] var21 = new double[]{1.1, 1.3, 0.95};
      int[] var22 = new int[]{9141759, 10276863, 5913855};
      double[] var23 = new double[3];

      for (int var24 = 0; var24 < 3; var24++) {
         double var25 = var4 * var19[var24] + var24 * 2.2;
         double var27 = Math.signum(var19[var24]);
         Parts.orbit(
            var0,
            Tex.RIBBON_WISP,
            var16,
            var21[var24],
            var20[var24],
            var20[var24],
            var17[var24],
            var18[var24],
            var25,
            var27,
            3.0,
            1.0 / Math.abs(var19[var24]),
            0.75,
            var22[var24],
            16777215,
            var12,
            30,
            0.15,
            var4 * 0.08
         );
         orbitPt(var1, var2, var21[var24], var20[var24], var17[var24], var18[var24], var25, 0.0, var23);
         Parts.flare(var0, var23[0], var23[1], var23[2], 0.75, var4 * 0.1 + var24, 16777215, var12, true);

         for (int var29 = 1; var29 <= 3; var29++) {
            double var30 = var29 * 0.55;
            orbitPt(var1, var2, var21[var24], var20[var24], var17[var24], var18[var24], var25 - var27 * var30, var30 / Math.abs(var19[var24]), var23);
            Parts.flare(
               var0,
               var23[0],
               var23[1],
               var23[2],
               0.38 - var29 * 0.05,
               -var4 * 0.1 + var29,
               var22[var24],
               var12 * (0.9 - var29 * 0.2) * (0.6 + 0.4 * Math.sin(var4 * 0.3 + var29 + var24)),
               false
            );
         }
      }

      for (int var32 = 0; var32 < 8; var32++) {
         double var34 = (Math.PI * 2) * var32 / 8.0 + var4 * 0.015;
         double var36 = 1.1 + var32 % 3 * 0.7;
         Parts.shaft(
            var0,
            var6 + Math.cos(var34) * var36,
            var8,
            var10 + Math.sin(var34) * var36,
            0.16,
            4.0 + var32 % 4 * 0.9,
            var32 % 2 == 0 ? 10276863 : 9141759,
            var12 * (0.3 + 0.35 * Math.abs(Math.sin(var4 * 0.09 + var32 * 1.3))),
            var34
         );
      }

      Parts.column(var0, var6, var8, var10, 1.0, 4.8, 9141759, var12 * 0.25, var4 * 0.08, 16777215, var12 * 0.12);

      for (int var33 = 0; var33 < 9; var33++) {
         double var35 = (var4 * 0.022 + Geo.hash(var33, 1)) % 1.0;
         double var37 = Geo.hash(var33, 2) * (Math.PI * 2) + var4 * 0.04;
         double var38 = 0.8 + Geo.hash(var33, 3) * 1.8;
         Parts.flare(
            var0,
            var6 + Math.cos(var37) * var38,
            var8 + 0.3 + var35 * 3.6,
            var10 + Math.sin(var37) * var38,
            0.3 + 0.35 * Geo.hash(var33, 4),
            var4 * 0.08 + var33,
            16777215,
            var12 * Math.sin(var35 * Math.PI) * 0.95,
            false
         );
      }
   }

   private AuraMeshes() {
   }
}
