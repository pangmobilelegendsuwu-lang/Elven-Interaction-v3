package com.elvencompanions.client.fx;

public enum Tex {
   RIBBON_SOFT("ribbon_soft"),
   RIBBON_THORN("ribbon_thorn"),
   RIBBON_WISP("ribbon_wisp"),
   BEAM("beam"),
   BEAM_CORE("beam_core"),
   FLARE4("flare4"),
   FLARE8("flare8"),
   GLOW("glow"),
   RING("ring"),
   SPARK("spark"),
   EYE("eye"),
   MOON("moon"),
   SPROUT("sprout"),
   LEAVES("leaves"),
   SPIKE("spike"),
   ARROW("arrow"),
   SWORD("sword"),
   HAND("hand"),
   RUNE_NATURE("rune_nature"),
   RUNE_MOON("rune_moon"),
   RUNE_GOLD("rune_gold"),
   RUNE_RAGE("rune_rage"),
   CLOCK("clock"),
   TREE("tree"),
   GUARDIAN("guardian"),
   CRACK("crack"),
   VINE("vine"),
   DOME("dome"),
   FLAME("flame"),
   SWIRL("swirl");

   public static final int COUNT = values().length;
   public final String file;

   private Tex(String nullxx) {
      this.file = nullxx;
   }
}
