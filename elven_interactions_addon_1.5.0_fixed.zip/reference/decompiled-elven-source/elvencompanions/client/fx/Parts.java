package com.elvencompanions.client.fx;

final class Parts {
   static void rune(Ctx var0, Tex var1, double var2, double var4, double var6, double var8, double var10, int var12, double var13) {
      if (!(var13 <= 0.01) && !(var8 <= 0.01)) {
         Geo.disc(var0.q, var1, var2, var4, var6, var8 * 1.03, var10, Col.mul(var12, var13));
      }
   }

   static void glowDisc(Ctx var0, double var1, double var3, double var5, double var7, int var9, double var10) {
      if (!(var10 <= 0.01)) {
         Geo.disc(var0.q, Tex.GLOW, var1, var3, var5, var7, 0.0, Col.mul(var9, var10));
      }
   }

   static void ring(Ctx var0, double var1, double var3, double var5, double var7, int var9, double var10) {
      if (!(var10 <= 0.01) && !(var7 <= 0.01)) {
         Geo.disc(var0.q, Tex.RING, var1, var3, var5, var7 / 0.9, 0.0, Col.mul(var9, var10));
      }
   }

   static void ringBB(Ctx var0, double var1, double var3, double var5, double var7, int var9, double var10) {
      if (!(var10 <= 0.01)) {
         Geo.billboard(var0.q, Tex.RING, var1, var3, var5, var7 / 0.9, 0.0, Col.mul(var9, var10));
      }
   }

   static void column(Ctx var0, double var1, double var3, double var5, double var7, double var9, int var11, double var12, double var14, int var16, double var17) {
      if (var12 > 0.01) {
         int var19 = var0.n(10, 6);
         Geo.cylinder(
            var0.q,
            Tex.BEAM,
            var1,
            var3,
            var5,
            var7,
            var7 * 0.85,
            var9,
            var19,
            var14 * 0.3,
            Col.mul(var11, var12),
            Col.mul(var11, var12 * 0.35),
            3.0,
            var14,
            0.0,
            1.0
         );
         Geo.cylinder(
            var0.q,
            Tex.BEAM,
            var1,
            var3,
            var5,
            var7 * 0.62,
            var7 * 0.5,
            var9,
            Math.max(6, var19 - 2),
            -var14 * 0.5,
            Col.mul(var11, var12 * 0.8),
            Col.mul(var11, var12 * 0.25),
            2.0,
            -var14 * 1.4,
            0.0,
            1.0
         );
      }

      if (var17 > 0.01) {
         Geo.standing(var0.q, Tex.BEAM_CORE, var1, var3, var5, var14 * 0.2, var7 * 0.45, var9, 2, Col.mul(var16, var17), Col.mul(var16, var17 * 0.2));
      }
   }

   static void shaft(Ctx var0, double var1, double var3, double var5, double var7, double var9, int var11, double var12, double var14) {
      if (!(var12 <= 0.01)) {
         Geo.standing(var0.q, Tex.BEAM_CORE, var1, var3, var5, var14, var7, var9, 2, Col.mul(var11, var12), Col.mul(var11, var12 * 0.15));
      }
   }

   static void helix(
      Ctx var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      int var20,
      double var21,
      int var23,
      double var24,
      double var26,
      double var28
   ) {
      var23 = var0.n(var23, 6);
      double[] var30 = new double[var23];
      double[] var31 = new double[var23];
      double[] var32 = new double[var23];
      double[] var33 = new double[var23];
      int[] var34 = new int[var23];

      for (int var35 = 0; var35 < var23; var35++) {
         double var36 = Geo.lerp(var24, var26, (double)var35 / (var23 - 1));
         double var38 = Geo.lerp(var8, var10, var36);
         double var40 = var16 + var36 * var14 * (Math.PI * 2);
         var30[var35] = var2 + Math.cos(var40) * var38;
         var31[var35] = var4 + var36 * var12;
         var32[var35] = var6 + Math.sin(var40) * var38;
         double var42 = Math.sin(Math.PI * ((double)var35 / (var23 - 1)));
         var33[var35] = var18 * (0.15 + 0.85 * Math.pow(var42, 0.7));
         var34[var35] = Col.mul(var20, var21 * (0.25 + 0.75 * var42));
      }

      Geo.ribbon(var0.q, var1, var30, var31, var32, var33, var34, var23, var28, var28 + 3.0);
   }

   static void orbit(
      Ctx var0,
      Tex var1,
      Parts.Centre var2,
      double var3,
      double var5,
      double var7,
      double var9,
      double var11,
      double var13,
      double var15,
      double var17,
      double var19,
      double var21,
      int var23,
      int var24,
      double var25,
      int var27,
      double var28,
      double var30
   ) {
      var27 = var0.n(var27, 8);
      double[] var32 = new double[var27];
      double[] var33 = new double[var27];
      double[] var34 = new double[var27];
      double[] var35 = new double[var27];
      int[] var36 = new int[var27];
      double[] var37 = new double[3];
      double var38 = Math.cos(var9);
      double var40 = Math.sin(var9);
      double var42 = Math.cos(var11);
      double var44 = Math.sin(var11);

      for (int var46 = 0; var46 < var27; var46++) {
         double var47 = (double)var46 / (var27 - 1);
         double var49 = (1.0 - var47) * var17;
         double var51 = var13 - var15 * var49;
         double var53 = Geo.lerp(var7, var5, var47);
         double var55 = Math.cos(var51) * var53;
         double var57 = Math.sin(var51) * var53;
         double var59 = -var57 * var40;
         double var61 = var57 * var38;
         double var63 = var55 * var42 + var61 * var44;
         double var65 = -var55 * var44 + var61 * var42;
         var2.at(var49 * var19, var37);
         var32[var46] = var37[0] + var63;
         var33[var46] = var37[1] + var3 + var59 + var28 * Math.sin(var51 * 2.0 + var11);
         var34[var46] = var37[2] + var65;
         double var67 = Math.pow(var47, 1.1);
         var35[var46] = var21 * (0.04 + 0.96 * Math.pow(var47, 0.65));
         var36[var46] = Col.mul(Col.mix(var23, var24, Math.pow(var47, 3.0)), var25 * (0.08 + 0.92 * var67));
      }

      Geo.ribbon(var0.q, var1, var32, var33, var34, var35, var36, var27, var30, var30 + Math.max(1.0, var17 * var5 * 0.25));
   }

   static void leaf(Ctx var0, int var1, double var2, double var4, double var6, double var8, double var10, int var12, double var13) {
      if (!(var13 <= 0.01)) {
         double var15 = (var1 & 1) * 0.5;
         double var17 = (var1 >> 1 & 1) * 0.5;
         Geo.billboard(var0.q, Tex.LEAVES, var2, var4, var6, var8, var10, Col.mul(var12, var13), var15 + 0.004, var17 + 0.004, var15 + 0.496, var17 + 0.496);
      }
   }

   static void flare(Ctx var0, double var1, double var3, double var5, double var7, double var9, int var11, double var12, boolean var14) {
      if (!(var12 <= 0.01)) {
         Geo.billboard(var0.q, var14 ? Tex.FLARE8 : Tex.FLARE4, var1, var3, var5, var7, var9, Col.mul(var11, var12));
      }
   }

   static void spark(Ctx var0, double var1, double var3, double var5, double var7, int var9, double var10) {
      if (!(var10 <= 0.01)) {
         Geo.billboard(var0.q, Tex.SPARK, var1, var3, var5, var7, 0.0, Col.mul(var9, var10));
      }
   }

   private Parts() {
   }

   interface Centre {
      void at(double var1, double[] var3);
   }
}
