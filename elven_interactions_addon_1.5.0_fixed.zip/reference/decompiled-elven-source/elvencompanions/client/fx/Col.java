package com.elvencompanions.client.fx;

public final class Col {
   public static final int GREEN = 6750059;
   public static final int LIME = 12124002;
   public static final int PALE = 14221264;
   public static final int GOLD = 16767050;
   public static final int AMBER = 16752688;
   public static final int MOON = 10276863;
   public static final int VIOLET = 9141759;
   public static final int DEEPV = 5913855;
   public static final int WHITE = 16777215;
   public static final int RED = 16722490;
   public static final int DRED = 8000024;
   public static final int FIRE = 16738832;
   public static final int CYAN = 7332095;
   public static final int EMERALD = 3137648;
   public static final int ICE = 13625087;
   public static final int ORANGE = 16747040;
   public static final int CRIMSON = 14684208;

   public static int mul(int var0, double var1) {
      if (var1 < 0.0) {
         var1 = 0.0;
      }

      int var3 = clamp((int)((var0 >> 16 & 0xFF) * var1));
      int var4 = clamp((int)((var0 >> 8 & 0xFF) * var1));
      int var5 = clamp((int)((var0 & 0xFF) * var1));
      return 0xFF000000 | var3 << 16 | var4 << 8 | var5;
   }

   public static int mix(int var0, int var1, double var2) {
      var2 = var2 < 0.0 ? 0.0 : (var2 > 1.0 ? 1.0 : var2);
      int var4 = (int)((var0 >> 16 & 0xFF) * (1.0 - var2) + (var1 >> 16 & 0xFF) * var2);
      int var5 = (int)((var0 >> 8 & 0xFF) * (1.0 - var2) + (var1 >> 8 & 0xFF) * var2);
      int var6 = (int)((var0 & 0xFF) * (1.0 - var2) + (var1 & 0xFF) * var2);
      return 0xFF000000 | clamp(var4) << 16 | clamp(var5) << 8 | clamp(var6);
   }

   public static int mixMul(int var0, int var1, double var2, double var4) {
      return mul(mix(var0, var1, var2), var4);
   }

   private static int clamp(int var0) {
      return var0 < 0 ? 0 : Math.min(var0, 255);
   }

   private Col() {
   }
}
