package com.elvencompanions.client.fx;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent.Post;

@EventBusSubscriber(
   modid = "elven_companions",
   value = {Dist.CLIENT}
)
public final class FxManager {
   private static final List<FxInst> SKILLS = new ArrayList<>();
   private static final Map<Integer, AuraState> AURAS = new HashMap<>();
   private static final QuadBuffer QB = new QuadBuffer();
   private static final ResourceLocation[] LOC = new ResourceLocation[Tex.COUNT];
   private static long clock;
   private static int errors;
   private static boolean broken;
   private static double lrx;
   private static double lry;
   private static double lrz;
   private static long lrTick = -1000L;
   private static final Map<Integer, FxManager.ArrowTrail> ARROWS = new HashMap<>();
   private static int said;
   private static final Set<String> SAID = new HashSet<>();
   static final boolean DEBUG = false;
   private static final FxType[] TYPES = new FxType[Tex.COUNT];
   private static final FxCarrier[] CARRIERS = new FxCarrier[Tex.COUNT];
   private static Object carrierLevel;
   private static int idle;
   private static long stampClock = -1L;
   private static float stampPt = -1.0F;

   private static boolean carriersReady() {
      Minecraft var0 = Minecraft.getInstance();
      FxCarrier var1 = CARRIERS[0];
      return var1 != null && var1.isAlive() && carrierLevel == var0.level;
   }

   public static boolean arrowTake(Entity var0, float var1) {
      try {
         if (!broken && (Boolean)ECConfig.particles.get()) {
            FxManager.ArrowTrail var2 = ARROWS.get(var0.getId());
            if (var2 == null) {
               if (ARROWS.size() >= 80) {
                  return false;
               }

               var2 = new FxManager.ArrowTrail();
               var2.id = var0.getId();
               ARROWS.put(var2.id, var2);
            }

            var2.seen = clock;
            var2.pt = var1;
            var2.x = var0.getX();
            var2.y = var0.getY();
            var2.z = var0.getZ();
            var2.xo = var0.xo;
            var2.yo = var0.yo;
            var2.zo = var0.zo;
            var2.yaw = var0.getYRot();
            var2.pitch = var0.getXRot();
            if (var2.lastTick != var0.tickCount) {
               var2.lastTick = var0.tickCount;
               double var3 = var2.x - var2.xo;
               double var5 = var2.y - var2.yo;
               double var7 = var2.z - var2.zo;
               if (var3 * var3 + var5 * var5 + var7 * var7 < 0.0025) {
                  var2.still++;
               } else {
                  var2.still = 0;
               }

               if (var2.n == var2.hx.length) {
                  for (int var9 = 1; var9 < var2.n; var9++) {
                     var2.hx[var9 - 1] = var2.hx[var9];
                     var2.hy[var9 - 1] = var2.hy[var9];
                     var2.hz[var9 - 1] = var2.hz[var9];
                  }

                  var2.n--;
               }

               var2.hx[var2.n] = var2.xo;
               var2.hy[var2.n] = var2.yo;
               var2.hz[var2.n] = var2.zo;
               var2.n++;
            }

            return var2.still < 60 && carriersReady();
         } else {
            return false;
         }
      } catch (Throwable var10) {
         fail(var10, "arrow");
         return false;
      }
   }

   private static void drawArrow(Ctx var0, FxManager.ArrowTrail var1) {
      double var2 = var1.pt;
      double var4 = var1.xo + (var1.x - var1.xo) * var2;
      double var6 = var1.yo + (var1.y - var1.yo) * var2;
      double var8 = var1.zo + (var1.z - var1.zo) * var2;
      double var10 = Math.toRadians(var1.yaw);
      double var12 = Math.toRadians(var1.pitch);
      double var14 = -Math.sin(var10) * Math.cos(var12);
      double var16 = -Math.sin(var12);
      double var18 = Math.cos(var10) * Math.cos(var12);
      int var20 = (var1.id & 1) == 0 ? 12124002 : 6750059;
      if (var1.still < 3 && var1.n >= 1) {
         int var21 = var1.n + 1;
         double[] var22 = new double[var21];
         double[] var23 = new double[var21];
         double[] var24 = new double[var21];
         double[] var25 = new double[var21];
         int[] var26 = new int[var21];

         for (int var27 = 0; var27 < var21 - 1; var27++) {
            var22[var27] = var1.hx[var27];
            var23[var27] = var1.hy[var27];
            var24[var27] = var1.hz[var27];
         }

         var22[var21 - 1] = var4;
         var23[var21 - 1] = var6;
         var24[var21 - 1] = var8;

         for (int var30 = 0; var30 < var21; var30++) {
            double var28 = (double)var30 / (var21 - 1);
            var25[var30] = 0.2 * Math.pow(var28, 0.8) + 0.01;
            var26[var30] = Col.mul(Col.mix(var20, 16777215, Math.pow(var28, 3.0)), 0.05 + 0.95 * var28);
         }

         Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var22, var23, var24, var25, var26, var21, -var0.clock * 0.1, -var0.clock * 0.1 + 2.0);
      }

      Geo.oriented(
         var0.q, Tex.ARROW, var4 - var14 * 1.0, var6 - var16 * 1.0, var8 - var18 * 1.0, var14, var16, var18, 1.2, 0.16, 2, 0.0, Col.mul(var20, 0.4), 16777215
      );
      Parts.flare(var0, var4, var6, var8, 0.45, var0.clock * 0.3 + var1.id, var20, 1.0, false);
   }

   static void say(String var0, String var1) {
      try {
         if (!var0.startsWith("err:") && !var0.equals("camfix") && !var0.equals("broken")) {
            return;
         }

         if (said >= 16 || !SAID.add(var0)) {
            return;
         }

         Minecraft var2 = Minecraft.getInstance();
         if (var2.player == null) {
            SAID.remove(var0);
            return;
         }

         said++;
         var2.player.displayClientMessage(Component.literal("[Elven FX] " + var1), false);
      } catch (Throwable var3) {
      }
   }

   static void fail(Throwable var0, String var1) {
      var0.printStackTrace();
      StackTraceElement[] var2 = var0.getStackTrace();
      String var3 = var2.length > 0
         ? var2[0].getClassName().substring(var2[0].getClassName().lastIndexOf(46) + 1) + "." + var2[0].getMethodName() + ":" + var2[0].getLineNumber()
         : "?";
      say("err:" + var0.getClass().getName() + var3, var1 + " error " + var0.getClass().getSimpleName() + ": " + var0.getMessage() + " @ " + var3);
   }

   public static void addSkill(int var0, int var1, double var2, double var4, double var6, double var8, double var10, double var12, int var14, float var15) {
      say("skill", "skill packet received, kind " + var0 + (SkillMeshes.handles(var0) ? " (mesh)" : " (no mesh)"));
      if (!broken && SkillMeshes.handles(var0)) {
         if (SKILLS.size() >= 110) {
            SKILLS.remove(0);
         }

         if (var0 == 37) {
            for (FxInst var17 : SKILLS) {
               if (var17.kind == 36 && var17.ent == var1) {
                  var17.age = var17.ticks + 2;
               }
            }
         }

         FxInst var23 = new FxInst(var0, var1, var2, var4, var6, var8, var10, var12, var14, var15, (int)(clock * 31L + var0 * 7 + var1));
         if (var0 == 15) {
            if (clock - lrTick <= 14L) {
               double var24 = var2 - lrx;
               double var19 = var4 - lry;
               double var21 = var6 - lrz;
               if (var24 * var24 + var19 * var19 + var21 * var21 < 576.0) {
                  var23.lx = lrx;
                  var23.ly = lry;
                  var23.lz = lrz;
                  var23.hasLink = true;
               }
            }

            lrx = var2;
            lry = var4;
            lrz = var6;
            lrTick = clock;
         }

         track(var23);
         SKILLS.add(var23);
      }
   }

   public static float ghostAlpha(int var0) {
      try {
         for (FxInst var2 : SKILLS) {
            if (var2.kind == 36 && var2.ent == var0 && var2.age <= var2.ticks) {
               double var3 = Math.min(1.0, (var2.age + 1) / 8.0);
               return (float)(var3 * (0.42 + 0.08 * Math.sin(clock * 0.25 + var0)));
            }
         }
      } catch (Throwable var5) {
      }

      return -1.0F;
   }

   public static void touchAura(int var0, int var1, double var2, double var4, double var6) {
      if (!broken) {
         say("aura", "aura active for elf #" + var0 + " kind " + var1);
         AuraState var8 = AURAS.get(var0);
         if (var8 == null) {
            if (AURAS.size() > 12) {
               return;
            }

            var8 = new AuraState(var0, var2, var4, var6);
            var8.life = var8.prevLife = 0.0;
            AURAS.put(var0, var8);
         }

         var8.kind = var1;
         var8.target = 1.0;
         var8.lastTouched = (int)clock;
      }
   }

   public static void clear() {
      SKILLS.clear();
      AURAS.clear();
      ARROWS.clear();
   }

   private static void track(FxInst var0) {
      if (var0.ent >= 0) {
         Minecraft var1 = Minecraft.getInstance();
         if (var1.level != null) {
            Entity var2 = var1.level.getEntity(var0.ent);
            if (var2 != null) {
               var0.pcx = var0.cx;
               var0.pcy = var0.cy;
               var0.pcz = var0.cz;
               var0.cx = var2.getX();
               var0.cy = var2.getY();
               var0.cz = var2.getZ();
               var0.yaw = var2.getYRot();
            }
         }
      }
   }

   @SubscribeEvent
   public static void tick(Post var0) {
      try {
         tick0();
      } catch (Throwable var2) {
         fail(var2, "tick");
      }
   }

   private static void tick0() {
      Minecraft var0 = Minecraft.getInstance();
      clock++;
      if (var0.level == null) {
         if (!SKILLS.isEmpty() || !AURAS.isEmpty() || !ARROWS.isEmpty()) {
            clear();
         }
      } else {
         Iterator var1 = SKILLS.iterator();

         while (var1.hasNext()) {
            FxInst var2 = (FxInst)var1.next();
            var2.age++;
            if (var2.age > var2.ticks + 1) {
               var1.remove();
            } else if (var2.ent >= 0) {
               Entity var3 = var0.level.getEntity(var2.ent);
               if (var3 != null) {
                  var2.pcx = var2.cx;
                  var2.pcy = var2.cy;
                  var2.pcz = var2.cz;
                  var2.cx = var3.getX();
                  var2.cy = var3.getY();
                  var2.cz = var3.getZ();
                  var2.yaw = var3.getYRot();
               } else {
                  var2.pcx = var2.cx;
                  var2.pcy = var2.cy;
                  var2.pcz = var2.cz;
               }
            }
         }

         var1 = ARROWS.values().iterator();

         while (var1.hasNext()) {
            if (clock - ((FxManager.ArrowTrail)var1.next()).seen > 3L) {
               var1.remove();
            }
         }

         manageCarriers(var0);
         var1 = AURAS.values().iterator();

         while (var1.hasNext()) {
            AuraState var6 = (AuraState)var1.next();
            Entity var7 = var0.level.getEntity(var6.id);
            if (var7 == null || clock - var6.lastTouched > 3L) {
               var6.target = 0.0;
            }

            if (var7 != null) {
               var6.push(var7.getX(), var7.getY(), var7.getZ());
            } else {
               var6.push(0.0, 0.0, 0.0);
            }

            if (var6.target == 0.0 && var6.life <= 0.011) {
               var1.remove();
            }
         }
      }
   }

   static ResourceLocation loc(Tex var0) {
      ResourceLocation var1 = LOC[var0.ordinal()];
      if (var1 == null) {
         LOC[var0.ordinal()] = var1 = ElvenCompanions.rl("textures/fx/" + var0.file + ".png");
      }

      return var1;
   }

   static QuadBuffer.Batch batch(Tex var0) {
      return QB.batches[var0.ordinal()];
   }

   static void ensure(Camera var0, float var1) {
      if (stampClock != clock || stampPt != var1) {
         stampClock = clock;
         stampPt = var1;
         QB.reset(0.0, 0.0, 0.0);
         if (!broken && (!SKILLS.isEmpty() || !AURAS.isEmpty() || !ARROWS.isEmpty())) {
            try {
               if (!(Boolean)ECConfig.particles.get()) {
                  return;
               }

               Vec3 var2 = var0.getPosition();
               double var3 = var2.x;
               double var5 = var2.y;
               double var7 = var2.z;
               Minecraft var9 = Minecraft.getInstance();
               if (var9.player != null
                  && Math.abs(var3) + Math.abs(var5) + Math.abs(var7) < 0.001
                  && Math.abs(var9.player.getX()) + Math.abs(var9.player.getZ()) > 8.0) {
                  var3 = var9.player.getX();
                  var5 = var9.player.getY() + var9.player.getEyeHeight();
                  var7 = var9.player.getZ();
                  say("camfix", "camera position was 0,0,0 - using player eye position");
               }

               QB.reset(var3, var5, var7);
               Ctx var10 = new Ctx(QB);
               var10.clock = (float)clock + var1;
               var10.den = Math.max(0.15, Math.min(1.0, (Double)ECConfig.particleDensity.get()));

               for (AuraState var12 : AURAS.values()) {
                  if (QB.full()) {
                     break;
                  }

                  AuraMeshes.render(var10, var12, var1);
               }

               for (FxInst var22 : SKILLS) {
                  if (QB.full()) {
                     break;
                  }

                  double var13 = var22.cx - var3;
                  double var15 = var22.cy - var5;
                  double var17 = var22.cz - var7;
                  if (!(var13 * var13 + var15 * var15 + var17 * var17 > 25600.0)) {
                     SkillMeshes.render(var10, var22, var1);
                  }
               }

               for (FxManager.ArrowTrail var23 : ARROWS.values()) {
                  if (QB.full()) {
                     break;
                  }

                  if (clock - var23.seen <= 1L && var23.still < 60) {
                     double var24 = var23.x - var3;
                     double var25 = var23.y - var5;
                     double var26 = var23.z - var7;
                     if (!(var24 * var24 + var25 * var25 + var26 * var26 > 16384.0)) {
                        drawArrow(var10, var23);
                     }
                  }
               }

               if (QB.quads > 0) {
                  say("draw", "built " + QB.quads + " mesh quads (skills " + SKILLS.size() + ", auras " + AURAS.size() + ")");
               }
            } catch (Throwable var19) {
               QB.reset(0.0, 0.0, 0.0);
               fail(var19, "render");
               if (++errors >= 4) {
                  broken = true;
                  say("broken", "mesh layer disabled after repeated errors");
                  clear();
               }
            }
         }
      }
   }

   private static void manageCarriers(Minecraft var0) {
      boolean var1 = !broken && (!SKILLS.isEmpty() || !AURAS.isEmpty() || !ARROWS.isEmpty()) && (Boolean)ECConfig.particles.get();
      if (var1) {
         idle = 0;
         FxCarrier var2 = CARRIERS[0];
         if (var2 != null && var2.isAlive() && carrierLevel == var0.level) {
            return;
         }

         for (int var3 = 0; var3 < Tex.COUNT; var3++) {
            Tex var4 = Tex.values()[var3];
            if (TYPES[var3] == null) {
               TYPES[var3] = new FxType(var4, 0);
            }

            FxCarrier var5 = CARRIERS[var3];
            if (var5 != null) {
               var5.remove();
            }

            FxCarrier var6 = new FxCarrier(var0.level, TYPES[var3]);
            CARRIERS[var3] = var6;
            var0.particleEngine.add(var6);
         }

         carrierLevel = var0.level;
         say("carriers", "particle carriers created");
      } else if (CARRIERS[0] != null && ++idle > 60) {
         for (int var7 = 0; var7 < CARRIERS.length; var7++) {
            if (CARRIERS[var7] != null) {
               CARRIERS[var7].remove();
            }

            CARRIERS[var7] = null;
         }

         carrierLevel = null;
      }
   }

   private FxManager() {
   }

   private static final class ArrowTrail {
      final double[] hx = new double[6];
      final double[] hy = new double[6];
      final double[] hz = new double[6];
      int n;
      int lastTick = -1;
      int still;
      long seen;
      double x;
      double y;
      double z;
      double xo;
      double yo;
      double zo;
      double yaw;
      double pitch;
      float pt;
      int id;
   }
}
