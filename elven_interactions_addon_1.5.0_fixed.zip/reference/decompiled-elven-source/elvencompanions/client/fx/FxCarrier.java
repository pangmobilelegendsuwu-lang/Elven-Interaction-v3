package com.elvencompanions.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.world.phys.AABB;

final class FxCarrier extends Particle {
   private final FxType type;

   FxCarrier(ClientLevel var1, FxType var2) {
      super(var1, 0.0, 0.0, 0.0);
      this.type = var2;
      this.lifetime = Integer.MAX_VALUE;
   }

   public void tick() {
   }

   public ParticleRenderType getRenderType() {
      return this.type;
   }

   public AABB getRenderBoundingBox(float var1) {
      return new AABB(-3.0E7, -3.0E7, -3.0E7, 3.0E7, 3.0E7, 3.0E7);
   }

   public void render(VertexConsumer var1, Camera var2, float var3) {
      try {
         FxManager.ensure(var2, var3);
         QuadBuffer.Batch var4 = FxManager.batch(this.type.tex);
         if (var4.n == 0) {
            return;
         }

         float[] var5 = var4.d;
         int[] var6 = var4.c;
         byte var7 = 5;

         for (int var8 = 0; var8 + var7 * 4 <= var4.n; var8 += var7 * 4) {
            for (int var9 = 0; var9 < 4; var9++) {
               put(var1, var5, var6, var8 + var9 * var7);
            }

            for (int var11 = 3; var11 >= 0; var11--) {
               put(var1, var5, var6, var8 + var11 * var7);
            }
         }

         FxManager.say("carrier", "particle pipeline drawing " + var4.n / (var7 * 4) + " quads of " + this.type.tex);
      } catch (Throwable var10) {
         FxManager.fail(var10, "carrier");
      }
   }

   private static void put(VertexConsumer var0, float[] var1, int[] var2, int var3) {
      var0.addVertex(var1[var3], var1[var3 + 1], var1[var3 + 2]).setUv(var1[var3 + 3], var1[var3 + 4]).setColor(var2[var3 / 5]).setLight(15728880);
   }

   private static void put(VertexConsumer var0, float[] var1, int var2, int var3) {
      var0.addVertex(var1[var2], var1[var2 + 1], var1[var2 + 2]).setUv(var1[var2 + 3], var1[var2 + 4]).setColor(var3).setLight(15728880);
   }
}
