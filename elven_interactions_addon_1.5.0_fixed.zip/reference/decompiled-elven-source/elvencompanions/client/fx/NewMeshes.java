package com.elvencompanions.client.fx;

import com.elvencompanions.entity.FalconPath;

final class NewMeshes {
   static boolean handles(int var0) {
      return var0 >= 31 && var0 <= 38;
   }

   static void render(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8, double var10) {
      switch (var1.kind) {
         case 31:
            falcon(var0, var1, var4);
            break;
         case 32:
            bolt(var0, var1, var4);
            break;
         case 33:
            sunder(var0, var1, var4, var6, var8, var10);
            break;
         case 34:
            stagger(var0, var1, var4, var6, var8, var10);
            break;
         case 35:
            rhythm(var0, var1, var4, var6, var8, var10);
            break;
         case 36:
            ghost(var0, var1, var4, var6, var8, var10);
            break;
         case 37:
            vanish(var0, var1, var4);
            break;
         case 38:
            afterimage(var0, var1, var4);
      }
   }

   private static void falcon(Ctx var0, FxInst var1, double var2) {
      int var4 = Math.max(1, Math.round(var1.sc));
      int var5 = FalconPath.total(var4);
      double var6 = Math.min(var2, (double)var5);
      double var8 = Math.max(0.0, var2 - var5);
      double var10 = 1.0 - Geo.sstep(0.0, 8.0, var8);
      if (!(var10 <= 0.01)) {
         double[] var12 = new double[3];
         double[] var13 = new double[3];

         for (int var14 = 0; var14 < 2; var14++) {
            double var15 = var14 == 0 ? 20.0 : 62.0;
            double var17 = var14 == 0 ? var6 : var6 - 20.0;
            double var19 = Math.max(0.0, var17 - (var14 == 0 ? var15 : 42.0));
            if (!(var17 - var19 < 0.5)) {
               int var21 = var0.n(var14 == 0 ? 26 : 34, 10);
               double[] var22 = new double[var21];
               double[] var23 = new double[var21];
               double[] var24 = new double[var21];
               double[] var25 = new double[var21];
               int[] var26 = new int[var21];

               for (int var27 = 0; var27 < var21; var27++) {
                  double var28 = (double)var27 / (var21 - 1);
                  double var30 = var19 + (var17 - var19) * var28;
                  FalconPath.pos(var1.x, var1.y, var1.z, var1.x2, var1.y2, var1.z2, var30, var12);
                  var22[var27] = var12[0];
                  var23[var27] = var12[1];
                  var24[var27] = var12[2];
                  double var32 = var14 == 0 ? Math.pow(var28, 1.2) : 0.18 + 0.4 * var28;
                  var25[var27] = (var14 == 0 ? 0.62 : 0.36) * (0.06 + 0.94 * var28);
                  var26[var27] = Col.mul(Col.mix(var14 == 0 ? 3137648 : 6750059, 16777215, var14 == 0 ? Math.pow(var28, 4.0) * 0.8 : 0.0), var32 * var10);
               }

               Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var22, var23, var24, var25, var26, var21, -var2 * 0.12 * (var14 + 1), -var2 * 0.12 * (var14 + 1) + 3.0);
            }
         }

         if (var2 <= var5) {
            FalconPath.pos(var1.x, var1.y, var1.z, var1.x2, var1.y2, var1.z2, var6, var12);
            FalconPath.pos(var1.x, var1.y, var1.z, var1.x2, var1.y2, var1.z2, var6 + 0.3, var13);
            double var34 = var13[0] - var12[0];
            double var16 = var13[1] - var12[1];
            double var18 = var13[2] - var12[2];
            double var20 = Math.sqrt(var34 * var34 + var16 * var16 + var18 * var18);
            if (var20 > 1.0E-6) {
               var34 /= var20;
               var16 /= var20;
               var18 /= var20;
               Geo.oriented(
                  var0.q,
                  Tex.ARROW,
                  var12[0] - var34 * 1.1,
                  var12[1] - var16 * 1.1,
                  var12[2] - var18 * 1.1,
                  var34,
                  var16,
                  var18,
                  1.4,
                  0.2,
                  2,
                  0.0,
                  Col.mul(3137648, 0.5),
                  16777215
               );
               Parts.flare(var0, var12[0], var12[1], var12[2], 0.9, var2 * 0.35, 12124002, 1.0, true);
               Parts.spark(var0, var12[0], var12[1], var12[2], 1.3, 3137648, 0.8);
            }

            for (int var43 = 1; var43 <= 7; var43++) {
               double var44 = var6 - var43 * 2.4;
               if (var44 < 0.0) {
                  break;
               }

               FalconPath.pos(var1.x, var1.y, var1.z, var1.x2, var1.y2, var1.z2, var44, var13);
               double var45 = var43 * 0.06;
               Parts.leaf(
                  var0,
                  var43 & 3,
                  var13[0] + Math.sin(var2 * 0.2 + var43) * 0.15,
                  var13[1] - var45,
                  var13[2] + Math.cos(var2 * 0.17 + var43) * 0.15,
                  0.2,
                  var2 * 0.1 + var43,
                  12124002,
                  (1.0 - var43 / 8.0) * var10
               );
            }
         }

         for (int var36 = 0; var36 <= var4; var36++) {
            double var37 = 10 + (var36 - 1) * 9;
            if (var36 == 0) {
               var37 = 10.0;
            } else {
               var37 = 10 + var36 * 9;
            }

            double var40 = var2 - var37;
            if (!(var40 < 0.0) && !(var40 > 9.0)) {
               double var42 = var40 / 9.0;
               Parts.ringBB(var0, var1.x2, var1.y2, var1.z2, 0.4 + var42 * 2.4, 12124002, (1.0 - var42) * var10);
               Parts.flare(var0, var1.x2, var1.y2, var1.z2, 2.2 * (1.0 - var42 * 0.5), var40, 16777215, (1.0 - var42) * 0.8 * var10, true);
            }
         }
      }
   }

   private static void bolt(Ctx var0, FxInst var1, double var2) {
      int var4 = Math.round(var1.sc);
      int var5 = var4 == 2 ? 16777215 : (var4 == 1 ? 16767050 : 16777215);
      int var6 = var4 == 2 ? 7332095 : (var4 == 1 ? 12124002 : 3137648);
      double var7 = var1.ticks - 2;
      double var9 = Math.min(1.0, var2 / Math.max(1.0, var7));
      double var11 = var1.x2 - var1.x;
      double var13 = var1.y2 - var1.y;
      double var15 = var1.z2 - var1.z;
      double var17 = Math.sqrt(var11 * var11 + var13 * var13 + var15 * var15);
      if (!(var17 < 0.01)) {
         double var19 = 1.0 - Geo.sstep(var7, var7 + 3.0, var2);
         if (!(var19 <= 0.01)) {
            double var21 = var1.x + var11 * var9;
            double var23 = var1.y + var13 * var9;
            double var25 = var1.z + var15 * var9;
            double var27 = var11 / var17;
            double var29 = var13 / var17;
            double var31 = var15 / var17;
            double var33 = Math.min(var17 * var9, 6.0);
            int var35 = var0.n(14, 6);
            double[] var36 = new double[var35];
            double[] var37 = new double[var35];
            double[] var38 = new double[var35];
            double[] var39 = new double[var35];
            int[] var40 = new int[var35];
            double[] var41 = new double[3];
            double[] var42 = new double[3];
            Geo.basis(var27, var29, var31, var41, var42);

            for (int var43 = 0; var43 < var35; var43++) {
               double var44 = (double)var43 / (var35 - 1);
               double var46 = var33 * (1.0 - var44);
               double var48 = var4 == 2 ? Math.sin(var2 * 0.9 + var44 * 9.0) * 0.07 * var44 : 0.0;
               var36[var43] = var21 - var27 * var46 + var41[0] * var48;
               var37[var43] = var23 - var29 * var46 + var41[1] * var48;
               var38[var43] = var25 - var31 * var46 + var41[2] * var48;
               var39[var43] = (var4 == 3 ? 0.75 : 0.55) * (0.05 + 0.95 * var44);
               var40[var43] = Col.mul(Col.mix(var6, var5, Math.pow(var44, 3.0)), Math.pow(var44, 1.1) * var19);
            }

            Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var36, var37, var38, var39, var40, var35, -var2 * 0.3, -var2 * 0.3 + 2.0);
            Geo.oriented(
               var0.q,
               Tex.ARROW,
               var21 - var27 * 1.3,
               var23 - var29 * 1.3,
               var25 - var31 * 1.3,
               var27,
               var29,
               var31,
               1.6,
               0.24,
               2,
               0.0,
               Col.mul(var6, 0.4 * var19),
               Col.mul(var5, var19)
            );
            Parts.flare(var0, var21, var23, var25, var4 == 2 ? 1.5 : 1.2, var2 * 0.4, var5, var19, var4 != 2);
            if (var4 == 3) {
               double var50 = var2 / 4.0;
               if (var50 < 1.0) {
                  Parts.flare(var0, var1.x, var1.y, var1.z, 2.0 * (1.0 - var50), 0.0, 12124002, 1.0 - var50, true);
               }
            }
         }
      }
   }

   private static void sunder(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var1.ticks;
      double var12 = var2 / var10;
      double var14 = Math.max(0.4, (double)var1.sc);
      double var16 = var1.x2 > 0.1 ? var1.x2 : 1.8;
      double var18 = var1.y2 > 0.05 ? var1.y2 : 0.7;
      double var20 = Geo.sstep(0.0, 0.28, var12);
      double var22 = 1.0 - Geo.sstep(0.55, 1.0, var12);
      if (!(var22 <= 0.01)) {
         byte var24 = 5;

         for (int var25 = 0; var25 < var24; var25++) {
            double var26 = var25 * (Math.PI * 2) / var24 + Geo.hash(var25, var1.seed) * 0.6;
            double var28 = var18 * (0.62 + 0.1 * Geo.hash(var25, 7));
            double var30 = (1.0 + 0.5 * var14) * Math.max(0.6, var18) * var20;
            double var32 = var4 + Math.cos(var26) * var28;
            double var34 = var8 + Math.sin(var26) * var28;
            double var36 = var26 + (Math.PI / 2);
            int var38 = Col.mul(Col.mix(16767050, 12124002, Geo.hash(var25, 3)), var22 * (0.6 + 0.4 * Math.min(1.0, var14)));
            Geo.standing(var0.q, Tex.CRACK, var32, var6 + var16 * 0.08, var34, var36, var30, var16 * 0.9 * var20, 1, var38, var38);
         }

         for (int var39 = 0; var39 < 6; var39++) {
            double var41 = Geo.hash(var39, 51) * (Math.PI * 2);
            double var43 = var18 * 0.45;
            double var45 = var4 + Math.cos(var41) * var43;
            double var46 = var8 + Math.sin(var41) * var43;
            double var47 = var6 + var16 * (0.15 + 0.7 * (var39 * 0.37 % 1.0));
            double var48 = (0.7 + 0.55 * var14) * (0.6 + 0.5 * Geo.hash(var39, 52)) * var20;
            Geo.billboard(
               var0.q,
               Tex.CRACK,
               var45,
               var47,
               var46,
               var48,
               Geo.hash(var39, 53) * (Math.PI * 2),
               Col.mul(Col.mix(16767050, 12124002, Geo.hash(var39, 54)), var22 * 0.6)
            );
         }

         if (var2 < 8.0) {
            Parts.flare(var0, var4, var6 + var16 * 0.55, var8, (1.6 + var14) * (1.0 - var2 / 8.0), var2, 16767050, 1.0 - var2 / 8.0, true);
         }

         Parts.ringBB(var0, var4, var6 + var16 * 0.55, var8, 0.5 + var20 * (0.9 + 0.5 * var14), 12124002, var22 * 0.7);

         for (int var40 = 0; var40 < 7; var40++) {
            double var42 = Geo.hash(var40, 11) * (Math.PI * 2) + var2 * 0.05;
            double var44 = var18 * (0.7 + 0.5 * Geo.hash(var40, 12)) + var2 * 0.015;
            Parts.spark(
               var0,
               var4 + Math.cos(var42) * var44,
               var6 + var16 * (0.2 + 0.7 * Geo.hash(var40, 13)) + var2 * 0.01,
               var8 + Math.sin(var42) * var44,
               0.35,
               16767050,
               var22 * (0.5 + 0.5 * Math.sin(var2 * 0.4 + var40))
            );
         }
      }
   }

   private static void stagger(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = var1.ticks;
      double var12 = var2 / var10;
      double var14 = Math.max(0.4, (double)var1.sc);
      double var16 = var1.x2 > 0.1 ? var1.x2 : 1.8;
      double var18 = var1.y2 > 0.05 ? var1.y2 : 0.7;
      double var20 = Geo.sstep(0.0, 0.2, var12);
      double var22 = 1.0 - Geo.sstep(0.62, 1.0, var12);
      if (!(var22 <= 0.01)) {
         double var24 = var6 + var16 * 0.5;
         if (var2 < 7.0) {
            double var26 = 1.0 - var2 / 7.0;
            Parts.flare(var0, var4, var24, var8, (2.2 + 1.6 * var14) * var26, var2 * 0.2, 16777215, var26, true);
            Parts.spark(var0, var4, var24, var8, 2.6 * var14 * var26, 7332095, var26);
         }

         double var42 = (var18 * 1.8 + 0.5) * (0.6 + 0.4 * Math.min(1.5, var14));
         Parts.rune(var0, Tex.RUNE_MOON, var4, var6 + 0.06, var8, var42 * var20, var2 * 0.06, 13625087, var22);
         Geo.discN(var0.q, Tex.RUNE_MOON, var4, var24, var8, var42 * 0.8 * var20, 0.25, 1.0, 0.1, -var2 * 0.08, Col.mul(7332095, var22 * 0.75));
         Geo.discN(var0.q, Tex.RUNE_MOON, var4, var24, var8, var42 * 0.6 * var20, -0.2, 1.0, 0.3, var2 * 0.1, Col.mul(16777215, var22 * 0.55));
         if (var14 > 0.7) {
            Geo.dome(
               var0.q,
               Tex.DOME,
               var4,
               var6,
               var8,
               var42 * 0.75 * var20,
               var16 / (var42 * 0.75) * 0.7,
               4,
               var0.n(10, 6),
               var2 * 0.02,
               Col.mul(13625087, var22 * 0.55),
               Col.mul(7332095, var22 * 0.2),
               2.0,
               2.0,
               1.0
            );
         }

         int var28 = (int)(5.0 + 5.0 * Math.min(1.5, var14));

         for (int var29 = 0; var29 < var28; var29++) {
            double var30 = Geo.hash(var29, 21) * (Math.PI * 2);
            double var32 = (Geo.hash(var29, 22) - 0.3) * 1.6;
            double var34 = (0.6 + 0.8 * Geo.hash(var29, 23)) * var20 * (0.7 + 0.3 * var14);
            double var36 = Math.cos(var30) * Math.cos(var32);
            double var38 = Math.sin(var32);
            double var40 = Math.sin(var30) * Math.cos(var32);
            Geo.oriented(
               var0.q,
               Tex.SPIKE,
               var4 + var36 * var18 * 0.5,
               var24 + var38 * var16 * 0.4,
               var8 + var40 * var18 * 0.5,
               var36,
               var38,
               var40,
               var34,
               0.1,
               2,
               var29,
               Col.mul(16777215, var22 * 0.9),
               Col.mul(7332095, 0.0)
            );
         }

         for (int var43 = 0; var43 < 12; var43++) {
            double var44 = Geo.hash(var43, 31) * (Math.PI * 2) + var2 * 0.04;
            double var45 = var18 * (0.4 + 0.7 * Geo.hash(var43, 32)) * (0.4 + var12);
            double var46 = var6 + var16 * Geo.hash(var43, 33) + var2 * 0.012 * (0.5 + Geo.hash(var43, 34));
            Parts.spark(
               var0,
               var4 + Math.cos(var44) * var45,
               var46,
               var8 + Math.sin(var44) * var45,
               0.28,
               13625087,
               var22 * (0.4 + 0.6 * Math.abs(Math.sin(var2 * 0.3 + var43)))
            );
         }
      }
   }

   private static void rhythm(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = Math.max(0.0, Math.min(1.0, var1.sc - 0.05));
      if (!(var10 <= 0.01)) {
         double var12 = Geo.fadeIO(var2 / var1.ticks, 0.25, 0.4);
         double var14 = var4 + (var1.x2 - var1.x);
         double var16 = var6 + (var1.y2 - var1.y);
         double var18 = var8 + (var1.z2 - var1.z);
         int var20 = 2 + (int)Math.round(var10 * 8.0);

         for (int var21 = 0; var21 < var20; var21++) {
            double var22 = var21 * (Math.PI * 2) / var20 + var2 * (0.07 + 0.03 * var10) * (var21 % 2 == 0 ? 1 : -1);
            double var24 = 0.42 + 0.1 * Math.sin(var21 * 1.7);
            double var26 = var14 + Math.cos(var22) * var24;
            double var28 = var18 + Math.sin(var22) * var24;
            double var30 = var16 + Math.sin(var22 * 1.3 + var21) * 0.28;
            Parts.leaf(var0, var21 & 3, var26, var30, var28, 0.2 + 0.08 * var10, var2 * 0.12 + var21, 3137648, var12 * (0.5 + 0.5 * var10));
            if (var10 > 0.5) {
               Parts.flare(var0, var26, var30, var28, 0.22, var22, 12124002, var12 * 0.35 * var10, false);
            }
         }

         Parts.flare(var0, var14, var16, var18, 0.5 + 1.1 * var10, var2 * 0.2, 12124002, var12 * (0.25 + 0.75 * var10), true);
         Geo.standing(
            var0.q,
            Tex.BEAM_CORE,
            var14,
            var16 - 0.55,
            var18,
            var2 * 0.05,
            0.05 + 0.04 * var10,
            1.1,
            2,
            Col.mul(3137648, var12 * var10 * 0.7),
            Col.mul(3137648, var12 * var10 * 0.7)
         );
         if (var10 > 0.7) {
            Parts.ringBB(var0, var14, var16, var18, 0.6 + 0.2 * Math.sin(var2 * 0.4), 3137648, var12 * 0.4);
         }
      }
   }

   private static void ghost(Ctx var0, FxInst var1, double var2, double var4, double var6, double var8) {
      double var10 = Geo.sstep(0.0, 6.0, var2);
      if (var2 < 18.0) {
         double var12 = var2 / 18.0;
         Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.05, var8, 1.6 * (0.6 + 0.4 * var12), var2 * 0.15, 3137648, (1.0 - var12) * 0.9);
         Parts.column(var0, var4, var6, var8, 0.6, 2.4, 6750059, (1.0 - var12) * 0.7, var2 * 0.4, 16777215, (1.0 - var12) * 0.4);

         for (int var14 = 0; var14 < 10; var14++) {
            double var15 = Geo.hash(var14, 5) * (Math.PI * 2) + var2 * 0.25;
            double var17 = 0.5 + var12 * 1.1;
            double var19 = var6 + 0.2 + var12 * 2.0 * Geo.hash(var14, 6);
            Parts.leaf(var0, var14 & 3, var4 + Math.cos(var15) * var17, var19, var8 + Math.sin(var15) * var17, 0.3, var15 * 2.0, 12124002, 1.0 - var12);
         }
      }

      Parts.rune(var0, Tex.RUNE_NATURE, var4, var6 + 0.04, var8, 1.0, -var2 * 0.03, 3137648, 0.28 * var10);

      for (int var21 = 0; var21 < 3; var21++) {
         double var13 = var2 * 0.05 + var21 * (Math.PI * 2) / 3.0;
         Parts.leaf(
            var0,
            var21,
            var4 + Math.cos(var13) * 0.8,
            var6 + 0.6 + 0.5 * Math.sin(var2 * 0.08 + var21 * 2),
            var8 + Math.sin(var13) * 0.8,
            0.18,
            var2 * 0.1,
            3137648,
            0.55 * var10
         );
      }
   }

   private static void vanish(Ctx var0, FxInst var1, double var2) {
      double var4 = var2 / var1.ticks;
      double var6 = 1.0 - Geo.sstep(0.2, 1.0, var4);
      if (!(var6 <= 0.01)) {
         double var8 = var1.x;
         double var10 = var1.y;
         double var12 = var1.z;
         Parts.flare(var0, var8, var10 + 1.0, var12, 3.0 * (1.0 - var4), var2 * 0.3, 16777215, 1.0 - Geo.sstep(0.0, 0.4, var4), true);
         Parts.ringBB(var0, var8, var10 + 1.0, var12, 0.5 + var4 * 2.6, 12124002, (1.0 - var4) * 0.8);
         int var14 = var0.n(22, 10);

         for (int var15 = 0; var15 < var14; var15++) {
            double var16 = Geo.hash(var15, 41) * (Math.PI * 2) + var2 * 0.12;
            double var18 = (Geo.hash(var15, 42) - 0.2) * 1.0;
            double var20 = 0.5 + Geo.hash(var15, 43) * 0.9;
            double var22 = var20 * var2 * 0.14;
            double var24 = var10 + 0.9 + var18 * var2 * 0.12 - var2 * var2 * 0.0035;
            Parts.leaf(
               var0,
               var15 & 3,
               var8 + Math.cos(var16) * var22,
               var24,
               var12 + Math.sin(var16) * var22,
               0.3 + 0.1 * Geo.hash(var15, 44),
               var16 * 2.0 + var2 * 0.3,
               Col.mix(12124002, 3137648, Geo.hash(var15, 45)),
               var6
            );
         }

         Parts.column(var0, var8, var10, var12, 0.35, 2.2, 6750059, (1.0 - var4) * 0.6, var2 * 0.5, 16777215, (1.0 - var4) * 0.3);
      }
   }

   private static void afterimage(Ctx var0, FxInst var1, double var2) {
      double var4 = var1.ticks;
      double var6 = var2 / var4;
      double var8 = Math.max(1.0F, var1.sc);
      double var10 = var1.x2 - var1.x;
      double var12 = var1.z2 - var1.z;
      double var14 = Math.sqrt(var10 * var10 + var12 * var12);
      if (!(var14 < 0.2)) {
         int var16 = var8 > 1.5 ? 8 : 5;
         double var17 = Math.atan2(var12, var10) + (Math.PI / 2);
         double var19 = Math.min(1.0, var2 / (var4 * 0.55));
         int var21 = var0.n(12, 6);
         double[] var22 = new double[var21];
         double[] var23 = new double[var21];
         double[] var24 = new double[var21];
         double[] var25 = new double[var21];
         int[] var26 = new int[var21];

         for (int var27 = 0; var27 < var21; var27++) {
            double var28 = (double)var27 / (var21 - 1);
            var22[var27] = var1.x + var10 * var28 * var19;
            var23[var27] = var1.y + 1.0;
            var24[var27] = var1.z + var12 * var28 * var19;
            var25[var27] = 0.5 * (1.0 - var28 * 0.6) * var8;
            var26[var27] = Col.mul(Col.mix(3137648, 12124002, var28), (1.0 - Geo.sstep(0.4, 1.0, var6)) * (0.15 + 0.5 * (1.0 - var28)));
         }

         Geo.ribbon(var0.q, Tex.RIBBON_SOFT, var22, var23, var24, var25, var26, var21, 0.0, 2.0);

         for (int var43 = 0; var43 < var16; var43++) {
            double var44 = (var43 + 0.5) / var16;
            double var30 = var44 * var4 * 0.5;
            double var32 = var2 - var30;
            if (!(var32 < 0.0)) {
               double var34 = (1.0 - Geo.sstep(0.0, var4 * 0.55, var32)) * (0.35 + 0.65 * (1.0 - var44));
               if (!(var34 <= 0.01)) {
                  double var36 = var1.x + var10 * var44 * var19;
                  double var38 = var1.z + var12 * var44 * var19;
                  double var40 = var1.y;
                  int var42 = Col.mul(Col.mix(12124002, 6750059, var44), var34);
                  Geo.standing(var0.q, Tex.GLOW, var36, var40, var38, var17, 0.55, 1.9, 3, Col.mul(3137648, var34 * 0.6), var42);
                  Parts.flare(var0, var36, var40 + 1.55, var38, 0.6, 0.0, 16777215, var34, false);
                  Parts.leaf(var0, var43 & 3, var36, var40 + 0.9, var38, 0.22, var32 * 0.2 + var43, 12124002, var34);
               }
            }
         }
      }
   }
}
