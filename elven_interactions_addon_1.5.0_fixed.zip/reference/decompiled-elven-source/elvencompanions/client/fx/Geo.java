package com.elvencompanions.client.fx;

public final class Geo {
   public static final double TAU = Math.PI * 2;

   public static double clamp01(double var0) {
      return var0 < 0.0 ? 0.0 : (var0 > 1.0 ? 1.0 : var0);
   }

   public static double sstep(double var0, double var2, double var4) {
      double var6 = clamp01((var4 - var0) / (var2 - var0));
      return var6 * var6 * (3.0 - 2.0 * var6);
   }

   public static double lerp(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * var4;
   }

   public static double fadeIO(double var0, double var2, double var4) {
      return sstep(0.0, var2, var0) * (1.0 - sstep(1.0 - var4, 1.0, var0));
   }

   public static double hash(int var0) {
      var0 = var0 << 13 ^ var0;
      var0 = var0 * (var0 * var0 * 15731 + 789221) + 1376312589;
      return (var0 & 2147483647) / 2.147483647E9;
   }

   public static double hash(int var0, int var1) {
      return hash(var0 * 7919 + var1 * 104729 + 17);
   }

   public static void plane(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      int var20,
      double var21,
      double var23,
      double var25,
      double var27
   ) {
      var0.begin(var1);
      var0.v(var2 - var8 - var14, var4 - var10 - var16, var6 - var12 - var18, var21, var23, var20);
      var0.v(var2 + var8 - var14, var4 + var10 - var16, var6 + var12 - var18, var25, var23, var20);
      var0.v(var2 + var8 + var14, var4 + var10 + var16, var6 + var12 + var18, var25, var27, var20);
      var0.v(var2 - var8 + var14, var4 - var10 + var16, var6 - var12 + var18, var21, var27, var20);
   }

   public static void plane4(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      double var18,
      int var20,
      int var21,
      int var22,
      int var23,
      double var24,
      double var26,
      double var28,
      double var30
   ) {
      var0.begin(var1);
      var0.v(var2 - var8 - var14, var4 - var10 - var16, var6 - var12 - var18, var24, var26, var20);
      var0.v(var2 + var8 - var14, var4 + var10 - var16, var6 + var12 - var18, var28, var26, var21);
      var0.v(var2 + var8 + var14, var4 + var10 + var16, var6 + var12 + var18, var28, var30, var22);
      var0.v(var2 - var8 + var14, var4 - var10 + var16, var6 - var12 + var18, var24, var30, var23);
   }

   public static void disc(QuadBuffer var0, Tex var1, double var2, double var4, double var6, double var8, double var10, int var12) {
      double var13 = Math.cos(var10) * var8;
      double var15 = Math.sin(var10) * var8;
      plane(var0, var1, var2, var4, var6, var13, 0.0, var15, -var15, 0.0, var13, var12, 0.0, 0.0, 1.0, 1.0);
   }

   public static void discN(
      QuadBuffer var0, Tex var1, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, int var18
   ) {
      double[] var19 = new double[3];
      double[] var20 = new double[3];
      basis(var10, var12, var14, var19, var20);
      double var21 = Math.cos(var16) * var8;
      double var23 = Math.sin(var16) * var8;
      plane(
         var0,
         var1,
         var2,
         var4,
         var6,
         var19[0] * var21 + var20[0] * var23,
         var19[1] * var21 + var20[1] * var23,
         var19[2] * var21 + var20[2] * var23,
         -var19[0] * var23 + var20[0] * var21,
         -var19[1] * var23 + var20[1] * var21,
         -var19[2] * var23 + var20[2] * var21,
         var18,
         0.0,
         0.0,
         1.0,
         1.0
      );
   }

   public static void basis(double var0, double var2, double var4, double[] var6, double[] var7) {
      double var8 = Math.sqrt(var0 * var0 + var2 * var2 + var4 * var4);
      if (var8 < 1.0E-9) {
         var6[0] = 1.0;
         var6[1] = 0.0;
         var6[2] = 0.0;
         var7[0] = 0.0;
         var7[1] = 0.0;
         var7[2] = 1.0;
      } else {
         var0 /= var8;
         var2 /= var8;
         var4 /= var8;
         double var10 = Math.abs(var2) > 0.9 ? 1.0 : 0.0;
         double var12 = Math.abs(var2) > 0.9 ? 0.0 : 1.0;
         double var14 = 0.0;
         double var16 = var12 * var4 - var14 * var2;
         double var18 = var14 * var0 - var10 * var4;
         double var20 = var10 * var2 - var12 * var0;
         double var22 = Math.sqrt(var16 * var16 + var18 * var18 + var20 * var20);
         var16 /= var22;
         var18 /= var22;
         var20 /= var22;
         var6[0] = var16;
         var6[1] = var18;
         var6[2] = var20;
         var7[0] = var2 * var20 - var4 * var18;
         var7[1] = var4 * var16 - var0 * var20;
         var7[2] = var0 * var18 - var2 * var16;
      }
   }

   public static void billboard(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      int var12,
      double var13,
      double var15,
      double var17,
      double var19
   ) {
      double var21 = var0.ox - var2;
      double var23 = var0.oy - var4;
      double var25 = var0.oz - var6;
      double var27 = Math.sqrt(var21 * var21 + var23 * var23 + var25 * var25);
      if (!(var27 < 1.0E-6)) {
         var21 /= var27;
         var23 /= var27;
         var25 /= var27;
         double var29 = var25;
         double var31 = 0.0;
         double var33 = -var21;
         double var35 = Math.sqrt(var25 * var25 + var33 * var33);
         if (var35 < 1.0E-4) {
            var29 = 1.0;
            var33 = 0.0;
            var35 = 1.0;
         }

         var29 /= var35;
         var33 /= var35;
         double var37 = var23 * var33 - var25 * var31;
         double var39 = var25 * var29 - var21 * var33;
         double var41 = var21 * var31 - var23 * var29;
         double var43 = Math.cos(var10) * var8;
         double var45 = Math.sin(var10) * var8;
         plane(
            var0,
            var1,
            var2,
            var4,
            var6,
            var29 * var43 + var37 * var45,
            var31 * var43 + var39 * var45,
            var33 * var43 + var41 * var45,
            -var29 * var45 + var37 * var43,
            -var31 * var45 + var39 * var43,
            -var33 * var45 + var41 * var43,
            var12,
            var13,
            var15,
            var17,
            var19
         );
      }
   }

   public static void billboard(QuadBuffer var0, Tex var1, double var2, double var4, double var6, double var8, double var10, int var12) {
      billboard(var0, var1, var2, var4, var6, var8, var10, var12, 0.0, 0.0, 1.0, 1.0);
   }

   public static void flameSprite(QuadBuffer var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      var11 &= 15;
      double var13 = var11 % 4 / 4.0;
      double var15 = var11 / 4 / 4.0;
      double var17 = var0.ox - var1;
      double var19 = var0.oz - var5;
      double var21 = Math.sqrt(var17 * var17 + var19 * var19);
      if (!(var21 < 1.0E-4)) {
         double var23 = var19 / var21;
         double var25 = -var17 / var21;
         plane4(
            var0,
            Tex.FLAME,
            var1,
            var3 + var9 / 2.0,
            var5,
            var23 * var7,
            0.0,
            var25 * var7,
            0.0,
            var9 / 2.0,
            0.0,
            var12,
            var12,
            var12,
            var12,
            var13 + 0.002,
            var15 + 0.002,
            var13 + 0.248,
            var15 + 0.248
         );
      }
   }

   public static void standing(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      int var18,
      int var19,
      int var20,
      double var21,
      double var23,
      double var25,
      double var27
   ) {
      for (int var29 = 0; var29 < var18; var29++) {
         double var30 = var8 + var29 * Math.PI / var18;
         double var32 = Math.cos(var30) * var10;
         double var34 = Math.sin(var30) * var10;
         var0.begin(var1);
         var0.v(var2 - var32, var4, var6 - var34, var21, var27, var19);
         var0.v(var2 + var32, var4, var6 + var34, var25, var27, var19);
         var0.v(var2 + var32 + var14, var4 + var12, var6 + var34 + var16, var25, var23, var20);
         var0.v(var2 - var32 + var14, var4 + var12, var6 - var34 + var16, var21, var23, var20);
      }
   }

   public static void standing(
      QuadBuffer var0, Tex var1, double var2, double var4, double var6, double var8, double var10, double var12, int var14, int var15, int var16
   ) {
      standing(var0, var1, var2, var4, var6, var8, var10, var12, 0.0, 0.0, var14, var15, var16, 0.0, 0.0, 1.0, 1.0);
   }

   public static void oriented(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      double var14,
      double var16,
      int var18,
      double var19,
      int var21,
      int var22
   ) {
      double var23 = Math.sqrt(var8 * var8 + var10 * var10 + var12 * var12);
      if (!(var23 < 1.0E-9)) {
         var8 /= var23;
         var10 /= var23;
         var12 /= var23;
         double[] var25 = new double[3];
         double[] var26 = new double[3];
         basis(var8, var10, var12, var25, var26);

         for (int var27 = 0; var27 < var18; var27++) {
            double var28 = var19 + var27 * Math.PI / var18;
            double var30 = Math.cos(var28) * var16;
            double var32 = Math.sin(var28) * var16;
            double var34 = var25[0] * var30 + var26[0] * var32;
            double var36 = var25[1] * var30 + var26[1] * var32;
            double var38 = var25[2] * var30 + var26[2] * var32;
            double var40 = var2 + var8 * var14;
            double var42 = var4 + var10 * var14;
            double var44 = var6 + var12 * var14;
            var0.begin(var1);
            var0.v(var2 - var34, var4 - var36, var6 - var38, 0.0, 1.0, var21);
            var0.v(var2 + var34, var4 + var36, var6 + var38, 1.0, 1.0, var21);
            var0.v(var40 + var34, var42 + var36, var44 + var38, 1.0, 0.0, var22);
            var0.v(var40 - var34, var42 - var36, var44 - var38, 0.0, 0.0, var22);
         }
      }
   }

   public static void ribbon(
      QuadBuffer var0, Tex var1, double[] var2, double[] var3, double[] var4, double[] var5, int[] var6, int var7, double var8, double var10
   ) {
      if (var7 >= 2) {
         double[] var12 = new double[var7];
         double[] var13 = new double[var7];
         double[] var14 = new double[var7];
         double[] var15 = new double[var7];
         double[] var16 = new double[var7];
         double[] var17 = new double[var7];
         double var18 = 0.0;
         double var20 = 1.0;
         double var22 = 0.0;

         for (int var24 = 0; var24 < var7; var24++) {
            int var25 = Math.max(0, var24 - 1);
            int var26 = Math.min(var7 - 1, var24 + 1);
            double var27 = var2[var26] - var2[var25];
            double var29 = var3[var26] - var3[var25];
            double var31 = var4[var26] - var4[var25];
            double var33 = var0.ox - var2[var24];
            double var35 = var0.oy - var3[var24];
            double var37 = var0.oz - var4[var24];
            double var39 = var29 * var37 - var31 * var35;
            double var41 = var31 * var33 - var27 * var37;
            double var43 = var27 * var35 - var29 * var33;
            double var45 = Math.sqrt(var39 * var39 + var41 * var41 + var43 * var43);
            if (var45 < 1.0E-8) {
               var39 = var18;
               var41 = var20;
               var43 = var22;
            } else {
               var39 /= var45;
               var41 /= var45;
               var43 /= var45;
               if (var39 * var18 + var41 * var20 + var43 * var22 < 0.0 && var24 > 0) {
                  var39 = -var39;
                  var41 = -var41;
                  var43 = -var43;
               }
            }

            var18 = var39;
            var20 = var41;
            var22 = var43;
            double var47 = var5[var24] * 0.5;
            var12[var24] = var2[var24] + var39 * var47;
            var13[var24] = var3[var24] + var41 * var47;
            var14[var24] = var4[var24] + var43 * var47;
            var15[var24] = var2[var24] - var39 * var47;
            var16[var24] = var3[var24] - var41 * var47;
            var17[var24] = var4[var24] - var43 * var47;
         }

         for (int var49 = 0; var49 < var7 - 1; var49++) {
            double var50 = lerp(var8, var10, (double)var49 / (var7 - 1));
            double var51 = lerp(var8, var10, (double)(var49 + 1) / (var7 - 1));
            var0.begin(var1);
            var0.v(var12[var49], var13[var49], var14[var49], var50, 0.0, var6[var49]);
            var0.v(var15[var49], var16[var49], var17[var49], var50, 1.0, var6[var49]);
            var0.v(var15[var49 + 1], var16[var49 + 1], var17[var49 + 1], var51, 1.0, var6[var49 + 1]);
            var0.v(var12[var49 + 1], var13[var49 + 1], var14[var49 + 1], var51, 0.0, var6[var49 + 1]);
         }
      }
   }

   public static void tube(
      QuadBuffer var0,
      Tex var1,
      double[] var2,
      double[] var3,
      double[] var4,
      double[] var5,
      int[] var6,
      int var7,
      int var8,
      double var9,
      double var11,
      double var13
   ) {
      if (var7 >= 2) {
         double[][] var15 = new double[var7][];
         double var16 = 0.0;
         double var18 = 0.0;
         double var20 = 0.0;

         for (int var22 = 0; var22 < var7; var22++) {
            int var23 = Math.max(0, var22 - 1);
            int var24 = Math.min(var7 - 1, var22 + 1);
            double var25 = var2[var24] - var2[var23];
            double var27 = var3[var24] - var3[var23];
            double var29 = var4[var24] - var4[var23];
            double var31 = Math.sqrt(var25 * var25 + var27 * var27 + var29 * var29);
            if (var31 < 1.0E-9) {
               var25 = 0.0;
               var27 = 1.0;
               var29 = 0.0;
               var31 = 1.0;
            }

            var25 /= var31;
            var27 /= var31;
            var29 /= var31;
            if (var22 == 0) {
               double[] var33 = new double[3];
               double[] var34 = new double[3];
               basis(var25, var27, var29, var33, var34);
               var16 = var33[0];
               var18 = var33[1];
               var20 = var33[2];
            } else {
               double var59 = var16 * var25 + var18 * var27 + var20 * var29;
               var16 -= var59 * var25;
               var18 -= var59 * var27;
               var20 -= var59 * var29;
               double var35 = Math.sqrt(var16 * var16 + var18 * var18 + var20 * var20);
               if (var35 < 1.0E-9) {
                  double[] var37 = new double[3];
                  double[] var38 = new double[3];
                  basis(var25, var27, var29, var37, var38);
                  var16 = var37[0];
                  var18 = var37[1];
                  var20 = var37[2];
               } else {
                  var16 /= var35;
                  var18 /= var35;
                  var20 /= var35;
               }
            }

            double var60 = var27 * var20 - var29 * var18;
            double var61 = var29 * var16 - var25 * var20;
            double var62 = var25 * var18 - var27 * var16;
            double[] var39 = new double[var8 * 3];

            for (int var40 = 0; var40 < var8; var40++) {
               double var41 = (Math.PI * 2) * var40 / var8;
               double var43 = Math.cos(var41) * var5[var22];
               double var45 = Math.sin(var41) * var5[var22];
               var39[var40 * 3] = var2[var22] + var16 * var43 + var60 * var45;
               var39[var40 * 3 + 1] = var3[var22] + var18 * var43 + var61 * var45;
               var39[var40 * 3 + 2] = var4[var22] + var20 * var43 + var62 * var45;
            }

            var15[var22] = var39;
         }

         for (int var50 = 0; var50 < var7 - 1; var50++) {
            double var51 = lerp(var11, var13, (double)var50 / (var7 - 1));
            double var53 = lerp(var11, var13, (double)(var50 + 1) / (var7 - 1));

            for (int var55 = 0; var55 < var8; var55++) {
               int var28 = (var55 + 1) % var8;
               double var57 = var9 * var55 / var8;
               double var58 = var9 * (var55 + 1) / var8;
               var0.begin(var1);
               var0.v(var15[var50][var55 * 3], var15[var50][var55 * 3 + 1], var15[var50][var55 * 3 + 2], var57, var51, var6[var50]);
               var0.v(var15[var50][var28 * 3], var15[var50][var28 * 3 + 1], var15[var50][var28 * 3 + 2], var58, var51, var6[var50]);
               var0.v(var15[var50 + 1][var28 * 3], var15[var50 + 1][var28 * 3 + 1], var15[var50 + 1][var28 * 3 + 2], var58, var53, var6[var50 + 1]);
               var0.v(var15[var50 + 1][var55 * 3], var15[var50 + 1][var55 * 3 + 1], var15[var50 + 1][var55 * 3 + 2], var57, var53, var6[var50 + 1]);
            }
         }
      }
   }

   public static void cylinder(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      int var14,
      double var15,
      int var17,
      int var18,
      double var19,
      double var21,
      double var23,
      double var25
   ) {
      for (int var27 = 0; var27 < var14; var27++) {
         double var28 = var15 + (Math.PI * 2) * var27 / var14;
         double var30 = var15 + (Math.PI * 2) * (var27 + 1) / var14;
         double var32 = Math.cos(var28);
         double var34 = Math.sin(var28);
         double var36 = Math.cos(var30);
         double var38 = Math.sin(var30);
         double var40 = var21 + var19 * var27 / var14;
         double var42 = var21 + var19 * (var27 + 1) / var14;
         var0.begin(var1);
         var0.v(var2 + var32 * var8, var4, var6 + var34 * var8, var40, var25, var17);
         var0.v(var2 + var36 * var8, var4, var6 + var38 * var8, var42, var25, var17);
         var0.v(var2 + var36 * var10, var4 + var12, var6 + var38 * var10, var42, var23, var18);
         var0.v(var2 + var32 * var10, var4 + var12, var6 + var34 * var10, var40, var23, var18);
      }
   }

   public static void dome(
      QuadBuffer var0,
      Tex var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      int var12,
      int var13,
      double var14,
      int var16,
      int var17,
      double var18,
      double var20,
      double var22
   ) {
      for (int var24 = 0; var24 < var12; var24++) {
         double var25 = (Math.PI / 2) * var24 / var12;
         double var27 = (Math.PI / 2) * (var24 + 1) / var12;
         if (var25 / (Math.PI / 2) > var22) {
            break;
         }

         int var29 = lerpCol(var16, var17, (double)var24 / var12);
         int var30 = lerpCol(var16, var17, (double)(var24 + 1) / var12);

         for (int var31 = 0; var31 < var13; var31++) {
            double var32 = var14 + (Math.PI * 2) * var31 / var13;
            double var34 = var14 + (Math.PI * 2) * (var31 + 1) / var13;
            double var36 = var18 * var31 / var13;
            double var38 = var18 * (var31 + 1) / var13;
            double var40 = var20 * var24 / var12;
            double var42 = var20 * (var24 + 1) / var12;
            var0.begin(var1);
            var0.v(
               var2 + Math.cos(var25) * Math.cos(var32) * var8,
               var4 + Math.sin(var25) * var8 * var10,
               var6 + Math.cos(var25) * Math.sin(var32) * var8,
               var36,
               var40,
               var29
            );
            var0.v(
               var2 + Math.cos(var25) * Math.cos(var34) * var8,
               var4 + Math.sin(var25) * var8 * var10,
               var6 + Math.cos(var25) * Math.sin(var34) * var8,
               var38,
               var40,
               var29
            );
            var0.v(
               var2 + Math.cos(var27) * Math.cos(var34) * var8,
               var4 + Math.sin(var27) * var8 * var10,
               var6 + Math.cos(var27) * Math.sin(var34) * var8,
               var38,
               var42,
               var30
            );
            var0.v(
               var2 + Math.cos(var27) * Math.cos(var32) * var8,
               var4 + Math.sin(var27) * var8 * var10,
               var6 + Math.cos(var27) * Math.sin(var32) * var8,
               var36,
               var42,
               var30
            );
         }
      }
   }

   public static int lerpCol(int var0, int var1, double var2) {
      return Col.mix(var0, var1, var2);
   }

   private Geo() {
   }
}
