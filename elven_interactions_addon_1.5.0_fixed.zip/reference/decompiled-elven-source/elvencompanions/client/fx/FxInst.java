package com.elvencompanions.client.fx;

public final class FxInst {
   public final int kind;
   public final int ent;
   public final int ticks;
   public final int seed;
   public final double x;
   public final double y;
   public final double z;
   public final double x2;
   public final double y2;
   public final double z2;
   public final float sc;
   public int age;
   public double cx;
   public double cy;
   public double cz;
   public double pcx;
   public double pcy;
   public double pcz;
   public double yaw;
   public double lx;
   public double ly;
   public double lz;
   public boolean hasLink;

   public FxInst(int var1, int var2, double var3, double var5, double var7, double var9, double var11, double var13, int var15, float var16, int var17) {
      this.kind = var1;
      this.ent = var2;
      this.x = var3;
      this.y = var5;
      this.z = var7;
      this.x2 = var9;
      this.y2 = var11;
      this.z2 = var13;
      this.ticks = Math.max(1, var15);
      this.sc = var16 <= 0.0F ? 1.0F : var16;
      this.seed = var17;
      this.cx = this.pcx = var3;
      this.cy = this.pcy = var5;
      this.cz = this.pcz = var7;
   }

   public double ix(double var1) {
      return this.pcx + (this.cx - this.pcx) * var1;
   }

   public double iy(double var1) {
      return this.pcy + (this.cy - this.pcy) * var1;
   }

   public double iz(double var1) {
      return this.pcz + (this.cz - this.pcz) * var1;
   }
}
