package com.elvencompanions.client.fx;

public final class AuraState {
   public static final int NORMAL = 0;
   public static final int RAGE = 1;
   public static final int TRANSCEND = 2;
   private static final int H = 64;
   public final int id;
   public int kind;
   public int tick;
   public int lastTouched;
   public double life;
   public double prevLife;
   public double target = 1.0;
   private final double[] hx = new double[64];
   private final double[] hy = new double[64];
   private final double[] hz = new double[64];

   public AuraState(int var1, double var2, double var4, double var6) {
      this.id = var1;

      for (int var8 = 0; var8 < 64; var8++) {
         this.hx[var8] = var2;
         this.hy[var8] = var4;
         this.hz[var8] = var6;
      }
   }

   public void push(double var1, double var3, double var5) {
      this.tick++;
      int var7 = this.tick & 63;
      this.hx[var7] = var1;
      this.hy[var7] = var3;
      this.hz[var7] = var5;
      this.prevLife = this.life;
      this.life = this.life + (this.target - this.life) * 0.18;
      if (Math.abs(this.target - this.life) < 0.01) {
         this.life = this.target;
      }
   }

   public double lifeAt(double var1) {
      return this.prevLife + (this.life - this.prevLife) * var1;
   }

   public void posAt(double var1, double var3, double[] var5) {
      double var6 = this.tick - 1 + var3 - var1;
      double var8 = this.tick - 61;
      if (var6 < var8) {
         var6 = var8;
      }

      if (var6 < 0.0) {
         var6 = 0.0;
      }

      int var10 = (int)Math.floor(var6);
      double var11 = var6 - var10;
      int var13 = var10 & 63;
      int var14 = var10 + 1 & 63;
      if (var10 + 1 > this.tick) {
         var14 = var13;
      }

      var5[0] = this.hx[var13] + (this.hx[var14] - this.hx[var13]) * var11;
      var5[1] = this.hy[var13] + (this.hy[var14] - this.hy[var13]) * var11;
      var5[2] = this.hz[var13] + (this.hz[var14] - this.hz[var13]) * var11;
   }
}
