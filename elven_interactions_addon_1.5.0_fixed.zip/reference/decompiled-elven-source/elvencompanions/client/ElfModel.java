package com.elvencompanions.client;

import com.elvencompanions.ECConfig;
import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.entity.ElfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class ElfModel extends EntityModel<ElfEntity> implements ArmedModel {
   private static final float DEG = (float) (Math.PI / 180.0);
   private static final float HALF_PI = (float) (Math.PI / 2);
   private static final float[] HIP = new float[]{0.0F, 0.75F, 0.0F};
   private static final float[] NECK = new float[]{0.0F, 1.5F, 0.0F};
   private static final float SHOULDER_X = 0.3125F;
   private static final float SHOULDER_Y = 1.375F;
   private static final float LEG_X = 0.125F;
   private float headX;
   private float headY;
   private float torsoX;
   private float torsoZ;
   private float drop;
   private float rArmX;
   private float rArmY;
   private float rArmZ;
   private float lArmX;
   private float lArmY;
   private float lArmZ;
   private float rLegX;
   private float rLegZ;
   private float lLegX;
   private float lLegZ;
   private float rLegY;
   private float lLegY;
   private float bowYaw;
   private float bowPitch;
   private float swingAmt;
   public static final ResourceLocation CELESTIAL_ARMOR_TEX = ElvenCompanions.rl("textures/entity/celestial_armor.png");
   public static final ResourceLocation CELESTIAL_GLOW_TEX = ElvenCompanions.rl("textures/entity/celestial_glow.png");
   private static final float[] WHITE = new float[]{0.0F, 0.0F, 0.25F, 0.25F};
   private static final float[] GOLD = new float[]{0.25F, 0.0F, 0.5F, 0.25F};
   private static final float[] HAIR = new float[]{0.5F, 0.0F, 1.0F, 0.5F};
   private static final float[] EYE = new float[]{0.0F, 0.0F, 0.25F, 0.25F};
   private static final float[] WING = new float[]{0.0F, 0.5F, 0.5F, 1.0F};
   private static final float[] FULL_UV = new float[]{0.0F, 0.0F, 1.0F, 1.0F};
   public static final ResourceLocation CELESTIAL_WING_TEX = ElvenCompanions.rl("textures/entity/celestial_wing.png");
   private static final float[] WING_ANCHOR = new float[]{0.09F, 1.3F, 0.235F};
   private static final float[] WG_SEG = new float[]{
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F
   };
   private static final float[] WG_T = new float[]{
      1.0F,
      0.965F,
      0.93F,
      0.895F,
      0.86F,
      0.825F,
      0.79F,
      0.12F,
      0.26F,
      0.4F,
      0.54F,
      0.68F,
      0.82F,
      0.3F,
      0.52F,
      0.74F,
      0.96F,
      0.15F,
      0.43F,
      0.71F,
      0.99F,
      0.1F,
      0.3F,
      0.5F,
      0.7F,
      0.9F
   };
   private static final float[] WG_AS = new float[]{
      0.244F,
      0.0F,
      -0.244F,
      -0.489F,
      -0.733F,
      -0.977F,
      -1.222F,
      -1.082F,
      -1.169F,
      -1.257F,
      -1.344F,
      -1.431F,
      -1.518F,
      -1.676F,
      -1.78F,
      -1.885F,
      -1.99F,
      -1.431F,
      -1.326F,
      -1.222F,
      -1.117F,
      -0.908F,
      -0.733F,
      -0.559F,
      -0.384F,
      -0.209F
   };
   private static final float[] WG_AF = new float[]{
      -1.466F,
      -1.501F,
      -1.536F,
      -1.571F,
      -1.606F,
      -1.641F,
      -1.676F,
      -1.571F,
      -1.571F,
      -1.571F,
      -1.571F,
      -1.571F,
      -1.571F,
      -1.606F,
      -1.606F,
      -1.606F,
      -1.606F,
      -1.571F,
      -1.571F,
      -1.571F,
      -1.571F,
      -1.536F,
      -1.536F,
      -1.536F,
      -1.536F,
      -1.536F
   };
   private static final float[] WG_LS = new float[]{
      1.2F,
      1.32F,
      1.38F,
      1.36F,
      1.28F,
      1.16F,
      1.02F,
      0.98F,
      1.02F,
      1.04F,
      1.02F,
      0.96F,
      0.88F,
      0.82F,
      0.74F,
      0.66F,
      0.58F,
      0.44F,
      0.44F,
      0.44F,
      0.44F,
      0.5F,
      0.52F,
      0.54F,
      0.56F,
      0.58F
   };
   private static final float[] WG_LF = new float[]{
      1.032F,
      1.135F,
      1.187F,
      1.17F,
      1.101F,
      0.998F,
      0.877F,
      0.823F,
      0.857F,
      0.874F,
      0.857F,
      0.806F,
      0.739F,
      0.705F,
      0.636F,
      0.568F,
      0.499F,
      0.4F,
      0.4F,
      0.4F,
      0.4F,
      0.44F,
      0.44F,
      0.44F,
      0.44F,
      0.44F
   };
   private static final float[] WG_W = new float[]{
      0.3F,
      0.294F,
      0.288F,
      0.282F,
      0.276F,
      0.27F,
      0.264F,
      0.27F,
      0.27F,
      0.27F,
      0.27F,
      0.27F,
      0.27F,
      0.25F,
      0.25F,
      0.25F,
      0.25F,
      0.2F,
      0.2F,
      0.2F,
      0.2F,
      0.2F,
      0.2F,
      0.2F,
      0.2F,
      0.2F
   };
   private static final float[] WG_TIER = new float[]{
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      0.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      1.0F,
      2.0F,
      2.0F,
      2.0F,
      2.0F,
      2.0F,
      2.0F,
      2.0F,
      2.0F,
      2.0F
   };
   private static final float[] WG_JS = new float[]{0.0F, 0.0F, 0.42F, 0.5F, 0.98F, 0.8F};
   private static final float[] WG_JF = new float[]{0.0F, 0.0F, 0.1F, 0.36F, 0.15F, 0.62F};
   private static final float[] RUNE = new float[]{0.5F, 0.5F, 1.0F, 1.0F};

   public float armorDrop() {
      return this.drop;
   }

   public float torsoX() {
      return this.torsoX;
   }

   public float torsoZ() {
      return this.torsoZ;
   }

   public void poseArmor(HumanoidModel<?> var1) {
      var1.head.xRot = -this.headX;
      var1.head.yRot = -this.headY;
      var1.head.zRot = 0.0F;
      var1.hat.copyFrom(var1.head);
      var1.body.xRot = 0.0F;
      var1.body.yRot = 0.0F;
      var1.body.zRot = 0.0F;
      var1.rightArm.xRot = -this.rArmX;
      var1.rightArm.yRot = -this.rArmY;
      var1.rightArm.zRot = this.rArmZ;
      var1.leftArm.xRot = -this.lArmX;
      var1.leftArm.yRot = -this.lArmY;
      var1.leftArm.zRot = this.lArmZ;
      var1.rightLeg.xRot = -this.rLegX;
      var1.rightLeg.yRot = -this.rLegY;
      var1.rightLeg.zRot = this.rLegZ;
      var1.leftLeg.xRot = -this.lLegX;
      var1.leftLeg.yRot = -this.lLegY;
      var1.leftLeg.zRot = this.lLegZ;
   }

   public ElfModel() {
      super(RenderType::entityCutoutNoCull);
   }

   public void setupAnim(ElfEntity var1, float var2, float var3, float var4, float var5, float var6) {
      var3 = ElfFlightPose.limb(var1, var3);
      this.headX = this.headY = this.torsoX = this.torsoZ = this.drop = 0.0F;
      this.rArmX = this.rArmY = this.rArmZ = this.lArmX = this.lArmY = this.lArmZ = this.rLegX = this.rLegZ = this.lLegX = this.lLegZ = this.rLegY = this.lLegY = this.bowYaw = this.bowPitch = 0.0F;
      float var7 = var2 * 0.6662F;
      this.swingAmt = var3;
      float var8 = var6 * (float) (Math.PI / 180.0);
      boolean var9 = var1.getRestState() >= 2 || var1.isSleeping();
      boolean var10 = !var9 && (var1.getStance() == 1 || this.riding || var1.isCarried());
      this.headY = -var5 * (float) (Math.PI / 180.0);
      this.headX = -var8;
      if (var9) {
         this.headX = 0.0F;
         this.headY = 0.0F;
      }

      this.rLegX = Mth.cos(var7) * 1.2F * var3;
      this.lLegX = -this.rLegX;
      this.rArmX = -Mth.cos(var7) * 0.9F * var3;
      this.lArmX = -this.rArmX;
      float var11 = Mth.sin(var4 * 0.09F) * 0.04F + 0.06F;
      this.rArmZ = var11;
      this.lArmZ = -var11;
      if (var9) {
         this.rArmX = 0.1F;
         this.lArmX = 0.1F;
         this.rArmZ = 0.12F;
         this.lArmZ = -0.12F;
         this.rLegX = this.lLegX = 0.0F;
      } else if (var10) {
         this.drop = 0.62F;
         this.rLegX = this.lLegX = (float) (Math.PI / 2);
         this.rLegZ = 0.08F;
         this.lLegZ = -0.08F;
         this.rArmX = this.lArmX = 0.55F;
         this.rArmZ = 0.18F;
         this.lArmZ = -0.18F;
      }

      if (!var9 && var1.isAggressive() && !var1.isDrinking()) {
         this.rArmX = (float) (Math.PI / 2) - var8;
         this.rArmY = this.headY + 0.12F;
         this.rArmZ = 0.0F;
         this.lArmX = (float) (Math.PI / 2) - var8;
         this.lArmY = this.headY - 0.55F;
         this.lArmZ = 0.0F;
      }

      if (var1.isDrinking()) {
         this.rArmX = 2.35F;
         this.rArmY = 0.3F;
         this.rArmZ = 0.0F;
      }

      switch (var1.getAnim()) {
         case 1:
         case 4:
            this.rArmX = this.lArmX = (float) (Math.PI / 2) - var8;
            this.rArmY = this.headY + 0.1F;
            this.lArmY = this.headY - 0.5F;
            this.rArmZ = this.lArmZ = 0.0F;
            break;
         case 2:
            this.rArmX = this.lArmX = 2.6F;
            this.rArmZ = 0.5F;
            this.lArmZ = -0.5F;
            this.rLegX = 0.6F;
            this.lLegX = -0.3F;
            this.torsoX = -0.1F;
            break;
         case 3:
            float var12 = Mth.sin(var4 * 1.6F) * 0.12F;
            this.rArmX = (float) (Math.PI / 2) - var8 + var12;
            this.lArmX = (float) (Math.PI / 2) - var8 - var12;
            this.rArmY = this.headY + 0.1F;
            this.lArmY = this.headY - 0.5F;
            this.rArmZ = this.lArmZ = 0.0F;
            break;
         case 5:
            this.rArmX = this.lArmX = 3.0F;
            this.rArmZ = 0.35F;
            this.lArmZ = -0.35F;
            this.headX = 0.3F;
            break;
         case 6:
            this.rArmX = this.lArmX = 3.1F + Mth.sin(var4 * 0.1F) * 0.06F;
            this.rArmZ = 0.55F;
            this.lArmZ = -0.55F;
            this.torsoX = -0.18F;
            this.headX = 0.35F;
            this.headY = 0.0F;
            this.rLegX = 0.15F + Mth.sin(var4 * 0.08F) * 0.05F;
            this.lLegX = -0.1F;
            this.rLegZ = 0.12F;
            this.lLegZ = -0.12F;
            break;
         case 7:
            int var13 = var1.getDashDir();
            if (var13 == 1 || var13 == 2) {
               this.torsoZ = var13 == 1 ? 0.4F : -0.4F;
               this.rArmZ = var13 == 1 ? 0.9F : 0.1F;
               this.lArmZ = var13 == 1 ? -0.1F : -0.9F;
               this.rArmX = this.lArmX = 0.3F;
               this.rLegZ = var13 == 1 ? -0.3F : 0.5F;
               this.lLegZ = var13 == 1 ? -0.5F : 0.3F;
            } else if (var13 == 3) {
               this.torsoX = 0.5F;
               this.rArmX = this.lArmX = -1.1F;
               this.rLegX = 0.9F;
               this.lLegX = -0.9F;
            } else {
               this.torsoX = -0.3F;
               this.rArmX = this.lArmX = 0.8F;
               this.rLegX = -0.7F;
               this.lLegX = 0.7F;
            }
            break;
         case 8:
            this.rArmX = this.lArmX = 2.7F;
            this.rArmZ = 0.7F;
            this.lArmZ = -0.7F;
            this.torsoX = -0.22F;
            this.headX = 0.4F;
            this.rLegZ = 0.15F;
            this.lLegZ = -0.15F;
            break;
         case 9:
            this.rArmX = this.lArmX = 0.3F;
            this.rArmZ = 1.35F;
            this.lArmZ = -1.35F;
            this.headX = 0.5F;
            this.headY = 0.0F;
            this.torsoX = -0.1F;
            break;
         case 10:
            this.rArmX = this.lArmX = 0.9F;
            this.rArmY = 0.12F;
            this.lArmY = -0.3F;
            this.headX = -0.55F;
            this.torsoX = 0.18F;
            this.rLegX = 0.15F;
            this.lLegX = -0.1F;
      }

      int var16 = var1.getWakeAnim();
      if (var16 > 0) {
         float var17 = Mth.sin(var16 / 20.0F * (float) Math.PI);
         this.rArmX = this.lArmX = 2.8F * var17;
         this.rArmZ = 0.5F * var17;
         this.lArmZ = -0.5F * var17;
         this.headX = 0.3F * var17;
      }

      if (this.riding && !var9) {
         this.rArmX = this.lArmX = 0.9F;
         this.rArmZ = 0.1F;
         this.lArmZ = -0.1F;
      }

      if (var1.isCarried() && !var9 && var1.getAnim() == 0) {
         Player var18 = var1.getOwnerPlayer();
         boolean var14 = var18 != null && ElfEntity.carrierLying(var18);
         if (!var14) {
            this.torsoX = 0.28F;
            this.rLegX = this.lLegX = 1.35F;
            this.rLegY = -0.8F;
            this.lLegY = 0.8F;
            this.rLegZ = this.lLegZ = 0.0F;
            this.rArmX = this.lArmX = 0.6F;
            this.rArmY = 0.3F;
            this.lArmY = -0.3F;
            this.rArmZ = 0.12F;
            this.lArmZ = -0.12F;
         } else {
            this.torsoX = -1.15F;
            this.rLegX = this.lLegX = 0.25F;
            this.rLegY = -0.5F;
            this.lLegY = 0.5F;
            this.rArmX = this.lArmX = 1.2F;
            this.rArmY = 0.3F;
            this.lArmY = -0.3F;
         }
      }

      if (this.rArmX > 1.1F && this.rArmX < 2.2F) {
         this.bowPitch = Mth.clamp(this.rArmX - (float) (Math.PI / 2), -0.9F, 0.9F);
         this.bowYaw = this.rArmY;
      }
   }

   public void renderToBuffer(PoseStack var1, VertexConsumer var2, int var3, int var4, int var5) {
      var5 = ElfGhost.tint(var5);
      ElfObjModel var6 = ElfObjModel.get();
      boolean var7 = (Boolean)ECConfig.renderEquipmentMeshes.get();
      var1.pushPose();
      toObjFrame(var1);
      var1.translate(0.0F, -this.drop, 0.0F);
      bone(var1, var2, var6, ElfObjModel.Bone.R_LEG, 0.125F, HIP[1], 0.0F, this.rLegX, this.rLegY, this.rLegZ, var3, var4, var5, var7);
      bone(var1, var2, var6, ElfObjModel.Bone.L_LEG, -0.125F, HIP[1], 0.0F, this.lLegX, this.lLegY, this.lLegZ, var3, var4, var5, var7);
      var1.pushPose();
      pivotRotate(var1, HIP[0], HIP[1], HIP[2], this.torsoX, 0.0F, this.torsoZ);
      bone(var1, var2, var6, ElfObjModel.Bone.BODY, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, var3, var4, var5, var7);
      bone(var1, var2, var6, ElfObjModel.Bone.HEAD, NECK[0], NECK[1], NECK[2], this.headX, this.headY, 0.0F, var3, var4, var5, var7);
      bone(var1, var2, var6, ElfObjModel.Bone.R_ARM, 0.3125F, 1.375F, 0.0F, this.rArmX, this.rArmY, this.rArmZ, var3, var4, var5, var7);
      bone(var1, var2, var6, ElfObjModel.Bone.L_ARM, -0.3125F, 1.375F, 0.0F, this.lArmX, this.lArmY, this.lArmZ, var3, var4, var5, var7);
      var1.popPose();
      var1.popPose();
   }

   private static void toObjFrame(PoseStack var0) {
      var0.translate(0.0F, 1.501F, 0.0F);
      var0.scale(-1.0F, -1.0F, 1.0F);
   }

   private static void pivotRotate(PoseStack var0, float var1, float var2, float var3, float var4, float var5, float var6) {
      var0.translate(var1, var2, var3);
      if (var6 != 0.0F) {
         var0.mulPose(Axis.ZP.rotation(var6));
      }

      if (var5 != 0.0F) {
         var0.mulPose(Axis.YP.rotation(var5));
      }

      if (var4 != 0.0F) {
         var0.mulPose(Axis.XP.rotation(var4));
      }

      var0.translate(-var1, -var2, -var3);
   }

   private static void bone(
      PoseStack var0,
      VertexConsumer var1,
      ElfObjModel var2,
      ElfObjModel.Bone var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      int var10,
      int var11,
      int var12,
      boolean var13
   ) {
      var0.pushPose();
      pivotRotate(var0, var4, var5, var6, var7, var8, var9);

      for (ElfObjModel.Part var15 : var2.parts) {
         if (var15.bone == var3 && (var13 || !var15.equipment)) {
            var15.render(var0.last(), var1, var10, var11, var12);
         }
      }

      var0.popPose();
   }

   public void transformToBow(PoseStack var1, float var2) {
      toObjFrame(var1);
      var1.translate(0.0F, -this.drop, 0.0F);
      pivotRotate(var1, HIP[0], HIP[1], HIP[2], this.torsoX, 0.0F, this.torsoZ);
      Vector3f var3 = new Vector3f(0.0F, -0.6F, 0.0F);
      new Matrix4f().rotateZ(this.rArmZ).rotateY(this.rArmY).rotateX(this.rArmX).transformPosition(var3);
      var1.translate(0.3125F + var3.x, 1.375F + var3.y, var3.z - 0.08F);
      if (this.bowYaw != 0.0F) {
         var1.mulPose(Axis.YP.rotation(this.bowYaw));
      }

      if (this.bowPitch != 0.0F) {
         var1.mulPose(Axis.XP.rotation(this.bowPitch));
      }

      var1.mulPose(new Quaternionf().setFromNormalized(new Matrix3f(0.0F, 0.0F, -1.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F)));
      var1.scale(var2, var2, var2);
   }

   public void translateToHand(HumanoidArm var1, PoseStack var2) {
      toObjFrame(var2);
      var2.translate(0.0F, -this.drop, 0.0F);
      pivotRotate(var2, HIP[0], HIP[1], HIP[2], this.torsoX, 0.0F, this.torsoZ);
      boolean var3 = var1 == HumanoidArm.RIGHT;
      float var4 = var3 ? 0.3125F : -0.3125F;
      pivotRotate(var2, var4, 1.375F, 0.0F, var3 ? this.rArmX : this.lArmX, var3 ? this.rArmY : this.lArmY, var3 ? this.rArmZ : this.lArmZ);
      var2.translate(var4, 1.375F, 0.0F);
      var2.scale(-1.0F, -1.0F, 1.0F);
   }

   static void quad(
      Pose var0,
      VertexConsumer var1,
      int var2,
      int var3,
      float var4,
      float var5,
      float var6,
      float[] var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17,
      float var18,
      float var19
   ) {
      var1.addVertex(var0.pose(), var8, var9, var10)
         .setColor(var3)
         .setUv(var7[0], var7[1])
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(var2)
         .setNormal(var0, var4, var5, var6);
      var1.addVertex(var0.pose(), var11, var12, var13)
         .setColor(var3)
         .setUv(var7[2], var7[1])
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(var2)
         .setNormal(var0, var4, var5, var6);
      var1.addVertex(var0.pose(), var14, var15, var16)
         .setColor(var3)
         .setUv(var7[2], var7[3])
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(var2)
         .setNormal(var0, var4, var5, var6);
      var1.addVertex(var0.pose(), var17, var18, var19)
         .setColor(var3)
         .setUv(var7[0], var7[3])
         .setOverlay(OverlayTexture.NO_OVERLAY)
         .setLight(var2)
         .setNormal(var0, var4, var5, var6);
   }

   private static void box(PoseStack var0, VertexConsumer var1, int var2, float[] var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      Pose var10 = var0.last();
      byte var11 = -1;
      quad(var10, var1, var2, var11, 0.0F, 0.0F, -1.0F, var3, var4, var8, var6, var7, var8, var6, var7, var5, var6, var4, var5, var6);
      quad(var10, var1, var2, var11, 0.0F, 0.0F, 1.0F, var3, var7, var8, var9, var4, var8, var9, var4, var5, var9, var7, var5, var9);
      quad(var10, var1, var2, var11, 1.0F, 0.0F, 0.0F, var3, var7, var8, var6, var7, var8, var9, var7, var5, var9, var7, var5, var6);
      quad(var10, var1, var2, var11, -1.0F, 0.0F, 0.0F, var3, var4, var8, var9, var4, var8, var6, var4, var5, var6, var4, var5, var9);
      quad(var10, var1, var2, var11, 0.0F, 1.0F, 0.0F, var3, var4, var8, var9, var7, var8, var9, var7, var8, var6, var4, var8, var6);
      quad(var10, var1, var2, var11, 0.0F, -1.0F, 0.0F, var3, var4, var5, var6, var7, var5, var6, var7, var5, var9, var4, var5, var9);
   }

   private static void flat(
      PoseStack var0,
      VertexConsumer var1,
      int var2,
      float[] var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15
   ) {
      Pose var16 = var0.last();
      quad(var16, var1, 15728880, var2, 0.0F, 0.0F, 1.0F, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15);
      quad(var16, var1, 15728880, var2, 0.0F, 0.0F, -1.0F, var3, var13, var14, var15, var10, var11, var12, var7, var8, var9, var4, var5, var6);
   }

   private static float lerpf(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   private void wings(PoseStack var1, VertexConsumer var2, int var3, float var4, float var5, float var6, boolean var7) {
      float var8 = (0.82F + 0.18F * var5) * (1.0F + 0.45F * var6);
      float var9 = var7 ? 0.15F : 0.1F;
      float var10 = var4 * var9;
      float var11 = (var7 ? 0.26F : 0.2F) * var5;
      float var12 = Mth.sin(var4 * 0.06F) * 0.025F * (1.0F - var5 * 0.5F);
      float var13 = (Mth.sin(var10) + 0.25F * Mth.sin(2.0F * var10 - 0.9F)) * var11;
      float var14 = Mth.sin(var10 - 0.7F) * 0.12F * var5;
      int var15 = (int)(168.0F + 87.0F * var5);
      if (var3 == 1) {
         var15 = (int)((70.0F + 120.0F * var5) * (1.0F + 0.3F * var6));
         var15 = Math.min(255, var15);
      }

      int var16 = ARGB32.color(var15, 255, (int)(255.0F - 28.0F * var6), (int)(255.0F - 95.0F * var6));
      float[] var17 = WG_JS;
      float[] var18 = WG_JF;
      float var19 = lerpf(var18[0], var17[0], var5);
      float var20 = lerpf(var18[1], var17[1], var5);
      float var21 = lerpf(var18[2], var17[2], var5);
      float var22 = lerpf(var18[3], var17[3], var5);
      float var23 = lerpf(var18[4], var17[4], var5);
      float var24 = lerpf(var18[5], var17[5], var5);

      for (int var25 = 0; var25 < 2; var25++) {
         float var26 = var25 == 0 ? 1.0F : -1.0F;
         var1.pushPose();
         var1.translate(var26 * WING_ANCHOR[0], WING_ANCHOR[1], WING_ANCHOR[2]);
         var1.mulPose(Axis.YP.rotation(-var26 * (0.06F + 0.24F * var5 + var13 + var12)));
         var1.mulPose(Axis.XP.rotation(0.1F + 0.2F * var5 + var12 * 0.5F + var14));
         var1.scale(var8, var8, var8);
         Pose var27 = var1.last();

         for (int var28 = 0; var28 < WG_T.length; var28++) {
            boolean var29 = WG_SEG[var28] > 0.5F;
            float var30 = WG_T[var28];
            float var31 = var29 ? lerpf(var21, var23, var30) : lerpf(var19, var21, var30);
            float var32 = var29 ? lerpf(var22, var24, var30) : lerpf(var20, var22, var30);
            int var33 = (int)WG_TIER[var28];
            float var34 = Mth.sin(var4 * var9 * 0.9F - var28 * 0.33F) * 0.045F * var5 * (var33 == 0 ? 1.0F : 0.6F);
            float var35 = lerpf(WG_AF[var28], WG_AS[var28], var5) + var34;
            float var36 = lerpf(WG_LF[var28], WG_LS[var28], var5);
            float var37 = WG_W[var28];
            if (var3 == 1) {
               var36 *= 1.07F;
               var37 *= 1.35F;
            }

            float var38 = Mth.cos(var35);
            float var39 = Mth.sin(var35);
            float var40 = -var39 * var37 * 0.5F;
            float var41 = var38 * var37 * 0.5F;
            float var42 = var33 * 0.012F + (var3 == 1 ? 0.006F : 0.0F);
            float var43 = var26 * (var31 - var40);
            float var44 = var32 - var41;
            float var45 = var26 * (var31 + var38 * var36 - var40);
            float var46 = var32 + var39 * var36 - var41;
            float var47 = var26 * (var31 + var38 * var36 + var40);
            float var48 = var32 + var39 * var36 + var41;
            float var49 = var26 * (var31 + var40);
            float var50 = var32 + var41;
            if (var3 == 0) {
               quad(var27, var2, 15728880, var16, 0.0F, 1.0F, 0.0F, FULL_UV, var43, var44, var42, var45, var46, var42, var47, var48, var42, var49, var50, var42);
            } else {
               quad(var27, var2, 15728880, var16, 0.0F, 0.0F, 1.0F, WING, var43, var44, var42, var45, var46, var42, var47, var48, var42, var49, var50, var42);
               quad(var27, var2, 15728880, var16, 0.0F, 0.0F, -1.0F, WING, var49, var50, var42, var47, var48, var42, var45, var46, var42, var43, var44, var42);
            }
         }

         var1.popPose();
      }
   }

   public void renderCelestial(PoseStack var1, MultiBufferSource var2, int var3, float var4, float var5, float var6, boolean var7) {
      float var8 = Math.max(var5, var6);
      float var9 = var8 * var8 * (3.0F - 2.0F * var8);
      VertexConsumer var10 = var2.getBuffer(RenderType.entityTranslucentEmissive(CELESTIAL_WING_TEX));
      var1.pushPose();
      toObjFrame(var1);
      var1.translate(0.0F, -this.drop, 0.0F);
      pivotRotate(var1, HIP[0], HIP[1], HIP[2], this.torsoX, 0.0F, this.torsoZ);
      this.wings(var1, var10, 0, var4, var9, var6, var7);
      var1.popPose();
      VertexConsumer var11 = var2.getBuffer(RenderType.entityCutoutNoCull(CELESTIAL_ARMOR_TEX));
      Object var12 = null;
      var1.pushPose();
      toObjFrame(var1);
      var1.translate(0.0F, -this.drop, 0.0F);

      for (int var13 = 0; var13 < 2; var13++) {
         boolean var14 = var13 == 0;
         float var15 = var14 ? 1.0F : -1.0F;
         float var16 = var14 ? this.rLegX : this.lLegX;
         float var17 = var14 ? this.rLegY : this.lLegY;
         float var18 = var14 ? this.rLegZ : this.lLegZ;
         var1.pushPose();
         pivotRotate(var1, var15 * 0.125F, HIP[1], 0.0F, var16, var17, var18);
         float var19 = var14 ? -0.015F : -0.265F;
         float var20 = var14 ? 0.265F : 0.015F;
         box(var1, var11, var3, WHITE, var19, 0.1F, -0.14F, var20, 0.46F, 0.14F);
         box(var1, var11, var3, GOLD, var19 - 0.005F, 0.42F, -0.145F, var20 + 0.005F, 0.5F, 0.145F);
         box(var1, var11, var3, GOLD, var19, 0.06F, -0.145F, var20, 0.12F, 0.145F);
         var1.popPose();
      }

      var1.pushPose();
      pivotRotate(var1, HIP[0], HIP[1], HIP[2], this.torsoX, 0.0F, this.torsoZ);
      box(var1, var11, var3, WHITE, -0.27F, 1.02F, -0.155F, 0.27F, 1.5F, 0.155F);
      box(var1, var11, var3, GOLD, -0.255F, 1.46F, -0.15F, 0.255F, 1.54F, 0.15F);
      box(var1, var11, var3, GOLD, -0.275F, 0.77F, -0.16F, 0.275F, 0.88F, 0.16F);
      box(var1, var11, var3, GOLD, -0.09F, 1.16F, -0.162F, 0.09F, 1.36F, -0.15F);

      for (int var24 = 0; var24 < 2; var24++) {
         boolean var26 = var24 == 0;
         float var29 = var26 ? 1.0F : -1.0F;
         float var34 = var26 ? this.rArmX : this.lArmX;
         float var38 = var26 ? this.rArmY : this.lArmY;
         float var41 = var26 ? this.rArmZ : this.lArmZ;
         var1.pushPose();
         pivotRotate(var1, var29 * 0.3125F, 1.375F, 0.0F, var34, var38, var41);
         float var43 = var29 * 0.22F;
         float var45 = var29 * 0.57F;
         box(var1, var11, var3, WHITE, Math.min(var43, var45), 1.4F, -0.19F, Math.max(var43, var45), 1.6F, 0.19F);
         box(var1, var11, var3, GOLD, Math.min(var43, var45), 1.37F, -0.195F, Math.max(var43, var45), 1.42F, 0.195F);
         float var21 = var29 * 0.245F;
         float var22 = var29 * 0.505F;
         box(var1, var11, var3, GOLD, Math.min(var21, var22), 0.8F, -0.145F, Math.max(var21, var22), 1.02F, 0.145F);
         var1.popPose();
      }

      var1.pushPose();
      pivotRotate(var1, NECK[0], NECK[1], NECK[2], this.headX, this.headY, 0.0F);
      box(var1, var11, var3, HAIR, -0.268F, 1.72F, 0.0F, 0.268F, 2.03F, 0.268F);
      box(var1, var11, var3, HAIR, -0.268F, 1.92F, -0.268F, 0.268F, 2.03F, 0.0F);
      box(var1, var11, var3, HAIR, -0.285F, 1.55F, -0.13F, -0.255F, 1.92F, 0.13F);
      box(var1, var11, var3, HAIR, 0.255F, 1.55F, -0.13F, 0.285F, 1.92F, 0.13F);
      box(var1, var11, var3, GOLD, -0.272F, 1.85F, -0.272F, 0.272F, 1.9F, -0.262F);
      box(var1, var11, var3, GOLD, -0.272F, 1.85F, 0.262F, 0.272F, 1.9F, 0.272F);
      box(var1, var11, var3, GOLD, -0.272F, 1.85F, -0.272F, -0.262F, 1.9F, 0.272F);
      box(var1, var11, var3, GOLD, 0.262F, 1.85F, -0.272F, 0.272F, 1.9F, 0.272F);
      box(var1, var11, var3, GOLD, -0.03F, 1.9F, -0.275F, 0.03F, 1.99F, -0.262F);
      float var25 = this.swingAmt * 0.5F;

      for (int var27 = 0; var27 < 5; var27++) {
         float var30 = -0.2F + var27 * 0.1F;
         float var35 = 0.85F + var27 % 3 * 0.12F;
         var1.pushPose();
         var1.translate(var30, 1.96F, 0.262F);
         var1.mulPose(Axis.XP.rotation(0.16F + var25 + (float)Math.sin(var4 * 0.07 + var27) * 0.07F + var27 * 0.01F));
         var1.mulPose(Axis.ZP.rotation((float)Math.sin(var4 * 0.05 + var27 * 1.7) * 0.06F));
         box(var1, var11, var3, HAIR, -0.05F, -var35, -0.025F, 0.05F, 0.0F, 0.025F);
         var1.popPose();
      }

      var12 = var2.getBuffer(RenderType.eyes(CELESTIAL_GLOW_TEX));
      flat(var1, (VertexConsumer)var12, -1, EYE, 0.05F, 1.82F, -0.2535F, 0.2F, 1.82F, -0.2535F, 0.2F, 1.73F, -0.2535F, 0.05F, 1.73F, -0.2535F);
      flat(var1, (VertexConsumer)var12, -1, EYE, -0.2F, 1.82F, -0.2535F, -0.05F, 1.82F, -0.2535F, -0.05F, 1.73F, -0.2535F, -0.2F, 1.73F, -0.2535F);
      float var28 = var4 * (var7 ? 0.16F : 0.05F);
      var1.pushPose();
      var1.translate(0.0F, 2.34F, 0.0F);

      for (int var31 = 0; var31 < 8; var31++) {
         float var36 = var28 + var31 * (float) (Math.PI / 4);
         float var39 = (float)Math.cos(var36) * 0.46F;
         float var42 = (float)Math.sin(var36) * 0.46F;
         float var44 = -((float)Math.sin(var36)) * 0.09F;
         float var46 = (float)Math.cos(var36) * 0.09F;
         float[] var47 = new float[]{var31 / 8.0F, 0.25F, (var31 + 1) / 8.0F, 0.5F};
         int var48 = ARGB32.color((int)(150.0F + 105.0F * Math.max(var5, var6)), 255, 255, 255);
         flat(
            var1,
            (VertexConsumer)var12,
            var48,
            var47,
            var39 - var44,
            0.09F,
            var42 - var46,
            var39 + var44,
            0.09F,
            var42 + var46,
            var39 + var44,
            -0.09F,
            var42 + var46,
            var39 - var44,
            -0.09F,
            var42 - var46
         );
      }

      for (int var32 = 0; var32 < 24; var32++) {
         float var37 = var28 * 0.5F + var32 * (float) (Math.PI / 12);
         float var40 = var37 + 0.23561946F;
         flat(
            var1,
            (VertexConsumer)var12,
            ARGB32.color(170, 255, 255, 255),
            RUNE,
            (float)Math.cos(var37) * 0.46F,
            0.012F,
            (float)Math.sin(var37) * 0.46F,
            (float)Math.cos(var40) * 0.46F,
            0.012F,
            (float)Math.sin(var40) * 0.46F,
            (float)Math.cos(var40) * 0.46F,
            -0.012F,
            (float)Math.sin(var40) * 0.46F,
            (float)Math.cos(var37) * 0.46F,
            -0.012F,
            (float)Math.sin(var37) * 0.46F
         );
      }

      var1.popPose();
      var1.popPose();
      this.wings(var1, (VertexConsumer)var12, 1, var4, var9, var6, var7);
      if (var6 > 0.02F) {
         int var33 = ARGB32.color((int)(255.0F * var6), 255, 255, 255);
         flat(var1, (VertexConsumer)var12, var33, RUNE, -0.21F, 1.46F, -0.17F, 0.21F, 1.46F, -0.17F, 0.21F, 1.04F, -0.17F, -0.21F, 1.04F, -0.17F);
         flat(var1, (VertexConsumer)var12, var33, RUNE, -0.21F, 1.46F, 0.17F, 0.21F, 1.46F, 0.17F, 0.21F, 1.04F, 0.17F, -0.21F, 1.04F, 0.17F);
      }

      var1.popPose();
      var1.popPose();
   }
}
