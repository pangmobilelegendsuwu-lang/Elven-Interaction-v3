package com.elvencompanions.client;

final class VfxRecipes {
   static void play(Vfx.Fx var0) {
      double[] var1 = Vfx.centre(var0);
      switch (var0.kind) {
         case 1:
            if (var0.age == 1) {
               Vfx.burst(var0.x, var0.y, var0.z, 6, 0.16, 6750059, 0.15F, 12);
            }

            leaves(var0, 0.25F, 0.0, 1.0);
            break;
         case 2:
            if (var0.age == 1) {
               Vfx.burst(var1[0], var1[1] + 1.0, var1[2], 14, 0.3, 10274047, 0.18F, 14);
            }
            break;
         case 3:
            if (var0.age == 1) {
               Vfx.burst(var0.x, var0.y, var0.z, 8, 0.22, 12124002, 0.16F, 12);
            }
            break;
         case 4:
            if (var0.age == 1) {
               Vfx.burst(var0.x, var0.y, var0.z, 8, 0.22, 16754736, 0.18F, 14);
            }

            if (Vfx.ok(0.7F)) {
               double var2 = var0.x2 - var0.x;
               double var4 = var0.y2 - var0.y;
               double var6 = var0.z2 - var0.z;
               double var8 = Math.max(0.5, Math.sqrt(var2 * var2 + var4 * var4 + var6 * var6));
               double var10 = Math.min(var8, (double)var0.age / var0.ticks * (var8 + 3.0)) * Vfx.R.nextDouble();
               Vfx.spark(var0.x + var2 / var8 * var10, var0.y + var4 / var8 * var10, var0.z + var6 / var8 * var10, 0.0, 0.05, 0.0, 16734736, 0.16F, 14, -0.004F);
            }
            break;
         case 5:
            if (Vfx.ok(0.25F)) {
               Vfx.star(
                  var1[0] + (Vfx.R.nextDouble() - 0.5) * 8.0 * var0.sc,
                  var1[1] + Vfx.R.nextDouble() * 6.0,
                  var1[2] + (Vfx.R.nextDouble() - 0.5) * 8.0 * var0.sc,
                  0.0,
                  0.0,
                  0.0,
                  16777215,
                  0.4F,
                  12
               );
            }
            break;
         case 6:
         case 7:
         case 9:
         case 12:
         case 16:
            rise(var0, var1, 0.3F, 12124002, true);
            break;
         case 8:
            rise(var0, var1, 0.35F, 16765514, false);
            break;
         case 10:
            if (Vfx.ok(0.7F)) {
               Vfx.shard(
                  var1[0] + (Vfx.R.nextDouble() - 0.5) * 2.0,
                  var1[1] + 0.5,
                  var1[2] + (Vfx.R.nextDouble() - 0.5) * 2.0,
                  (Vfx.R.nextDouble() - 0.5) * 0.4,
                  0.2 + Vfx.R.nextDouble() * 0.3,
                  (Vfx.R.nextDouble() - 0.5) * 0.4,
                  2097184,
                  0.28F,
                  18,
                  0.03F
               );
            }
            break;
         case 11:
         case 14:
            if (Vfx.ok(0.3F)) {
               Vfx.star(
                  var1[0] + (Vfx.R.nextDouble() - 0.5) * 3.0,
                  var1[1] + Vfx.R.nextDouble() * 3.0,
                  var1[2] + (Vfx.R.nextDouble() - 0.5) * 3.0,
                  0.0,
                  0.0,
                  0.0,
                  var0.kind == 11 ? 9140223 : 16777215,
                  0.35F,
                  10
               );
            }
            break;
         case 13:
            if (var0.age >= var0.ticks - 4) {
               Vfx.burst(var1[0], var1[1] + 2.0, var1[2], 22, 0.7, 16765514, 0.24F, 16);
            }
            break;
         case 15:
            if (var0.age == 1) {
               Vfx.burst(var0.x, var0.y, var0.z, 8, 0.22, 10274047, 0.16F, 10);
            }
         case 17:
         case 18:
         case 19:
         default:
            break;
         case 20:
            if (Vfx.ok(0.5F)) {
               Vfx.star(
                  var1[0] + (Vfx.R.nextDouble() - 0.5) * 5.0,
                  var1[1] + Vfx.R.nextDouble() * 4.0,
                  var1[2] + (Vfx.R.nextDouble() - 0.5) * 5.0,
                  0.0,
                  0.03,
                  0.0,
                  16777215,
                  0.45F,
                  12
               );
            }

            if (var0.age >= var0.ticks - 12 && var0.age % 3 == 0) {
               Vfx.burst(var1[0], var1[1] + 1.5, var1[2], 16, 0.6, 10274047, 0.2F, 14);
            }
      }
   }

   private static void leaves(Vfx.Fx var0, float var1, double var2, double var4) {
      if (Vfx.ok(var1)) {
         double var6 = var0.x2 - var0.x;
         double var8 = var0.y2 - var0.y;
         double var10 = var0.z2 - var0.z;
         double var12 = Math.max(0.5, Math.sqrt(var6 * var6 + var8 * var8 + var10 * var10));
         double var14 = Vfx.R.nextDouble() * Math.min(var12, (double)var0.age / var0.ticks * (var12 + 3.0));
         Vfx.leaf(
            var0.x + var6 / var12 * var14,
            var0.y + var8 / var12 * var14 + 0.2,
            var0.z + var10 / var12 * var14,
            (Vfx.R.nextDouble() - 0.5) * 0.06,
            0.03,
            (Vfx.R.nextDouble() - 0.5) * 0.06,
            12124002,
            0.26F,
            24
         );
      }
   }

   private static void rise(Vfx.Fx var0, double[] var1, float var2, int var3, boolean var4) {
      if (Vfx.ok(var2)) {
         double var5 = (1.0 + Vfx.R.nextDouble() * 4.0) * var0.sc;
         double var7 = Vfx.R.nextDouble() * Math.PI * 2.0;
         if (var4) {
            Vfx.leaf(
               var1[0] + Math.cos(var7) * var5, var1[1] + 0.3 + Vfx.R.nextDouble() * 4.0, var1[2] + Math.sin(var7) * var5, 0.0, 0.04, 0.0, var3, 0.28F, 26
            );
         } else {
            Vfx.glow(var1[0] + Math.cos(var7) * var5, var1[1] + 0.3 + Vfx.R.nextDouble() * 4.0, var1[2] + Math.sin(var7) * var5, 0.0, 0.03, 0.0, var3, 0.2F, 12);
         }
      }
   }

   private VfxRecipes() {
   }
}
