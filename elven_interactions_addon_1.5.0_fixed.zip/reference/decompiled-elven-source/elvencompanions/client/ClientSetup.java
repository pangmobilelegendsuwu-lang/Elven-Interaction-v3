package com.elvencompanions.client;

import com.elvencompanions.ModRegistry;
import com.mojang.blaze3d.platform.InputConstants.Type;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterRenderers;
import net.neoforged.neoforge.client.settings.KeyConflictContext;

@EventBusSubscriber(
   modid = "elven_companions",
   bus = Bus.MOD,
   value = {Dist.CLIENT}
)
public final class ClientSetup {
   public static final KeyMapping UNMOUNT_KEY = new KeyMapping(
      "key.elven_companions.unmount", KeyConflictContext.IN_GAME, Type.KEYSYM, 80, "key.categories.elven_companions"
   );
   public static final KeyMapping SKILL_POINTER = new KeyMapping(
      "key.elven_companions.skill_pointer", KeyConflictContext.IN_GAME, Type.KEYSYM, 71, "key.categories.elven_companions"
   );

   @SubscribeEvent
   public static void renderers(RegisterRenderers e) {
      e.registerEntityRenderer((EntityType)ModRegistry.ELF.get(), ElfRenderer::new);
      e.registerEntityRenderer((EntityType)ModRegistry.ELF_ARROW.get(), ElfArrowRenderer::new);
      e.registerEntityRenderer((EntityType)ModRegistry.SPECTRAL_STAG.get(), SpectralStagRenderer::new);
   }

   @SubscribeEvent
   public static void layers(RegisterLayerDefinitions e) {
      e.registerLayerDefinition(SpectralStagModel.LAYER, SpectralStagModel::create);
   }

   @SubscribeEvent
   public static void particles(RegisterParticleProvidersEvent e) {
      e.registerSpriteSet((ParticleType)ModRegistry.GLOW_GREEN.get(), s -> new ElfGlowParticle.Provider(s, 0.35F, 1.0F, 0.5F, 0.3F, 20, -0.002F, 0.0F));
      e.registerSpriteSet((ParticleType)ModRegistry.GLOW_GOLD.get(), s -> new ElfGlowParticle.Provider(s, 1.0F, 0.84F, 0.3F, 0.34F, 22, -0.002F, 0.0F));
      e.registerSpriteSet((ParticleType)ModRegistry.GLOW_FIRE.get(), s -> new ElfGlowParticle.Provider(s, 1.0F, 0.42F, 0.08F, 0.32F, 18, -0.004F, 0.0F));
      e.registerSpriteSet((ParticleType)ModRegistry.GLOW_MOON.get(), s -> new ElfGlowParticle.Provider(s, 0.62F, 0.82F, 1.0F, 0.3F, 22, 0.0F, 0.0F));
      e.registerSpriteSet((ParticleType)ModRegistry.STAR.get(), s -> new ElfGlowParticle.Provider(s, 1.0F, 0.97F, 0.78F, 0.38F, 16, 0.0F, 0.12F));
      e.registerSpriteSet((ParticleType)ModRegistry.LEAF.get(), s -> new ElfGlowParticle.Provider(s, 1.0F, 1.0F, 1.0F, 0.26F, 40, 0.012F, 0.1F));
   }

   @SubscribeEvent
   public static void keys(RegisterKeyMappingsEvent e) {
      e.register(UNMOUNT_KEY);
      e.register(SKILL_POINTER);
   }

   @SubscribeEvent
   public static void screens(RegisterMenuScreensEvent e) {
      e.register((MenuType)ModRegistry.ELF_MENU.get(), ElfInventoryScreen::new);
   }

   @SubscribeEvent
   public static void reload(RegisterClientReloadListenersEvent e) {
      e.registerReloadListener((ResourceManagerReloadListener)rm -> {
         ElfObjModel.invalidate();
         ElfRenderer.clearCache();
      });
   }

   private ClientSetup() {
   }
}
