package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.entity.SpectralStagEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.FastColor.ARGB32;

public class SpectralStagRenderer extends EntityRenderer<SpectralStagEntity> {
   private static final ResourceLocation TEXTURE = ElvenCompanions.rl("textures/entity/spectral_stag.png");
   private static final float SCALE = 1.3F;
   private final SpectralStagModel model;

   public SpectralStagRenderer(Context ctx) {
      super(ctx);
      this.model = new SpectralStagModel(ctx.bakeLayer(SpectralStagModel.LAYER));
   }

   public void render(SpectralStagEntity e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
      ps.pushPose();
      ps.mulPose(Axis.YP.rotationDegrees(180.0F - Mth.rotLerp(partialTick, e.yRotO, e.getYRot())));
      ps.scale(-1.3F, -1.3F, 1.3F);
      ps.translate(0.0F, -2.001F, 0.0F);
      this.model.animate(e.tickCount + partialTick);
      float fade = Mth.clamp((e.tickCount + partialTick) / 6.0F, 0.0F, 1.0F);
      int color = ARGB32.color((int)(fade * 235.0F), 255, 255, 255);
      VertexConsumer vc = buffers.getBuffer(RenderType.eyes(TEXTURE));
      this.model.root.render(ps, vc, 15728880, OverlayTexture.NO_OVERLAY, color);
      ps.popPose();
      super.render(e, yaw, partialTick, ps, buffers, light);
   }

   public ResourceLocation getTextureLocation(SpectralStagEntity e) {
      return TEXTURE;
   }
}
