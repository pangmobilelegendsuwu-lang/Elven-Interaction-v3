package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.entity.ElfAction;
import com.elvencompanions.logic.ElfRank;
import com.elvencompanions.logic.RestSchedule;
import com.elvencompanions.net.ElfStatus;
import com.elvencompanions.net.ModNetwork;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.Button.OnPress;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.PacketDistributor;

public class CommandScreen extends Screen {
   private static final String[] STANCES = new String[]{"follow", "sit", "guard", "wander"};
   private static final ResourceLocation TEX_PANEL = ElvenCompanions.rl("textures/gui/panel.png");
   private static final ResourceLocation TEX_BTN = ElvenCompanions.rl("textures/gui/btn.png");
   private static final ResourceLocation TEX_BTN_HOVER = ElvenCompanions.rl("textures/gui/btn_hover.png");
   private static final ResourceLocation TEX_BTN_SEL = ElvenCompanions.rl("textures/gui/btn_sel.png");
   private static final ResourceLocation TEX_BTN_OFF = ElvenCompanions.rl("textures/gui/btn_off.png");
   private static final ResourceLocation TEX_ICONS = ElvenCompanions.rl("textures/gui/icons.png");
   private static final ResourceLocation TEX_EMBLEM = ElvenCompanions.rl("textures/gui/emblem.png");
   private static final ResourceLocation TEX_BAR_BG = ElvenCompanions.rl("textures/gui/bar_bg.png");
   private static final ResourceLocation TEX_BAR_FILL = ElvenCompanions.rl("textures/gui/bar_fill.png");
   private static final ResourceLocation TEX_FALLBACK = ElvenCompanions.rl("textures/entity/elf_fallback.png");
   private static final int ICON_RIDE_PLAYER = 0;
   private static final int ICON_RIDE_MOUNT = 1;
   private static final int ICON_UNMOUNT = 2;
   private static final int ICON_TELEPORT = 3;
   private static final int ICON_NEUTRAL = 4;
   private static final int ICON_PASSIVE = 5;
   private static final int ICON_AGGRESSIVE = 6;
   private static final int ICON_INVENTORY = 7;
   private static final int ICON_REST = 8;
   private static final int ICON_OFF = 9;
   private static final int ICON_STANCE = 10;
   private static final int ICON_PICKUP = 11;
   private static final int ICON_GROUP = 12;
   private static final int ICON_SET_HOME = 13;
   private static final int ICON_GO_HOME = 14;
   private static final int ICON_BACK = 15;
   private static final int ICON_LV_MINUS = 16;
   private static final int ICON_LV_PLUS = 17;
   private static final int ICON_HEALTH = 18;
   private static final int ICON_STAMINA = 19;
   private static final int ICON_DAMAGE = 20;
   private static final int ICON_DEFENSE = 21;
   private static final int ICON_HEALING = 22;
   private static final int ICON_COOLDOWN = 23;
   private static final int ICON_AREA = 24;
   private static final int ICON_STATUS = 25;
   private static final int ICON_MOUNT = 26;
   private static final int ICON_BAG = 27;
   private static final int ICON_CDS = 28;
   private static final int ICON_PENCIL = 29;
   private static final int ICON_FEATHER = 30;
   private static final int ICON_STATS = 31;
   private static final int ICON_NOTE = 32;
   private static final int ICON_WING = 33;
   private static final int ICON_STAR = 34;
   private static final int ICON_NONE = -1;
   private ElfStatus status;
   private boolean groupMode;
   private boolean statsMode;
   private EditBox nameBox;
   private Button rest;
   private Button schedule;
   private Button pickup;
   private Button group;
   private Button stanceBtn;
   private Button homeBtn;
   private Button statsBtn;
   private Button prevSkin;
   private Button nextSkin;
   private Button renameBtn;
   private Button musicBtn;
   private Button healthBtn;
   private Button flightBtn;
   private Button auraBtn;
   private Button transcendBtn;
   private int ticks;
   private final List<CommandScreen.Themed> themed = new ArrayList<>();
   private float k = 0.254F;
   private int ox;
   private int oy;
   private int skinCached = -1;
   private ResourceLocation skinTex = TEX_FALLBACK;

   public CommandScreen(ElfStatus var1) {
      super(Component.translatable("gui.elven_companions.command.title", new Object[]{var1.name()}));
      this.status = var1;
   }

   public UUID elfId() {
      return this.status.id();
   }

   private void send(ElfAction var1) {
      PacketDistributor.sendToServer(new ModNetwork.CommandC2S(this.status.id(), var1.ordinal(), this.groupMode), new CustomPacketPayload[0]);
   }

   private int X(float var1) {
      return this.ox + Math.round((var1 - 8.0F) * this.k);
   }

   private int Y(float var1) {
      return this.oy + Math.round((var1 - 10.0F) * this.k);
   }

   private int S(float var1) {
      return Math.max(1, Math.round(var1 * this.k));
   }

   private int skillShift() {
      return this.status.manualSkills() ? 70 : 0;
   }

   private Button themed(Button var1, String var2, float var3, float var4, float var5, float var6, int var7, int var8) {
      if (var2 != null) {
         var1.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip." + var2)));
      }

      var1.setAlpha(0.02F);
      this.addRenderableWidget(var1);
      this.themed.add(new CommandScreen.Themed(var1, this.X(var3), this.Y(var4), this.S(var5 - var3), this.S(var6 - var4), var7, var8));
      return var1;
   }

   private Button action(ElfAction var1, String var2, float var3, float var4, float var5, float var6, int var7, int var8) {
      Button var9 = Button.builder(Component.translatable("gui.elven_companions.action." + var2), var2x -> this.send(var1))
         .bounds(this.X(var3), this.Y(var4), this.S(var5 - var3), this.S(var6 - var4))
         .build();
      return this.themed(var9, var2, var3, var4, var5, var6, var7, var8);
   }

   private Button custom(OnPress var1, float var2, float var3, float var4, float var5, int var6, int var7) {
      Button var8 = Button.builder(Component.empty(), var1).bounds(this.X(var2), this.Y(var3), this.S(var4 - var2), this.S(var5 - var3)).build();
      return this.themed(var8, null, var2, var3, var4, var5, var6, var7);
   }

   protected void init() {
      this.themed.clear();
      float var1 = 1646.0F;
      float var2 = 1015.0F + this.skillShift();
      this.k = Math.min(0.254F, Math.min((this.width - 8.0F) / var1, (this.height - 8.0F) / var2));
      this.ox = Math.round((this.width - var1 * this.k) / 2.0F);
      this.oy = Math.round((this.height - var2 * this.k) / 2.0F);
      int var3 = this.skillShift();
      this.nameBox = new EditBox(
         this.font, this.X(236.0F), this.Y(768.0F), this.S(290.0F), this.S(34.0F), Component.translatable("gui.elven_companions.rename.label")
      );
      this.nameBox.setMaxLength(24);
      this.nameBox.setBordered(false);
      this.nameBox.setValue(this.status.name());
      this.nameBox.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.rename")));
      this.addRenderableWidget(this.nameBox);
      this.renameBtn = this.custom(var1x -> this.sendRename(), 556.0F, 752.0F, 758.0F, 812.0F, 30, 1);
      this.renameBtn.setMessage(Component.translatable("gui.elven_companions.rename.button"));
      this.renameBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.rename")));
      this.prevSkin = this.custom(var1x -> this.sendSkin(-1), 155.0F, 663.0F, 255.0F, 737.0F, -1, 2);
      this.prevSkin.setMessage(Component.literal("<"));
      this.prevSkin.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.skin_prev")));
      this.nextSkin = this.custom(var1x -> this.sendSkin(1), 648.0F, 663.0F, 745.0F, 737.0F, -1, 3);
      this.nextSkin.setMessage(Component.literal(">"));
      this.nextSkin.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.skin_next")));
      this.statsBtn = this.custom(var1x -> {
         this.statsMode = !this.statsMode;
         this.refreshLabels();
      }, 186.0F, 828.0F, 683.0F, 894.0F, 31, 0);
      this.statsBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.stats")));
      this.musicBtn = this.custom(var1x -> {
         TranscendMusic.setEnabled(!TranscendMusic.isEnabled());
         this.refreshLabels();
      }, 822.0F, 18.0F, 1210.0F, 84.0F, 32, 7);
      this.musicBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.music")));
      this.healthBtn = this.custom(var1x -> {
         ClientPrefs.setHealthBar(!ClientPrefs.healthBar());
         this.refreshLabels();
      }, 1228.0F, 18.0F, 1630.0F, 84.0F, 18, 8);
      this.healthBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.healthbar")));
      float var4 = 936.0F + this.skillShift();
      this.auraBtn = this.custom(var1x -> {
         ClientPrefs.cycleAura();
         this.refreshLabels();
      }, 186.0F, var4, 683.0F, var4 + 66.0F, 24, 11);
      this.auraBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.aura")));
      this.flightBtn = this.custom(var1x -> this.send(ElfAction.FLIGHT_TOGGLE), 822.0F, var4, 1210.0F, var4 + 66.0F, 33, 9);
      this.flightBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.flight")));
      this.transcendBtn = this.custom(var1x -> {
         if (this.status.transcended()) {
            this.send(ElfAction.TRANSCEND_STOP);
         } else {
            Minecraft var2x = Minecraft.getInstance();
            var2x.setScreen(new ConfirmScreen(var2xx -> {
               var2x.setScreen(this);
               this.send(var2xx ? ElfAction.TRANSCEND_START : ElfAction.TRANSCEND_START_INSTANT);
            }, Component.translatable("gui.elven_companions.transcend.prompt.title"), Component.translatable("gui.elven_companions.transcend.prompt.message")));
         }
      }, 1228.0F, var4, 1630.0F, var4 + 66.0F, 34, 10);
      this.transcendBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.transcend")));
      this.action(ElfAction.RIDE_PLAYER, "ride_player", 822.0F, 118.0F, 1210.0F, 198.0F, 0, 0);
      this.action(ElfAction.RIDE_MOUNT, "ride_mount", 1228.0F, 118.0F, 1630.0F, 198.0F, 1, 0);
      this.action(ElfAction.UNMOUNT, "unmount", 822.0F, 214.0F, 1210.0F, 298.0F, 2, 0);
      this.action(ElfAction.TELEPORT, "teleport", 1228.0F, 214.0F, 1630.0F, 298.0F, 3, 0);
      this.action(ElfAction.NEUTRAL, "neutral", 824.0F, 313.0F, 1084.0F, 395.0F, 4, 4);
      this.action(ElfAction.PASSIVE, "passive", 1100.0F, 313.0F, 1358.0F, 395.0F, 5, 5);
      this.action(ElfAction.AGGRESSIVE, "aggressive", 1372.0F, 313.0F, 1630.0F, 395.0F, 6, 6);
      this.action(ElfAction.INVENTORY, "inventory", 822.0F, 411.0F, 1142.0F, 493.0F, 7, 0);
      this.rest = this.action(ElfAction.REST, "rest", 1158.0F, 411.0F, 1412.0F, 493.0F, 8, 0);
      this.schedule = this.custom(var1x -> this.send(ElfAction.REST_SCHEDULE), 1428.0F, 411.0F, 1630.0F, 493.0F, 9, 0);
      this.schedule.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.schedule")));
      this.stanceBtn = this.custom(var1x -> this.send(ElfAction.STANCE), 822.0F, 509.0F, 1630.0F, 575.0F, 10, 0);
      this.stanceBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.stance")));
      this.homeBtn = this.custom(var1x -> this.send(ElfAction.HOME_TOGGLE), 822.0F, 591.0F, 1214.0F, 658.0F, 13, 0);
      this.homeBtn.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.home")));
      this.action(ElfAction.GO_HOME, "go_home", 1230.0F, 591.0F, 1630.0F, 658.0F, 14, 0);
      this.pickup = this.action(ElfAction.PICKUP, "pickup", 822.0F, 674.0F, 1630.0F, 740.0F, 11, 0);
      if (this.status.manualSkills()) {
         String[] var5 = new String[]{"verdant_piercer", "skyfall_burst", "tenfold_volley", "wildfire_piercer", "moonfall_arrow_circle", "thornroot_snare"};
         float var6 = 126.0F;
         float var7 = (808.0F - 6.0F * var6) / 5.0F;

         for (int var8 = 0; var8 < 6; var8++) {
            int var9 = var8;
            Button var10 = Button.builder(
                  Component.translatable("gui.elven_companions.skill.short." + var8),
                  var2x -> this.send(ElfAction.values()[ElfAction.SKILL_0.ordinal() + var9])
               )
               .bounds(this.X(822.0F + var8 * (var6 + var7)), this.Y(754.0F), this.S(var6), this.S(62.0F))
               .build();
            var10.setTooltip(
               Tooltip.create(
                  Component.translatable("skill.elven_companions." + var5[var8])
                     .append(Component.literal(" - "))
                     .append(Component.translatable("gui.elven_companions.tip.skill"))
               )
            );
            var10.setAlpha(0.02F);
            this.addRenderableWidget(var10);
            this.themed.add(new CommandScreen.Themed(var10, this.X(822.0F + var8 * (var6 + var7)), this.Y(754.0F), this.S(var6), this.S(62.0F), -1, 0));
         }
      }

      this.group = this.custom(var1x -> {
         this.groupMode = !this.groupMode;
         this.refreshLabels();
      }, 822.0F, 758.0F + var3, 1630.0F, 818.0F + var3, 12, 0);
      this.group.setTooltip(Tooltip.create(Component.translatable("gui.elven_companions.tip.group")));
      boolean var11 = this.minecraft != null && this.minecraft.player != null && this.minecraft.player.isCreative();
      float var12 = 830.0F + var3;
      float var13 = 894.0F + var3;
      Button var14 = Button.builder(
            Component.translatable("gui.elven_companions.back"),
            var0 -> PacketDistributor.sendToServer(new ModNetwork.RosterRequestC2S(), new CustomPacketPayload[0])
         )
         .bounds(this.X(822.0F), this.Y(var12), this.S(var11 ? 286.0F : 808.0F), this.S(var13 - var12))
         .build();
      this.themed(var14, null, 822.0F, var12, var11 ? 1108.0F : 1630.0F, var13, 15, 0);
      if (var11) {
         Button var15 = Button.builder(
               Component.literal("Lv -"), var1x -> PacketDistributor.sendToServer(new ModNetwork.LevelC2S(this.status.id(), -1), new CustomPacketPayload[0])
            )
            .bounds(this.X(1126.0F), this.Y(var12), this.S(242.0F), this.S(var13 - var12))
            .build();
         Button var16 = Button.builder(
               Component.literal("Lv +"), var1x -> PacketDistributor.sendToServer(new ModNetwork.LevelC2S(this.status.id(), 1), new CustomPacketPayload[0])
            )
            .bounds(this.X(1386.0F), this.Y(var12), this.S(244.0F), this.S(var13 - var12))
            .build();
         this.themed(var15, "level_minus", 1126.0F, var12, 1368.0F, var13, 16, 0);
         this.themed(var16, "level_plus", 1386.0F, var12, 1630.0F, var13, 17, 0);
      }

      this.refreshLabels();
   }

   private void sendSkin(int var1) {
      byte var2 = 6;
      PacketDistributor.sendToServer(new ModNetwork.SkinC2S(this.status.id(), Math.floorMod(this.status.skin() + var1, var2)), new CustomPacketPayload[0]);
   }

   private void sendRename() {
      String var1 = this.nameBox.getValue().strip();
      if (!var1.isEmpty()) {
         PacketDistributor.sendToServer(new ModNetwork.RenameC2S(this.status.id(), var1), new CustomPacketPayload[0]);
      }

      this.setFocused(null);
   }

   public boolean keyPressed(int var1, int var2, int var3) {
      if (this.nameBox != null && this.nameBox.isFocused() && (var1 == 257 || var1 == 335)) {
         this.sendRename();
         return true;
      } else {
         return super.keyPressed(var1, var2, var3);
      }
   }

   public void updateStatus(ElfStatus var1) {
      boolean var2 = !var1.name().equals(this.status.name());
      boolean var3 = var1.manualSkills() != this.status.manualSkills();
      this.status = var1;
      if (var3) {
         this.rebuildWidgets();
      } else {
         if (var2 && this.nameBox != null && !this.nameBox.isFocused()) {
            this.nameBox.setValue(var1.name());
         }

         this.refreshLabels();
      }
   }

   private void refreshLabels() {
      if (this.auraBtn != null) {
         int var1 = ClientPrefs.auraMode();
         this.auraBtn
            .setMessage(
               Component.translatable(
                  var1 == 0 ? "gui.elven_companions.aura.off" : (var1 == 1 ? "gui.elven_companions.aura.always" : "gui.elven_companions.aura.default")
               )
            );
      }

      if (this.flightBtn != null) {
         int[] var4 = this.status.cooldownSecs();
         boolean var2 = var4.length > 16 && var4[16] == 1;
         boolean var3 = var4.length > 17 && var4[17] == 1;
         this.flightBtn.visible = this.status.transcended();
         this.flightBtn.setMessage(Component.translatable(var2 ? "gui.elven_companions.flight.on" : "gui.elven_companions.flight.off"));
         this.transcendBtn.visible = this.status.transcended() || var3;
         this.transcendBtn
            .setMessage(Component.translatable(this.status.transcended() ? "gui.elven_companions.transcend.stop" : "gui.elven_companions.transcend.start"));
      }

      if (this.healthBtn != null) {
         this.healthBtn
            .setMessage(Component.translatable(ClientPrefs.healthBar() ? "gui.elven_companions.healthbar.on" : "gui.elven_companions.healthbar.off"));
      }

      if (this.musicBtn != null) {
         this.musicBtn.setMessage(Component.translatable(TranscendMusic.isEnabled() ? "gui.elven_companions.music.on" : "gui.elven_companions.music.off"));
      }

      if (this.rest != null) {
         this.rest.setMessage(Component.translatable(this.status.rest() != 0 ? "gui.elven_companions.action.wake" : "gui.elven_companions.action.rest"));
         this.schedule.setMessage(Component.translatable("gui.elven_companions.schedule.short." + RestSchedule.byId(this.status.schedule()).id()));
         this.pickup
            .setMessage(
               Component.translatable(
                  "gui.elven_companions.action.pickup",
                  new Object[]{Component.translatable(this.status.pickup() ? "gui.elven_companions.on" : "gui.elven_companions.off")}
               )
            );
         this.stanceBtn
            .setMessage(
               Component.translatable(
                  "gui.elven_companions.action.stance",
                  new Object[]{Component.translatable("stance.elven_companions." + STANCES[Math.floorMod(this.status.stance(), 4)])}
               )
            );
         this.homeBtn
            .setMessage(Component.translatable(this.status.hasHome() ? "gui.elven_companions.action.home_remove" : "gui.elven_companions.action.home_set"));
         this.group.setMessage(Component.translatable(this.groupMode ? "gui.elven_companions.group.on" : "gui.elven_companions.group.off"));
         this.statsBtn.setMessage(Component.translatable(this.statsMode ? "gui.elven_companions.stats.hide" : "gui.elven_companions.stats.show"));
      }
   }

   public void tick() {
      super.tick();
      if (++this.ticks % 20 == 0) {
         PacketDistributor.sendToServer(new ModNetwork.StatusRequestC2S(this.status.id()), new CustomPacketPayload[0]);
      }
   }

   private static String f(float var0) {
      return String.format(Locale.ROOT, "%.0f", var0);
   }

   private static String f1(float var0) {
      return String.format(Locale.ROOT, "%.1f", var0);
   }

   private static String f2(float var0) {
      return String.format(Locale.ROOT, "%.2f", var0);
   }

   private void blit(
      GuiGraphics var1, ResourceLocation var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12
   ) {
      var1.blit(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12);
   }

   private void nine(GuiGraphics var1, ResourceLocation var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      int var10 = Math.min(var9, Math.min(var5, var6) / 2);
      int var11 = var7 - 2 * var8;
      this.blit(var1, var2, var3, var4, var10, var10, 0, 0, var8, var8, var7, var7);
      this.blit(var1, var2, var3 + var5 - var10, var4, var10, var10, var7 - var8, 0, var8, var8, var7, var7);
      this.blit(var1, var2, var3, var4 + var6 - var10, var10, var10, 0, var7 - var8, var8, var8, var7, var7);
      this.blit(var1, var2, var3 + var5 - var10, var4 + var6 - var10, var10, var10, var7 - var8, var7 - var8, var8, var8, var7, var7);
      this.blit(var1, var2, var3 + var10, var4, var5 - 2 * var10, var10, var8, 0, var11, var8, var7, var7);
      this.blit(var1, var2, var3 + var10, var4 + var6 - var10, var5 - 2 * var10, var10, var8, var7 - var8, var11, var8, var7, var7);
      this.blit(var1, var2, var3, var4 + var10, var10, var6 - 2 * var10, 0, var8, var8, var11, var7, var7);
      this.blit(var1, var2, var3 + var5 - var10, var4 + var10, var10, var6 - 2 * var10, var7 - var8, var8, var8, var11, var7, var7);
      this.blit(var1, var2, var3 + var10, var4 + var10, var5 - 2 * var10, var6 - 2 * var10, var8, var8, var11, var11, var7, var7);
   }

   private void slice(GuiGraphics var1, ResourceLocation var2, int var3, int var4, int var5, int var6) {
      int var7 = Math.min(var5 / 2, Math.round(44.0F * var6 / 68.0F));
      this.blit(var1, var2, var3, var4, var7, var6, 0, 0, 44, 68, 188, 68);
      this.blit(var1, var2, var3 + var7, var4, var5 - 2 * var7, var6, 44, 0, 100, 68, 188, 68);
      this.blit(var1, var2, var3 + var5 - var7, var4, var7, var6, 144, 0, 44, 68, 188, 68);
   }

   private void icon(GuiGraphics var1, int var2, int var3, int var4, int var5) {
      if (var2 >= 0) {
         int var6 = var2 % 8 * 48;
         int var7 = var2 / 8 * 48;
         this.blit(var1, TEX_ICONS, var3 - var5 / 2, var4 - var5 / 2, var5, var5, var6, var7, 48, 48, 384, 240);
      }
   }

   private void text(GuiGraphics var1, String var2, float var3, float var4, float var5, int var6) {
      var1.pose().pushPose();
      var1.pose().translate(this.X(var3), this.Y(var4), 0.0F);
      float var7 = var5 * this.k / 0.254F;
      var1.pose().scale(var7, var7, 1.0F);
      var1.drawString(this.font, var2, 0, -4, var6);
      var1.pose().popPose();
   }

   private int textW(String var1, float var2) {
      return Math.round(this.font.width(var1) * var2 * this.k / 0.254F);
   }

   private void textC(GuiGraphics var1, String var2, float var3, float var4, float var5, int var6) {
      int var7 = this.textW(var2, var5);
      var1.pose().pushPose();
      var1.pose().translate(this.X(var3) - var7 / 2, this.Y(var4), 0.0F);
      float var8 = var5 * this.k / 0.254F;
      var1.pose().scale(var8, var8, 1.0F);
      var1.drawString(this.font, var2, 0, -4, var6);
      var1.pose().popPose();
   }

   private ResourceLocation skinTexture() {
      int var1 = Math.floorMod(this.status.skin(), 6);
      if (var1 != this.skinCached) {
         this.skinCached = var1;
         ResourceLocation var2 = ElvenCompanions.rl("textures/entity/elf" + (var1 + 1) + ".png");
         this.skinTex = Minecraft.getInstance().getResourceManager().getResource(var2).isPresent() ? var2 : TEX_FALLBACK;
      }

      return this.skinTex;
   }

   public void render(GuiGraphics var1, int var2, int var3, float var4) {
      var1.fill(0, 0, this.width, this.height, 1711276032);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      int var5 = this.X(110.0F);
      int var6 = this.Y(78.0F);
      this.nine(var1, TEX_PANEL, var5, var6, this.X(790.0F) - var5, this.Y(920.0F) - var6, 192, 48, this.S(48.0F));
      int var7 = this.X(798.0F);
      int var8 = this.Y(96.0F);
      this.nine(var1, TEX_PANEL, var7, var8, this.X(1650.0F) - var7, this.Y(918.0F + this.skillShift()) - var8, 192, 48, this.S(48.0F));
      var1.fill(this.X(160.0F), this.Y(250.0F), this.X(600.0F), this.Y(250.0F) + 1, -2135895974);
      var1.fill(this.X(160.0F), this.Y(503.0F), this.X(600.0F), this.Y(503.0F) + 1, -2135895974);
      this.slice(var1, TEX_BTN, this.X(150.0F), this.Y(752.0F), this.X(542.0F) - this.X(150.0F), this.Y(812.0F) - this.Y(752.0F));
      var1.fill(this.X(230.0F), this.Y(762.0F), this.X(535.0F), this.Y(802.0F), -536604664);
      var1.renderOutline(this.X(230.0F), this.Y(762.0F), this.X(535.0F) - this.X(230.0F), this.Y(802.0F) - this.Y(762.0F), -12615867);
      this.icon(var1, 29, this.X(192.0F), this.Y(782.0F), this.S(50.0F));
      this.slice(var1, TEX_BTN, this.X(290.0F), this.Y(661.0F), this.X(640.0F) - this.X(290.0F), this.Y(739.0F) - this.Y(661.0F));
      int var9 = this.X(298.0F);
      int var10 = this.Y(667.0F);
      int var11 = this.S(66.0F);
      var1.fill(var9 - 1, var10 - 1, var9 + var11 + 1, var10 + var11 + 1, -4926374);
      this.blit(var1, this.skinTexture(), var9, var10, var11, var11, 512, 0, 1024, 1024, 4096, 4096);
      if (this.statsMode) {
         this.renderStats(var1);
      } else {
         this.renderInfo(var1);
      }

      this.textC(
         var1, Component.translatable("gui.elven_companions.skin.label", new Object[]{this.status.skin() + 1, 6}).getString(), 505.0F, 683.0F, 0.9F, 16777215
      );
      this.text(var1, this.status.name() + (this.status.skin() + 1), 504.0F, 717.0F, 0.75F, 13166799);
      super.render(var1, var2, var3, var4);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      this.renderThemedButtons(var1, var2, var3);
      this.blit(var1, TEX_EMBLEM, this.X(8.0F), this.Y(10.0F), this.S(232.0F), this.S(282.0F), 0, 0, 232, 282, 232, 282);
   }

   public void renderBackground(GuiGraphics var1, int var2, int var3, float var4) {
   }

   private boolean flightOn() {
      int[] var1 = this.status.cooldownSecs();
      return var1.length > 16 && var1[16] == 1;
   }

   private void renderThemedButtons(GuiGraphics var1, int var2, int var3) {
      for (CommandScreen.Themed var5 : this.themed) {
         if (var5.w().visible) {
            boolean var6 = var2 >= var5.x() && var2 < var5.x() + var5.bw() && var3 >= var5.y() && var3 < var5.y() + var5.bh();
            boolean var7 = var5.kind() >= 4 && var5.kind() <= 6 && Math.floorMod(this.status.combat(), 3) == var5.kind() - 4
               || var5.kind() == 7 && TranscendMusic.isEnabled()
               || var5.kind() == 8 && ClientPrefs.healthBar()
               || var5.kind() == 9 && this.flightOn()
               || var5.kind() == 11 && ClientPrefs.auraMode() != 0;
            ResourceLocation var8 = !var5.w().active ? TEX_BTN_OFF : (var7 ? TEX_BTN_SEL : (var6 ? TEX_BTN_HOVER : TEX_BTN));
            this.slice(var1, var8, var5.x(), var5.y(), var5.bw(), var5.bh());
            String var9 = var5.w().getMessage().getString();
            int var10 = var5.w().active ? (var6 ? -96 : -1) : -6250336;
            if (var5.kind() != 2 && var5.kind() != 3) {
               float var19 = var5.bh() >= this.S(60.0F) ? 0.85F : 0.8F;
               int var20 = Math.round(var5.bh() * 0.72F);
               int var21 = Math.round(this.font.width(var9) * var19 * this.k / 0.254F);
               int var22 = this.S(18.0F);
               boolean var23 = var5.icon() >= 0;
               int var24 = (var23 ? var20 + var22 : 0) + var21;
               int var17 = var5.x() + (var5.bw() - var24) / 2;
               if (var23) {
                  this.icon(var1, var5.icon(), var17 + var20 / 2, var5.y() + var5.bh() / 2, var20);
                  var17 += var20 + var22;
               }

               var1.pose().pushPose();
               var1.pose().translate(var17, var5.y() + var5.bh() / 2, 0.0F);
               float var18 = var19 * this.k / 0.254F;
               var1.pose().scale(var18, var18, 1.0F);
               var1.drawString(this.font, var9, 0, -4, var10);
               var1.pose().popPose();
            } else {
               int var11 = var5.x() + var5.bw() / 2;
               int var12 = var5.y() + var5.bh() / 2;
               int var13 = Math.max(3, var5.bh() / 5);
               int var14 = var5.kind() == 2 ? -1 : 1;

               for (int var15 = 0; var15 < var13; var15++) {
                  int var16 = var11 - var14 * (var13 / 2) + var14 * -var15 + (var14 > 0 ? 0 : 0);
                  var1.fill(var16 - 1, var12 - var15 - 1, var16 + 1, var12 - var15 + 1, -1509216);
                  var1.fill(var16 - 1, var12 + var15 - 1, var16 + 1, var12 + var15 + 1, -1509216);
               }
            }
         }
      }
   }

   private void statLine(GuiGraphics var1, int var2, float var3, String var4, String var5, int var6, int var7) {
      this.icon(var1, var2, this.X(188.0F), this.Y(var3), this.S(40.0F));
      this.text(var1, var4, 226.0F, var3, 0.85F, var6);
      this.text(var1, var5, 372.0F, var3, 0.85F, var7);
   }

   private void renderInfo(GuiGraphics var1) {
      ElfStatus var2 = this.status;
      this.text(var1, var2.name(), 262.0F, 118.0F, 1.55F, 16777215);
      String var3 = Component.translatable(ElfRank.key(var2.level(), var2.transcended())).getString();
      this.text(var1, "Level " + var2.level(), 232.0F, 163.0F, 1.0F, 12120186);
      this.text(var1, "•", 372.0F, 163.0F, 1.0F, 16777215);
      this.text(var1, var3, 434.0F, 163.0F, 1.0F, 15260786);
      String var4;
      float var5;
      if (var2.transcended()) {
         var4 = Component.translatable("gui.elven_companions.stats.xp_max").getString();
         var5 = 1.0F;
      } else {
         var4 = "XP: " + String.format(Locale.US, "%,d", var2.xp()) + " / " + String.format(Locale.US, "%,d", var2.xpNext());
         var5 = var2.xpNext() > 0 ? Math.min(1.0F, (float)var2.xp() / var2.xpNext()) : 0.0F;
      }

      this.text(var1, var4, 232.0F, 197.0F, 0.85F, 16777215);
      int var6 = this.X(232.0F);
      int var7 = this.Y(214.0F);
      int var8 = this.X(562.0F) - var6;
      int var9 = this.Y(236.0F) - var7;
      this.blit(var1, TEX_BAR_BG, var6, var7, var8, var9, 0, 0, 256, 24, 256, 24);
      int var10 = Math.round((var8 - 4) * var5);
      if (var10 > 0) {
         this.blit(var1, TEX_BAR_FILL, var6 + 2, var7 + 1, var10, var9 - 2, 0, 0, Math.max(1, Math.round(256.0F * var5)), 24, 256, 24);
      }

      float[] var11 = var2.stats();
      float[] var12 = var2.base();
      boolean var13 = var11.length >= 14 && var12.length >= 14;
      float var14 = var13 ? var11[0] : var2.health();
      float var15 = var13 ? var11[1] : var2.maxHealth();
      this.statLine(var1, 18, 274.0F, "Health:", f1(var14) + " / " + f1(var15), 16738936, 16747156);
      this.statLine(var1, 19, 309.0F, "Stamina:", var2.stamina() + " / " + var2.maxStamina(), 16769098, 16772752);
      if (var13) {
         this.statLine(
            var1,
            20,
            343.0F,
            "Damage:",
            "x" + f1(var11[3]) + (var11[3] > var12[3] + 0.005F ? " ↑" : ""),
            16777215,
            var11[3] > var12[3] + 0.005F ? 8191884 : 16777215
         );
         this.statLine(var1, 21, 377.0F, "Defense:", f1(var11[2]) + "%", 16777215, var11[2] > var12[2] + 0.005F ? 8191884 : 16777215);
         float var16 = var11[12] > 0.01F ? var12[12] / var11[12] : 1.0F;
         this.statLine(var1, 22, 411.0F, "Healing:", "x" + f1(var16), 7074472, 16777215);
         this.statLine(var1, 23, 445.0F, "Cooldown:", "x" + f1(var11[13]), 8382719, 16777215);
         this.statLine(var1, 24, 480.0F, "Area:", "x" + f1(var11[7]), 16768862, 16777215);
      }

      String var21 = Component.translatable("stance.elven_companions." + STANCES[Math.floorMod(var2.stance(), 4)]).getString();
      this.statLine(var1, 25, 526.0F, "Status:", var21, 8126346, 8126346);
      String var17 = Component.translatable(
            var2.riding() == 1
               ? "gui.elven_companions.status.mount_player"
               : (var2.riding() == 2 ? "gui.elven_companions.status.mount_other" : "gui.elven_companions.status.mount_none")
         )
         .getString();
      this.icon(var1, 26, this.X(188.0F), this.Y(558.0F), this.S(40.0F));
      this.text(var1, var17, 226.0F, 558.0F, 0.85F, 16777215);
      this.statLine(
         var1,
         27,
         591.0F,
         "Pickup:",
         Component.translatable(var2.pickup() ? "gui.elven_companions.on" : "gui.elven_companions.off").getString(),
         16777215,
         var2.pickup() ? 8126346 : 16747146
      );
      String[] var18 = new String[]{"V", "S", "T", "W", "M", "R", "Asc", "Hunt", "Guard", "Seed", "Annih", "Rage", "Stealth", "Chrono", "Rico", "World"};
      StringBuilder var19 = new StringBuilder();

      for (int var20 = 0; var20 < var2.cooldownSecs().length && var20 < var18.length; var20++) {
         if (var2.cooldownSecs()[var20] > 0) {
            var19.append(var18[var20]).append(':').append(var2.cooldownSecs()[var20]).append("s ");
         }
      }

      boolean var22 = var19.length() == 0;
      this.icon(var1, 28, this.X(188.0F), this.Y(625.0F), this.S(40.0F));
      this.text(var1, "Cooldowns:", 226.0F, 625.0F, 0.85F, 8126346);
      this.text(
         var1,
         var22 ? Component.translatable("gui.elven_companions.status.ready").getString() : var19.toString().trim(),
         400.0F,
         625.0F,
         0.85F,
         var22 ? 8126346 : 16760960
      );
   }

   private void bonus(GuiGraphics var1, float var2, float var3, float var4, float var5, Function<Float, String> var6, boolean var7) {
      float var8 = var4 - var5;
      if (!(Math.abs(var8) < 0.005F)) {
         boolean var9 = var7 ? var8 < 0.0F : var8 > 0.0F;
         this.text(var1, (var8 > 0.0F ? "(+" : "(") + (String)var6.apply(var8) + ")", var2, var3, 0.7F, var9 ? 5635925 : 16744576);
      }
   }

   private void row(GuiGraphics var1, float var2, String var3, String var4, int var5, float var6, float var7, Function<Float, String> var8, boolean var9) {
      this.text(var1, Component.translatable(var3).getString(), 190.0F, var2, 0.72F, 11196592);
      this.text(var1, var4, 400.0F, var2, 0.72F, var5);
      if (var7 >= 0.0F) {
         int var10 = this.font.width(var4);
         this.bonus(var1, 400.0F + var10 * 0.72F * 3.9F + 14.0F, var2, var6, var7, var8, var9);
      }
   }

   private void renderStats(GuiGraphics var1) {
      ElfStatus var2 = this.status;
      float[] var3 = var2.stats();
      float[] var4 = var2.base();
      this.text(var1, var2.name(), 262.0F, 118.0F, 1.55F, 16777215);
      this.text(var1, Component.translatable("gui.elven_companions.stats.title").getString() + "  •  Lv." + var2.level(), 232.0F, 163.0F, 0.95F, 16767370);
      this.text(
         var1,
         var2.transcended()
            ? Component.translatable("gui.elven_companions.stats.xp_max").getString()
            : Component.translatable("gui.elven_companions.stats.xp", new Object[]{var2.xp(), var2.xpNext()}).getString(),
         232.0F,
         197.0F,
         0.85F,
         16777215
      );
      if (var3.length >= 14 && var4.length >= 14) {
         float var5 = 272.0F;
         float var6 = 28.0F;
         this.row(
            var1, var5, "gui.elven_companions.stats.health", f(var3[0]) + " / " + f(var3[1]), 16747156, var3[1], var4[1], CommandScreen.ElfStatsFmt::f0, false
         );
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.reduction", f1(var3[2]) + "%", 16777215, var3[2], var4[2], CommandScreen.ElfStatsFmt::f1, false);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.arrow", "x" + f1(var3[3]), 16777215, var3[3], var4[3], CommandScreen.ElfStatsFmt::f1, false);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.fire", f1(20.0F / var3[4]) + "/s", 16777215, 0.0F, -1.0F, null, false);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.chance", f(var3[5]) + "%", 16777215, var3[5], var4[5], CommandScreen.ElfStatsFmt::f0, false);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.skill_damage", "x" + f2(var3[6]), 16777215, var3[6], var4[6], CommandScreen.ElfStatsFmt::f2, false);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.area", "x" + f2(var3[7]), 16777215, var3[7], var4[7], CommandScreen.ElfStatsFmt::f2, false);
         var5 += var6;
         this.row(
            var1, var5, "gui.elven_companions.stats.stamina", f(var3[8]) + " / " + f(var3[9]), 16772752, var3[9], var4[9], CommandScreen.ElfStatsFmt::f0, false
         );
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.speed", "x" + f2(var3[10]), 16777215, var3[10], var4[10], CommandScreen.ElfStatsFmt::f2, false);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.spread", f1(var3[11]), 16777215, var3[11], var4[11], CommandScreen.ElfStatsFmt::f1, true);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.potion", f1(var3[12]) + " s", 16777215, var3[12], var4[12], CommandScreen.ElfStatsFmt::f1, true);
         var5 += var6;
         this.row(var1, var5, "gui.elven_companions.stats.cooldown", "x" + f2(var3[13]), 16777215, var3[13], var4[13], CommandScreen.ElfStatsFmt::f2, true);
      }
   }

   public boolean isPauseScreen() {
      return false;
   }

   private static final class ElfStatsFmt {
      static String f0(Float var0) {
         return CommandScreen.f(var0);
      }

      static String f1(Float var0) {
         return CommandScreen.f1(var0);
      }

      static String f2(Float var0) {
         return CommandScreen.f2(var0);
      }
   }

   private record Themed(Button w, int x, int y, int bw, int bh, int icon, int kind) {
   }
}
