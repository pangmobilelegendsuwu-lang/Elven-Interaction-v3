package com.elvencompanions.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

public class ElfGlowParticle extends TextureSheetParticle {
   private final float baseSize;
   private final float spin;
   private final float phase;
   private final float baseR;
   private final float baseG;
   private final float baseB;
   private final boolean swirl;
   private float hotAmt = 0.65F;
   public static SpriteSet GLOW;
   public static SpriteSet STAR;
   public static SpriteSet LEAF;

   ElfGlowParticle(
      ClientLevel var1,
      double var2,
      double var4,
      double var6,
      double var8,
      double var10,
      double var12,
      SpriteSet var14,
      float var15,
      float var16,
      float var17,
      float var18,
      int var19,
      float var20,
      float var21
   ) {
      super(var1, var2, var4, var6, var8, var10, var12);
      this.xd = var8;
      this.yd = var10;
      this.zd = var12;
      this.friction = 0.94F;
      this.gravity = var20;
      this.hasPhysics = false;
      this.rCol = var15;
      this.gCol = var16;
      this.bCol = var17;
      this.lifetime = var19 + this.random.nextInt(Math.max(1, var19 / 2));
      this.baseSize = var18 * (0.75F + this.random.nextFloat() * 0.5F);
      this.quadSize = this.baseSize;
      this.spin = var21 * (this.random.nextBoolean() ? 1 : -1);
      this.roll = this.random.nextFloat() * (float) (Math.PI * 2);
      this.oRoll = this.roll;
      this.phase = this.random.nextFloat() * (float) (Math.PI * 2);
      this.baseR = var15;
      this.baseG = var16;
      this.baseB = var17;
      this.swirl = var20 > 0.005F;
      this.pickSprite(var14);
   }

   static ElfGlowParticle make(
      ClientLevel var0,
      double var1,
      double var3,
      double var5,
      double var7,
      double var9,
      double var11,
      SpriteSet var13,
      float var14,
      float var15,
      float var16,
      float var17,
      int var18,
      float var19,
      float var20,
      float var21,
      float var22
   ) {
      ElfGlowParticle var23 = new ElfGlowParticle(var0, var1, var3, var5, var7, var9, var11, var13, var14, var15, var16, var17, var18, var19, var20);
      var23.friction = var21;
      var23.hotAmt = var22;
      return var23;
   }

   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   public int getLightColor(float var1) {
      return 15728880;
   }

   public float getQuadSize(float var1) {
      float var2 = (this.age + var1) / this.lifetime;
      float var3 = Mth.clamp((this.age + var1) / 3.0F, 0.35F, 1.0F);
      float var4 = 1.0F + 0.12F * Mth.sin((this.age + var1) * 0.6F + this.phase);
      return this.baseSize * Mth.clamp(1.0F - var2 * var2 * 0.85F, 0.05F, 1.0F) * var3 * var4;
   }

   public void tick() {
      if (this.swirl) {
         this.xd = this.xd + Mth.sin(this.age * 0.3F + this.phase) * 0.004F;
         this.zd = this.zd + Mth.cos(this.age * 0.3F + this.phase) * 0.004F;
      }

      super.tick();
      float var1 = (float)this.age / this.lifetime;
      float var2 = Mth.clamp(1.0F - var1 * 3.0F, 0.0F, 1.0F) * this.hotAmt;
      this.rCol = this.baseR + (1.0F - this.baseR) * var2;
      this.gCol = this.baseG + (1.0F - this.baseG) * var2;
      this.bCol = this.baseB + (1.0F - this.baseB) * var2;
      float var3 = 0.78F + 0.22F * Mth.sin(this.age * 0.9F + this.phase);
      this.alpha = Mth.clamp((1.0F - var1 * var1 * var1) * var3, 0.0F, 1.0F);
      this.oRoll = this.roll;
      this.roll = this.roll + this.spin;
   }

   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private static final float THIN = 0.5F;
      private final SpriteSet sprites;
      private final float r;
      private final float g;
      private final float b;
      private final float size;
      private final float gravity;
      private final float spin;
      private final int life;

      public Provider(SpriteSet var1, float var2, float var3, float var4, float var5, int var6, float var7, float var8) {
         if (var6 == 16 && var8 > 0.11F) {
            ElfGlowParticle.STAR = var1;
         } else if (var6 == 40) {
            ElfGlowParticle.LEAF = var1;
         } else {
            ElfGlowParticle.GLOW = var1;
         }

         this.sprites = var1;
         this.r = var2;
         this.g = var3;
         this.b = var4;
         this.size = var5;
         this.life = var6;
         this.gravity = var7;
         this.spin = var8;
      }

      public Particle createParticle(SimpleParticleType var1, ClientLevel var2, double var3, double var5, double var7, double var9, double var11, double var13) {
         return Vfx.R.nextFloat() > 0.5F
            ? null
            : new ElfGlowParticle(
               var2, var3, var5, var7, var9, var11, var13, this.sprites, this.r, this.g, this.b, this.size, this.life, this.gravity, this.spin
            );
      }
   }
}
