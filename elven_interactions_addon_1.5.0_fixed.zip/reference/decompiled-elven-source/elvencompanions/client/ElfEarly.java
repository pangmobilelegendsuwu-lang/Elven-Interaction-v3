package com.elvencompanions.client;

import com.elvencompanions.entity.ElfEntity;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;

public final class ElfEarly {
   private static long until;

   public static void onCinematic(int var0) {
      try {
         if (var0 != 0) {
            return;
         }

         Minecraft var1 = Minecraft.getInstance();
         if (var1.level == null) {
            return;
         }

         until = var1.level.getGameTime() + 260L;

         try {
            Field var2 = TranscendMusic.class.getDeclaredField("ticks");
            var2.setAccessible(true);
            var2.setInt(null, 6);
         } catch (Throwable var3) {
         }
      } catch (Throwable var4) {
         until = 0L;
      }
   }

   public static boolean isT(ElfEntity var0) {
      if (var0.isTranscended()) {
         return true;
      } else {
         try {
            if (until != 0L && var0.isAlive() && var0.isNoGravity()) {
               Minecraft var1 = Minecraft.getInstance();
               return var1.level != null && var1.level.getGameTime() < until;
            } else {
               return false;
            }
         } catch (Throwable var2) {
            return false;
         }
      }
   }

   private ElfEarly() {
   }
}
