package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.client.fx.FxManager;
import com.elvencompanions.entity.ElfArrow;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.AbstractArrow;

public class ElfArrowRenderer extends ArrowRenderer<ElfArrow> {
   private static final ResourceLocation TEXTURE = ElvenCompanions.rl("textures/entity/elf_arrow.png");

   public ElfArrowRenderer(Context ctx) {
      super(ctx);
   }

   public ResourceLocation getTextureLocation(ElfArrow arrow) {
      return TEXTURE;
   }

   protected int getBlockLightLevel(ElfArrow arrow, BlockPos pos) {
      return 15;
   }

   public void render(AbstractArrow var1, float var2, float var3, PoseStack var4, MultiBufferSource var5, int var6) {
      if (!FxManager.arrowTake(var1, var3)) {
         super.render(var1, var2, var3, var4, var5, var6);
      }
   }
}
