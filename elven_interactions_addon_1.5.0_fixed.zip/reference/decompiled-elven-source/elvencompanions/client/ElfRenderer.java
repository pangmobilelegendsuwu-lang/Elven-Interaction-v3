package com.elvencompanions.client;

import com.elvencompanions.ElvenCompanions;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.logic.ElfRank;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Font.DisplayMode;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix4f;

public class ElfRenderer extends MobRenderer<ElfEntity, ElfModel> {
   private static final ResourceLocation FALLBACK = ElvenCompanions.rl("textures/entity/elf_fallback.png");
   private static final ResourceLocation BAR_PX = ElvenCompanions.rl("textures/entity/bar_px.png");
   private static final float[] BAR_UV = new float[]{0.0F, 0.0F, 1.0F, 1.0F};
   private static final Map<Integer, ResourceLocation> CACHE = new HashMap<>();

   public ElfRenderer(Context var1) {
      super(var1, new ElfModel(), 0.4F);
      this.addLayer(new ElfArmorLayer(this, var1.getModelSet()));
      this.addLayer(new TranscendedLayer(this));
      this.addLayer(new ElfHeldItemLayer(this, var1.getItemInHandRenderer()));
   }

   public static void clearCache() {
      CACHE.clear();
   }

   public ResourceLocation getTextureLocation(ElfEntity var1) {
      int var2 = Math.floorMod(var1.getSkin(), 6);
      return CACHE.computeIfAbsent(var2, var0 -> {
         ResourceLocation var1x = ElvenCompanions.rl("textures/entity/elf" + (var0 + 1) + ".png");
         return Minecraft.getInstance().getResourceManager().getResource(var1x).isPresent() ? var1x : FALLBACK;
      });
   }

   protected void setupRotations(ElfEntity var1, PoseStack var2, float var3, float var4, float var5, float var6) {
      super.setupRotations(var1, var2, var3, var4, var5, var6);
      if (var1.getRestState() == 3) {
         var2.translate(0.0F, 0.14F, 0.0F);
         var2.mulPose(Axis.XP.rotationDegrees(90.0F));
      }

      ElfFlightPose.apply(var1, var2, var3, var4, var5);
   }

   protected void renderNameTag(ElfEntity var1, Component var2, PoseStack var3, MultiBufferSource var4, int var5, float var6) {
      int var7 = var1.getElfLevel();
      MutableComponent var8 = Component.literal("[")
         .append(Component.translatable(ElfRank.key(var7, var1.isTranscended())))
         .append("]")
         .withStyle(ChatFormatting.GOLD);
      MutableComponent var9 = Component.literal(" · Lv. " + var7 + (var1.isTranscended() ? " ✦" : "")).withStyle(ChatFormatting.YELLOW);
      if (var2.getString().length() + var8.getString().length() + 8 <= 30) {
         super.renderNameTag(var1, var2.copy().append(" ").append(var8).append(var9), var3, var4, var5, var6);
      } else {
         super.renderNameTag(var1, var2, var3, var4, var5, var6);
         var3.pushPose();
         var3.translate(0.0F, 0.27F, 0.0F);
         super.renderNameTag(var1, var8.copy().append(var9), var3, var4, var5, var6);
         var3.popPose();
      }

      if (ClientPrefs.healthBar() && var1.isAlive()) {
         this.renderHealthBar(var1, var3, var4, var5);
      }
   }

   private void renderHealthBar(ElfEntity var1, PoseStack var2, MultiBufferSource var3, int var4) {
      float var5 = Mth.clamp(var1.getHealth() / Math.max(1.0F, var1.getMaxHealth()), 0.0F, 1.0F);
      byte var6 = 24;
      int var7 = Math.round(var5 * var6);
      if (var5 > 0.0F && var7 == 0) {
         var7 = 1;
      }

      int var8 = (int)(255.0F * Mth.clamp(2.0F - var5 * 2.0F, 0.0F, 1.0F));
      int var9 = (int)(255.0F * Mth.clamp(var5 * 2.0F, 0.0F, 1.0F));
      int var10 = var8 << 16 | Math.min(235, var9) << 8 | 70;
      MutableComponent var11 = Component.literal("|".repeat(var7)).withStyle(Style.EMPTY.withColor(var10));
      var11.append(Component.literal("|".repeat(var6 - var7)).withStyle(Style.EMPTY.withColor(4210752)));
      var2.pushPose();
      var2.translate(0.0F, var1.getBbHeight() + 0.5F, 0.0F);
      var2.mulPose(this.entityRenderDispatcher.cameraOrientation());
      var2.scale(0.025F, -0.025F, 0.025F);
      Font var12 = this.getFont();
      float var13 = -var12.width(var11) / 2;
      Matrix4f var14 = var2.last().pose();
      var12.drawInBatch(var11, var13, 11.0F, 553648127, false, var14, var3, DisplayMode.SEE_THROUGH, 1073741824, var4);
      var12.drawInBatch(var11, var13, 11.0F, -1, false, var14, var3, DisplayMode.NORMAL, 0, var4);
      var2.popPose();
   }

   protected void scale(ElfEntity var1, PoseStack var2, float var3) {
      var2.scale(0.95F, 0.95F, 0.95F);
   }

   protected RenderType getRenderType(LivingEntity var1, boolean var2, boolean var3, boolean var4) {
      return ElfGhost.type(super.getRenderType(var1, var2, var3, var4), var1, this.getTextureLocation(var1));
   }
}
