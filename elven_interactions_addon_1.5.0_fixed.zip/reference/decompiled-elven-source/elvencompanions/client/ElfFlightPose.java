package com.elvencompanions.client;

import com.elvencompanions.entity.ElfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.WeakHashMap;

public final class ElfFlightPose {
   private static final WeakHashMap<ElfEntity, ElfFlightPose.S> STATES = new WeakHashMap<>();

   private ElfFlightPose() {
   }

   private static float wrap(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   private static float lerp(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   private static float lerpAngle(float var0, float var1, float var2) {
      return var0 + wrap(var1 - var0) * var2;
   }

   private static void step(ElfEntity var0, ElfFlightPose.S var1) {
      var1.amtO = var1.amt;
      var1.yawO = var1.yaw;
      var1.rollO = var1.roll;
      var1.pitchO = var1.pitch;
      double var2 = var0.getX() - var0.xo;
      double var4 = var0.getY() - var0.yo;
      double var6 = var0.getZ() - var0.zo;
      double var8 = Math.sqrt(var2 * var2 + var6 * var6);
      double var10 = Math.sqrt(var8 * var8 + var4 * var4);
      boolean var12 = var0.isNoGravity()
         && !var0.onGround()
         && !var0.isPassenger()
         && !var0.isSleeping()
         && !var0.isCarried()
         && var0.getRestState() == 0
         && var0.isAlive();
      float var13 = var12 ? (float)Math.max(0.0, Math.min(1.0, (var10 - 0.05) / 0.2)) : 0.0F;
      var1.amt = var1.amt + (var13 - var1.amt) * 0.25F;
      if (var1.amt < 0.001F) {
         var1.amt = 0.0F;
      }

      if (var8 > 0.04) {
         float var14 = (float)Math.toDegrees(Math.atan2(-var2, var6));
         if (!var1.init) {
            var1.yaw = var14;
            var1.yawO = var14;
            var1.init = true;
         }

         float var15 = wrap(var14 - var1.yaw);
         var1.turn = var1.turn + (var15 - var1.turn) * 0.3F;
         var1.yaw = wrap(var1.yaw + var15 * 0.35F);
      } else {
         var1.turn *= 0.8F;
      }

      float var17 = Math.max(-40.0F, Math.min(40.0F, var1.turn * 1.8F));
      var1.roll = var1.roll + (var17 - var1.roll) * 0.3F;
      float var18 = (float)Math.toDegrees(Math.atan2(-var4, Math.max(var8, 0.02)));
      var18 = Math.max(-45.0F, Math.min(45.0F, var18));
      float var16 = 80.0F * var1.amt + var18 * var1.amt;
      var16 = Math.max(0.0F, Math.min(100.0F, var16));
      var1.pitch = var1.pitch + (-var16 - var1.pitch) * 0.3F;
   }

   public static float limb(ElfEntity var0, float var1) {
      try {
         ElfFlightPose.S var2 = STATES.get(var0);
         if (var2 != null && var2.amt > 0.05F) {
            return 0.0F;
         }
      } catch (Throwable var3) {
      }

      return var1;
   }

   public static void apply(ElfEntity var0, PoseStack var1, float var2, float var3, float var4) {
      try {
         ElfFlightPose.S var5 = STATES.computeIfAbsent(var0, var0x -> new ElfFlightPose.S());
         if (var5.last != var0.tickCount) {
            var5.last = var0.tickCount;
            step(var0, var5);
         }

         float var6 = lerp(var5.amtO, var5.amt, var4);
         if (var6 < 0.01F) {
            return;
         }

         float var7 = lerpAngle(var5.yawO, var5.yaw, var4);
         float var8 = Math.max(-100.0F, Math.min(100.0F, wrap(var3 - var7))) * var6;
         float var9 = lerp(var5.pitchO, var5.pitch, var4) + (float)Math.sin(var2 * 0.09F) * 2.5F * var6;
         float var10 = lerp(var5.rollO, var5.roll, var4) + (float)Math.sin(var2 * 0.13F) * 5.0F * var6;
         float var11 = var0.getBbHeight() * 0.5F;
         var1.translate(0.0F, var11, 0.0F);
         var1.mulPose(Axis.YP.rotationDegrees(var8));
         var1.mulPose(Axis.XP.rotationDegrees(var9));
         var1.mulPose(Axis.YP.rotationDegrees(var10));
         var1.translate(0.0F, -var11, 0.0F);
      } catch (Throwable var12) {
      }
   }

   private static final class S {
      int last = -1;
      boolean init;
      float amtO;
      float amt;
      float yawO;
      float yaw;
      float rollO;
      float roll;
      float pitchO;
      float pitch;
      float turn;
   }
}
