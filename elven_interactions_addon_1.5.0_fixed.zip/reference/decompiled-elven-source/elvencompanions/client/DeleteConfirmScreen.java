package com.elvencompanions.client;

import com.elvencompanions.net.ElfStatus;
import com.elvencompanions.net.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.PacketDistributor;

public class DeleteConfirmScreen extends Screen {
   private final Screen parent;
   private final ElfStatus elf;

   public DeleteConfirmScreen(Screen parent, ElfStatus elf) {
      super(Component.translatable("gui.elven_companions.delete.title"));
      this.parent = parent;
      this.elf = elf;
   }

   protected void init() {
      int cx = this.width / 2;
      int y = this.height / 2 + 24;
      Button cancel = (Button)this.addRenderableWidget(
         Button.builder(Component.translatable("gui.elven_companions.delete.cancel"), b -> this.minecraft.setScreen(this.parent))
            .bounds(cx - 105, y, 100, 20)
            .build()
      );
      this.addRenderableWidget(
         Button.builder(
               Component.translatable("gui.elven_companions.delete.confirm").withStyle(ChatFormatting.RED),
               b -> PacketDistributor.sendToServer(new ModNetwork.DeleteC2S(this.elf.id()), new CustomPacketPayload[0])
            )
            .bounds(cx + 5, y, 100, 20)
            .build()
      );
      this.setInitialFocus(cancel);
   }

   public void render(GuiGraphics g, int mx, int my, float pt) {
      super.render(g, mx, my, pt);
      int cx = this.width / 2;
      int top = this.height / 2 - 50;
      g.fill(cx - 130, top - 8, cx + 130, this.height / 2 + 52, -804253680);
      g.drawCenteredString(this.font, this.title, cx, top, 16733525);
      g.drawCenteredString(this.font, Component.translatable("gui.elven_companions.delete.question", new Object[]{this.elf.name()}), cx, top + 16, 16777215);
      g.drawCenteredString(this.font, Component.translatable("gui.elven_companions.delete.warning1"), cx, top + 30, 16755285);
      g.drawCenteredString(this.font, Component.translatable("gui.elven_companions.delete.warning2"), cx, top + 41, 16755285);
   }

   public boolean isPauseScreen() {
      return false;
   }

   public void onClose() {
      this.minecraft.setScreen(this.parent);
   }
}
