package com.elvencompanions;

import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.DoubleValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public final class ECConfig {
   public static final ModConfigSpec SPEC;
   public static final DoubleValue maxHealth;
   public static final BooleanValue randomNames;
   public static final BooleanValue dialogueOwnerOnly;
   public static final BooleanValue allowManualSkills;
   public static final BooleanValue renderEquipmentMeshes;
   public static final BooleanValue particles;
   public static final DoubleValue reviveHealthFraction;
   public static final IntValue reviveTicks;
   public static final IntValue followStartDistance;
   public static final IntValue followStopDistance;
   public static final IntValue teleportDistance;
   public static final IntValue guardRadius;
   public static final DoubleValue mountRadius;
   public static final DoubleValue pickupRadius;
   public static final DoubleValue restHealAmount;
   public static final IntValue bedRadius;
   public static final IntValue bedSearchSeconds;
   public static final IntValue restHealIntervalTicks;
   public static final IntValue pickupIntervalTicks;
   public static final IntValue pickupMaxPerScan;
   public static final DoubleValue arrowDamageMultiplier;
   public static final DoubleValue stealthArrowMultiplier;
   public static final DoubleValue fireIntervalFactor;
   public static final DoubleValue doubleShotChance;
   public static final DoubleValue arrowInaccuracy;
   public static final IntValue attackRange;
   public static final DoubleValue stealthHealthBelow;
   public static final DoubleValue stealthSpeedMultiplier;
   public static final IntValue stealthCooldownSec;
   public static final IntValue stealthDurationSec;
   public static final IntValue stealthRadius;
   public static final IntValue chanceVerdant;
   public static final IntValue chanceSkyfall;
   public static final IntValue chanceVolley;
   public static final IntValue chanceWildfire;
   public static final IntValue chanceMoonfall;
   public static final IntValue cdVerdant;
   public static final IntValue cdSkyfall;
   public static final IntValue cdVolley;
   public static final IntValue cdWildfire;
   public static final IntValue cdMoonfall;
   public static final DoubleValue piercerWidth;
   public static final DoubleValue piercerSpeed;
   public static final DoubleValue verdantDamage;
   public static final DoubleValue wildfireDamage;
   public static final DoubleValue wildfireBurnPerSecond;
   public static final IntValue piercerLifeTicks;
   public static final IntValue wildfireBurnSeconds;
   public static final DoubleValue skyfallJumpHeight;
   public static final DoubleValue skyfallRadius;
   public static final DoubleValue skyfallDirect;
   public static final DoubleValue skyfallSplash;
   public static final IntValue skyfallImmunityTicks;
   public static final IntValue skyfallSlowFallTicks;
   public static final IntValue volleyArrows;
   public static final IntValue volleyIntervalTicks;
   public static final IntValue volleyMaxHits;
   public static final DoubleValue volleyDamage;
   public static final DoubleValue moonDiameter;
   public static final DoubleValue moonDamage;
   public static final IntValue moonDurationTicks;
   public static final IntValue moonIntervalTicks;
   public static final IntValue moonMaxHits;
   public static final IntValue moonSlowAmplifier;
   public static final IntValue announceRadius;
   public static final BooleanValue skillsUseArrowMultiplier;
   public static final DoubleValue ultHealthBelow;
   public static final DoubleValue ultAttemptChance;
   public static final DoubleValue ultSuccessChance;
   public static final DoubleValue ultNearDamage;
   public static final DoubleValue ultFarDamage;
   public static final DoubleValue ultBeamWidth;
   public static final IntValue ultRetryCooldownSec;
   public static final IntValue ultSuccessCooldownSec;
   public static final IntValue ultHeight;
   public static final IntValue ultDurationTicks;
   public static final IntValue ultNearRadius;
   public static final IntValue ultFarRadius;
   public static final IntValue ultAnnounceRadius;
   public static final BooleanValue ultInvulnerable;
   public static final DoubleValue maxHealthMax;
   public static final DoubleValue maxDamageReduction;
   public static final DoubleValue arrowDamageMultiplierMax;
   public static final DoubleValue fireSpeedMaxMultiplier;
   public static final DoubleValue skillChanceMaxMultiplier;
   public static final DoubleValue skillDamageMaxMultiplier;
   public static final DoubleValue skillAreaMaxMultiplier;
   public static final DoubleValue staminaMaxMultiplier;
   public static final DoubleValue skillCooldownMinFactor;
   public static final DoubleValue walkSpeedMaxMultiplier;
   public static final DoubleValue arrowInaccuracyMin;
   public static final DoubleValue xpBase;
   public static final DoubleValue xpLinear;
   public static final DoubleValue xpQuad;
   public static final DoubleValue xpMultiplier;
   public static final DoubleValue assistXpFraction;
   public static final DoubleValue airVariantChance;
   public static final DoubleValue stompChance;
   public static final DoubleValue stompDamage;
   public static final DoubleValue stompRadius;
   public static final DoubleValue airJumpFallDistance;
   public static final IntValue escapeDashCooldownTicks;
   public static final IntValue airJumpCooldownTicks;
   public static final IntValue potionDrinkTicksMin;
   public static final DoubleValue escapeExitHealth;
   public static final DoubleValue escapeRegenPerSecond;
   public static final BooleanValue escapeEnabled;
   public static final BooleanValue waterJumpEnabled;
   public static final IntValue wanderRadius;
   public static final IntValue goHomeTeleportDistance;
   public static final IntValue interactionDistance;
   public static final DoubleValue stepHeight;
   public static final BooleanValue deleteDropsInventory;
   public static final IntValue restDayStart;
   public static final IntValue restDayEnd;
   public static final IntValue restNoonStart;
   public static final IntValue restNoonEnd;
   public static final IntValue restEveningStart;
   public static final IntValue restEveningEnd;
   public static final IntValue restNightStart;
   public static final IntValue restNightEnd;
   public static final IntValue chanceThorn;
   public static final IntValue cdThorn;
   public static final IntValue thornDurationTicks;
   public static final IntValue thornBossHealth;
   public static final DoubleValue thornDamage;
   public static final DoubleValue thornRadius;
   public static final DoubleValue huntChancePerShot;
   public static final DoubleValue huntDamage;
   public static final DoubleValue huntPathDamage;
   public static final DoubleValue huntSpeed;
   public static final IntValue huntCooldownSec;
   public static final IntValue huntMinLevel;
   public static final IntValue huntRadius;
   public static final IntValue huntMinTargetHealth;
   public static final IntValue huntMaxTicks;
   public static final BooleanValue guardianEnabled;
   public static final BooleanValue seedEnabled;
   public static final DoubleValue guardianOwnerHealthFraction;
   public static final DoubleValue guardianRadius;
   public static final DoubleValue seedHealthFraction;
   public static final DoubleValue seedHealFraction;
   public static final IntValue guardianMobCount;
   public static final IntValue guardianMobRadius;
   public static final IntValue guardianAmplifier;
   public static final IntValue guardianDurationTicks;
   public static final IntValue guardianCooldownSec;
   public static final IntValue guardianRange;
   public static final IntValue seedCooldownSec;
   public static final IntValue seedHealTicks;
   public static final DoubleValue transcendXpMultiplier;
   public static final DoubleValue transcendSpellMultiplier;
   public static final DoubleValue musicVolume;
   public static final BooleanValue annihilationEnabled;
   public static final IntValue annihilationCooldownSec;
   public static final IntValue annihilationHordeCount;
   public static final IntValue annihilationBossSeconds;
   public static final IntValue annihilationRadius;
   public static final IntValue annihilationHeight;
   public static final IntValue annihilationDescentTicks;
   public static final IntValue annihilationSilenceTicks;
   public static final IntValue ragingDurationTicks;
   public static final IntValue ragingCooldownSec;
   public static final IntValue ragingMinInterval;
   public static final IntValue skillWandRange;
   public static final IntValue particleBudgetPerTick;
   public static final IntValue annihilationMaxTargets;
   public static final DoubleValue annihilationDamage;
   public static final DoubleValue annihilationMinFraction;
   public static final DoubleValue annihilationKnockback;
   public static final DoubleValue ragingHealthFraction;
   public static final DoubleValue ragingMultiplier;
   public static final DoubleValue ragingArrowCap;
   public static final DoubleValue ragingSpeedCap;
   public static final DoubleValue particleDensity;
   public static final BooleanValue voiceEnabled;
   public static final DoubleValue voiceVolume;
   public static final DoubleValue attackVoiceChance;
   public static final DoubleValue skillLineChance;
   public static final DoubleValue idleChancePerSecond;
   public static final DoubleValue talkChancePerSecond;
   public static final DoubleValue hurtHeavyFraction;
   public static final DoubleValue lowHealthFraction;
   public static final IntValue talkDistance;
   public static final IntValue encounterEliteHealth;
   public static final IntValue encounterBossHealth;
   public static final DoubleValue potionHealthBelow;
   public static final DoubleValue potionHeal;
   public static final DoubleValue knockbackChance;
   public static final DoubleValue knockbackStrength;
   public static final IntValue potionCooldownTicks;
   public static final IntValue potionDrinkTicks;
   public static final IntValue maxStamina;
   public static final IntValue dashCost;
   public static final IntValue staminaRegen;
   public static final IntValue staminaRegenTicks;
   public static final IntValue dashTriggerDistance;
   public static final IntValue dashDistance;
   public static final IntValue dashCooldownTicks;
   public static final IntValue knockbackCooldownTicks;
   public static final IntValue knockbackRadius;

   public static int ticks(IntValue seconds) {
      return (Integer)seconds.get() * 20;
   }

   private ECConfig() {
   }

   static {
      Builder b = new Builder();
      b.push("general");
      maxHealth = b.comment("Elf max health (applied when the elf joins a world)").defineInRange("maxHealth", 80.0, 10.0, 400.0);
      randomNames = b.comment("Give newly summoned elves a random elven name").define("randomNames", true);
      dialogueOwnerOnly = b.comment("Command dialogue is shown only to the owner (false = nearby players too)").define("dialogueOwnerOnly", true);
      allowManualSkills = b.comment("Show/allow manual skill buttons (they still use the normal cooldowns)").define("allowManualSkills", false);
      renderEquipmentMeshes = b.comment(
            "Render the OBJ's chest/chainmail/belt/leggings groups. Their UVs target textures that are not supplied, so default off."
         )
         .define("renderEquipmentMeshes", false);
      particles = b.comment("Cosmetic particles for skills/auras").define("particles", true);
      reviveHealthFraction = b.comment("Fraction of max health restored on revival").defineInRange("reviveHealthFraction", 1.0, 0.1, 1.0);
      reviveTicks = b.comment("Length of the revival ritual at the Soulwood Revival Tree").defineInRange("reviveTicks", 80, 10, 1200);
      followStartDistance = b.comment("Follow stance: start walking when farther than this").defineInRange("followStartDistance", 6, 3, 32);
      followStopDistance = b.comment("Follow stance: stop when closer than this").defineInRange("followStopDistance", 3, 1, 16);
      teleportDistance = b.comment("Follow stance: teleport to owner when farther than this").defineInRange("teleportDistance", 24, 8, 128);
      guardRadius = b.comment("Guard stance: leash radius around the guard point").defineInRange("guardRadius", 10, 3, 48);
      b.pop();
      b.push("utility");
      mountRadius = b.comment("Ride Nearby Mounts search radius").defineInRange("mountRadius", 5.0, 1.0, 32.0);
      bedRadius = b.comment("Rest: bed search radius").defineInRange("bedRadius", 8, 2, 24);
      bedSearchSeconds = b.comment("Rest: seconds to look for a bed before lying on the ground").defineInRange("bedSearchSeconds", 10, 1, 120);
      restHealIntervalTicks = b.comment("Rest: heal every N ticks").defineInRange("restHealIntervalTicks", 40, 1, 1200);
      restHealAmount = b.comment("Rest: HP healed per interval").defineInRange("restHealAmount", 1.0, 0.0, 40.0);
      pickupRadius = b.comment("Pickup toggle radius").defineInRange("pickupRadius", 5.0, 1.0, 16.0);
      pickupIntervalTicks = b.comment("Pickup scan interval").defineInRange("pickupIntervalTicks", 10, 1, 200);
      pickupMaxPerScan = b.comment("Max item entities processed per scan").defineInRange("pickupMaxPerScan", 4, 1, 64);
      b.pop();
      b.push("combat");
      arrowDamageMultiplier = b.comment("Normal arrows at level 1: multiple of a vanilla arrow (level 50 = arrowDamageMultiplierMax)")
         .defineInRange("arrowDamageMultiplier", 2.0, 0.1, 20.0);
      stealthArrowMultiplier = b.comment("Normal arrows while stealthed").defineInRange("stealthArrowMultiplier", 3.0, 0.1, 20.0);
      fireIntervalFactor = b.comment("Fire interval as a multiple of the skeleton's (1.5 = 50% slower than a skeleton; 0.5 = twice as fast)")
         .defineInRange("fireIntervalFactor", 1.5, 0.1, 6.0);
      doubleShotChance = b.comment("Chance a shot fires two arrows").defineInRange("doubleShotChance", 0.1, 0.0, 1.0);
      arrowInaccuracy = b.comment("Arrow spread at level 1 (skeletons use 2-10). Aim tightens with level down to arrowInaccuracyMin")
         .defineInRange("arrowInaccuracy", 8.0, 0.0, 30.0);
      arrowInaccuracyMin = b.comment("Arrow spread at level 50").defineInRange("arrowInaccuracyMin", 0.6, 0.0, 30.0);
      attackRange = b.comment("Max shooting range in blocks").defineInRange("attackRange", 24, 4, 64);
      b.pop();
      b.push("stealth");
      stealthHealthBelow = b.defineInRange("stealthHealthBelow", 10.0, 1.0, 200.0);
      stealthCooldownSec = b.defineInRange("stealthCooldownSec", 30, 1, 3600);
      stealthDurationSec = b.defineInRange("stealthDurationSec", 10, 1, 600);
      stealthRadius = b.comment("Hostiles within this radius drop their target").defineInRange("stealthRadius", 10, 1, 48);
      stealthSpeedMultiplier = b.defineInRange("stealthSpeedMultiplier", 1.5, 1.0, 5.0);
      b.pop();
      b.push("skills");
      chanceVerdant = b.comment("Chance points out of 100 per successful basic shot (total must be <= 100)").defineInRange("chanceVerdant", 12, 0, 100);
      chanceSkyfall = b.defineInRange("chanceSkyfall", 6, 0, 100);
      chanceVolley = b.defineInRange("chanceVolley", 3, 0, 100);
      chanceWildfire = b.defineInRange("chanceWildfire", 6, 0, 100);
      chanceMoonfall = b.defineInRange("chanceMoonfall", 3, 0, 100);
      cdVerdant = b.comment("Cooldowns in seconds").defineInRange("cooldownVerdantSec", 8, 0, 3600);
      cdSkyfall = b.defineInRange("cooldownSkyfallSec", 18, 0, 3600);
      cdVolley = b.defineInRange("cooldownVolleySec", 24, 0, 3600);
      cdWildfire = b.defineInRange("cooldownWildfireSec", 16, 0, 3600);
      cdMoonfall = b.defineInRange("cooldownMoonfallSec", 30, 0, 3600);
      skillsUseArrowMultiplier = b.comment("If true, special-skill damage is also multiplied by the arrow/stealth multiplier (spec default: false)")
         .define("skillsUseArrowMultiplier", false);
      announceRadius = b.comment("Actionbar announcement range for ordinary skills").defineInRange("announceRadius", 15, 1, 128);
      piercerWidth = b.defineInRange("piercerWidth", 3.0, 0.5, 16.0);
      piercerSpeed = b.comment("Blocks per tick").defineInRange("piercerSpeed", 1.5, 0.2, 4.0);
      piercerLifeTicks = b.defineInRange("piercerLifeTicks", 60, 5, 400);
      verdantDamage = b.defineInRange("verdantDamage", 6.0, 0.0, 200.0);
      wildfireDamage = b.defineInRange("wildfireDamage", 5.0, 0.0, 200.0);
      wildfireBurnPerSecond = b.defineInRange("wildfireBurnPerSecond", 1.0, 0.0, 50.0);
      wildfireBurnSeconds = b.defineInRange("wildfireBurnSeconds", 5, 0, 60);
      skyfallJumpHeight = b.defineInRange("skyfallJumpHeight", 5.0, 2.0, 12.0);
      skyfallRadius = b.defineInRange("skyfallRadius", 4.0, 1.0, 16.0);
      skyfallDirect = b.defineInRange("skyfallDirectDamage", 8.0, 0.0, 200.0);
      skyfallSplash = b.defineInRange("skyfallSplashDamage", 6.0, 0.0, 200.0);
      skyfallImmunityTicks = b.comment("Explosion immunity while airborne").defineInRange("skyfallImmunityTicks", 100, 0, 600);
      skyfallSlowFallTicks = b.defineInRange("skyfallSlowFallTicks", 120, 20, 1200);
      volleyArrows = b.defineInRange("volleyArrows", 10, 1, 100);
      volleyIntervalTicks = b.defineInRange("volleyIntervalTicks", 4, 1, 40);
      volleyDamage = b.defineInRange("volleyDamage", 3.0, 0.0, 200.0);
      volleyMaxHits = b.defineInRange("volleyMaxHitsPerEntity", 4, 1, 100);
      moonDiameter = b.defineInRange("moonDiameter", 6.0, 2.0, 32.0);
      moonDurationTicks = b.defineInRange("moonDurationTicks", 120, 20, 1200);
      moonIntervalTicks = b.defineInRange("moonIntervalTicks", 6, 1, 100);
      moonDamage = b.defineInRange("moonDamage", 3.0, 0.0, 200.0);
      moonMaxHits = b.defineInRange("moonMaxHitsPerEntity", 4, 1, 100);
      moonSlowAmplifier = b.comment("Slowness amplifier (1 = Slowness II = 30% slower)").defineInRange("moonSlowAmplifier", 1, 0, 6);
      b.pop();
      b.push("ultimate");
      ultHealthBelow = b.defineInRange("ultHealthBelow", 10.0, 1.0, 200.0);
      ultAttemptChance = b.comment("Chance per eligible basic shot to ATTEMPT the ultimate").defineInRange("ultAttemptChance", 0.005, 0.0, 1.0);
      ultSuccessChance = b.defineInRange("ultSuccessChance", 0.5, 0.0, 1.0);
      ultRetryCooldownSec = b.defineInRange("ultRetryCooldownSec", 30, 0, 7200);
      ultSuccessCooldownSec = b.defineInRange("ultSuccessCooldownSec", 240, 0, 7200);
      ultHeight = b.defineInRange("ultHeight", 50, 3, 200);
      ultDurationTicks = b.comment("Length of the cinematic before the beam fires").defineInRange("ultDurationTicks", 200, 40, 1200);
      ultNearRadius = b.defineInRange("ultNearRadius", 12, 1, 64);
      ultFarRadius = b.defineInRange("ultFarRadius", 40, 2, 128);
      ultNearDamage = b.defineInRange("ultNearDamage", 16.0, 0.0, 500.0);
      ultFarDamage = b.defineInRange("ultFarDamage", 8.0, 0.0, 500.0);
      ultBeamWidth = b.defineInRange("ultBeamWidth", 10.0, 1.0, 32.0);
      ultAnnounceRadius = b.defineInRange("ultAnnounceRadius", 40, 1, 256);
      ultInvulnerable = b.comment("Elf takes no damage during the ultimate").define("ultInvulnerable", true);
      b.pop();
      b.push("progression");
      maxHealthMax = b.comment("Max health at level 50 (level 1 = general.maxHealth)").defineInRange("maxHealthMax", 120.0, 10.0, 1000.0);
      maxDamageReduction = b.comment("Damage reduction ('durability') at level 50: 0.5 = takes 50% less damage")
         .defineInRange("maxDamageReduction", 0.5, 0.0, 0.95);
      arrowDamageMultiplierMax = b.comment("Arrow damage multiplier at level 50 (x vanilla arrow)").defineInRange("arrowDamageMultiplierMax", 5.0, 0.1, 50.0);
      fireSpeedMaxMultiplier = b.comment("Fire RATE at level 50 relative to level 1 (3 = three times faster)")
         .defineInRange("fireSpeedMaxMultiplier", 3.0, 1.0, 10.0);
      skillChanceMaxMultiplier = b.comment("Skill proc chances at level 50 relative to level 1 (total still capped at 100)")
         .defineInRange("skillChanceMaxMultiplier", 2.0, 1.0, 10.0);
      skillDamageMaxMultiplier = b.comment("Skill damage at level 50 relative to level 1").defineInRange("skillDamageMaxMultiplier", 2.5, 1.0, 20.0);
      skillAreaMaxMultiplier = b.comment("Skill width/radius at level 50 relative to level 1").defineInRange("skillAreaMaxMultiplier", 1.8, 1.0, 5.0);
      staminaMaxMultiplier = b.comment("Max stamina and regeneration at level 50 relative to level 1").defineInRange("staminaMaxMultiplier", 2.0, 1.0, 10.0);
      skillCooldownMinFactor = b.comment("Skill cooldowns at level 50 relative to level 1").defineInRange("skillCooldownMinFactor", 0.6, 0.1, 1.0);
      walkSpeedMaxMultiplier = b.comment("Walking speed at level 50 relative to level 1").defineInRange("walkSpeedMaxMultiplier", 1.25, 1.0, 3.0);
      xpBase = b.comment("XP needed for level L -> L+1 = base + linear*L + quad*L^2").defineInRange("xpBase", 25.0, 1.0, 100000.0);
      xpLinear = b.defineInRange("xpLinear", 4.0, 0.0, 100000.0);
      xpQuad = b.defineInRange("xpQuad", 0.35, 0.0, 1000.0);
      xpMultiplier = b.comment("Global XP gain multiplier").defineInRange("xpMultiplier", 1.0, 0.01, 1000.0);
      assistXpFraction = b.comment("XP share when the owner finishes a hostile the elf damaged/targeted").defineInRange("assistXpFraction", 0.5, 0.0, 1.0);
      airVariantChance = b.comment("Chance that a skill proc becomes its rare AERIAL variant (constant, does not scale with level)")
         .defineInRange("airVariantChance", 0.08, 0.0, 1.0);
      stompChance = b.comment("After an aerial skill: chance to dive and stomp instead of slow-falling").defineInRange("stompChance", 0.5, 0.0, 1.0);
      stompDamage = b.defineInRange("stompDamage", 8.0, 0.0, 500.0);
      stompRadius = b.defineInRange("stompRadius", 3.5, 1.0, 16.0);
      b.pop();
      b.push("patch13");
      wanderRadius = b.comment("Wander stance: roam radius around the anchor (blocks)").defineInRange("wanderRadius", 10, 3, 48);
      goHomeTeleportDistance = b.comment("Go Home: walk when closer than this, otherwise teleport to a safe spot near home")
         .defineInRange("goHomeTeleportDistance", 48, 8, 512);
      interactionDistance = b.comment("Inventory/ride commands: max distance between owner and elf (blocks)").defineInRange("interactionDistance", 16, 4, 64);
      stepHeight = b.comment("Step-up height like a horse (1.0 = one full block)").defineInRange("stepHeight", 1.0, 0.6, 1.4);
      deleteDropsInventory = b.comment("Permanent deletion drops the elf's inventory items (no Elf Soul is ever created)").define("deleteDropsInventory", true);
      b.comment(
         "Rest schedule windows in Minecraft day time ticks (0=06:00 sunrise, 6000=12:00, 12000=18:00, 13000=19:00, 18000=00:00, 23000=05:00). start>end wraps midnight."
      );
      restDayStart = b.defineInRange("restDayStart", 0, 0, 23999);
      restDayEnd = b.defineInRange("restDayEnd", 6000, 0, 23999);
      restNoonStart = b.defineInRange("restNoonStart", 6000, 0, 23999);
      restNoonEnd = b.defineInRange("restNoonEnd", 9000, 0, 23999);
      restEveningStart = b.defineInRange("restEveningStart", 11000, 0, 23999);
      restEveningEnd = b.defineInRange("restEveningEnd", 14000, 0, 23999);
      restNightStart = b.defineInRange("restNightStart", 14000, 0, 23999);
      restNightEnd = b.defineInRange("restNightEnd", 23000, 0, 23999);
      chanceThorn = b.comment("Thornroot Snare: chance points out of 100 per basic shot").defineInRange("chanceThorn", 5, 0, 100);
      cdThorn = b.defineInRange("cooldownThornSec", 14, 0, 3600);
      thornDamage = b.defineInRange("thornDamage", 6.0, 0.0, 200.0);
      thornRadius = b.defineInRange("thornRadius", 2.5, 0.5, 16.0);
      thornDurationTicks = b.comment("Root/slow field duration (bosses get a fraction)").defineInRange("thornDurationTicks", 80, 10, 1200);
      thornBossHealth = b.comment("Enemies with at least this max health count as bosses/powerful: reduced control, never fully rooted")
         .defineInRange("thornBossHealth", 100, 20, 100000);
      huntChancePerShot = b.comment("Chance per basic shot (while a dangerous enemy is in range) to start the Wild Hunt")
         .defineInRange("huntChancePerShot", 0.02, 0.0, 1.0);
      huntCooldownSec = b.defineInRange("huntCooldownSec", 150, 5, 7200);
      huntMinLevel = b.comment("Unlock level").defineInRange("huntMinLevel", 20, 1, 50);
      huntRadius = b.comment("Detection radius for the marked target (highest max-health hostile wins, ties: nearest)").defineInRange("huntRadius", 32, 8, 96);
      huntMinTargetHealth = b.comment("Only used when the best target has at least this max health, or 4+ hostiles are near it")
         .defineInRange("huntMinTargetHealth", 30, 1, 100000);
      huntDamage = b.comment("Primary target damage at level 1 (scales up to x1.6 at level 50)").defineInRange("huntDamage", 40.0, 0.0, 1000.0);
      huntPathDamage = b.comment("Damage to other hostiles on the charge path").defineInRange("huntPathDamage", 12.0, 0.0, 1000.0);
      huntSpeed = b.comment("Stag speed in blocks per tick").defineInRange("huntSpeed", 1.5, 0.3, 4.0);
      huntMaxTicks = b.comment("Hard lifetime of the stag (it always dissolves)").defineInRange("huntMaxTicks", 140, 40, 600);
      guardianEnabled = b.define("guardianEnabled", true);
      guardianOwnerHealthFraction = b.comment("Triggers when the owner's health is at or below this fraction")
         .defineInRange("guardianOwnerHealthFraction", 0.4, 0.05, 1.0);
      guardianMobCount = b.comment("...or when this many hostiles are within guardianMobRadius of the owner").defineInRange("guardianMobCount", 4, 2, 64);
      guardianMobRadius = b.defineInRange("guardianMobRadius", 7, 2, 32);
      guardianRadius = b.comment("Barrier radius around the owner (owner, their elves and pets inside are protected)")
         .defineInRange("guardianRadius", 6.0, 2.0, 24.0);
      guardianAmplifier = b.comment("Resistance amplifier (1 = Resistance II = 40% less damage; never invulnerable)")
         .defineInRange("guardianAmplifier", 1, 0, 3);
      guardianDurationTicks = b.defineInRange("guardianDurationTicks", 160, 20, 1200);
      guardianCooldownSec = b.defineInRange("guardianCooldownSec", 45, 5, 3600);
      guardianRange = b.comment("The elf must be within this distance of the owner").defineInRange("guardianRange", 24, 4, 128);
      seedEnabled = b.define("seedEnabled", true);
      seedHealthFraction = b.comment("Owner or elf at or below this health fraction can receive a Life Seed")
         .defineInRange("seedHealthFraction", 0.3, 0.05, 0.9);
      seedHealFraction = b.comment("Total healing as a fraction of the target's max health, delivered over seedHealTicks")
         .defineInRange("seedHealFraction", 0.6, 0.05, 1.0);
      seedHealTicks = b.defineInRange("seedHealTicks", 160, 20, 1200);
      seedCooldownSec = b.defineInRange("seedCooldownSec", 180, 10, 7200);
      b.pop();
      b.push("transcendence");
      transcendXpMultiplier = b.comment("XP to transcend = the normal XP requirement of level 50 x this (about 3x harder)")
         .defineInRange("transcendXpMultiplier", 3.0, 1.0, 100.0);
      transcendSpellMultiplier = b.comment("Transcended elves: every existing spell's damage AND area/scale are multiplied by this")
         .defineInRange("transcendSpellMultiplier", 2.0, 1.0, 10.0);
      musicVolume = b.comment("Volume of the transcendence music").defineInRange("musicVolume", 1.0, 0.0, 2.0);
      b.pop();
      b.push("annihilation");
      annihilationEnabled = b.define("annihilationEnabled", true);
      annihilationCooldownSec = b.comment("5 minutes").defineInRange("annihilationCooldownSec", 300, 10, 7200);
      annihilationHordeCount = b.comment("Hostiles with less than 99 max health within 32 blocks needed to trigger")
         .defineInRange("annihilationHordeCount", 32, 2, 512);
      annihilationBossSeconds = b.comment("Seconds of continuous engagement with the same boss/elite (max health >= 100)")
         .defineInRange("annihilationBossSeconds", 20, 1, 600);
      annihilationRadius = b.comment("Damage radius of the explosion").defineInRange("annihilationRadius", 60, 8, 128);
      annihilationHeight = b.comment("How high she launches (blocks); reduced when the sky is blocked, skipped when less than 30 is free")
         .defineInRange("annihilationHeight", 100, 30, 200);
      annihilationDescentTicks = b.comment("Time the giant arrow needs to descend (client visual)").defineInRange("annihilationDescentTicks", 140, 40, 600);
      annihilationSilenceTicks = b.comment("Sound silence on impact (40 = 2 s)").defineInRange("annihilationSilenceTicks", 40, 0, 200);
      annihilationDamage = b.comment("Damage at the centre; falls off linearly to the minimum fraction at the radius edge")
         .defineInRange("annihilationDamage", 160.0, 1.0, 5000.0);
      annihilationMinFraction = b.defineInRange("annihilationMinFraction", 0.35, 0.0, 1.0);
      annihilationKnockback = b.comment("Knockback strength (capped to avoid launching mobs)").defineInRange("annihilationKnockback", 0.5, 0.0, 2.0);
      annihilationMaxTargets = b.comment("Safety cap on damaged entities per detonation").defineInRange("annihilationMaxTargets", 400, 10, 5000);
      b.pop();
      b.push("raging");
      ragingHealthFraction = b.comment("Transcended elf at or below this health fraction starts Raging Mode")
         .defineInRange("ragingHealthFraction", 0.2, 0.01, 0.9);
      ragingDurationTicks = b.defineInRange("ragingDurationTicks", 200, 20, 1200);
      ragingCooldownSec = b.comment("Prevents instant re-activation while she stays at low health").defineInRange("ragingCooldownSec", 60, 0, 3600);
      ragingMultiplier = b.comment(
            "Multiplies damage, attack speed, movement speed, spell damage, skill area and stamina regeneration (once, on top of Transcendence)"
         )
         .defineInRange("ragingMultiplier", 2.0, 1.0, 5.0);
      ragingArrowCap = b.comment("Safety cap on the arrow damage multiplier while raging").defineInRange("ragingArrowCap", 12.0, 1.0, 100.0);
      ragingSpeedCap = b.comment("Safety cap on walking speed (attribute value) while raging").defineInRange("ragingSpeedCap", 0.7, 0.1, 2.0);
      ragingMinInterval = b.comment("Safety floor for ticks between shots while raging").defineInRange("ragingMinInterval", 3, 2, 40);
      b.pop();
      b.push("skillwand");
      skillWandRange = b.comment("Max distance between player and elf for manual skills (blocks)").defineInRange("skillWandRange", 128, 8, 512);
      b.pop();
      b.push("fx");
      particleDensity = b.comment("Multiplier on particle counts of elf effects (lower = faster)").defineInRange("particleDensity", 1.0, 0.1, 1.0);
      particleBudgetPerTick = b.comment("Hard cap on elf effect particles sent per level per tick (excess is dropped)")
         .defineInRange("particleBudgetPerTick", 3000, 200, 100000);
      b.pop();
      b.push("voice");
      voiceEnabled = b.comment("Master switch for elf voice clips").define("voiceEnabled", true);
      voiceVolume = b.comment("Volume of elf voice clips (also adjustable with the Voice slider in Sound settings)")
         .defineInRange("voiceVolume", 1.0, 0.05, 2.0);
      attackVoiceChance = b.comment("Chance of a grunt/shout per basic shot").defineInRange("attackVoiceChance", 0.3, 0.0, 1.0);
      skillLineChance = b.comment("On a skill: chance of a spoken voiceline (otherwise a breath/voice clip)")
         .defineInRange("skillVoicelineChance", 0.6, 0.0, 1.0);
      idleChancePerSecond = b.defineInRange("idleChancePerSecond", 0.06, 0.0, 1.0);
      talkChancePerSecond = b.comment("Chance per second to chat when the owner is close and the elf is calm")
         .defineInRange("talkChancePerSecond", 0.05, 0.0, 1.0);
      talkDistance = b.defineInRange("talkDistance", 5, 1, 32);
      encounterEliteHealth = b.comment("Enemy max health >= this: elite encounter line (below it: normal)").defineInRange("encounterEliteHealth", 20, 1, 10000);
      encounterBossHealth = b.comment("Enemy max health >= this: boss encounter line").defineInRange("encounterBossHealth", 50, 1, 10000);
      hurtHeavyFraction = b.comment("Hit of at least this fraction of max health: heavy hurt clip").defineInRange("hurtHeavyFraction", 0.12, 0.01, 1.0);
      lowHealthFraction = b.comment("Below this fraction of max health after a hit: low-health hurt clip").defineInRange("lowHealthFraction", 0.25, 0.01, 1.0);
      b.pop();
      b.push("defense");
      potionHealthBelow = b.comment("Escape + drink the built-in healing potion when health drops below this")
         .defineInRange("potionHealthBelow", 10.0, 1.0, 400.0);
      potionHeal = b.comment("HP restored by the built-in potion (no inventory item needed)").defineInRange("potionHeal", 35.0, 0.0, 400.0);
      potionCooldownTicks = b.defineInRange("potionCooldownTicks", 600, 20, 72000);
      potionDrinkTicks = b.comment("Drink time at level 1 (120 = 6 s); shrinks to potionDrinkTicksMin at level 50")
         .defineInRange("potionDrinkTicks", 120, 10, 1200);
      potionDrinkTicksMin = b.comment("Drink time at level 50 (60 = 3 s)").defineInRange("potionDrinkTicksMin", 60, 5, 1200);
      escapeEnabled = b.comment("Below potionHealthBelow the elf runs to its owner and drinks; false = fight on").define("escapeEnabled", true);
      escapeExitHealth = b.comment(
            "Escape ends (and she re-enters combat) once health is ABOVE this. Between 10 and 20 she keeps fighting if already recovered"
         )
         .defineInRange("escapeExitHealth", 20.0, 2.0, 400.0);
      escapeRegenPerSecond = b.comment("Slow natural regeneration while escaping (potion on cooldown)").defineInRange("escapeRegenPerSecond", 1.0, 0.0, 20.0);
      escapeDashCooldownTicks = b.comment("Minimum ticks between escape dashes toward the owner (also limited by stamina)")
         .defineInRange("escapeDashCooldownTicks", 30, 5, 600);
      airJumpFallDistance = b.comment("Fall distance (blocks) at which she does a mid-air high jump + forward dash")
         .defineInRange("airJumpFallDistance", 5.0, 2.0, 40.0);
      airJumpCooldownTicks = b.defineInRange("airJumpCooldownTicks", 100, 10, 1200);
      waterJumpEnabled = b.comment("High jump + dash out of deep water").define("waterJumpEnabled", true);
      maxStamina = b.defineInRange("maxStamina", 120, 20, 1000);
      dashCost = b.defineInRange("dashCost", 20, 1, 1000);
      staminaRegen = b.defineInRange("staminaRegen", 20, 1, 1000);
      staminaRegenTicks = b.defineInRange("staminaRegenTicks", 60, 1, 1200);
      dashTriggerDistance = b.defineInRange("dashTriggerDistance", 4, 1, 16);
      dashDistance = b.defineInRange("dashDistance", 3, 1, 12);
      dashCooldownTicks = b.defineInRange("dashCooldownTicks", 30, 1, 600);
      knockbackChance = b.defineInRange("knockbackChance", 0.5, 0.0, 1.0);
      knockbackCooldownTicks = b.defineInRange("knockbackCooldownTicks", 120, 1, 7200);
      knockbackRadius = b.defineInRange("knockbackRadius", 4, 1, 16);
      knockbackStrength = b.defineInRange("knockbackStrength", 1.2, 0.1, 5.0);
      b.pop();
      SPEC = b.build();
   }
}
