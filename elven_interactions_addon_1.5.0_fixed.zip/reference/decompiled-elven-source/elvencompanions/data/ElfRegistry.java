package com.elvencompanions.data;

import com.elvencompanions.entity.ElfEntity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedData.Factory;

public class ElfRegistry extends SavedData {
   private final Map<UUID, ElfRegistry.Record> records = new LinkedHashMap<>();
   private final Set<UUID> deleted = new HashSet<>();

   public static ElfRegistry get(MinecraftServer server) {
      return (ElfRegistry)server.overworld()
         .getDataStorage()
         .computeIfAbsent(new Factory(ElfRegistry::new, ElfRegistry::load, null), "elven_companions_registry");
   }

   public static ElfRegistry load(CompoundTag tag, Provider provider) {
      ElfRegistry reg = new ElfRegistry();
      ListTag list = tag.getList("Elves", 10);

      for (int i = 0; i < list.size(); i++) {
         ElfRegistry.Record r = ElfRegistry.Record.load(list.getCompound(i));
         reg.records.put(r.id, r);
      }

      for (Tag t : tag.getList("Deleted", 11)) {
         reg.deleted.add(NbtUtils.loadUUID(t));
      }

      return reg;
   }

   public CompoundTag save(CompoundTag tag, Provider provider) {
      ListTag list = new ListTag();

      for (ElfRegistry.Record r : this.records.values()) {
         list.add(r.save());
      }

      tag.put("Elves", list);
      ListTag del = new ListTag();

      for (UUID u : this.deleted) {
         del.add(NbtUtils.createUUID(u));
      }

      tag.put("Deleted", del);
      return tag;
   }

   public ElfRegistry.Record byId(UUID companionId) {
      return this.records.get(companionId);
   }

   public List<ElfRegistry.Record> ownedBy(UUID owner) {
      List<ElfRegistry.Record> out = new ArrayList<>();

      for (ElfRegistry.Record r : this.records.values()) {
         if (r.owner.equals(owner)) {
            out.add(r);
         }
      }

      return out;
   }

   public void update(ElfEntity e) {
      if (e.getOwnerUUID() != null && e.getCompanionId() != null && !this.deleted.contains(e.getCompanionId())) {
         ElfRegistry.Record r = this.records.computeIfAbsent(e.getCompanionId(), k -> new ElfRegistry.Record());
         boolean changed = r.id == null;
         r.id = e.getCompanionId();
         r.owner = e.getOwnerUUID();
         String name = e.getName().getString();
         changed |= !name.equals(r.name);
         r.name = name;
         changed |= r.skin != e.getSkin();
         r.skin = e.getSkin();
         changed |= r.stance != e.getStance();
         r.stance = e.getStance();
         changed |= r.combat != e.getCombat();
         r.combat = e.getCombat();
         changed |= r.pickup != e.isPickup();
         r.pickup = e.isPickup();
         changed |= r.level != e.getElfLevel() || r.transcended != e.isTranscended();
         r.level = e.getElfLevel();
         r.xp = e.getXp();
         r.transcended = e.isTranscended();
         changed |= r.dead;
         r.dead = false;
         changed |= Math.abs(r.health - e.getHealth()) > 0.5F;
         r.health = e.getHealth();
         r.maxHealth = e.getMaxHealth();
         int inv = e.inventory.usedSlots();
         changed |= r.invUsed != inv;
         r.invUsed = inv;
         String dim = e.level().dimension().location().toString();
         changed |= !dim.equals(r.dim);
         r.dim = dim;
         changed |= e.distanceToSqr(r.x, r.y, r.z) > 4.0;
         r.x = e.getX();
         r.y = e.getY();
         r.z = e.getZ();
         if (changed) {
            this.setDirty();
         }
      }
   }

   public boolean isDeleted(UUID companionId) {
      return companionId != null && this.deleted.contains(companionId);
   }

   public boolean delete(UUID companionId) {
      boolean had = this.records.remove(companionId) != null;
      had |= this.deleted.add(companionId);
      this.setDirty();
      return had;
   }

   public void markDead(ElfEntity e) {
      if (!this.isDeleted(e.getCompanionId())) {
         this.update(e);
         ElfRegistry.Record r = this.records.get(e.getCompanionId());
         if (r != null) {
            r.dead = true;
            r.health = 0.0F;
            this.setDirty();
         }
      }
   }

   public void queue(UUID companionId, int action) {
      ElfRegistry.Record r = this.records.get(companionId);
      if (r != null) {
         r.pending.add(action);
         this.setDirty();
      }
   }

   public List<Integer> drainPending(UUID companionId) {
      ElfRegistry.Record r = this.records.get(companionId);
      if (r != null && !r.pending.isEmpty()) {
         List<Integer> copy = new ArrayList<>(r.pending);
         r.pending.clear();
         this.setDirty();
         return copy;
      } else {
         return List.of();
      }
   }

   public static class Record {
      public UUID id;
      public UUID owner;
      public String name = "Elf";
      public int skin;
      public int stance;
      public int combat;
      public int level = 1;
      public int xp;
      public boolean pickup;
      public boolean dead;
      public boolean transcended;
      public float health;
      public float maxHealth;
      public int invUsed;
      public String dim = "";
      public double x;
      public double y;
      public double z;
      public List<Integer> pending = new ArrayList<>();

      CompoundTag save() {
         CompoundTag t = new CompoundTag();
         t.putUUID("Id", this.id);
         t.putUUID("Owner", this.owner);
         t.putString("Name", this.name);
         t.putInt("Skin", this.skin);
         t.putInt("Stance", this.stance);
         t.putInt("Combat", this.combat);
         t.putBoolean("Pickup", this.pickup);
         t.putBoolean("Dead", this.dead);
         t.putFloat("Health", this.health);
         t.putFloat("MaxHealth", this.maxHealth);
         t.putInt("Inv", this.invUsed);
         t.putInt("Level", this.level);
         t.putInt("Xp", this.xp);
         t.putBoolean("Transcended", this.transcended);
         t.putString("Dim", this.dim);
         t.putDouble("X", this.x);
         t.putDouble("Y", this.y);
         t.putDouble("Z", this.z);
         t.putIntArray("Pending", this.pending);
         return t;
      }

      static ElfRegistry.Record load(CompoundTag t) {
         ElfRegistry.Record r = new ElfRegistry.Record();
         r.id = t.getUUID("Id");
         r.owner = t.getUUID("Owner");
         r.name = t.getString("Name");
         r.skin = t.getInt("Skin");
         r.stance = t.getInt("Stance");
         r.combat = t.getInt("Combat");
         r.pickup = t.getBoolean("Pickup");
         r.dead = t.getBoolean("Dead");
         r.health = t.getFloat("Health");
         r.maxHealth = t.getFloat("MaxHealth");
         r.invUsed = t.getInt("Inv");
         r.level = t.contains("Level") ? t.getInt("Level") : 1;
         r.xp = t.getInt("Xp");
         r.transcended = t.getBoolean("Transcended");
         r.dim = t.getString("Dim");
         r.x = t.getDouble("X");
         r.y = t.getDouble("Y");
         r.z = t.getDouble("Z");

         for (int v : t.getIntArray("Pending")) {
            r.pending.add(v);
         }

         return r;
      }
   }
}
