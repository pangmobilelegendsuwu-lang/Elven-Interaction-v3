package com.elvencompanions.data;

import com.elvencompanions.entity.ElfEntity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.EntityLeaveLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

@EventBusSubscriber(
   modid = "elven_companions"
)
public final class ElfManager {
   public static final Map<UUID, ElfEntity> LOADED = new HashMap<>();

   @SubscribeEvent
   public static void onJoin(EntityJoinLevelEvent event) {
      if (event.getLevel() instanceof ServerLevel level && event.getEntity() instanceof ElfEntity elf) {
         elf.onServerJoin(level);
         LOADED.put(elf.getCompanionId(), elf);
      }
   }

   @SubscribeEvent
   public static void onLeave(EntityLeaveLevelEvent event) {
      if (!event.getLevel().isClientSide() && event.getEntity() instanceof ElfEntity elf && elf.getCompanionId() != null) {
         LOADED.remove(elf.getCompanionId(), elf);
         if (elf.isCarried()) {
            ElfEntity.reindexCarried(elf.getOwnerUUID());
         }
      }
   }

   @SubscribeEvent
   public static void onDeath(LivingDeathEvent event) {
      LivingEntity victim = event.getEntity();
      if (!victim.level().isClientSide() && victim instanceof Enemy && !(victim instanceof ElfEntity)) {
         if (event.getSource().getEntity() instanceof Player killer) {
            for (ElfEntity elf : LOADED.values()) {
               if (elf.isAlive() && elf.isOwnedBy(killer) && elf.level() == victim.level() && elf.distanceToSqr(victim) < 4096.0) {
                  elf.onAssist(victim);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public static void onStopped(ServerStoppedEvent event) {
      LOADED.clear();
   }

   private ElfManager() {
   }
}
