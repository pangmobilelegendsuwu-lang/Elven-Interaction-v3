package com.elvencompanions.item;

import com.elvencompanions.net.SkillWandManager;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.level.Level;

public class SkillWandItem extends Item {
   public SkillWandItem(Properties props) {
      super(props);
   }

   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      if (player instanceof ServerPlayer sp && !sp.getCooldowns().isOnCooldown(this)) {
         sp.getCooldowns().addCooldown(this, 6);
         SkillWandManager.onWandUse(sp);
      }

      return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
   }

   public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
      tooltip.add(Component.translatable("tooltip.elven_companions.skill_wand").withStyle(ChatFormatting.GRAY));
      tooltip.add(Component.translatable("tooltip.elven_companions.skill_wand2").withStyle(ChatFormatting.DARK_GRAY));
   }
}
