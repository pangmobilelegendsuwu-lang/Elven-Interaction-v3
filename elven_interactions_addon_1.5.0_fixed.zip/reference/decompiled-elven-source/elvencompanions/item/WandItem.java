package com.elvencompanions.item;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.net.ElfStatus;
import com.elvencompanions.net.ModNetwork;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.network.PacketDistributor;

public class WandItem extends Item {
   private static final double LOOK_RANGE = 24.0;

   public WandItem(Properties var1) {
      super(var1);
   }

   public InteractionResultHolder<ItemStack> use(Level var1, Player var2, InteractionHand var3) {
      ItemStack var4 = var2.getItemInHand(var3);
      if (var2 instanceof ServerPlayer var5) {
         ElfEntity var6 = lookedAtElf(var5);
         if (var6 == null) {
            ModNetwork.sendRoster(var5);
         } else if (var6.skills.isUltimate()) {
            var5.displayClientMessage(Component.translatable("message.elven_companions.ult_locked", new Object[]{var6.getName()}), true);
            ModNetwork.sendRoster(var5);
         } else {
            PacketDistributor.sendToPlayer(var5, new ModNetwork.StatusS2C(ElfStatus.of(var6), true), new CustomPacketPayload[0]);
         }
      }

      return InteractionResultHolder.sidedSuccess(var4, var1.isClientSide);
   }

   private static ElfEntity lookedAtElf(ServerPlayer var0) {
      ServerLevel var1 = var0.serverLevel();
      Vec3 var2 = var0.getEyePosition();
      Vec3 var3 = var0.getLookAngle();
      Vec3 var4 = var2.add(var3.x * 24.0, var3.y * 24.0, var3.z * 24.0);
      BlockHitResult var5 = var1.clip(new ClipContext(var2, var4, Block.COLLIDER, Fluid.NONE, var0));
      double var6 = var5.getType() == Type.MISS ? 24.0 : var5.getLocation().distanceTo(var2);
      ElfEntity var8 = null;
      double var9 = var6 + 0.5;

      for (ElfEntity var12 : var1.getEntitiesOfClass(ElfEntity.class, new AABB(var2, var4).inflate(2.0), var0x -> true)) {
         if (var12.isAlive() && var12.isOwnedBy(var0)) {
            AABB var13 = var12.getBoundingBox().inflate(0.3);
            double var14;
            if (var13.contains(var2)) {
               var14 = 0.0;
            } else {
               Optional var16 = var13.clip(var2, var4);
               if (var16.isEmpty()) {
                  continue;
               }

               var14 = ((Vec3)var16.get()).distanceTo(var2);
            }

            if (var14 < var9) {
               var9 = var14;
               var8 = var12;
            }
         }
      }

      return var8;
   }

   public void appendHoverText(ItemStack var1, TooltipContext var2, List<Component> var3, TooltipFlag var4) {
      var3.add(Component.translatable("tooltip.elven_companions.wand").withStyle(ChatFormatting.GRAY));
   }
}
