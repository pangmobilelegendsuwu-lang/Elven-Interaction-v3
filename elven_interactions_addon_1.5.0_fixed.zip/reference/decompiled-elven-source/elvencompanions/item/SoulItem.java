package com.elvencompanions.item;

import com.elvencompanions.ModRegistry;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.ItemLike;

public class SoulItem extends Item {
   public SoulItem(Properties props) {
      super(props);
   }

   public static ItemStack create(CompoundTag elfData) {
      ItemStack stack = new ItemStack((ItemLike)ModRegistry.SOUL.get());
      CompoundTag root = new CompoundTag();
      root.put("Elf", elfData);
      stack.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
      return stack;
   }

   public static CompoundTag read(ItemStack stack) {
      CustomData cd = (CustomData)stack.get(DataComponents.CUSTOM_DATA);
      if (cd == null) {
         return null;
      } else {
         CompoundTag root = cd.copyTag();
         return root.contains("Elf") && root.getCompound("Elf").hasUUID("CompanionId") ? root.getCompound("Elf") : null;
      }
   }

   public boolean isFoil(ItemStack stack) {
      return true;
   }

   public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
      CompoundTag data = read(stack);
      if (data == null) {
         tooltip.add(Component.translatable("tooltip.elven_companions.soul_empty").withStyle(ChatFormatting.DARK_GRAY));
      } else {
         String name = data.contains("NameText") ? data.getString("NameText") : "Elf";
         tooltip.add(Component.translatable("tooltip.elven_companions.soul", new Object[]{name}).withStyle(ChatFormatting.AQUA));
         tooltip.add(Component.translatable("tooltip.elven_companions.soul_hint").withStyle(ChatFormatting.GRAY));
      }
   }
}
