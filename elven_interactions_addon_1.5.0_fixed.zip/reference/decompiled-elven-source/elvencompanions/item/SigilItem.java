package com.elvencompanions.item;

import com.elvencompanions.entity.ElfEntity;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.level.Level;

public class SigilItem extends Item {
   public SigilItem(Properties props) {
      super(props);
   }

   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      if (level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
         ElfEntity elf = ElfEntity.summon(sl, sp);
         if (elf == null) {
            sp.displayClientMessage(Component.translatable("message.elven_companions.summon_failed"), true);
            return InteractionResultHolder.fail(stack);
         } else {
            stack.consume(1, player);
            return InteractionResultHolder.sidedSuccess(stack, false);
         }
      } else {
         return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
      }
   }

   public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
      tooltip.add(Component.translatable("tooltip.elven_companions.sigil").withStyle(ChatFormatting.GRAY));
   }
}
