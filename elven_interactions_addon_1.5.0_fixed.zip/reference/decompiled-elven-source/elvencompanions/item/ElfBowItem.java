package com.elvencompanions.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;

public class ElfBowItem extends Item {
   public ElfBowItem(Properties props) {
      super(props);
   }

   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
