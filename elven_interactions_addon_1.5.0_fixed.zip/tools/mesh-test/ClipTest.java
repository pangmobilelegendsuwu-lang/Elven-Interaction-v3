import com.elvencompanions.interactions.*;
import com.elvencompanions.interactions.Clip.Ch;
public class ClipTest {
    static int fails = 0;
    static void ok(String n, boolean c, String x) { System.out.printf("%-58s %s %s%n", n, c ? "ok" : "FAIL", x); if (!c) fails++; }
    public static void main(String[] a) {
        for (InteractionType t : InteractionType.values())
            System.out.printf("%-11s dist=%.2f playerActs=%-5s player=%3d elf=%3d delay=%2d total=%3d%n", t, t.distance, t.playerActs(), t.player.duration, t.elf.duration, t.elfDelay, t.duration());
        ok("BOW is elf-only", !InteractionType.BOW.playerActs(), "");
        ok("every other interaction has a player animation", java.util.Arrays.stream(InteractionType.values()).filter(t -> t != InteractionType.BOW).allMatch(InteractionType::playerActs), "");
        ok("BOW is farther than every other interaction", java.util.Arrays.stream(InteractionType.values()).filter(t -> t != InteractionType.BOW).allMatch(t -> InteractionType.BOW.distance > t.distance), "");
        ok("all non-bow distances are closer than before (<=1.25)", java.util.Arrays.stream(InteractionType.values()).filter(t -> t != InteractionType.BOW).allMatch(t -> t.distance <= 1.25f), "");
        // head pat: elf head pitch (vanilla convention, + = DOWN) must be positive during the pat
        float mid = InteractionType.HEAD_PAT.elf.duration / 2f;
        float hp = InteractionType.HEAD_PAT.elf.sample(Ch.HEAD_PITCH, mid);
        ok("head pat: elf bows head DOWN (vanilla pitch > 0)", hp > 0.3f, "(" + hp + ")");
        // hug: arms almost level, strongly inward, both sides mirrored
        Clip hp1 = InteractionType.HUG.player, he = InteractionType.HUG.elf;
        float pm = hp1.duration / 2f, em = he.duration / 2f;
        ok("hug: player arms ~level", hp1.sample(Ch.R_ARM_PITCH, pm) < -1.3f && hp1.sample(Ch.L_ARM_PITCH, pm) < -1.3f, "(" + hp1.sample(Ch.R_ARM_PITCH, pm) + ")");
        ok("hug: player arms inward and mirrored", hp1.sample(Ch.R_ARM_YAW, pm) < -0.6f && hp1.sample(Ch.L_ARM_YAW, pm) > 0.6f, "");
        ok("hug: elf arms ~level + inward", he.sample(Ch.R_ARM_PITCH, em) < -1.2f && he.sample(Ch.R_ARM_YAW, em) < -0.7f && he.sample(Ch.L_ARM_YAW, em) > 0.7f, "");
        ok("hug: heads turned (cheek to cheek)", hp1.sample(Ch.HEAD_YAW, pm) > 0.3f && he.sample(Ch.HEAD_YAW, em) > 0.3f, "");
        ok("hug: closer than before (0.5)", InteractionType.HUG.distance <= 0.5f, "");
        // every clip returns to neutral at the end, and is finite throughout
        boolean fine = true;
        for (InteractionType t : InteractionType.values()) for (Clip c : new Clip[]{t.player, t.elf}) for (Ch ch : Ch.values()) if (c.has(ch)) {
            float end = c.sample(ch, c.duration);
            if (Float.isNaN(end) || Math.abs(end) > 1e-4) fine = false;
            for (float x = 0; x <= c.duration; x += 1f) if (Float.isNaN(c.sample(ch, x)) || Math.abs(c.sample(ch, x)) > 4f) fine = false;
        }
        ok("all clips finite, bounded and return to neutral", fine, "");
        System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
}
