Offline tests for the touch geometry, run against the real elf OBJ. No Minecraft needed, only a JDK 21. From this folder:

1) Zone raycast (which body part a ray hits; rotated elves, left/right, hand/arm, knee/leg, reach, from behind):
   mkdir out && javac -d out -sourcepath stubs ../../src/main/java/com/elvencompanions/interactions/ElfMesh.java \
       ../../src/main/java/com/elvencompanions/interactions/TouchZone.java Test.java && java -cp out Test

2) Joint mesh (elbow/knee split + caps + rotation: area conserved, no holes, winding, rotation direction):
   mkdir jout && javac -d jout ../../src/main/java/com/elvencompanions/interactions/JointMesh.java JointTest.java && java -cp jout JointTest

Each prints one line per check and ALL PASSED or the failures.

3) Interaction clips (distances, elf-only bow, head-pat direction, hug geometry, clips finite and returning to neutral):
   mkdir cout && javac -d cout ../../src/main/java/com/elvencompanions/interactions/Clip.java \
       ../../src/main/java/com/elvencompanions/interactions/InteractionType.java ClipTest.java && java -cp cout ClipTest
