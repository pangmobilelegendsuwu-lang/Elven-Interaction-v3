import com.elvencompanions.interactions.*;
import java.io.*;
public class Test {
    static int fails = 0;
    static void check(String name, TouchZone.Hit h, TouchZone z, Boolean left) {
        boolean ok = (z == null) ? h == null : (h != null && h.zone() == z && (left == null || h.left() == left));
        System.out.printf("%-34s -> %-22s %s%n", name, h == null ? "MISS" : h.zone() + (h.zone()==TouchZone.ARM||h.zone()==TouchZone.HAND||h.zone()==TouchZone.LEG ? (h.left()?"/L":"/R") : ""), ok ? "ok" : "FAIL (expected " + z + (left!=null?"/"+(left?"L":"R"):"") + ")");
        if (!ok) fails++;
    }
    // shoot from eye to target (world), elf at (0,0,0) with yaw
    static TouchZone.Hit shoot(float yaw, double[] eye, double[] tgt, double reach) {
        return ElfMesh.raycast(0, 0, 0, yaw, eye[0], eye[1], eye[2], tgt[0]-eye[0], tgt[1]-eye[1], tgt[2]-eye[2], reach);
    }
    public static void main(String[] a) throws Exception {
        java.lang.reflect.Method load = ElfMesh.class.getDeclaredMethod("load", InputStream.class);
        load.setAccessible(true);
        try (InputStream in = new FileInputStream("elf.obj")) { load.invoke(null, in); }
        System.out.println("available=" + ElfMesh.available());
        double[] eyeS = {0, 1.62, 1.6};      // in front of an elf facing +Z (yaw 0)
        check("face (chin/eye level)", shoot(0, eyeS, new double[]{0, 1.5, 0}, 3.2), TouchZone.FACE, null);
        check("head top / hair", shoot(0, eyeS, new double[]{0, 1.75, 0}, 3.2), TouchZone.HEAD, null);
        check("face but far off-centre -> head", shoot(0, eyeS, new double[]{0.2, 1.5, 0}, 3.2), TouchZone.HEAD, null);
        check("torso", shoot(0, eyeS, new double[]{0, 1.2, 0}, 3.2), TouchZone.TORSO, null);
        check("elf RIGHT arm (world -x)", shoot(0, eyeS, new double[]{-0.43, 1.1, 0}, 3.2), TouchZone.ARM, false);
        check("elf LEFT arm  (world +x)", shoot(0, eyeS, new double[]{0.43, 1.1, 0}, 3.2), TouchZone.ARM, true);
        check("inner arm from front = torso (chest cover)", shoot(0, eyeS, new double[]{-0.30, 1.2, 0}, 3.2), TouchZone.TORSO, null);
        check("right hand (lower arm)", shoot(0, eyeS, new double[]{-0.43, 0.85, 0}, 3.2), TouchZone.HAND, false);
        check("left hand", shoot(0, eyeS, new double[]{0.43, 0.85, 0}, 3.2), TouchZone.HAND, true);
        check("right leg (thigh, above the knee)", shoot(0, eyeS, new double[]{-0.1, 0.40, 0}, 3.2), TouchZone.LEG, false);
        check("left leg (thigh, above the knee)", shoot(0, eyeS, new double[]{0.1, 0.40, 0}, 3.2), TouchZone.LEG, true);
        check("steep look at the thigh passes through the hips = torso", shoot(0, eyeS, new double[]{-0.1, 0.5, 0}, 3.2), TouchZone.TORSO, null);
        check("right knee / lower leg", shoot(0, eyeS, new double[]{-0.1, 0.2, 0}, 3.2), TouchZone.KNEE, false);
        check("left knee / lower leg", shoot(0, eyeS, new double[]{0.1, 0.2, 0}, 3.2), TouchZone.KNEE, true);
        check("yaw90 left knee", shoot(90, new double[]{-1.6, 1.62, 0}, new double[]{0, 0.2, 0.1}, 3.2), TouchZone.KNEE, true);
        check("miss (beside elf)", shoot(0, eyeS, new double[]{1.5, 1.0, 0}, 3.2), null, null);
        // from behind: never FACE
        check("head from behind", shoot(0, new double[]{0,1.62,-1.6}, new double[]{0,1.5,0}, 3.2), TouchZone.HEAD, null);
        // rotated elf: yaw 90 faces -x; player stands at -x
        double[] eyeW = {-1.6, 1.62, 0};
        check("yaw90 face", shoot(90, eyeW, new double[]{0, 1.5, 0}, 3.2), TouchZone.FACE, null);
        check("yaw90 elf RIGHT arm (world -z)", shoot(90, eyeW, new double[]{0, 1.1, -0.43}, 3.2), TouchZone.ARM, false);
        check("yaw90 elf LEFT arm (world +z)", shoot(90, eyeW, new double[]{0, 1.1, 0.43}, 3.2), TouchZone.ARM, true);
        // arbitrary yaw 37: player stands 1.5 in front along the elf's forward
        double yw = Math.toRadians(37); double[] f = {-Math.sin(yw), Math.cos(yw)};
        double[] eye37 = {f[0]*1.5, 1.62, f[1]*1.5};
        check("yaw37 face", shoot(37, eye37, new double[]{0, 1.5, 0}, 3.2), TouchZone.FACE, null);
        check("yaw37 torso", shoot(37, eye37, new double[]{0, 1.2, 0}, 3.2), TouchZone.TORSO, null);
        // reach limit
        check("out of reach", shoot(0, new double[]{0,1.62,5}, new double[]{0,1.5,0}, 3.2), null, null);
        check("within long reach", shoot(0, new double[]{0,1.62,5}, new double[]{0,1.5,0}, 6.0), TouchZone.FACE, null);
        // ray from above hits the head top
        check("from above onto head", shoot(0, new double[]{0,3.0,1.0}, new double[]{0,1.8,0}, 3.2), TouchZone.HEAD, null);
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
