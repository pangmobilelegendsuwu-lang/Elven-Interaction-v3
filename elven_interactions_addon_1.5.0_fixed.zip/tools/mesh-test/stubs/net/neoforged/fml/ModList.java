package net.neoforged.fml;
import java.util.Optional;
public class ModList {
  public static ModList get(){ return new ModList(); }
  public Optional<C> getModContainerById(String id){ return Optional.empty(); }
  public static class C { public Info getModInfo(){return null;} }
  public static class Info { public FI getOwningFile(){return null;} }
  public static class FI { public F getFile(){return null;} }
  public static class F { public java.nio.file.Path findResource(String... parts){return null;} }
}
