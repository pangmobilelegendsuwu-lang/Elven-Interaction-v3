package com.elvencompanions.interactions;
public final class ElvenInteractions { public static final L LOGGER = new L(); public static final class L { public void warn(String s,Object o){System.out.println("WARN "+s.replace("{}",String.valueOf(o)));} } }
