package com.elvencompanions.interactions;
public final class Cfg { public static final Common COMMON = new Common(); public static final class Common { public final V drainScale=new V(), gainScale=new V(); } public static final class V { public Double get(){return 1.0;} } }
