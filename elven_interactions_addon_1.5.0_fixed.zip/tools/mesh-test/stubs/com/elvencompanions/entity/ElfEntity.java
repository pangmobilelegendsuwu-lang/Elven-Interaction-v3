package com.elvencompanions.entity;
public class ElfEntity { public float yBodyRot; public double getX(){return 0;} public double getY(){return 0;} public double getZ(){return 0;} public float getBbHeight(){return 1.9f;} public float getBbWidth(){return 0.6f;} }
