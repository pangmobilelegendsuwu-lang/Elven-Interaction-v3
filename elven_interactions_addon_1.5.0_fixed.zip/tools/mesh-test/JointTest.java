import com.elvencompanions.interactions.JointMesh;
import java.io.*;
import java.util.*;

public class JointTest {
    static int fails = 0;
    static void ok(String n, boolean c, String extra) { System.out.printf("%-52s %s %s%n", n, c ? "ok" : "FAIL", extra); if (!c) fails++; }

    // replicate ElfObjModel's quad assembly (positions, uv, normals) for a named object
    static Map<String, float[]> load(String path) throws Exception {
        List<float[]> v = new ArrayList<>(), vt = new ArrayList<>(), vn = new ArrayList<>();
        Map<String, List<int[][]>> faces = new LinkedHashMap<>(); String cur = null;
        for (String line : java.nio.file.Files.readAllLines(java.nio.file.Path.of(path))) {
            line = line.trim(); if (line.isEmpty() || line.startsWith("#")) continue;
            String[] p = line.split("\\s+");
            switch (p[0]) {
                case "v" -> v.add(new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3])});
                case "vt" -> vt.add(new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2])});
                case "vn" -> vn.add(new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3])});
                case "o", "g" -> { cur = line.substring(p[0].length()).trim(); faces.put(cur, new ArrayList<>()); }
                case "f" -> { int[][] f = new int[p.length - 1][3]; for (int i = 1; i < p.length; i++) { String[] a = p[i].split("/", -1); f[i-1][0] = Integer.parseInt(a[0]) - 1; f[i-1][1] = a.length > 1 && !a[1].isEmpty() ? Integer.parseInt(a[1]) - 1 : -1; f[i-1][2] = a.length > 2 && !a[2].isEmpty() ? Integer.parseInt(a[2]) - 1 : -1; } faces.get(cur).add(f); }
                default -> {}
            }
        }
        Map<String, float[]> out = new LinkedHashMap<>();
        for (var e : faces.entrySet()) {
            List<Float> d = new ArrayList<>();
            for (int[][] face : e.getValue()) {
                int[][] q = face.length == 3 ? new int[][]{face[0], face[1], face[2], face[2]} : face; // box faces are quads
                float[] a = v.get(q[0][0]), b = v.get(q[1][0]), c = v.get(q[2][0]);
                float[] n0 = norm(cross(sub(b,a), sub(c,a)));
                for (int[] c4 : q) { float[] pos = v.get(c4[0]); float[] uv = c4[1] >= 0 ? vt.get(c4[1]) : new float[]{0,0}; float[] nr = c4[2] >= 0 ? vn.get(c4[2]) : n0;
                    d.add(pos[0]); d.add(pos[1]); d.add(pos[2]); d.add(uv[0]); d.add(1f - uv[1]); d.add(nr[0]); d.add(nr[1]); d.add(nr[2]); }
            }
            float[] arr = new float[d.size()]; for (int i = 0; i < arr.length; i++) arr[i] = d.get(i);
            out.put(e.getKey(), arr);
        }
        return out;
    }
    static float[] sub(float[] a, float[] b) { return new float[]{a[0]-b[0], a[1]-b[1], a[2]-b[2]}; }
    static float[] cross(float[] a, float[] b) { return new float[]{a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]}; }
    static float[] norm(float[] a) { float l = (float) Math.sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]); return l < 1e-9 ? new float[]{0,1,0} : new float[]{a[0]/l,a[1]/l,a[2]/l}; }

    // total surface area of quads (each as two triangles 0,1,2 and 0,2,3)
    static double area(float[] q) {
        double s = 0; int V = 8;
        for (int i = 0; i + 32 <= q.length; i += 32) {
            float[] p0 = {q[i],q[i+1],q[i+2]}, p1 = {q[i+V],q[i+V+1],q[i+V+2]}, p2 = {q[i+2*V],q[i+2*V+1],q[i+2*V+2]}, p3 = {q[i+3*V],q[i+3*V+1],q[i+3*V+2]};
            s += 0.5 * len(cross(sub(p1,p0), sub(p2,p0))) + 0.5 * len(cross(sub(p2,p0), sub(p3,p0)));
        }
        return s;
    }
    static double len(float[] a) { return Math.sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]); }
    static boolean finite(float[] a) { for (float f : a) if (Float.isNaN(f) || Float.isInfinite(f)) return false; return true; }
    // winding check: every quad's geometric normal must agree with its stored normal
    static int badWinding(float[] q) {
        int bad = 0; int V = 8;
        for (int i = 0; i + 32 <= q.length; i += 32) {
            float[] p0 = {q[i],q[i+1],q[i+2]}, p1 = {q[i+V],q[i+V+1],q[i+V+2]}, p2 = {q[i+2*V],q[i+2*V+1],q[i+2*V+2]};
            float[] c = cross(sub(p1,p0), sub(p2,p0));
            float d = c[0]*q[i+5] + c[1]*q[i+6] + c[2]*q[i+7];
            if (len(c) > 1e-9 && d <= 0) bad++;
        }
        return bad;
    }

    public static void main(String[] a) throws Exception {
        Map<String, float[]> parts = load("elf.obj");
        float armY = 1.125f, legY = 0.375f;
        for (String name : new String[]{"left arm", "right arm", "left leg", "right leg"}) {
            float plane = name.contains("arm") ? armY : legY;
            float[] data = parts.get(name);
            ok(name + ": source winding consistent", badWinding(data) == 0, "(bad=" + badWinding(data) + ")");
            JointMesh.Split s = JointMesh.split(data, plane);
            double a0 = area(data), a1 = area(s.upper) + area(s.lower);
            ok(name + ": split keeps surface area (no holes)", Math.abs(a0 - a1) < 1e-4, String.format("(%.5f vs %.5f)", a0, a1));
            ok(name + ": both halves non-empty", s.upper.length > 0 && s.lower.length > 0, "(up=" + s.upper.length/32 + " low=" + s.lower.length/32 + " quads)");
            ok(name + ": caps generated", s.capUpper.length > 0 && s.capLower.length > 0, "(" + s.capUpper.length/32 + "+" + s.capLower.length/32 + " quads)");
            ok(name + ": split windings consistent", badWinding(s.upper) == 0 && badWinding(s.lower) == 0, "");
            ok(name + ": caps wound outward (down/up)", badWinding(s.capUpper) == 0 && badWinding(s.capLower) == 0, "");
            ok(name + ": all vertices on the right side", minY(s.upper) >= plane - 1e-4 && maxY(s.lower) <= plane + 1e-4, "");
            // caps lie on the plane and span the box cross-section (0.25 x 0.25)
            double capArea = area(s.capUpper);
            ok(name + ": cap area == cross-section (0.0625)", Math.abs(capArea - 0.0625) < 1e-4, String.format("(%.5f)", capArea));
            // rotation sanity: 90 deg about the elbow swings the lowest FRONT-edge vertex forward (-z)
            float[] rot = JointMesh.rotateAboutX(s.lower, plane, 0f, (float) (Math.PI / 2));
            ok(name + ": rotated mesh is finite", finite(rot), "");
            double dz = minZ(rot) - minZ(s.lower);
            ok(name + ": +90deg swings the lower half toward -Z (front)", minZ(rot) < -(plane - minY(s.lower)) + 0.2, String.format("(min z %.3f -> %.3f)", minZ(s.lower), minZ(rot)));
            // identity at 0 rad
            float[] id = JointMesh.rotateAboutX(s.lower, plane, 0f, 0f);
            ok(name + ": 0 rad is the identity", Arrays.equals(id, s.lower), "");
            // rigid: rotation preserves lower surface area
            ok(name + ": rotation is rigid (area preserved)", Math.abs(area(rot) - area(s.lower)) < 1e-4, "");
            // rotated normals stay unit length and windings stay consistent
            ok(name + ": rotated winding still consistent", badWinding(rot) == 0, "");
        }
        // a part that does NOT cross the plane stays whole on one side
        for (var e : parts.entrySet()) {
            JointMesh.Split s = JointMesh.split(e.getValue(), armY);
            boolean allOne = (s.upper.length == 0) != (s.lower.length == 0);
            boolean crosses = minY(e.getValue()) < armY - 1e-5 && maxY(e.getValue()) > armY + 1e-5;
            if (!crosses) ok("part '" + e.getKey() + "' not crossing: one side only", allOne || (s.upper.length + s.lower.length) == 0, "");
            if (maxY(e.getValue()) <= armY + 1e-5) ok("part '" + e.getKey() + "' entirely at/below plane -> all lower", s.upper.length == 0, "");
        }
        // every part of the whole model splits without NaN and with consistent winding at both joint heights
        boolean allFine = true;
        for (var e : parts.entrySet()) for (float plane : new float[]{armY, legY}) {
            JointMesh.Split s = JointMesh.split(e.getValue(), plane);
            allFine &= finite(s.upper) && finite(s.lower) && finite(s.capUpper) && finite(s.capLower) && badWinding(s.upper) == 0 && badWinding(s.lower) == 0
                    && badWinding(s.capUpper) == 0 && badWinding(s.capLower) == 0;
        }
        ok("all " + parts.size() + " parts split cleanly at both joints", allFine, "");
        System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
    static float minY(float[] q) { float m = Float.MAX_VALUE; for (int i = 1; i < q.length; i += 8) m = Math.min(m, q[i]); return m; }
    static float maxY(float[] q) { float m = -Float.MAX_VALUE; for (int i = 1; i < q.length; i += 8) m = Math.max(m, q[i]); return m; }
    static float minZ(float[] q) { float m = Float.MAX_VALUE; for (int i = 2; i < q.length; i += 8) m = Math.min(m, q[i]); return m; }
}
