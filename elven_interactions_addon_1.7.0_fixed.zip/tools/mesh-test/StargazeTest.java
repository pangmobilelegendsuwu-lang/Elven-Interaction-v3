import com.elvencompanions.interactions.StargazeMath;
public class StargazeTest {
    static int fails = 0;
    static void ok(String n, boolean c) { System.out.printf("%-66s %s%n", n, c ? "ok" : "FAIL"); if (!c) fails++; }
    public static void main(String[] a) {
        // default window 12000..23000 (sunset .. just before sunrise)
        ok("11999 is day (blocked)", !StargazeMath.inWindow(11999, 12000, 23000));
        ok("12000 sunset allowed", StargazeMath.inWindow(12000, 12000, 23000));
        ok("18000 midnight allowed", StargazeMath.inWindow(18000, 12000, 23000));
        ok("23000 allowed", StargazeMath.inWindow(23000, 12000, 23000));
        ok("23001 blocked", !StargazeMath.inWindow(23001, 12000, 23000));
        ok("0 (sunrise) blocked", !StargazeMath.inWindow(0, 12000, 23000));
        ok("day time beyond 24000 wraps (36000 = 12000)", StargazeMath.inWindow(36000, 12000, 23000));
        ok("dayTime 24000*5+13000 allowed", StargazeMath.inWindow(24000L * 5 + 13000, 12000, 23000));
        ok("negative time handled", !StargazeMath.inWindow(-1000, 12000, 23000) == !StargazeMath.inWindow(23000, 12000, 23000));
        // wrapping window 22000..2000
        ok("wrap: 23000 in", StargazeMath.inWindow(23000, 22000, 2000));
        ok("wrap: 1000 in", StargazeMath.inWindow(1000, 22000, 2000));
        ok("wrap: 3000 out", !StargazeMath.inWindow(3000, 22000, 2000));
        ok("wrap: 12000 out", !StargazeMath.inWindow(12000, 22000, 2000));
        // sides (Minecraft: yaw 0 faces +Z, 90 faces -X, 180 faces -Z, 270 faces +X)
        ok("yaw 0 (facing +Z): point at -X is on the RIGHT", StargazeMath.sideOf(-1, 0, 0) == 1);
        ok("yaw 0: point at +X is on the LEFT", StargazeMath.sideOf(1, 0, 0) == -1);
        ok("yaw 0: straight ahead is 0", StargazeMath.sideOf(0, 1, 0) == 0);
        ok("yaw 90 (facing -X): -Z is on the right (north)", StargazeMath.sideOf(0, -1, 90) == 1);
        ok("yaw 180 (facing -Z): +X is on the right (east)", StargazeMath.sideOf(1, 0, 180) == 1);
        ok("yaw 270 (facing +X): +Z is on the right (south)", StargazeMath.sideOf(0, 1, 270) == 1);
        // player seated 0.8 to the elf's RIGHT: elf is then on the player's LEFT; mirrored for the other side
        for (float yaw : new float[]{0, 90, 180, 270, 37, 211}) {
            double rx = StargazeMath.rightX(yaw), rz = StargazeMath.rightZ(yaw);
            double px = rx * 0.8, pz = rz * 0.8;                 // player seat on the elf's right (elf at origin)
            boolean e1 = StargazeMath.sideOf(0 - px, 0 - pz, yaw) == -1;
            double qx = -rx * 0.8, qz = -rz * 0.8;               // player seat on the elf's left
            boolean e2 = StargazeMath.sideOf(0 - qx, 0 - qz, yaw) == 1;
            ok("yaw " + yaw + ": elf is on the opposite side of the player's seat side", e1 && e2);
            // and the player, seen from the elf, is on the matching side (used for her head turn = -side)
            ok("yaw " + yaw + ": head-turn sides are mirror images", StargazeMath.sideOf(px, pz, yaw) == -StargazeMath.sideOf(-px, -pz, yaw));
        }
        // seat entity height: rider hips on the surface
        ok("seat stand Y = surface - standHeight + offset", Math.abs(StargazeMath.seatStandY(1.0, 0.9875, 0.0) - 0.0125) < 1e-9
                && Math.abs(StargazeMath.seatStandY(65.5, 0.9875, 0.1) - 64.6125) < 1e-9);
        ok("script length 60 -> 105 ticks (settle 15 + gaze 60 + sky turn 30)", StargazeMath.scriptLength(60) == 105);
        ok("gaze 0 allowed, negative clamps", StargazeMath.scriptLength(0) == 45 && StargazeMath.scriptLength(-5) == 45);
        ok("smooth clamps and is monotonic", StargazeMath.smooth(-1) == 0f && StargazeMath.smooth(2) == 1f && Math.abs(StargazeMath.smooth(0.5f) - 0.5f) < 1e-6
                && StargazeMath.smooth(0.25f) < StargazeMath.smooth(0.75f));

        // ---- lead by the hand: she walks beside you on the side of the hand you hold
        for (float yaw : new float[]{0, 90, 180, 270, 37, 211}) {
            double[] holdHerLeft = StargazeMath.leadOffset(yaw, true, 0.9, 0.2);
            double[] holdHerRight = StargazeMath.leadOffset(yaw, false, 0.9, 0.2);
            ok("yaw " + yaw + ": her LEFT hand held -> she is on your RIGHT", StargazeMath.sideOf(holdHerLeft[0], holdHerLeft[1], yaw) == 1);
            ok("yaw " + yaw + ": her RIGHT hand held -> she is on your LEFT", StargazeMath.sideOf(holdHerRight[0], holdHerRight[1], yaw) == -1);
            double fx = -Math.sin(Math.toRadians(yaw)), fz = Math.cos(Math.toRadians(yaw));
            ok("yaw " + yaw + ": she is slightly BEHIND you and 0.9 to the side", holdHerLeft[0] * fx + holdHerLeft[1] * fz < -0.15
                    && Math.abs(Math.hypot(holdHerLeft[0], holdHerLeft[1]) - Math.hypot(0.9, 0.2)) < 1e-9);
        }
        // ---- kiss approach controller: direction
        double[] i1 = StargazeMath.approachImpulse(0, 1, 1.0, 0.5, 0);   // elf straight ahead (+Z), too far -> walk forward
        ok("elf ahead and too far -> forward input, no sideways", i1[0] > 0.3 && Math.abs(i1[1]) < 1e-9);
        double[] i2 = StargazeMath.approachImpulse(1, 0, 1.0, 0.5, 0);   // elf at +X while facing +Z = on the left
        ok("elf on the left and too far -> strafe left", i2[1] > 0.3 && Math.abs(i2[0]) < 1e-9);
        double[] i3 = StargazeMath.approachImpulse(0, 1, 0.3, 0.5, 0);   // too close -> back away
        ok("too close -> backs away", i3[0] < 0);
        double[] i4 = StargazeMath.approachImpulse(0, 1, 5.0, 0.5, 0);
        ok("input is clamped to 0.35", Math.abs(i4[0]) <= 0.35 + 1e-9);
        double[] i5 = StargazeMath.approachImpulse(0, 1, 0.505, 0.5, 0);
        ok("dead zone near the target", i5[0] == 0 && i5[1] == 0);
        for (float yaw : new float[]{0, 90, 180, 270, 45, 300}) {   // elf placed in front of the player at that yaw: always walk "forward"
            double fx = -Math.sin(Math.toRadians(yaw)), fz = Math.cos(Math.toRadians(yaw));
            double[] ii = StargazeMath.approachImpulse(fx * 0.55, fz * 0.55, 0.55, 0.34, yaw);
            ok("yaw " + yaw + ": elf dead ahead -> pure forward input", ii[0] > 0.25 && Math.abs(ii[1]) < 1e-6);
        }
        // ---- kiss approach: simulate the whole timeline with a first-order-lag walker (the real player accelerates and has friction)
        for (double startD : new double[]{0.55, 0.7, 0.45}) {
            double dist = startD, v = 0, minD = 9, d62 = 0;
            float yaw = 20f; // elf dead ahead of the player: horizontal axis along the player's forward
            for (int t = 0; t < 66; t++) {
                double desired = startD + (0.34 - startD) * StargazeMath.leanWeight(t);
                double fx = -Math.sin(Math.toRadians(yaw)), fz = Math.cos(Math.toRadians(yaw));
                double[] imp = StargazeMath.approachImpulse(fx * dist, fz * dist, dist, desired, yaw);
                double target = imp[0] * 0.98 * 0.2158;               // blocks per tick at this input
                v += (target - v) * 0.5;                              // acceleration / friction lag
                dist -= v;                                            // moving toward the elf shrinks the distance
                minD = Math.min(minD, dist);
                if (t == 65) d62 = dist;
            }
            ok(String.format("kiss approach from %.2f: reaches ~0.34 (min %.3f) and returns (%.3f)", startD, minD, d62),
                    minD > 0.28 && minD < 0.40 && Math.abs(d62 - startD) < 0.04);
        }
        ok("leanWeight is 0 before 2, 1 in the hold, 0 after 62", StargazeMath.leanWeight(0) == 0f && Math.abs(StargazeMath.leanWeight(25) - 1f) < 1e-6
                && StargazeMath.leanWeight(70) == 0f);
        System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
}
