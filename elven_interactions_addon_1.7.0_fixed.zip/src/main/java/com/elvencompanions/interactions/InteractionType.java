package com.elvencompanions.interactions;

import com.elvencompanions.interactions.Clip.Ch;

/**
 * All interactions. Each has its OWN clip for the player and its OWN clip for the elf (different poses, different
 * timing); the elf reacts {@code elfDelay} ticks after the player starts. Both are authored in vanilla angle
 * convention and written for this mod; nothing here is copied from any other mod.
 */
public enum InteractionType {
    //          id            minBond affection cooldownSec distance elfDelay  player clip         elf clip
    // distance = how far apart you stand (blocks, centre to centre); BOW is elf-only: she bows to you, you do nothing.
    WAVE("wave", 0, 2, 10, 1.25f, 10, wavePlayer(), waveElf()),
    HIGH_FIVE("high_five", 0, 4, 20, 0.9f, 4, highFivePlayer(), highFiveElf()),
    BOW("bow", 0, 3, 20, 1.9f, 0, Clip.of(0), bowElf()),
    HEAD_PAT("head_pat", 1, 6, 30, 0.7f, 8, patPlayer(), patElf()),
    HOLD_HANDS("hold_hands", 2, 8, 45, 0.8f, 8, holdPlayer(), holdElf()),
    DANCE("dance", 2, 10, 60, 0.9f, 8, dancePlayer(), danceElf()),
    HUG("hug", 3, 12, 60, 0.5f, 10, hugPlayer(), hugElf()),
    // a gentle kiss on the cheek: you lean in, she turns her face and holds her hands together, shy
    CHEEK_KISS("cheek_kiss", 3, 10, 60, 0.55f, 8, cheekPlayer(), cheekElf()),
    // multi-step session handled by StargazeManager (evening/night only): she finds a seat, walks there slowly, sits; you join her
    STARGAZE("stargaze", 2, 14, 120, 0f, 0, Clip.of(0), Clip.of(0));

    public final String id;
    public final int minBond;
    public final int affection;
    public final int cooldownTicks;
    public final float distance;
    /** Ticks the elf's clip lags behind the player's. */
    public final int elfDelay;
    public final Clip player;
    public final Clip elf;

    InteractionType(String id, int minBond, int affection, int cooldownSec, float distance, int elfDelay,
                    Clip player, Clip elf) {
        this.id = id;
        this.minBond = minBond;
        this.affection = affection;
        this.cooldownTicks = cooldownSec * 20;
        this.distance = distance;
        this.elfDelay = elfDelay;
        this.player = player;
        this.elf = elf;
    }

    /** Centre-to-centre distance to step in to during the interaction (client-side lean-in), or 0 for none. */
    public float leanIn() {
        return this == CHEEK_KISS ? 0.34f : 0f;
    }

    /** True for the multi-step stargazing session, which is run by StargazeManager rather than as one timed clip. */
    public boolean isSession() {
        return this == STARGAZE;
    }

    /** False for elf-only interactions (the player neither animates nor is frozen). */
    public boolean playerActs() {
        return !player.isEmpty();
    }

    /** Total session length: the later of the two clips' ends. */
    public int duration() {
        return Math.max(player.duration, elfDelay + elf.duration);
    }

    public String langKey() {
        return "gui.elven_companions.interact.type." + id;
    }

    public static InteractionType byId(int i) {
        InteractionType[] v = values();
        return i >= 0 && i < v.length ? v[i] : null;
    }

    private static final float PI = (float) Math.PI;

    // ---------------------------------------------------------------- WAVE
    // Player: confident right-arm wave with a slight head lift.
    private static Clip wavePlayer() {
        Clip c = Clip.of(64);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 10, -2.7f).key(Ch.R_ARM_PITCH, 54, -2.7f).key(Ch.R_ARM_PITCH, 64, 0);
        c.key(Ch.R_ARM_ROLL, 0, 0).key(Ch.R_ARM_ROLL, 10, 0.15f);
        c.wave(Ch.R_ARM_ROLL, 10, 52, 0.15f, 0.4f, 16f, 0f);
        c.key(Ch.R_ARM_ROLL, 64, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 10, -0.08f).key(Ch.HEAD_PITCH, 54, -0.08f).key(Ch.HEAD_PITCH, 64, 0);
        return c;
    }

    // Elf: answers with a quicker LEFT-arm wave, head tilted, body swaying.
    private static Clip waveElf() {
        Clip c = Clip.of(58);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 9, -2.6f).key(Ch.L_ARM_PITCH, 48, -2.6f).key(Ch.L_ARM_PITCH, 58, 0);
        c.key(Ch.L_ARM_ROLL, 0, 0).key(Ch.L_ARM_ROLL, 9, -0.2f);
        c.wave(Ch.L_ARM_ROLL, 9, 46, -0.2f, -0.5f, 11f, 0f);
        c.key(Ch.L_ARM_ROLL, 58, 0);
        c.key(Ch.HEAD_YAW, 0, 0).key(Ch.HEAD_YAW, 9, 0.25f).key(Ch.HEAD_YAW, 48, 0.25f).key(Ch.HEAD_YAW, 58, 0);
        c.wave(Ch.TORSO_ROLL, 9, 48, 0f, 0.05f, 22f, 0f);
        return c;
    }

    // ---------------------------------------------------------------- HIGH FIVE
    // Player: reaches up-forward and leans into the clap.
    private static Clip highFivePlayer() {
        Clip c = Clip.of(46);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 14, -2.1f).key(Ch.R_ARM_PITCH, 18, -2.3f)
                .key(Ch.R_ARM_PITCH, 24, -2.1f).key(Ch.R_ARM_PITCH, 46, 0);
        c.key(Ch.R_ARM_ROLL, 0, 0).key(Ch.R_ARM_ROLL, 14, 0.1f).key(Ch.R_ARM_ROLL, 46, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 16, 0.1f).key(Ch.TORSO_PITCH, 46, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 16, -0.1f).key(Ch.HEAD_PITCH, 46, 0);
        return c;
    }

    // Elf: shorter, so it stretches higher, looks up, other arm out for balance.
    private static Clip highFiveElf() {
        Clip c = Clip.of(42);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 12, -2.55f).key(Ch.R_ARM_PITCH, 16, -2.7f)
                .key(Ch.R_ARM_PITCH, 22, -2.55f).key(Ch.R_ARM_PITCH, 42, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 12, -0.5f).key(Ch.L_ARM_PITCH, 30, -0.5f).key(Ch.L_ARM_PITCH, 42, 0);
        c.key(Ch.L_ARM_ROLL, 0, 0).key(Ch.L_ARM_ROLL, 12, -0.5f).key(Ch.L_ARM_ROLL, 30, -0.5f).key(Ch.L_ARM_ROLL, 42, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 14, -0.38f).key(Ch.HEAD_PITCH, 30, -0.38f).key(Ch.HEAD_PITCH, 42, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 14, -0.1f).key(Ch.TORSO_PITCH, 30, -0.1f).key(Ch.TORSO_PITCH, 42, 0);
        return c;
    }

    // ---------------------------------------------------------------- BOW (elf only)
    // Elf: deeper, slower, formal bow with both hands clasped in front.
    private static Clip bowElf() {
        Clip c = Clip.of(66);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 22, 0.8f).key(Ch.TORSO_PITCH, 48, 0.8f).key(Ch.TORSO_PITCH, 66, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 22, 0.45f).key(Ch.HEAD_PITCH, 48, 0.45f).key(Ch.HEAD_PITCH, 66, 0);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 22, -0.7f).key(Ch.R_ARM_PITCH, 50, -0.7f).key(Ch.R_ARM_PITCH, 66, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 22, -0.7f).key(Ch.L_ARM_PITCH, 50, -0.7f).key(Ch.L_ARM_PITCH, 66, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 22, -0.5f).key(Ch.R_ARM_YAW, 50, -0.5f).key(Ch.R_ARM_YAW, 66, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 22, 0.5f).key(Ch.L_ARM_YAW, 50, 0.5f).key(Ch.L_ARM_YAW, 66, 0);
        return c;
    }

    // ---------------------------------------------------------------- HEAD PAT
    private static Clip patPlayer() {
        Clip c = Clip.of(76);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 14, -2.0f);
        c.wave(Ch.R_ARM_PITCH, 14, 60, -2.0f, 0.14f, 14f, 0f);
        c.key(Ch.R_ARM_PITCH, 76, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 14, 0.22f).key(Ch.HEAD_PITCH, 62, 0.22f).key(Ch.HEAD_PITCH, 76, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 14, 0.12f).key(Ch.TORSO_PITCH, 62, 0.12f).key(Ch.TORSO_PITCH, 76, 0);
        return c;
    }

    private static Clip patElf() {
        Clip c = Clip.of(70);
        // she bows her head into the pat (looks DOWN)
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 10, 0.5f).key(Ch.HEAD_PITCH, 56, 0.5f).key(Ch.HEAD_PITCH, 70, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 10, 0.06f).key(Ch.TORSO_PITCH, 56, 0.06f).key(Ch.TORSO_PITCH, 70, 0);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 10, -0.25f).key(Ch.R_ARM_PITCH, 56, -0.25f).key(Ch.R_ARM_PITCH, 70, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 10, -0.25f).key(Ch.L_ARM_PITCH, 56, -0.25f).key(Ch.L_ARM_PITCH, 70, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 10, -0.35f).key(Ch.R_ARM_YAW, 56, -0.35f).key(Ch.R_ARM_YAW, 70, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 10, 0.35f).key(Ch.L_ARM_YAW, 56, 0.35f).key(Ch.L_ARM_YAW, 70, 0);
        c.wave(Ch.TORSO_ROLL, 10, 54, 0f, 0.03f, 20f, 0f);
        return c;
    }

    // ---------------------------------------------------------------- HOLD HANDS
    // Player: arms low and relaxed, head slightly down.
    private static Clip holdPlayer() {
        Clip c = Clip.of(84);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 18, -0.95f).key(Ch.R_ARM_PITCH, 70, -0.95f).key(Ch.R_ARM_PITCH, 84, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 18, -0.95f).key(Ch.L_ARM_PITCH, 70, -0.95f).key(Ch.L_ARM_PITCH, 84, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 18, -0.2f).key(Ch.R_ARM_YAW, 70, -0.2f).key(Ch.R_ARM_YAW, 84, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 18, 0.2f).key(Ch.L_ARM_YAW, 70, 0.2f).key(Ch.L_ARM_YAW, 84, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 18, 0.2f).key(Ch.HEAD_PITCH, 70, 0.2f).key(Ch.HEAD_PITCH, 84, 0);
        c.wave(Ch.TORSO_ROLL, 18, 70, 0f, 0.05f, 40f, 0f);
        return c;
    }

    // Elf: reaches out first, then settles with arms higher; looks up, sways opposite the player.
    private static Clip holdElf() {
        Clip c = Clip.of(84);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 10, -1.55f).key(Ch.R_ARM_PITCH, 20, -1.35f)
                .key(Ch.R_ARM_PITCH, 72, -1.35f).key(Ch.R_ARM_PITCH, 84, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 10, -1.55f).key(Ch.L_ARM_PITCH, 20, -1.35f)
                .key(Ch.L_ARM_PITCH, 72, -1.35f).key(Ch.L_ARM_PITCH, 84, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 20, -0.1f).key(Ch.R_ARM_YAW, 72, -0.1f).key(Ch.R_ARM_YAW, 84, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 20, 0.1f).key(Ch.L_ARM_YAW, 72, 0.1f).key(Ch.L_ARM_YAW, 84, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 20, -0.25f).key(Ch.HEAD_PITCH, 72, -0.25f).key(Ch.HEAD_PITCH, 84, 0);
        c.wave(Ch.TORSO_ROLL, 20, 72, 0f, 0.05f, 40f, PI);
        return c;
    }

    // ---------------------------------------------------------------- DANCE
    // Player: arms alternate, stepping legs, head sweep (period 24).
    private static Clip dancePlayer() {
        Clip c = Clip.of(122);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 10, -0.9f);
        c.wave(Ch.R_ARM_PITCH, 10, 108, -0.9f, 0.7f, 24f, 0f);
        c.key(Ch.R_ARM_PITCH, 122, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 10, -0.9f);
        c.wave(Ch.L_ARM_PITCH, 10, 108, -0.9f, 0.7f, 24f, PI);
        c.key(Ch.L_ARM_PITCH, 122, 0);
        c.key(Ch.R_ARM_ROLL, 0, 0).key(Ch.R_ARM_ROLL, 10, 0.3f).key(Ch.R_ARM_ROLL, 108, 0.3f).key(Ch.R_ARM_ROLL, 122, 0);
        c.key(Ch.L_ARM_ROLL, 0, 0).key(Ch.L_ARM_ROLL, 10, -0.3f).key(Ch.L_ARM_ROLL, 108, -0.3f).key(Ch.L_ARM_ROLL, 122, 0);
        c.key(Ch.R_LEG_PITCH, 0, 0);
        c.wave(Ch.R_LEG_PITCH, 10, 108, 0f, 0.4f, 24f, 0f);
        c.key(Ch.R_LEG_PITCH, 122, 0);
        c.key(Ch.L_LEG_PITCH, 0, 0);
        c.wave(Ch.L_LEG_PITCH, 10, 108, 0f, 0.4f, 24f, PI);
        c.key(Ch.L_LEG_PITCH, 122, 0);
        c.key(Ch.TORSO_ROLL, 0, 0);
        c.wave(Ch.TORSO_ROLL, 10, 108, 0f, 0.08f, 24f, 0f);
        c.key(Ch.TORSO_ROLL, 122, 0);
        c.key(Ch.HEAD_YAW, 0, 0);
        c.wave(Ch.HEAD_YAW, 10, 108, 0f, 0.3f, 48f, 0f);
        c.key(Ch.HEAD_YAW, 122, 0);
        return c;
    }

    // Elf: a different dance - arms overhead, quick small steps, big body sway (period 16 / 32).
    private static Clip danceElf() {
        Clip c = Clip.of(116);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 12, -2.3f);
        c.wave(Ch.R_ARM_PITCH, 12, 104, -2.3f, 0.35f, 16f, 0f);
        c.key(Ch.R_ARM_PITCH, 116, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 12, -2.3f);
        c.wave(Ch.L_ARM_PITCH, 12, 104, -2.3f, 0.35f, 16f, PI / 2);
        c.key(Ch.L_ARM_PITCH, 116, 0);
        c.key(Ch.R_ARM_ROLL, 0, 0).key(Ch.R_ARM_ROLL, 12, 0.6f);
        c.wave(Ch.R_ARM_ROLL, 12, 104, 0.6f, 0.25f, 32f, 0f);
        c.key(Ch.R_ARM_ROLL, 116, 0);
        c.key(Ch.L_ARM_ROLL, 0, 0).key(Ch.L_ARM_ROLL, 12, -0.6f);
        c.wave(Ch.L_ARM_ROLL, 12, 104, -0.6f, -0.25f, 32f, 0f);
        c.key(Ch.L_ARM_ROLL, 116, 0);
        c.key(Ch.R_LEG_PITCH, 0, 0);
        c.wave(Ch.R_LEG_PITCH, 12, 104, 0f, 0.5f, 16f, PI);
        c.key(Ch.R_LEG_PITCH, 116, 0);
        c.key(Ch.L_LEG_PITCH, 0, 0);
        c.wave(Ch.L_LEG_PITCH, 12, 104, 0f, 0.5f, 16f, 0f);
        c.key(Ch.L_LEG_PITCH, 116, 0);
        c.key(Ch.TORSO_ROLL, 0, 0);
        c.wave(Ch.TORSO_ROLL, 12, 104, 0f, 0.14f, 32f, PI / 2);
        c.key(Ch.TORSO_ROLL, 116, 0);
        c.key(Ch.HEAD_YAW, 0, 0);
        c.wave(Ch.HEAD_YAW, 12, 104, 0f, 0.45f, 32f, 0f);
        c.key(Ch.HEAD_YAW, 116, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 12, -0.15f).key(Ch.HEAD_PITCH, 104, -0.15f).key(Ch.HEAD_PITCH, 116, 0);
        return c;
    }

    // ---------------------------------------------------------------- HUG
    // Both stand chest to chest (0.5 blocks). Arms go almost level (a hug wraps around the back, it is not hands held low in
    // front) and angle inward so the hands meet behind the partner; torsos lean in, heads turn to their own right (cheek to cheek).
    private static Clip hugPlayer() {
        Clip c = Clip.of(76);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 16, -1.4f).key(Ch.R_ARM_PITCH, 62, -1.4f).key(Ch.R_ARM_PITCH, 76, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 16, -1.4f).key(Ch.L_ARM_PITCH, 62, -1.4f).key(Ch.L_ARM_PITCH, 76, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 16, -0.75f).key(Ch.R_ARM_YAW, 62, -0.75f).key(Ch.R_ARM_YAW, 76, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 16, 0.75f).key(Ch.L_ARM_YAW, 62, 0.75f).key(Ch.L_ARM_YAW, 76, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 16, 0.18f).key(Ch.TORSO_PITCH, 62, 0.18f).key(Ch.TORSO_PITCH, 76, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 16, 0.25f).key(Ch.HEAD_PITCH, 62, 0.25f).key(Ch.HEAD_PITCH, 76, 0);
        c.key(Ch.HEAD_YAW, 0, 0).key(Ch.HEAD_YAW, 16, 0.5f).key(Ch.HEAD_YAW, 62, 0.5f).key(Ch.HEAD_YAW, 76, 0);
        return c;
    }

    // Elf: closes in a beat later, arms around the player's back, head resting on their shoulder.
    private static Clip hugElf() {
        Clip c = Clip.of(70);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 14, -1.3f).key(Ch.R_ARM_PITCH, 54, -1.3f).key(Ch.R_ARM_PITCH, 70, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 14, -1.3f).key(Ch.L_ARM_PITCH, 54, -1.3f).key(Ch.L_ARM_PITCH, 70, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 14, -0.85f).key(Ch.R_ARM_YAW, 54, -0.85f).key(Ch.R_ARM_YAW, 70, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 14, 0.85f).key(Ch.L_ARM_YAW, 54, 0.85f).key(Ch.L_ARM_YAW, 70, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 14, 0.12f).key(Ch.HEAD_PITCH, 54, 0.12f).key(Ch.HEAD_PITCH, 70, 0);
        c.key(Ch.HEAD_YAW, 0, 0).key(Ch.HEAD_YAW, 14, 0.5f).key(Ch.HEAD_YAW, 54, 0.5f).key(Ch.HEAD_YAW, 70, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 14, 0.1f).key(Ch.TORSO_PITCH, 54, 0.1f).key(Ch.TORSO_PITCH, 70, 0);
        return c;
    }

    // ---------------------------------------------------------------- CHEEK KISS
    // Player leans in with a hand resting lightly on her shoulder and turns their face to her cheek.
    private static Clip cheekPlayer() {
        Clip c = Clip.of(64);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 16, 0.22f).key(Ch.TORSO_PITCH, 42, 0.22f).key(Ch.TORSO_PITCH, 62, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 16, 0.14f).key(Ch.HEAD_PITCH, 42, 0.14f).key(Ch.HEAD_PITCH, 62, 0);
        c.key(Ch.HEAD_YAW, 0, 0).key(Ch.HEAD_YAW, 16, -0.45f).key(Ch.HEAD_YAW, 42, -0.45f).key(Ch.HEAD_YAW, 62, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 16, -1.0f).key(Ch.L_ARM_PITCH, 42, -1.0f).key(Ch.L_ARM_PITCH, 62, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 16, 0.35f).key(Ch.L_ARM_YAW, 42, 0.35f).key(Ch.L_ARM_YAW, 62, 0);
        return c;
    }

    // She turns her face to offer her cheek and holds her hands together in front of her, a little shy.
    private static Clip cheekElf() {
        Clip c = Clip.of(56);
        c.key(Ch.HEAD_YAW, 0, 0).key(Ch.HEAD_YAW, 12, 0.6f).key(Ch.HEAD_YAW, 38, 0.6f).key(Ch.HEAD_YAW, 56, 0);
        c.key(Ch.HEAD_PITCH, 0, 0).key(Ch.HEAD_PITCH, 12, 0.1f).key(Ch.HEAD_PITCH, 38, 0.1f).key(Ch.HEAD_PITCH, 56, 0);
        c.key(Ch.TORSO_PITCH, 0, 0).key(Ch.TORSO_PITCH, 12, -0.04f).key(Ch.TORSO_PITCH, 38, -0.04f).key(Ch.TORSO_PITCH, 56, 0);
        c.key(Ch.R_ARM_PITCH, 0, 0).key(Ch.R_ARM_PITCH, 12, -0.6f).key(Ch.R_ARM_PITCH, 38, -0.6f).key(Ch.R_ARM_PITCH, 56, 0);
        c.key(Ch.L_ARM_PITCH, 0, 0).key(Ch.L_ARM_PITCH, 12, -0.6f).key(Ch.L_ARM_PITCH, 38, -0.6f).key(Ch.L_ARM_PITCH, 56, 0);
        c.key(Ch.R_ARM_YAW, 0, 0).key(Ch.R_ARM_YAW, 12, -0.5f).key(Ch.R_ARM_YAW, 38, -0.5f).key(Ch.R_ARM_YAW, 56, 0);
        c.key(Ch.L_ARM_YAW, 0, 0).key(Ch.L_ARM_YAW, 12, 0.5f).key(Ch.L_ARM_YAW, 38, 0.5f).key(Ch.L_ARM_YAW, 56, 0);
        return c;
    }
}
