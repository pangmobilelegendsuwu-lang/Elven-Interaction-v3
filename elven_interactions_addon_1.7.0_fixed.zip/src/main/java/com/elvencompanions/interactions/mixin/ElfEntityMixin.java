package com.elvencompanions.interactions.mixin;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.ai.LeadGoal;
import com.elvencompanions.interactions.ai.StargazeWalkGoal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fourth mixin (common): appends two extra goals to the elf's goal list so she can walk to a stargazing seat, or follow you while you
 * hold her hand, without her own goals fighting the movement. Each goal is inert unless its job is running. (Extends Mob so the protected
 * goalSelector field is directly accessible.)
 */
@Mixin(value = ElfEntity.class, remap = false)
public abstract class ElfEntityMixin extends Mob {
    protected ElfEntityMixin(EntityType<? extends Mob> type, Level level) {
        super(type, level);
    }

    @Inject(method = "registerGoals", at = @At("TAIL"), remap = false)
    private void elven_interactions$addGoals(CallbackInfo ci) {
        this.goalSelector.addGoal(-1, new StargazeWalkGoal((ElfEntity) (Object) this));
        this.goalSelector.addGoal(-1, new LeadGoal((ElfEntity) (Object) this));
    }
}
