package com.elvencompanions.interactions.mixin;

import com.elvencompanions.client.ElfRenderer;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.mojang.blaze3d.vertex.PoseStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fifth (tiny) mixin: scales the elf model to the configured elfModelScale. The original renderer scales by a fixed 0.95; this
 * multiplies by elfModelScale / 0.95 right after it, so the config value is the final scale (0.95 = unchanged). The hitbox is not
 * changed. Scaling is about her feet, so she stays on the ground.
 */
@Mixin(value = ElfRenderer.class, remap = false)
public abstract class ElfRendererMixin {
    @Inject(method = "scale(Lcom/elvencompanions/entity/ElfEntity;Lcom/mojang/blaze3d/vertex/PoseStack;F)V",
            at = @At("TAIL"), remap = false)
    private void elven_interactions$scale(ElfEntity elf, PoseStack ps, float partialTick, CallbackInfo ci) {
        float k = (float) (Cfg.COMMON.elfModelScale.get() / 0.95);
        if (Math.abs(k - 1.0f) > 1.0E-4f) ps.scale(k, k, k);
    }
}
