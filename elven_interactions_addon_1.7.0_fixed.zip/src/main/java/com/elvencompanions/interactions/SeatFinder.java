package com.elvencompanions.interactions;

import com.elvencompanions.entity.ElfEntity;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Finds somewhere for the elf to sit (and for the player to sit beside her). Uses the blocks' real collision shapes so slabs,
 * stairs, logs and beds all give the correct sitting height; stairs are sat on the LOW tread facing away from the back.
 * Candidates need free headroom and (by default) open sky, are ranked nearest-first with a bonus for spots where the player
 * can also sit on a platform, and must be reachable by her own pathfinding.
 */
public final class SeatFinder {
    /** elf = where her feet go, player = where the player's seat surface is, pair = both sit on platforms. */
    public record Seat(BlockPos block, Vec3 elf, float yaw, Vec3 player, boolean pair) {}

    private record Cand(Seat seat, double score) {}

    private SeatFinder() {}

    public static Seat find(ServerLevel level, ElfEntity elf, ServerPlayer p) {
        int r = Cfg.COMMON.stargazeSearchRadius.get();
        BlockPos c = elf.blockPosition();
        List<Cand> cands = new ArrayList<>();
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -6, -r), c.offset(r, 6, r))) {
            int dx = pos.getX() - c.getX();
            int dz = pos.getZ() - c.getZ();
            if (dx * dx + dz * dz > r * r) continue;
            BlockState st = level.getBlockState(pos);
            if (st.isAir() || !SeatMatcher.matches(st)) continue;
            Seat s = evaluate(level, elf, p, pos.immutable(), st);
            if (s == null) continue;
            double score = elf.position().distanceToSqr(s.elf()) - (s.pair() ? 40.0 : 0.0);
            cands.add(new Cand(s, score));
        }
        cands.sort(Comparator.comparingDouble(Cand::score));
        int tried = 0;
        for (Cand cd : cands) {
            if (++tried > 12) break;
            Path path = elf.getNavigation().createPath(BlockPos.containing(cd.seat().elf()), 1);
            if (path != null && path.canReach()) return cd.seat();
        }
        return null;
    }

    private static Seat evaluate(ServerLevel level, ElfEntity elf, ServerPlayer p, BlockPos pos, BlockState st) {
        double surf;
        double ox = 0;
        double oz = 0;
        float yaw;
        if (st.getBlock() instanceof StairBlock) {
            if (st.getValue(StairBlock.HALF) == Half.TOP) return null;
            Direction low = lowSide(level, pos, st);
            if (low == null) return null;
            surf = 0.5;
            ox = low.getStepX() * 0.25;
            oz = low.getStepZ() * 0.25;
            yaw = low.toYRot();
        } else {
            VoxelShape shape = st.getCollisionShape(level, pos);
            if (shape.isEmpty()) return null;
            surf = shape.max(Direction.Axis.Y);
            if (surf < 0.3 || surf > 1.01) return null;
            yaw = pickYaw(level, pos, surf, p);
        }
        Vec3 e = new Vec3(pos.getX() + 0.5 + ox, pos.getY() + surf, pos.getZ() + 0.5 + oz);

        // the elf's full standing box must fit above the seat, and (by default) the sky must be open
        AABB elfBox = elf.getType().getDimensions().makeBoundingBox(e.x, e.y + 0.001, e.z);
        if (!level.noCollision(elfBox)) return null;
        if (Cfg.COMMON.stargazeRequireOpenSky.get() && !level.canSeeSky(BlockPos.containing(e.x, e.y + 0.2, e.z))) return null;

        // the player's seat, beside her (either side), preferring a platform at the same height
        double rx = StargazeMath.rightX(yaw);
        double rz = StargazeMath.rightZ(yaw);
        Vec3 best = null;
        boolean bestPair = false;
        double bestDy = 99;
        for (int sgn : new int[]{1, -1}) {
            double px = e.x + rx * sgn * 0.8;
            double pz = e.z + rz * sgn * 0.8;
            double top = columnTop(level, px, pz, e.y);
            if (Double.isNaN(top) || Math.abs(top - e.y) > 1.0) continue;
            boolean pair = SeatMatcher.matches(level.getBlockState(BlockPos.containing(px, top - 0.01, pz)));
            AABB pbox = new AABB(px - 0.3, top + 0.001, pz - 0.3, px + 0.3, top + 1.8, pz + 0.3);
            if (!level.noCollision(pbox)) continue;
            double dy = Math.abs(top - e.y);
            if (best == null || (pair && !bestPair) || (pair == bestPair && dy < bestDy)) {
                best = new Vec3(px, top, pz);
                bestPair = pair;
                bestDy = dy;
            }
        }
        if (best == null) return null;
        return new Seat(pos, e, yaw, best, bestPair);
    }

    /** The side of a stair whose upper tread is open (the low step) - found from the real collision shape, not assumed. */
    private static Direction lowSide(ServerLevel level, BlockPos pos, BlockState st) {
        VoxelShape shape = st.getCollisionShape(level, pos);
        for (Direction d : Direction.Plane.HORIZONTAL) {
            double cx = 0.5 + d.getStepX() * 0.28;
            double cz = 0.5 + d.getStepZ() * 0.28;
            AABB probe = new AABB(cx - 0.08, 0.55, cz - 0.08, cx + 0.08, 0.9, cz + 0.08);
            if (!Shapes.joinIsNotEmpty(shape, Shapes.create(probe), BooleanOp.AND)) return d;
        }
        return null;
    }

    /** Sit facing an open side (legs hang over free space), preferring to face away from the player. */
    private static float pickYaw(ServerLevel level, BlockPos pos, double surf, ServerPlayer p) {
        double ax = pos.getX() + 0.5 - p.getX();
        double az = pos.getZ() + 0.5 - p.getZ();
        double len = Math.sqrt(ax * ax + az * az);
        if (len > 1.0E-6) {
            ax /= len;
            az /= len;
        }
        Direction best = Direction.SOUTH;
        double bestScore = -99;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos n = pos.relative(d);
            VoxelShape ns = level.getBlockState(n).getCollisionShape(level, n);
            double h = ns.isEmpty() ? 0 : ns.max(Direction.Axis.Y);
            boolean open = h < surf - 0.2 && level.getBlockState(n.above()).getCollisionShape(level, n.above()).isEmpty();
            double score = (open ? 10 : 0) + d.getStepX() * ax + d.getStepZ() * az;
            if (score > bestScore) {
                bestScore = score;
                best = d;
            }
        }
        return best.toYRot();
    }

    /** Top surface of the highest collision at/below refY+0.55 in this column (looking down up to 2 blocks), or NaN. */
    private static double columnTop(ServerLevel level, double x, double z, double refY) {
        int startY = (int) Math.floor(refY + 0.6);
        int endY = (int) Math.floor(refY - 2.0);
        for (int y = startY; y >= endY; y--) {
            BlockPos bp = BlockPos.containing(x, y, z);
            VoxelShape sh = level.getBlockState(bp).getCollisionShape(level, bp);
            if (!sh.isEmpty()) {
                double top = bp.getY() + sh.max(Direction.Axis.Y);
                if (top <= refY + 0.55) return top;
            }
        }
        return Double.NaN;
    }
}
