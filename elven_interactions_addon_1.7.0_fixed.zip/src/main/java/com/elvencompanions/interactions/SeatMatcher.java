package com.elvencompanions.interactions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Decides which blocks she may sit on, from the config string ("#tag" entries and plain block ids, comma separated). */
public final class SeatMatcher {
    private static String cachedRaw;
    private static List<TagKey<Block>> tags = List.of();
    private static Set<Block> blocks = Set.of();

    private SeatMatcher() {}

    private static synchronized void refresh() {
        String raw = Cfg.COMMON.stargazeSeatBlocks.get();
        if (raw.equals(cachedRaw)) return;
        List<TagKey<Block>> t = new ArrayList<>();
        Set<Block> b = new HashSet<>();
        for (String part : raw.split(",")) {
            String s = part.trim();
            if (s.isEmpty()) continue;
            boolean isTag = s.startsWith("#");
            ResourceLocation id = ResourceLocation.tryParse(isTag ? s.substring(1) : s);
            if (id == null) {
                ElvenInteractions.LOGGER.warn("Ignoring invalid seat block entry '{}'", s);
                continue;
            }
            if (isTag) {
                t.add(TagKey.create(Registries.BLOCK, id));
            } else if (BuiltInRegistries.BLOCK.containsKey(id)) {
                b.add(BuiltInRegistries.BLOCK.get(id));
            } else {
                ElvenInteractions.LOGGER.warn("Unknown seat block '{}'", s);
            }
        }
        tags = t;
        blocks = b;
        cachedRaw = raw;
    }

    public static boolean matches(BlockState st) {
        refresh();
        for (TagKey<Block> t : tags) {
            if (st.is(t)) return true;
        }
        return blocks.contains(st.getBlock());
    }
}
