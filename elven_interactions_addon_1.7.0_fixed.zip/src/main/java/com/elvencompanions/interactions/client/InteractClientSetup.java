package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.ElvenInteractions;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import com.mojang.blaze3d.platform.InputConstants;

/** MOD-bus client registration for the interaction system (kept separate from the original ClientSetup). */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class InteractClientSetup {
    /** Hold to open the wheel, release over a slice to select. Default: V. */
    public static final KeyMapping WHEEL_KEY = new KeyMapping("key.elven_companions.interact_wheel",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, InputConstants.KEY_V, "key.categories.elven_companions");

    /** Locks (pins) the body part you are touching / aiming at so it stays selected without holding right-click. Default: L. */
    public static final KeyMapping TOUCH_LOCK_KEY = new KeyMapping("key.elven_companions.touch_lock",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, InputConstants.KEY_L, "key.categories.elven_companions");

    private InteractClientSetup() {}

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(WHEEL_KEY);
        e.register(TOUCH_LOCK_KEY);
    }

    @SubscribeEvent
    public static void setup(FMLClientSetupEvent e) {
        e.enqueueWork(PlayerAnimBridge::register);
    }
}
