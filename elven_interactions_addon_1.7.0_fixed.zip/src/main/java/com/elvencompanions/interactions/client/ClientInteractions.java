package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.StargazeMath;
import com.elvencompanions.interactions.InteractNet;
import com.elvencompanions.interactions.InteractionType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.Input;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Client-side interaction state: active sessions, relationship cache, input lock, wheel key, animation start/stop. */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class ClientInteractions {
    public static final class Active {
        public final int playerId;
        public final int elfEntityId;
        public final InteractionType type;
        public int elapsed;
        /** Centre-to-centre distance to the elf when the interaction began (for the lean-in controller). */
        double startDist = Double.NaN;

        Active(int playerId, int elfEntityId, InteractionType type) {
            this.playerId = playerId;
            this.elfEntityId = elfEntityId;
            this.type = type;
        }
    }

    public record Bond(int affection, int[] cooldownSecs, long receivedMs) {
        public int cooldownLeft(InteractionType t) {
            int base = t.ordinal() < cooldownSecs.length ? cooldownSecs[t.ordinal()] : 0;
            return Math.max(0, base - (int) ((System.currentTimeMillis() - receivedMs) / 1000L));
        }
    }

    private static final Map<Integer, Active> BY_ELF = new HashMap<>();
    private static final Map<Integer, Active> BY_PLAYER = new HashMap<>();
    private static final Map<UUID, Bond> BOND_BY_COMPANION = new HashMap<>();
    private static final Map<Integer, Bond> BOND_BY_ENTITY = new HashMap<>();
    private static boolean cancelSent;

    private ClientInteractions() {}

    // ------------------------------------------------------------------ queries

    public static Active activeForElf(int elfEntityId) {
        return BY_ELF.get(elfEntityId);
    }

    /** True during an interaction OR touch mode: movement is frozen and sneak cancels. */
    public static boolean selfBusy() {
        return selfActive() || TouchClient.active();
    }

    /** Movement is frozen only when the player takes part (not for elf-only interactions) or in touch mode. */
    public static boolean selfLocked() {
        Active a = selfActiveInfo();
        return (a != null && a.type.playerActs()) || (TouchClient.active() && !TouchClient.leading());
    }

    public static void resetCancel() {
        cancelSent = false;
    }

    public static void requestGift(UUID companion, int entityId) {
        PacketDistributor.sendToServer(new InteractNet.GiftC2S(wire(companion), entityId), new CustomPacketPayload[0]);
    }

    public static void requestTouch(UUID companion, int entityId) {
        PacketDistributor.sendToServer(new InteractNet.TouchStartC2S(wire(companion), entityId, false), new CustomPacketPayload[0]);
    }

    public static boolean selfActive() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null && BY_PLAYER.containsKey(mc.player.getId());
    }

    /** The local player's active interaction, or null. */
    public static Active selfActiveInfo() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player == null ? null : BY_PLAYER.get(mc.player.getId());
    }

    public static float elapsedWithPartial(Active a, float partial) {
        return a.elapsed + partial;
    }

    public static float elapsedWithPartial(Active a) {
        float partial = Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false);
        return a.elapsed + partial;
    }

    public static Bond bond(UUID companion, int entityId) {
        Bond b = companion == null ? null : BOND_BY_COMPANION.get(companion);
        return b != null ? b : BOND_BY_ENTITY.get(entityId);
    }

    // ------------------------------------------------------------------ packets in

    public static void onState(InteractNet.StateS2C p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        InteractionType type = InteractionType.byId(p.interactionTypeId());
        Entity pe = mc.level.getEntity(p.playerId());
        if (p.start()) {
            if (type == null) return;
            Active a = new Active(p.playerId(), p.elfEntityId(), type);
            BY_ELF.put(p.elfEntityId(), a);
            BY_PLAYER.put(p.playerId(), a);
            StowState.begin(p.elfEntityId());
            if (pe instanceof AbstractClientPlayer acp) PlayerAnimBridge.play(acp, type);
            if (mc.player != null && p.playerId() == mc.player.getId()) {
                cancelSent = false;
                mc.player.displayClientMessage(Component.translatable("message.elven_companions.interact.hint"), true);
            }
        } else {
            BY_ELF.remove(p.elfEntityId());
            BY_PLAYER.remove(p.playerId());
            StowState.end(p.elfEntityId());
            if (pe instanceof AbstractClientPlayer acp) PlayerAnimBridge.stop(acp);
        }
    }

    public static void onBond(InteractNet.BondS2C p) {
        Bond b = new Bond(p.affection(), p.cooldownSecs().stream().mapToInt(Integer::intValue).toArray(),
                System.currentTimeMillis());
        BOND_BY_COMPANION.put(p.companion(), b);
        BOND_BY_ENTITY.put(p.entityId(), b);
    }

    // ------------------------------------------------------------------ packets out

    private static UUID wire(UUID u) {
        return u == null ? new UUID(0L, 0L) : u;
    }

    public static void requestBond(UUID companion, int entityId) {
        PacketDistributor.sendToServer(new InteractNet.BondRequestC2S(wire(companion), entityId), new CustomPacketPayload[0]);
    }

    public static void adjustBond(UUID companion, int entityId, boolean up, boolean wholeLevel) {
        PacketDistributor.sendToServer(new InteractNet.BondAdjustC2S(wire(companion), entityId, up, wholeLevel),
                new CustomPacketPayload[0]);
    }

    public static void requestInteraction(UUID companion, int entityId, InteractionType t) {
        PacketDistributor.sendToServer(new InteractNet.RequestC2S(wire(companion), entityId, t.ordinal()),
                new CustomPacketPayload[0]);
    }

    // ------------------------------------------------------------------ elf lookup for the wheel

    /** The owned elf under the crosshair, or else the best owned elf in front of the player within reach. */
    public static ElfEntity findLookedElf() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return null;
        if (mc.crosshairPickEntity instanceof ElfEntity e && e.isOwnedBy(mc.player) && e.distanceTo(mc.player) <= 6.0F) {
            return e;
        }
        Vec3 look = mc.player.getLookAngle();
        ElfEntity best = null;
        double bestDot = 0.6;
        AABB box = mc.player.getBoundingBox().inflate(5.0);
        for (ElfEntity e : mc.level.getEntitiesOfClass(ElfEntity.class, box)) {
            if (!e.isOwnedBy(mc.player) || !e.isAlive()) continue;
            Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(mc.player.getEyePosition());
            if (to.lengthSqr() < 1.0E-4) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ events

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            clearAll();
            return;
        }

        // Open the wheel
        while (InteractClientSetup.WHEEL_KEY.consumeClick()) {
            if (mc.screen != null || selfBusy()) continue;
            ElfEntity elf = findLookedElf();
            if (elf == null) {
                mc.player.displayClientMessage(Component.translatable("message.elven_companions.interact.no_elf"), true);
            } else {
                mc.setScreen(new InteractionWheelScreen(elf, InteractClientSetup.WHEEL_KEY));
            }
        }

        // Sneak cancels my own interaction or touch session
        if (selfBusy() && !cancelSent && mc.options.keyShift.isDown()) {
            cancelSent = true;
            PacketDistributor.sendToServer(new InteractNet.CancelC2S(), new CustomPacketPayload[0]);
        }

        if (BY_PLAYER.isEmpty()) return;
        // Advance timers; drop stale sessions if the stop packet was lost
        for (Active a : List.copyOf(BY_PLAYER.values())) {
            a.elapsed++;
            if (a.elapsed > a.type.duration() + 20) {
                BY_PLAYER.remove(a.playerId);
                BY_ELF.remove(a.elfEntityId);
                StowState.end(a.elfEntityId);
                if (mc.level.getEntity(a.playerId) instanceof AbstractClientPlayer acp) PlayerAnimBridge.stop(acp);
            }
        }
    }

    /** Freeze the local player's movement input while they are in an interaction. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || e.getEntity() != mc.player || !selfLocked()) return;
        Input in = e.getInput();
        in.up = in.down = in.left = in.right = false;
        in.forwardImpulse = 0F;
        in.leftImpulse = 0F;
        in.jumping = false;
        in.shiftKeyDown = false;
        approachElf(mc, in);
    }

    /**
     * Interactions that need the two of you very close (the cheek kiss) physically step toward her and back: a proportional
     * controller feeds walking input so the centre distance follows the lean-in timeline (approach, hold, retreat) and ends where it
     * began. The camera therefore really moves closer, and so does the player model in third person.
     */
    private static void approachElf(Minecraft mc, Input in) {
        Active a = selfActiveInfo();
        if (a == null || a.type.leanIn() <= 0f || !Cfg.CLIENT.kissApproach.get()) return;
        Entity elf = mc.level.getEntity(a.elfEntityId);
        if (elf == null) return;
        double dx = elf.getX() - mc.player.getX();
        double dz = elf.getZ() - mc.player.getZ();
        double cur = Math.sqrt(dx * dx + dz * dz);
        if (cur < 1.0E-4) return;
        if (Double.isNaN(a.startDist)) a.startDist = cur;
        double desired = a.startDist + (a.type.leanIn() - a.startDist) * StargazeMath.leanWeight(a.elapsed);
        double[] imp = StargazeMath.approachImpulse(dx, dz, cur, desired, mc.player.getYRot());
        if (imp[0] == 0 && imp[1] == 0) return;
        in.forwardImpulse = (float) imp[0];
        in.leftImpulse = (float) imp[1];
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        clearAll();
        BOND_BY_COMPANION.clear();
        BOND_BY_ENTITY.clear();
    }

    private static void clearAll() {
        if (!BY_PLAYER.isEmpty()) {
            Minecraft mc = Minecraft.getInstance();
            for (Active a : List.copyOf(BY_PLAYER.values())) {
                if (mc.level != null && mc.level.getEntity(a.playerId) instanceof AbstractClientPlayer acp) {
                    PlayerAnimBridge.stop(acp);
                }
            }
        }
        BY_PLAYER.clear();
        BY_ELF.clear();
        StowState.clear();
        cancelSent = false;
    }
}
