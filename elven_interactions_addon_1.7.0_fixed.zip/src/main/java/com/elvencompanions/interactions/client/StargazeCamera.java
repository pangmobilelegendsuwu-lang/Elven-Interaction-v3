package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.StargazeMath;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * First-person camera during the stargazing script: the view eases toward her face, holds for the stare, then tips up toward the
 * sky; after a few seconds the pull releases so you can look around freely while you keep sitting. Render camera only.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class StargazeCamera {
    private static final float RAD = (float) (180.0 / Math.PI);
    private static final float SKY_PITCH = -55f;

    private StargazeCamera() {}

    @SubscribeEvent
    public static void onAngles(ViewportEvent.ComputeCameraAngles e) {
        Minecraft mc = Minecraft.getInstance();
        int phase = StargazeClient.phase();
        if (!Cfg.CLIENT.cameraEffects.get() || mc.player == null || mc.level == null
                || (phase != StargazeMath.PHASE_SCRIPT && phase != StargazeMath.PHASE_HOLD)
                || !mc.options.getCameraType().isFirstPerson() || e.getCamera().getEntity() != mc.player) {
            return;
        }
        float t = StargazeClient.scriptTime((float) e.getPartialTick());
        int gaze = StargazeClient.gazeTicks();
        float gazeEnd = StargazeMath.SETTLE_TICKS + gaze;
        float lookAt = Cfg.CLIENT.lookAtStrength.get().floatValue();

        float wElf = StargazeMath.smooth(t / StargazeMath.SETTLE_TICKS) * (1f - StargazeMath.smooth((t - gazeEnd) / 20f))
                * Math.min(1f, 0.7f * lookAt);
        float wSky = StargazeMath.smooth((t - gazeEnd) / StargazeMath.SKY_TURN_TICKS)
                * (1f - StargazeMath.smooth((t - (gazeEnd + StargazeMath.SKY_TURN_TICKS + 40f)) / 40f)) * 0.85f;

        float yaw = e.getYaw();
        float pitch = e.getPitch();
        if (wElf > 0.001f) {
            Entity elf = mc.level.getEntity(StargazeClient.elfEntityId());
            if (elf != null) {
                Vec3 cam = e.getCamera().getPosition();
                Vec3 target = elf.getEyePosition((float) e.getPartialTick());
                double dx = target.x - cam.x;
                double dy = target.y - cam.y;
                double dz = target.z - cam.z;
                double h = Math.sqrt(dx * dx + dz * dz);
                if (h > 1.0E-3) {
                    float ty = (float) (Mth.atan2(dz, dx) * RAD) - 90f;
                    float tp = (float) (-(Mth.atan2(dy, h) * RAD));
                    yaw += Mth.clamp(Mth.wrapDegrees(ty - yaw), -60f, 60f) * wElf;
                    pitch += Mth.clamp(tp - pitch, -30f, 30f) * wElf;
                }
            }
        }
        if (wSky > 0.001f) pitch += (SKY_PITCH - pitch) * wSky;
        e.setYaw(yaw);
        e.setPitch(pitch);
    }
}
