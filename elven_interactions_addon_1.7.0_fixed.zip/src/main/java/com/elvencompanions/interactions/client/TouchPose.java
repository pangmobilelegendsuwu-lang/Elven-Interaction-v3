package com.elvencompanions.interactions.client;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.Clip.Ch;
import com.elvencompanions.interactions.TouchGesture;
import com.elvencompanions.interactions.TouchZone;
import net.minecraft.util.Mth;

/**
 * The elf's reaction pose in touch mode: ADDITIVE offsets on top of her normal pose (so her idle animation keeps running)
 * plus elbow/knee bend angles for the joint renderer ({@link JointBend}). Targets are authored in vanilla angle convention and
 * converted with {@link InteractionPose#sign}; everything is smoothed per frame.
 *
 * While you hold right-click the part you grabbed is locked (server side) and follows how far your view has moved since the grab
 * (dragPitch: + = looked down, dragYaw: + = turned right):
 *  - ARM    swings at the shoulder (look up = raise, sideways = sweep); the forearm bends a little with it,
 *  - HAND   bends the ELBOW (look up = forearm folds up, look down = straightens) and sweeps the arm sideways,
 *  - LEG    swings at the hip, the knee bending as it lifts,
 *  - KNEE   bends the KNEE (look up = lower leg folds back, with a little hip lift),
 *  - HEAD   head follows the drag, or bows into a pat (server says PAT);  FACE follows lightly, or leans into a caress (CARESS),
 *  - torso / rough handling / refusing: recoil - leans back, turns away, guards with bent arms.
 * Limbs are driven by the actual mesh bone that was grabbed (elf's own left/right), so the swapElfArms config does not apply.
 */
public final class TouchPose {
    private static final int N = Ch.values().length;
    private static final float[] cur = new float[N];
    /** Smoothed bend magnitudes: [0] right arm, [1] left arm, [2] right leg, [3] left leg (radians, positive). */
    private static final float[] curBend = new float[4];
    private static float weight;
    private static int lastElf = -1;

    private TouchPose() {}

    private static void set(float[] t, Ch ch, float v) {
        t[ch.ordinal()] = v;
    }

    private static float time() {
        return (System.currentTimeMillis() % 100000L) / 1000f;
    }

    /** Joint bend magnitude for the renderer, already faded by the pose weight. idx: 0 right arm, 1 left arm, 2 right leg, 3 left leg. */
    public static float bend(int idx) {
        return curBend[idx] * weight;
    }

    /** @return additive offsets in InteractionPose slot layout (slot 0 = weight), or null when untouched. */
    public static float[] sample(ElfEntity elf) {
        boolean mine = TouchClient.active() && TouchClient.elfEntityId() == elf.getId();
        if (mine) lastElf = elf.getId();
        else if (elf.getId() != lastElf) return null;

        weight = Mth.clamp(weight + (mine ? 0.12f : -0.08f), 0f, 1f);
        if (weight <= 0.001f && !mine) {
            lastElf = -1;
            for (int i = 0; i < N; i++) cur[i] = 0f;
            for (int i = 0; i < 4; i++) curBend[i] = 0f;
            return null;
        }

        float[] t = new float[N];
        float[] b = new float[4];
        if (mine) {
            TouchZone zone = TouchClient.zone();
            TouchGesture gesture = TouchClient.gesture();
            boolean touching = TouchClient.touching();
            boolean recoil = TouchClient.locked()
                    || (touching && zone != null && (gesture == TouchGesture.ROUGH || zone.guarded()
                    || (zone == TouchZone.FACE && TouchClient.comfort() < 45f)));
            float dY = TouchClient.dragYaw() * (Cfg.CLIENT.flipTouchDragYaw.get() ? -1f : 1f);
            float dP = TouchClient.dragPitch() * (Cfg.CLIENT.flipTouchDragPitch.get() ? -1f : 1f);
            boolean left = TouchClient.left();
            if (recoil) {
                set(t, Ch.TORSO_PITCH, -0.14f);
                set(t, Ch.HEAD_YAW, 0.35f);
                set(t, Ch.HEAD_PITCH, 0.12f);
                set(t, Ch.R_ARM_PITCH, -0.95f);
                set(t, Ch.L_ARM_PITCH, -0.95f);
                set(t, Ch.R_ARM_YAW, -0.65f);
                set(t, Ch.L_ARM_YAW, 0.65f);
                b[0] = 0.9f; // arms folded in guard
                b[1] = 0.9f;
            } else if (touching && zone != null) {
                Ch armPitch = left ? Ch.L_ARM_PITCH : Ch.R_ARM_PITCH;
                Ch armYaw = left ? Ch.L_ARM_YAW : Ch.R_ARM_YAW;
                Ch legPitch = left ? Ch.L_LEG_PITCH : Ch.R_LEG_PITCH;
                int armIdx = left ? 1 : 0;
                int legIdx = left ? 3 : 2;
                switch (zone) {
                    case HEAD -> {
                        if (gesture == TouchGesture.PAT) {
                            set(t, Ch.HEAD_PITCH, 0.5f + 0.05f * (float) Math.sin(time() * 6f));
                            set(t, Ch.TORSO_PITCH, 0.06f);
                            set(t, Ch.R_ARM_PITCH, -0.2f);
                            set(t, Ch.L_ARM_PITCH, -0.2f);
                        } else {
                            set(t, Ch.HEAD_PITCH, Mth.clamp(dP * 0.9f, -0.5f, 0.55f));
                            set(t, Ch.HEAD_YAW, Mth.clamp(-dY * 0.9f, -0.6f, 0.6f));
                        }
                    }
                    case FACE -> {
                        if (gesture == TouchGesture.CARESS) {
                            // leans into the hand: head tips slightly down and follows the stroke, body sways a touch
                            set(t, Ch.HEAD_PITCH, 0.12f + 0.03f * (float) Math.sin(time() * 5f));
                            set(t, Ch.HEAD_YAW, Mth.clamp(-dY * 0.7f, -0.45f, 0.45f));
                            set(t, Ch.TORSO_ROLL, Mth.clamp(-dY * 0.08f, -0.06f, 0.06f));
                        } else {
                            set(t, Ch.HEAD_PITCH, Mth.clamp(dP * 0.6f, -0.4f, 0.4f));
                            set(t, Ch.HEAD_YAW, Mth.clamp(-dY * 0.7f, -0.5f, 0.5f));
                        }
                    }
                    case ARM -> {
                        float pitch = Mth.clamp(dP * 1.7f, -2.3f, 1.0f);
                        set(t, armPitch, pitch);
                        set(t, armYaw, Mth.clamp(-dY * 1.3f, -1.3f, 1.3f));
                        b[armIdx] = Mth.clamp(0.25f + 0.3f * Math.abs(pitch), 0f, 1.2f);
                        set(t, Ch.TORSO_ROLL, Mth.clamp(-dY * 0.1f, -0.1f, 0.1f));
                    }
                    case HAND -> {
                        if (TouchClient.leading()) {
                            // being led by the hand: the held arm reaches out toward you, slightly bent, while she walks beside you
                            set(t, armPitch, -0.3f);
                            set(t, left ? Ch.L_ARM_ROLL : Ch.R_ARM_ROLL, left ? -0.45f : 0.45f); // left arm: -roll is outward
                            b[armIdx] = 0.3f;
                            break;
                        }
                        float bend = Mth.clamp(0.15f - dP * 2.5f, 0f, 2.5f);
                        set(t, armPitch, Mth.clamp(-0.3f * bend, -1.0f, 0f));
                        set(t, armYaw, Mth.clamp(-dY * 0.9f, -1.0f, 1.0f));
                        b[armIdx] = bend;
                        set(t, Ch.TORSO_ROLL, Mth.clamp(-dY * 0.1f, -0.1f, 0.1f));
                    }
                    case LEG -> {
                        float pitch = Mth.clamp(dP * 1.5f, -1.6f, 0.8f);
                        set(t, legPitch, pitch);
                        b[legIdx] = Mth.clamp(-0.6f * pitch, 0f, 1.6f);
                    }
                    case KNEE -> {
                        float bend = Mth.clamp(0.1f - dP * 2.3f, 0f, 2.3f);
                        set(t, legPitch, -0.35f * bend);
                        b[legIdx] = bend;
                    }
                    default -> { }
                }
            }
        }

        for (int i = 0; i < N; i++) cur[i] += (t[i] - cur[i]) * 0.22f;
        for (int i = 0; i < 4; i++) curBend[i] += (b[i] - curBend[i]) * 0.25f;

        float[] out = new float[InteractionPose.SIZE];
        out[InteractionPose.W] = weight;
        out[InteractionPose.HEAD_X] = cur[Ch.HEAD_PITCH.ordinal()] * InteractionPose.sign(Ch.HEAD_PITCH);
        out[InteractionPose.HEAD_Y] = cur[Ch.HEAD_YAW.ordinal()] * InteractionPose.sign(Ch.HEAD_YAW);
        out[InteractionPose.TORSO_X] = cur[Ch.TORSO_PITCH.ordinal()] * InteractionPose.sign(Ch.TORSO_PITCH);
        out[InteractionPose.TORSO_Z] = cur[Ch.TORSO_ROLL.ordinal()] * InteractionPose.sign(Ch.TORSO_ROLL);
        // arms/legs are written straight to the bone that was grabbed (no swapElfArms)
        out[InteractionPose.R_ARM_X] = cur[Ch.R_ARM_PITCH.ordinal()] * InteractionPose.sign(Ch.R_ARM_PITCH);
        out[InteractionPose.R_ARM_Y] = cur[Ch.R_ARM_YAW.ordinal()] * InteractionPose.sign(Ch.R_ARM_YAW);
        out[InteractionPose.R_ARM_Z] = cur[Ch.R_ARM_ROLL.ordinal()] * InteractionPose.sign(Ch.R_ARM_ROLL);
        out[InteractionPose.L_ARM_X] = cur[Ch.L_ARM_PITCH.ordinal()] * InteractionPose.sign(Ch.L_ARM_PITCH);
        out[InteractionPose.L_ARM_Y] = cur[Ch.L_ARM_YAW.ordinal()] * InteractionPose.sign(Ch.L_ARM_YAW);
        out[InteractionPose.L_ARM_Z] = cur[Ch.L_ARM_ROLL.ordinal()] * InteractionPose.sign(Ch.L_ARM_ROLL);
        out[InteractionPose.R_LEG_X] = cur[Ch.R_LEG_PITCH.ordinal()] * InteractionPose.sign(Ch.R_LEG_PITCH);
        out[InteractionPose.L_LEG_X] = cur[Ch.L_LEG_PITCH.ordinal()] * InteractionPose.sign(Ch.L_LEG_PITCH);
        return out;
    }
}
