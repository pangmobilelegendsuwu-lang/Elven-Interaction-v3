package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.InteractNet;
import com.elvencompanions.interactions.StargazeMath;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Client mirror of the stargazing session: which phase we are in and for how long, so the elf's pose, the camera and the player's
 * animation line up. The server only sends phase CHANGES; ticks within a phase are counted here.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class StargazeClient {
    private static int phase = StargazeMath.PHASE_END;
    private static int elfEntityId = -1;
    private static int side;
    private static int gazeTicks;
    private static int phaseTicks;

    private StargazeClient() {}

    public static boolean active() {
        return phase != StargazeMath.PHASE_END;
    }

    public static int phase() {
        return phase;
    }

    public static int elfEntityId() {
        return elfEntityId;
    }

    /** +1: she is on YOUR right, -1: on your left. */
    public static int side() {
        return side;
    }

    public static int gazeTicks() {
        return gazeTicks;
    }

    /** Seconds-in-ticks since the current phase began. */
    public static float phaseTime(float partial) {
        return phaseTicks + partial;
    }

    /** Ticks since the scripted part began; keeps counting through the HOLD phase. 0 before it starts. */
    public static float scriptTime(float partial) {
        if (phase == StargazeMath.PHASE_SCRIPT) return phaseTicks + partial;
        if (phase == StargazeMath.PHASE_HOLD) return StargazeMath.scriptLength(gazeTicks) + phaseTicks + partial;
        return 0f;
    }

    public static void onState(InteractNet.StargazeStateS2C p) {
        Minecraft mc = Minecraft.getInstance();
        if (p.phase() == StargazeMath.PHASE_END) {
            stop(mc);
            return;
        }
        boolean changed = p.phase() != phase || p.elfEntityId() != elfEntityId;
        phase = p.phase();
        elfEntityId = p.elfEntityId();
        side = p.side();
        gazeTicks = p.gazeTicks();
        if (changed) phaseTicks = 0;
        StowState.begin(elfEntityId); // she puts her bow away for the whole session
        if (changed && phase == StargazeMath.PHASE_SCRIPT && mc.player instanceof AbstractClientPlayer acp) {
            PlayerAnimBridge.playStargaze(acp, side, gazeTicks);
        }
    }

    private static void stop(Minecraft mc) {
        if (phase != StargazeMath.PHASE_END) {
            StowState.end(elfEntityId);
            if (mc.player instanceof AbstractClientPlayer acp) PlayerAnimBridge.stop(acp);
        }
        phase = StargazeMath.PHASE_END;
        phaseTicks = 0;
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post e) {
        if (phase == StargazeMath.PHASE_END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            phase = StargazeMath.PHASE_END;
            return;
        }
        phaseTicks++;
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        phase = StargazeMath.PHASE_END;
        phaseTicks = 0;
    }
}
