package com.elvencompanions.interactions.client;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.BondData;
import com.elvencompanions.interactions.InteractionType;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import org.joml.Matrix4f;

/**
 * Radial interaction wheel: hold the key while looking at your elf, move the mouse to a slice, release to select
 * (a left click also selects). Slices are drawn as triangle strips; locked / cooling-down slices are dimmed.
 */
public class InteractionWheelScreen extends Screen {
    private static final float INNER = 44f;
    private static final float OUTER = 118f;
    private static final float GAP_RAD = 0.035f;

    private final int entityId;
    private final String elfName;
    private final KeyMapping key;
    private int hovered = -1;

    public InteractionWheelScreen(ElfEntity elf, KeyMapping key) {
        super(Component.translatable("gui.elven_companions.interact.wheel"));
        this.entityId = elf.getId();
        this.elfName = elf.getDisplayName().getString();
        this.key = key;
    }

    @Override
    protected void init() {
        ClientInteractions.requestBond(null, entityId);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        // keep the world fully visible behind the wheel
    }

    private ClientInteractions.Bond bond() {
        return ClientInteractions.bond(null, entityId);
    }

    private boolean available(InteractionType t) {
        ClientInteractions.Bond b = bond();
        int lv = BondData.levelOf(b == null ? 0 : b.affection());
        return lv >= t.minBond && (b == null || b.cooldownLeft(t) <= 0);
    }

    @Override
    public void tick() {
        if (minecraft == null) return;
        long window = minecraft.getWindow().getWindow();
        if (!InputConstants.isKeyDown(window, key.getKey().getValue())) {
            select();
        }
    }

    /** Slices after the interaction types: Gift. (Touching is built into the elf: aim and hold right-click.) */
    private static final int EXTRAS = 1;

    private static int total() {
        return InteractionType.values().length + EXTRAS;
    }

    private void select() {
        InteractionType[] all = InteractionType.values();
        if (hovered >= 0 && hovered < all.length) {
            if (available(all[hovered])) ClientInteractions.requestInteraction(null, entityId, all[hovered]);
        } else if (hovered == all.length) {
            ClientInteractions.requestGift(null, entityId);
        }
        if (minecraft != null) minecraft.setScreen(null);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            select();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void updateHover(int mx, int my) {
        float dx = mx - width / 2f;
        float dy = my - height / 2f;
        if (Math.sqrt(dx * dx + dy * dy) < INNER * 0.7f) {
            hovered = -1;
            return;
        }
        int n = total();
        double ang = Math.atan2(dx, -dy); // clockwise from "up"
        if (ang < 0) ang += Math.PI * 2;
        double sa = Math.PI * 2 / n;
        hovered = (int) Math.round(ang / sa) % n;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        updateHover(mx, my);
        InteractionType[] all = InteractionType.values();
        int n = total();
        float cx = width / 2f;
        float cy = height / 2f;
        double sa = Math.PI * 2 / n;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        Matrix4f m = g.pose().last().pose();
        for (int i = 0; i < n; i++) {
            boolean ok = i >= all.length || available(all[i]);
            boolean hov = i == hovered;
            int r, gr, b, a;
            if (!ok) { r = 40; gr = 40; b = 40; a = 150; }
            else if (hov) { r = 201; gr = 168; b = 74; a = 215; }
            else { r = 28; gr = 52; b = 34; a = 190; }
            double a0 = i * sa - sa / 2 + GAP_RAD;
            double a1 = i * sa + sa / 2 - GAP_RAD;
            float outer = hov ? OUTER + 6f : OUTER;
            BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);
            int steps = 10;
            for (int s = 0; s <= steps; s++) {
                double a_ = a0 + (a1 - a0) * s / steps;
                float sn = (float) Math.sin(a_);
                float cs = (float) Math.cos(a_);
                bb.addVertex(m, cx + INNER * sn, cy - INNER * cs, 0f).setColor(r, gr, b, a);
                bb.addVertex(m, cx + outer * sn, cy - outer * cs, 0f).setColor(r, gr, b, a);
            }
            BufferUploader.drawWithShader(bb.buildOrThrow());
        }
        RenderSystem.disableBlend();

        // labels
        for (int i = 0; i < n; i++) {
            double mid = i * sa;
            float rr = (INNER + OUTER) / 2f;
            int lx = Math.round(cx + rr * (float) Math.sin(mid));
            int ly = Math.round(cy - rr * (float) Math.cos(mid));
            boolean ok = i >= all.length || available(all[i]);
            Component label = i < all.length ? Component.translatable(all[i].langKey())
                    : Component.translatable("gui.elven_companions.gift.button");
            g.drawCenteredString(font, label, lx, ly - 4, ok ? 0xFFEFEFD0 : 0xFF777777);
        }

        // centre readout
        g.drawCenteredString(font, Component.literal(elfName), (int) cx, (int) cy - 16, 0xFFE9D9A0);
        ClientInteractions.Bond b = bond();
        int lv = BondData.levelOf(b == null ? 0 : b.affection());
        g.drawCenteredString(font, Component.translatable("gui.elven_companions.interact.bond." + lv), (int) cx, (int) cy - 4, 0xFF7FD68C);
        if (hovered >= all.length) {
            g.drawCenteredString(font, Component.translatable("gui.elven_companions.gift.wheel"), (int) cx, (int) cy + 8, 0xFFB0B0B0);
        } else if (hovered >= 0) {
            InteractionType t = all[hovered];
            Component sub;
            if (lv < t.minBond) {
                sub = Component.translatable("gui.elven_companions.interact.locked",
                        Component.translatable("gui.elven_companions.interact.bond." + t.minBond));
            } else if (b != null && b.cooldownLeft(t) > 0) {
                sub = Component.translatable("gui.elven_companions.interact.cooldown", b.cooldownLeft(t));
            } else {
                sub = Component.translatable("gui.elven_companions.interact.desc." + t.id);
            }
            g.drawCenteredString(font, sub, (int) cx, (int) cy + 8, 0xFFB0B0B0);
        }
    }
}
