package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.ElvenInteractions;
import com.elvencompanions.interactions.InteractNet;
import com.elvencompanions.interactions.TouchGesture;
import com.elvencompanions.interactions.TouchManager;
import com.elvencompanions.interactions.TouchZone;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import com.elvencompanions.entity.ElfEntity;
import java.util.UUID;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Client side of touch mode: mirrors the server's state (hovered zone, gesture, comfort, refusing), reports the right-click
 * held/released edge, blocks vanilla attack/use while touching (so right-click cannot open the elf's menu), tracks the
 * drag (how far the view moved since the grab, used for the elf's pose and the first-person hand) and draws the HUD.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class TouchClient {
    private static boolean active;
    private static int elfEntityId = -1;
    private static TouchZone zone;
    private static boolean left;
    private static TouchGesture gesture = TouchGesture.NONE;
    private static float comfort = TouchManager.DEFAULT_START;
    private static boolean locked;
    private static boolean touching;
    private static long lastStateMs;

    private static boolean leading;
    private static boolean pinned;
    private static boolean wasTouching;
    private static long lingerUntilMs;

    // built-in body touch: a press on your own elf is held back for a moment to tell a click (opens her menu) from a hold (touch)
    private static int pendingElf = -1;
    private static int pendingTicks;
    private static long suppressUseUntilMs;
    private static boolean startedHolding;

    private static boolean keyHeld;
    private static boolean sentHeld;
    private static float grabYaw;
    private static float grabPitch;
    /** Smoothed drag, radians: how far the view has moved since the grab (0 when not touching). */
    private static float dragYaw;
    private static float dragPitch;

    private TouchClient() {}

    public static boolean active() {
        return active;
    }

    public static int elfEntityId() {
        return elfEntityId;
    }

    public static TouchZone zone() {
        return zone;
    }

    public static boolean left() {
        return left;
    }

    public static TouchGesture gesture() {
        return gesture;
    }

    public static float comfort() {
        return comfort;
    }

    public static boolean locked() {
        return locked;
    }

    public static boolean touching() {
        return touching;
    }

    /** Holding her hand and walking: movement is not frozen and she follows you. */
    public static boolean leading() {
        return active && leading;
    }

    public static boolean pinned() {
        return pinned;
    }

    public static boolean keyHeld() {
        return keyHeld;
    }

    /** "Left Hand", "Right Knee", "Head"... (left/right are the ELF's own sides). */
    public static Component zoneLabel() {
        if (zone == null) return null;
        Component z = Component.translatable(zone.langKey());
        if (zone == TouchZone.ARM || zone == TouchZone.HAND || zone == TouchZone.LEG || zone == TouchZone.KNEE) {
            return Component.translatable("gui.elven_companions.touch.sided",
                    Component.translatable(left ? "gui.elven_companions.touch.side.left" : "gui.elven_companions.touch.side.right"), z);
        }
        return z;
    }

    public static float dragYaw() {
        return dragYaw;
    }

    public static float dragPitch() {
        return dragPitch;
    }

    // ------------------------------------------------------------------ server -> client

    public static void onState(InteractNet.TouchStateS2C p) {
        Minecraft mc = Minecraft.getInstance();
        if (!p.active()) {
            stop(mc);
            return;
        }
        if (!active) {
            active = true;
            keyHeld = startedHolding;
            sentHeld = startedHolding; // a session started by a hold already told the server the button is down
            startedHolding = false;
            wasTouching = false;
            dragYaw = dragPitch = 0f;
            ClientInteractions.resetCancel();
            if (mc.player instanceof AbstractClientPlayer acp) PlayerAnimBridge.startTouch(acp);
        }
        elfEntityId = p.elfEntityId();
        StowState.begin(elfEntityId);
        zone = p.zone();
        left = p.left();
        gesture = p.gesture();
        comfort = p.comfort();
        locked = p.locked();
        touching = p.touching();
        leading = p.leading();
        pinned = p.pinned();
        lastStateMs = System.currentTimeMillis();
    }

    private static void stop(Minecraft mc) {
        if (active) {
            StowState.end(elfEntityId);
            lingerUntilMs = System.currentTimeMillis() + 1800L; // keep the meter on screen a moment
        }
        if (active && mc.player instanceof AbstractClientPlayer acp) PlayerAnimBridge.stopTouch(acp);
        active = false;
        zone = null;
        gesture = TouchGesture.NONE;
        touching = false;
        locked = false;
        leading = false;
        pinned = false;
        keyHeld = false;
        sentHeld = false;
        wasTouching = false;
    }

    // ------------------------------------------------------------------ events

    private static final UUID NO_ID = new UUID(0L, 0L);

    /** The owned elf under the crosshair within touching reach, or null. */
    private static ElfEntity aimedElf(Minecraft mc) {
        if (mc.player != null && mc.crosshairPickEntity instanceof ElfEntity elf && elf.isOwnedBy(mc.player)
                && elf.isAlive() && elf.distanceTo(mc.player) <= 3.3f) {
            return elf;
        }
        return null;
    }

    /** A press held back long enough becomes a touch; a short press is replayed as the normal right-click (her menu). */
    private static void handlePending(Minecraft mc) {
        if (pendingElf < 0) return;
        Entity ent = mc.level.getEntity(pendingElf);
        if (!(ent instanceof ElfEntity elf) || mc.screen != null || active) {
            pendingElf = -1;
            return;
        }
        if (mc.options.keyUse.isDown()) {
            if (++pendingTicks >= Cfg.CLIENT.touchHoldTicks.get()) {
                startedHolding = true;
                suppressUseUntilMs = System.currentTimeMillis() + 1000L;
                PacketDistributor.sendToServer(new InteractNet.TouchStartC2S(NO_ID, pendingElf, true), new CustomPacketPayload[0]);
                pendingElf = -1;
            }
        } else {
            // released early: it was an ordinary click
            if (mc.gameMode != null) {
                mc.gameMode.interact(mc.player, elf, InteractionHand.MAIN_HAND);
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
            pendingElf = -1;
        }
    }

    /** L: pin / unpin the selected part; with no session, start one on the elf you are aiming at and pin what you aim at. */
    private static void handleLockKey(Minecraft mc) {
        while (InteractClientSetup.TOUCH_LOCK_KEY.consumeClick()) {
            if (mc.screen != null || !Cfg.COMMON.touchEnabled.get() || ClientInteractions.selfActive()) continue;
            if (active) {
                PacketDistributor.sendToServer(new InteractNet.TouchPinC2S(NO_ID, elfEntityId), new CustomPacketPayload[0]);
                continue;
            }
            ElfEntity elf = aimedElf(mc);
            if (elf == null) {
                mc.player.displayClientMessage(Component.translatable("message.elven_companions.touch.aim_first"), true);
            } else {
                PacketDistributor.sendToServer(new InteractNet.TouchPinC2S(NO_ID, elf.getId()), new CustomPacketPayload[0]);
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            pendingElf = -1;
            if (active) stop(mc);
            return;
        }
        handlePending(mc);
        handleLockKey(mc);
        if (!active) {
            dragYaw *= 0.7f;
            dragPitch *= 0.7f;
            return;
        }
        if (System.currentTimeMillis() - lastStateMs > 4000L) {
            stop(mc);
            return;
        }
        // right-click held? (a screen open counts as released)
        keyHeld = mc.screen == null && mc.options.keyUse.isDown();
        if (keyHeld != sentHeld) {
            sentHeld = keyHeld;
            PacketDistributor.sendToServer(new InteractNet.TouchHoldC2S(keyHeld), new CustomPacketPayload[0]);
        }
        // drag = how far the view has moved since the grab (also for a grab pinned with L); not while leading her by the hand
        if (touching && !wasTouching) {
            grabYaw = mc.player.getYRot();
            grabPitch = mc.player.getXRot();
        }
        wasTouching = touching;
        float ty = 0f;
        float tp = 0f;
        if (touching && !leading) {
            ty = Mth.clamp(Mth.wrapDegrees(mc.player.getYRot() - grabYaw) * Mth.DEG_TO_RAD, -1.2f, 1.2f);
            tp = Mth.clamp((mc.player.getXRot() - grabPitch) * Mth.DEG_TO_RAD, -1.0f, 1.0f);
        }
        dragYaw += (ty - dragYaw) * 0.35f;
        dragPitch += (tp - dragPitch) * 0.35f;
        PlayerAnimBridge.setTouchHolding(touching);
        PlayerAnimBridge.setTouchLead(touching && leading, left);
    }

    /**
     * Body touch: right-click on your own elf is held back; holding it starts touching, a short press is replayed as a normal click.
     * During a session (and while the start request is in flight) vanilla attack/use/pick is blocked, so right-click never opens her
     * menu and left-click never hits her.
     */
    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered e) {
        if (active || System.currentTimeMillis() < suppressUseUntilMs) {
            e.setCanceled(true);
            e.setSwingHand(false);
            return;
        }
        if (!e.isUseItem()) return;
        if (pendingElf >= 0) { // the repeat events while the button stays down
            e.setCanceled(true);
            e.setSwingHand(false);
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.isShiftKeyDown() || mc.player.isPassenger() || !Cfg.COMMON.touchEnabled.get()
                || ClientInteractions.selfActive() || StargazeClient.active()) {
            return;
        }
        ElfEntity elf = aimedElf(mc);
        if (elf != null) {
            pendingElf = elf.getId();
            pendingTicks = 0;
            e.setCanceled(true);
            e.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        if (!Cfg.CLIENT.touchHud.get() || (!active && System.currentTimeMillis() > lingerUntilMs)) return;
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g = e.getGuiGraphics();
        int w = g.guiWidth();
        int h = g.guiHeight();
        var font = mc.font;

        // comfort meter
        int bw = 120;
        int bx = w / 2 - bw / 2;
        int by = 20;
        g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.comfort"), w / 2, by - 11, 0xFFE9D9A0);
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 9, 0xFF000000);
        g.fill(bx, by, bx + bw, by + 8, 0xFF1F2E22);
        int col = comfort < TouchManager.lockLow() ? 0xFFD9534F : comfort < TouchManager.lockHigh() ? 0xFFE8923C
                : comfort < 60f ? 0xFFE8D44F : 0xFF4FA860;
        if (locked && (System.currentTimeMillis() / 250L) % 2L == 0L) col = 0xFFFF8080;
        g.fill(bx, by, bx + Math.round(bw * comfort / 100f), by + 8, col);
        g.fill(bx + Math.round(bw * TouchManager.lockLow() / 100f), by - 2, bx + Math.round(bw * TouchManager.lockLow() / 100f) + 1, by + 10, 0xFFFFFFFF);

        // what am I pointing at / holding
        if (zone != null) {
            boolean bad = zone.guarded() || locked || gesture == TouchGesture.ROUGH;
            Component zl = zoneLabel();
            if (touching && keyHeld) {
                Component held = Component.translatable("gui.elven_companions.touch.holding", zl);
                g.drawCenteredString(font, held, w / 2, h / 2 + 14, bad ? 0xFFFF9A8A : 0xFFFFE9A0);
            } else {
                g.drawCenteredString(font, zl, w / 2, h / 2 + 14, bad ? 0xFFFF9A8A : 0xFFB8F0C0);
            }
            if (gesture == TouchGesture.PAT) {
                g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.pat"), w / 2, h / 2 + 25, 0xFFB8F0C0);
            } else if (gesture == TouchGesture.CARESS) {
                g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.caress"), w / 2, h / 2 + 25, 0xFFB8F0C0);
            } else if (gesture == TouchGesture.ROUGH) {
                g.drawCenteredString(font, Component.translatable("gui.elven_companions.touch.rough"), w / 2, h / 2 + 25, 0xFFFF9A8A);
            }
        }
        if (Cfg.CLIENT.debugTouch.get()) {
            String dbg = String.format("zone=%s left=%s gesture=%s touching=%s locked=%s comfort=%.1f drag=(%.0f, %.0f) deg bend=[%.2f %.2f %.2f %.2f]",
                    zone, left, gesture, touching, locked, comfort, Math.toDegrees(dragYaw), Math.toDegrees(dragPitch),
                    TouchPose.bend(0), TouchPose.bend(1), TouchPose.bend(2), TouchPose.bend(3));
            g.drawCenteredString(font, dbg, w / 2, h - 68, 0xFFFFFF55);
        }
        if (!active) return; // only the meter lingers after a grab ends
        Component hint = locked ? Component.translatable("gui.elven_companions.touch.refusing")
                : leading ? Component.translatable("gui.elven_companions.touch.leading")
                : pinned ? Component.translatable("gui.elven_companions.touch.pinned", zoneLabel() == null ? Component.empty() : zoneLabel())
                : Component.translatable("gui.elven_companions.touch.hint");
        g.drawCenteredString(font, hint, w / 2, h - 52, locked ? 0xFFFF9A8A : 0xFFB0B0B0);
    }
}
