package com.elvencompanions.interactions.client;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Clip.Ch;
import com.elvencompanions.interactions.StargazeMath;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

/**
 * The elf's head/torso during stargazing, as ADDITIVE offsets over her normal (seated) pose:
 *  SEARCH      she looks around for somewhere to sit (head sweeps side to side, slightly up)
 *  SCRIPT      she turns her head toward you (a beat after you start), holds, then tips her head back to the sky
 *  HOLD        she keeps gazing at the sky, with a faint sway, for as long as the session lasts
 * Vanilla angle convention converted through {@link InteractionPose#sign}; smoothed per frame; fades out when the session ends.
 */
public final class StargazePose {
    private static final int N = Ch.values().length;
    private static final float[] cur = new float[N];
    private static float weight;
    private static int lastElf = -1;
    /** She reacts to you this many ticks after the player starts. */
    private static final float ELF_DELAY = 10f;

    private StargazePose() {}

    private static void set(float[] t, Ch ch, float v) {
        t[ch.ordinal()] = v;
    }

    private static float time() {
        return (System.currentTimeMillis() % 100000L) / 1000f;
    }

    /** @return additive offsets in InteractionPose slot layout (slot 0 = weight), or null when this elf is not stargazing. */
    public static float[] sample(ElfEntity elf) {
        boolean mine = StargazeClient.active() && StargazeClient.elfEntityId() == elf.getId();
        if (mine) lastElf = elf.getId();
        else if (elf.getId() != lastElf) return null;

        weight = Mth.clamp(weight + (mine ? 0.08f : -0.06f), 0f, 1f);
        if (weight <= 0.001f && !mine) {
            lastElf = -1;
            for (int i = 0; i < N; i++) cur[i] = 0f;
            return null;
        }

        float[] t = new float[N];
        if (mine) {
            float partial = Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false);
            int phase = StargazeClient.phase();
            if (phase == StargazeMath.PHASE_SEARCH) {
                float tt = StargazeClient.phaseTime(partial);
                set(t, Ch.HEAD_YAW, 0.7f * (float) Math.sin(tt * 0.16f));
                set(t, Ch.HEAD_PITCH, -0.12f);
            } else if (phase == StargazeMath.PHASE_SCRIPT || phase == StargazeMath.PHASE_HOLD) {
                int gaze = StargazeClient.gazeTicks();
                float tt = StargazeClient.scriptTime(partial) - ELF_DELAY;
                int toPlayer = -StargazeClient.side(); // the player is on the opposite side to the one she is on, from YOUR view
                float a = StargazeMath.smooth(tt / StargazeMath.SETTLE_TICKS);
                float s = StargazeMath.smooth((tt - (StargazeMath.SETTLE_TICKS + gaze)) / StargazeMath.SKY_TURN_TICKS);
                float yaw = toPlayer * 0.9f * a * (1f - s);
                float pitch = 0.1f * a * (1f - s) + (-0.95f) * s;
                if (phase == StargazeMath.PHASE_HOLD) pitch += 0.03f * (float) Math.sin(time() * 1.2f);
                set(t, Ch.HEAD_YAW, yaw);
                set(t, Ch.HEAD_PITCH, pitch);
                set(t, Ch.TORSO_PITCH, -0.1f * s);
            }
        }
        for (int i = 0; i < N; i++) cur[i] += (t[i] - cur[i]) * 0.12f;

        float[] out = new float[InteractionPose.SIZE];
        out[InteractionPose.W] = weight;
        out[InteractionPose.HEAD_X] = cur[Ch.HEAD_PITCH.ordinal()] * InteractionPose.sign(Ch.HEAD_PITCH);
        out[InteractionPose.HEAD_Y] = cur[Ch.HEAD_YAW.ordinal()] * InteractionPose.sign(Ch.HEAD_YAW);
        out[InteractionPose.TORSO_X] = cur[Ch.TORSO_PITCH.ordinal()] * InteractionPose.sign(Ch.TORSO_PITCH);
        return out;
    }
}
