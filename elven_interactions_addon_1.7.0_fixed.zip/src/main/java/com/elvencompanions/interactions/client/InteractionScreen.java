package com.elvencompanions.interactions.client;

import com.elvencompanions.interactions.BondData;
import com.elvencompanions.interactions.InteractionType;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * The separate Interaction GUI opened from the Elven command screen. Draws its own elven-styled panel with plain
 * fills (no new textures required): bond header + one cell per interaction (locked / cooldown / ready).
 */
public class InteractionScreen extends Screen {
    private static final int PANEL_W = 270;
    private static final int COLS = 2;
    private static final int CELL_W = 122;
    private static final int CELL_H = 30;
    private static final int GAP = 8;

    private final Screen parent;
    private final UUID companion;
    private final int entityId;
    private final String elfName;

    private record Cell(InteractionType type, int x, int y) {}

    private final List<Cell> cells = new ArrayList<>();
    private int left;
    private int top;
    private int panelH;
    private Button giftBtn;
    private Button bondMinus;
    private Button bondPlus;

    public InteractionScreen(Screen parent, UUID companion, int entityId, String elfName) {
        super(Component.translatable("gui.elven_companions.interact.title", elfName));
        this.parent = parent;
        this.companion = companion;
        this.entityId = entityId;
        this.elfName = elfName;
    }

    @Override
    protected void init() {
        cells.clear();
        InteractionType[] all = InteractionType.values();
        int rows = (all.length + COLS - 1) / COLS;
        panelH = 62 + rows * (CELL_H + GAP) + 34;
        left = (width - PANEL_W) / 2;
        top = Math.max(4, (height - panelH) / 2);
        for (int i = 0; i < all.length; i++) {
            int cx = left + 10 + (i % COLS) * (CELL_W + GAP);
            int cy = top + 58 + (i / COLS) * (CELL_H + GAP);
            cells.add(new Cell(all[i], cx, cy));
        }
        addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.back"), b -> onClose())
                .bounds(left + PANEL_W / 2 - 40, top + panelH - 28, 80, 20).build());
        // Gift button: on the LEFT side of the panel (touching is built into the elf now: aim at her and hold right-click)
        int tw = 84;
        int tx = Math.max(2, left - tw - 8);
        giftBtn = addRenderableWidget(Button.builder(Component.translatable("gui.elven_companions.gift.button"), b -> {
                    ClientInteractions.requestGift(companion, entityId);
                    if (minecraft != null) minecraft.setScreen(null);
                })
                .bounds(tx, top + 58, tw, 24)
                .tooltip(Tooltip.create(Component.translatable("gui.elven_companions.gift.tip"))).build());
        // Creative-only relationship test buttons (the server re-checks creative mode).
        bondMinus = addRenderableWidget(Button.builder(Component.literal("-"), b -> adjust(false))
                .bounds(left + 10, top + panelH - 28, 20, 20)
                .tooltip(Tooltip.create(Component.translatable("gui.elven_companions.interact.dev.minus"))).build());
        bondPlus = addRenderableWidget(Button.builder(Component.literal("+"), b -> adjust(true))
                .bounds(left + 34, top + panelH - 28, 20, 20)
                .tooltip(Tooltip.create(Component.translatable("gui.elven_companions.interact.dev.plus"))).build());
        updateCreativeButtons();
        ClientInteractions.requestBond(companion, entityId);
    }

    private void adjust(boolean up) {
        ClientInteractions.adjustBond(companion, entityId, up, hasShiftDown());
    }

    private void updateCreativeButtons() {
        boolean creative = minecraft != null && minecraft.player != null && minecraft.player.isCreative();
        bondMinus.visible = bondMinus.active = creative;
        bondPlus.visible = bondPlus.active = creative;
    }

    @Override
    public void tick() {
        updateCreativeButtons();
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private ClientInteractions.Bond bond() {
        return ClientInteractions.bond(companion, entityId);
    }

    private List<Component> pendingTip;

    /**
     * Screen#render calls renderBackground itself. We used to call it a second time AFTER drawing the panel, which in
     * 1.21 blurs everything drawn so far (that was the blurry GUI). Now the dim + panel are drawn inside the single
     * background pass, with a plain gradient instead of the blur, and the widgets/tooltip are drawn on top.
     */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xC0101010, 0xD0101010);
        drawPanel(g, mx, my);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        if (pendingTip != null) {
            g.renderComponentTooltip(font, pendingTip, mx, my);
            pendingTip = null;
        }
    }

    private void drawPanel(GuiGraphics g, int mx, int my) {
        // panel
        g.fill(left - 2, top - 2, left + PANEL_W + 2, top + panelH + 2, 0xFFC9A84A);
        g.fill(left, top, left + PANEL_W, top + panelH, 0xF0101A12);
        g.drawCenteredString(font, title, left + PANEL_W / 2, top + 8, 0xFFE9D9A0);

        ClientInteractions.Bond b = bond();
        int aff = b == null ? 0 : b.affection();
        int lv = BondData.levelOf(aff);
        g.drawCenteredString(font, Component.translatable("gui.elven_companions.interact.bond." + lv), left + PANEL_W / 2, top + 22, 0xFF7FD68C);
        // affection bar toward the next level
        int barX = left + 40;
        int barW = PANEL_W - 80;
        int lo = BondData.THRESHOLDS[lv];
        int hi = lv >= BondData.maxLevel() ? BondData.MAX : BondData.THRESHOLDS[lv + 1];
        float frac = hi <= lo ? 1f : Math.min(1f, (aff - lo) / (float) (hi - lo));
        g.fill(barX - 1, top + 35, barX + barW + 1, top + 43, 0xFF000000);
        g.fill(barX, top + 36, barX + barW, top + 42, 0xFF1F2E22);
        g.fill(barX, top + 36, barX + Math.round(barW * frac), top + 42, 0xFF4FA860);
        g.drawCenteredString(font, aff + " / " + hi, left + PANEL_W / 2, top + 44 - 0, 0xFF9AAA9E);

        List<Component> tip = null;
        for (Cell c : cells) {
            State s = state(c.type, lv, b);
            boolean hover = mx >= c.x && mx < c.x + CELL_W && my >= c.y && my < c.y + CELL_H;
            int border = s == State.READY ? (hover ? 0xFFFFE9A0 : 0xFFC9A84A) : 0xFF4A4A4A;
            int fill = s == State.READY ? (hover ? 0xFF2F4A34 : 0xFF1F3324) : 0xFF1A1A1A;
            g.fill(c.x - 1, c.y - 1, c.x + CELL_W + 1, c.y + CELL_H + 1, border);
            g.fill(c.x, c.y, c.x + CELL_W, c.y + CELL_H, fill);
            int tc = s == State.READY ? 0xFFEFEFD0 : 0xFF777777;
            g.drawCenteredString(font, Component.translatable(c.type.langKey()), c.x + CELL_W / 2, c.y + 6, tc);
            Component sub = switch (s) {
                case READY -> Component.translatable("gui.elven_companions.interact.ready");
                case COOLDOWN -> Component.translatable("gui.elven_companions.interact.cooldown", b.cooldownLeft(c.type));
                case LOCKED -> Component.translatable("gui.elven_companions.interact.locked",
                        Component.translatable("gui.elven_companions.interact.bond." + c.type.minBond));
            };
            g.drawCenteredString(font, sub, c.x + CELL_W / 2, c.y + 17, s == State.READY ? 0xFF7FD68C : 0xFF8A6A6A);
            if (hover) {
                tip = List.of(Component.translatable(c.type.langKey()),
                        Component.translatable("gui.elven_companions.interact.desc." + c.type.id),
                        Component.translatable("gui.elven_companions.interact.gain", c.type.affection));
            }
        }
        pendingTip = tip;
    }

    private enum State { READY, COOLDOWN, LOCKED }

    private static State state(InteractionType t, int lv, ClientInteractions.Bond b) {
        if (lv < t.minBond) return State.LOCKED;
        if (b != null && b.cooldownLeft(t) > 0) return State.COOLDOWN;
        return State.READY;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            ClientInteractions.Bond b = bond();
            int lv = BondData.levelOf(b == null ? 0 : b.affection());
            for (Cell c : cells) {
                if (mx >= c.x && mx < c.x + CELL_W && my >= c.y && my < c.y + CELL_H) {
                    if (state(c.type, lv, b) == State.READY) {
                        ClientInteractions.requestInteraction(companion, entityId, c.type);
                        if (minecraft != null) minecraft.setScreen(null);
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
