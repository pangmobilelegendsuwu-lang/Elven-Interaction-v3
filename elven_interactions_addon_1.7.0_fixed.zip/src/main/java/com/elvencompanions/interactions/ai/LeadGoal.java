package com.elvencompanions.interactions.ai;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.TouchManager;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/**
 * Top-priority goal that keeps the elf at the player's side while they lead her by the hand (touch mode, HAND grabbed). It only
 * runs while TouchManager reports a lead target for her, so her normal behaviour is untouched otherwise. She speeds up a little
 * the further she falls behind and stops when she is beside you.
 */
public final class LeadGoal extends Goal {
    private final ElfEntity elf;
    private int recalc;

    public LeadGoal(ElfEntity elf) {
        this.elf = elf;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return TouchManager.leadTarget(elf) != null;
    }

    @Override
    public boolean canContinueToUse() {
        return TouchManager.leadTarget(elf) != null;
    }

    @Override
    public boolean isInterruptable() {
        return false;
    }

    @Override
    public void start() {
        recalc = 0;
    }

    @Override
    public void tick() {
        Vec3 t = TouchManager.leadTarget(elf);
        if (t == null) return;
        double dist = elf.position().distanceTo(t);
        if (dist > 0.35) {
            if (--recalc <= 0) {
                recalc = 3;
                elf.getNavigation().moveTo(t.x, t.y, t.z, 1.0 + Math.min(0.7, dist * 0.3));
            }
        } else {
            elf.getNavigation().stop();
        }
    }

    @Override
    public void stop() {
        elf.getNavigation().stop();
    }
}
