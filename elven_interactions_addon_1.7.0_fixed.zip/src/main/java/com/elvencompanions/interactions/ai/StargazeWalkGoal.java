package com.elvencompanions.interactions.ai;

import com.elvencompanions.entity.ElfEntity;
import com.elvencompanions.interactions.Cfg;
import com.elvencompanions.interactions.StargazeManager;
import java.util.EnumSet;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/**
 * Top-priority goal that walks the elf (slowly) to her stargazing seat. It only runs while the StargazeManager has a job for her
 * in the WALK phase, so her normal behaviour is unaffected the rest of the time. Priority -1 outranks all her own goals; it uses
 * the MOVE and LOOK flags only, so swimming (JUMP) keeps working.
 */
public final class StargazeWalkGoal extends Goal {
    private final ElfEntity elf;
    private int recalc;

    public StargazeWalkGoal(ElfEntity elf) {
        this.elf = elf;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    private StargazeManager.Job job() {
        StargazeManager.Job j = StargazeManager.jobFor(elf);
        return j != null && j.walking() ? j : null;
    }

    @Override
    public boolean canUse() {
        return job() != null;
    }

    @Override
    public boolean canContinueToUse() {
        return job() != null;
    }

    @Override
    public boolean isInterruptable() {
        return false;
    }

    @Override
    public void start() {
        recalc = 0;
    }

    @Override
    public void tick() {
        StargazeManager.Job j = job();
        if (j == null) return;
        Vec3 t = j.target();
        if (--recalc <= 0) {
            recalc = 10;
            elf.getNavigation().moveTo(t.x, t.y, t.z, Cfg.COMMON.stargazeWalkSpeed.get());
        }
        elf.getLookControl().setLookAt(t.x, t.y + 1.2, t.z, 20.0F, 20.0F);
    }

    @Override
    public void stop() {
        elf.getNavigation().stop();
    }
}
