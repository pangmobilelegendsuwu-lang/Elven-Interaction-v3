package com.elvencompanions.interactions;

import com.elvencompanions.data.ElfManager;
import com.elvencompanions.entity.ElfDialogue;
import com.elvencompanions.entity.ElfEntity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Stargazing: a multi-step session, server-authoritative.
 *
 *   SEARCH  she looks around for a moment (a seat was already found when you asked)
 *   WALK    she walks slowly to the seat (StargazeWalkGoal does the movement) and sits down (her own sit stance)
 *   SEATED  she waits; walk close to her to join
 *   SCRIPT  you are seated beside her on a hidden seat entity; you look at her for a few seconds, then both look up
 *   HOLD    the scripted part is over; you stay seated and she keeps gazing until you SNEAK (vanilla dismount), or it is interrupted
 *
 * Interrupts: damage to either of you, death, logout, dimension change, combat/rest/carry on her side, timeouts while walking or waiting.
 * Asking for stargazing again while one is running cancels it.
 */
@EventBusSubscriber(modid = ElvenInteractions.MODID, bus = EventBusSubscriber.Bus.GAME)
public final class StargazeManager {
    public static final String SEAT_TAG = "elven_interactions_seat";
    private static final double ARRIVE_DIST = 0.9;

    public static final class Job {
        final UUID player;
        final UUID elfId;
        final int elfEntityId;
        final SeatFinder.Seat seat;
        int phase = StargazeMath.PHASE_SEARCH;
        int phaseStart;
        int prevStance;
        ArmorStand stand;
        int side;

        Job(UUID player, UUID elfId, int elfEntityId, SeatFinder.Seat seat) {
            this.player = player;
            this.elfId = elfId;
            this.elfEntityId = elfEntityId;
            this.seat = seat;
        }

        public boolean walking() {
            return phase == StargazeMath.PHASE_WALK;
        }

        public Vec3 target() {
            return seat.elf();
        }
    }

    private static final Map<UUID, Job> BY_PLAYER = new HashMap<>();
    private static final Map<UUID, Job> BY_ELF = new HashMap<>();
    private static final Set<UUID> SEATS = new HashSet<>();

    private StargazeManager() {}

    public static boolean isActive(UUID player) {
        return BY_PLAYER.containsKey(player);
    }

    /** The running job for this elf, if any (used by her walk goal). */
    public static Job jobFor(ElfEntity elf) {
        UUID id = elf.getCompanionId();
        return id == null ? null : BY_ELF.get(id);
    }

    private static void fail(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable("message.elven_companions." + key), true);
    }

    // ------------------------------------------------------------------ start / cancel

    public static void start(ServerPlayer p, ElfEntity elf) {
        UUID id = p.getUUID();
        if (BY_PLAYER.containsKey(id)) {
            cancel(p); // asking again cancels
            return;
        }
        if (elf == null || elf.getCompanionId() == null || !Cfg.COMMON.stargazeEnabled.get()) return;
        ServerLevel level = p.serverLevel();
        if (level.dimensionType().hasFixedTime() || !level.dimensionType().hasSkyLight()) {
            fail(p, "stargaze.no_sky");
            return;
        }
        if (Cfg.COMMON.stargazeOnlyAtNight.get() && !StargazeMath.inWindow(level.getDayTime(),
                Cfg.COMMON.stargazeStartTick.get(), Cfg.COMMON.stargazeEndTick.get())) {
            fail(p, "stargaze.daytime");
            return;
        }
        SeatFinder.Seat seat = SeatFinder.find(level, elf, p);
        if (seat == null) {
            fail(p, "stargaze.no_seat");
            return;
        }
        Job j = new Job(id, elf.getCompanionId(), elf.getId(), seat);
        j.prevStance = elf.getStance();
        if (j.prevStance == 1) elf.setStance(0); // stand up so she can walk
        j.phaseStart = p.server.getTickCount();
        BY_PLAYER.put(id, j);
        BY_ELF.put(j.elfId, j);
        TouchDialogue.line(elf, "stargaze_start");
        p.displayClientMessage(Component.translatable("message.elven_companions.stargaze.searching"), true);
        send(p, j, j.phase);
    }

    public static void cancel(ServerPlayer p) {
        Job j = BY_PLAYER.get(p.getUUID());
        if (j != null) end(p.server, j, p, null, null, true);
    }

    // ------------------------------------------------------------------ end

    private static void end(MinecraftServer server, Job j, ServerPlayer known, String msgKey, String elfLine, boolean online) {
        if (!BY_PLAYER.remove(j.player, j)) return;
        BY_ELF.remove(j.elfId, j);
        ServerPlayer p = known != null ? known : server.getPlayerList().getPlayer(j.player);
        if (j.stand != null) {
            if (p != null && p.getVehicle() == j.stand) p.stopRiding();
            SEATS.remove(j.stand.getUUID());
            j.stand.discard();
            j.stand = null;
        }
        ElfEntity elf = ElfManager.LOADED.get(j.elfId);
        if (elf != null && elf.isAlive()) {
            elf.getNavigation().stop();
            if (elf.getStance() != j.prevStance) elf.setStance(j.prevStance); // stands her up (or keeps her seated if she started seated)
            if (elfLine != null) TouchDialogue.line(elf, elfLine);
        }
        if (p != null) {
            ModeGuard.Holder.get().exit(p, online);
            if (online) {
                send(p, j, StargazeMath.PHASE_END);
                if (msgKey != null) fail(p, msgKey);
            }
        }
    }

    // ------------------------------------------------------------------ tick

    private static void holdSeated(ElfEntity elf, Job j) {
        Vec3 s = j.seat.elf();
        float yaw = j.seat.yaw();
        if (elf.position().distanceToSqr(s) > 0.04) elf.moveTo(s.x, s.y, s.z, yaw, 0f);
        elf.getNavigation().stop();
        elf.setDeltaMovement(0, 0, 0);
        elf.setYRot(yaw);
        elf.yBodyRot = yaw;
        elf.setYHeadRot(yaw);
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        if (BY_PLAYER.isEmpty()) return;
        MinecraftServer server = e.getServer();
        int tick = server.getTickCount();
        for (Job j : new ArrayList<>(BY_PLAYER.values())) {
            ServerPlayer p = server.getPlayerList().getPlayer(j.player);
            ElfEntity elf = ElfManager.LOADED.get(j.elfId);
            if (p == null || !p.isAlive() || elf == null || !elf.isAlive() || elf.isRemoved() || elf.level() != p.level()) {
                end(server, j, p, null, null, p != null);
                continue;
            }
            if (elf.getTarget() != null || elf.getRestState() != 0 || elf.isCarried() || elf.isMounted()) {
                end(server, j, p, "stargaze.interrupted", null, true);
                continue;
            }
            int age = tick - j.phaseStart;
            Vec3 s = j.seat.elf();
            switch (j.phase) {
                case StargazeMath.PHASE_SEARCH -> {
                    elf.getNavigation().stop();
                    if (age >= StargazeMath.SEARCH_TICKS) {
                        j.phase = StargazeMath.PHASE_WALK;
                        j.phaseStart = tick;
                        send(p, j, j.phase);
                        p.displayClientMessage(Component.translatable("message.elven_companions.stargaze.walking"), true);
                    }
                }
                case StargazeMath.PHASE_WALK -> {
                    double dx = elf.getX() - s.x;
                    double dz = elf.getZ() - s.z;
                    if (age > 20 * Cfg.COMMON.stargazeWalkTimeoutSeconds.get()) {
                        end(server, j, p, "stargaze.giveup", "stargaze_giveup", true);
                    } else if (dx * dx + dz * dz <= ARRIVE_DIST * ARRIVE_DIST && Math.abs(elf.getY() - s.y) <= 1.3) {
                        elf.getNavigation().stop();
                        elf.moveTo(s.x, s.y, s.z, j.seat.yaw(), 0f);
                        elf.setStance(1); // her own sit pose
                        j.phase = StargazeMath.PHASE_SEATED;
                        j.phaseStart = tick;
                        send(p, j, j.phase);
                        TouchDialogue.line(elf, "stargaze_arrive");
                        p.displayClientMessage(Component.translatable("message.elven_companions.stargaze.arrived"), true);
                    }
                }
                case StargazeMath.PHASE_SEATED -> {
                    holdSeated(elf, j);
                    double near = Math.hypot(p.getX() - s.x, p.getZ() - s.z);
                    if (near <= Cfg.COMMON.stargazeJoinDistance.get() && Math.abs(p.getY() - s.y) < 2.5
                            && !p.isPassenger() && !p.isSleeping()) {
                        startScript(p, elf, j, tick);
                    } else if (age > 20 * Cfg.COMMON.stargazeWaitTimeoutSeconds.get()) {
                        end(server, j, p, "stargaze.timeout", "stargaze_timeout", true);
                    }
                }
                case StargazeMath.PHASE_SCRIPT, StargazeMath.PHASE_HOLD -> {
                    holdSeated(elf, j);
                    if (j.stand == null || j.stand.isRemoved() || p.getVehicle() != j.stand) {
                        end(server, j, p, null, null, true); // you sneaked (vanilla dismount) or were moved off the seat
                        continue;
                    }
                    if (j.phase == StargazeMath.PHASE_SCRIPT
                            && age >= StargazeMath.scriptLength(Cfg.COMMON.stargazeGazeAtElfTicks.get())) {
                        toHold(server, p, elf, j, tick);
                    }
                }
                default -> { }
            }
        }
    }

    private static void startScript(ServerPlayer p, ElfEntity elf, Job j, int tick) {
        Vec3 pp = j.seat.player();
        float yaw = j.seat.yaw();
        ServerLevel level = p.serverLevel();
        ArmorStand stand = new ArmorStand(level, pp.x, pp.y, pp.z);
        // setSmall(boolean) is private in this Minecraft version. Apply the same
        // vanilla Small flag through the entity's supported NBT load path.
        CompoundTag standData = stand.saveWithoutId(new CompoundTag());
        standData.putBoolean("Small", true);
        stand.load(standData);
        stand.refreshDimensions();
        stand.setPos(pp.x, StargazeMath.seatStandY(pp.y, stand.getBbHeight(), Cfg.COMMON.stargazeSeatYOffset.get()), pp.z);
        stand.setInvisible(true);
        stand.setNoGravity(true);
        stand.setSilent(true);
        stand.setInvulnerable(true);
        stand.setYRot(yaw);
        stand.addTag(SEAT_TAG);
        SEATS.add(stand.getUUID());
        level.addFreshEntity(stand);
        p.teleportTo(level, pp.x, pp.y, pp.z, yaw, 0f);
        if (!p.startRiding(stand, true)) {
            SEATS.remove(stand.getUUID());
            stand.discard();
            end(p.server, j, p, "stargaze.interrupted", null, true);
            return;
        }
        j.stand = stand;
        Vec3 s = j.seat.elf();
        j.side = StargazeMath.sideOf(s.x - pp.x, s.z - pp.z, yaw); // which side of YOU she is on
        ModeGuard.Holder.get().enter(p);
        j.phase = StargazeMath.PHASE_SCRIPT;
        j.phaseStart = tick;
        send(p, j, j.phase);
        TouchDialogue.line(elf, "stargaze_join");
    }

    private static void toHold(MinecraftServer server, ServerPlayer p, ElfEntity elf, Job j, int tick) {
        InteractionType type = InteractionType.STARGAZE;
        BondData bond = BondData.get(server);
        long now = server.overworld().getGameTime();
        bond.setCooldown(j.elfId, type, now + Math.round(type.cooldownTicks * Cfg.COMMON.cooldownMultiplier.get().floatValue()));
        boolean up = bond.add(j.elfId, Math.round(type.affection * Cfg.COMMON.affectionMultiplier.get().floatValue()));
        int lvl = bond.level(j.elfId);
        if (Cfg.COMMON.healOnInteract.get()) elf.heal(1.0F + lvl);
        if (Cfg.COMMON.particles.get() && elf.level() instanceof ServerLevel sl) {
            sl.sendParticles(up ? ParticleTypes.HAPPY_VILLAGER : ParticleTypes.HEART, elf.getX(), elf.getY() + elf.getBbHeight() * 0.7,
                    elf.getZ(), up ? 10 : 5, 0.3, 0.2, 0.3, 0.02);
        }
        if (Cfg.COMMON.sounds.get()) {
            elf.level().playSound(null, elf.getX(), elf.getY(), elf.getZ(), up ? SoundEvents.PLAYER_LEVELUP : SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.NEUTRAL, up ? 0.5F : 0.6F, 1.0F);
        }
        ElfDialogue.say(elf, "interact_stargaze");
        if (up) {
            p.sendSystemMessage(Component.translatable("message.elven_companions.bond_up", elf.getDisplayName(),
                    Component.translatable("gui.elven_companions.interact.bond." + lvl)));
            ElfDialogue.say(elf, "bond_up");
        }
        InteractionManager.sendBond(p, elf);
        j.phase = StargazeMath.PHASE_HOLD;
        j.phaseStart = tick;
        send(p, j, j.phase);
    }

    private static void send(ServerPlayer p, Job j, int phase) {
        PacketDistributor.sendToPlayer(p, new InteractNet.StargazeStateS2C(j.elfEntityId, phase, j.side,
                Cfg.COMMON.stargazeGazeAtElfTicks.get()), new CustomPacketPayload[0]);
    }

    // ------------------------------------------------------------------ interruptions

    @SubscribeEvent
    public static void onDamaged(LivingDamageEvent.Post e) {
        if (BY_PLAYER.isEmpty()) return;
        if (e.getEntity() instanceof ServerPlayer sp) {
            Job j = BY_PLAYER.get(sp.getUUID());
            if (j != null) end(sp.server, j, sp, "stargaze.interrupted", null, true);
        } else if (e.getEntity() instanceof ElfEntity elf && elf.getCompanionId() != null) {
            Job j = BY_ELF.get(elf.getCompanionId());
            if (j != null && elf.getServer() != null) {
                end(elf.getServer(), j, null, "stargaze.interrupted", null, true);
            }
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!BY_PLAYER.isEmpty() && e.getEntity() instanceof ServerPlayer sp) cancel(sp);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            Job j = BY_PLAYER.get(sp.getUUID());
            if (j != null) end(sp.server, j, sp, null, null, false);
        }
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) cancel(sp);
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        for (Job j : new ArrayList<>(BY_PLAYER.values())) end(e.getServer(), j, null, null, null, false);
        BY_PLAYER.clear();
        BY_ELF.clear();
        SEATS.clear();
    }

    /** A seat entity that is not owned by a running job (left over after a crash) is not allowed back into the world. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (e.getEntity() instanceof ArmorStand a && a.getTags().contains(SEAT_TAG) && !SEATS.contains(a.getUUID())) {
            e.setCanceled(true);
        }
    }
}
